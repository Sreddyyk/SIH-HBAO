function out=c_valid(in)
sz=size(in);
out=in;
for i=1:sz(1)
    arr=in(i,:);
    [srt,loc]=sort(arr);
    mx=arr(loc(end))+arr(loc(end-1));
    out(i,i)=mx;
end
end