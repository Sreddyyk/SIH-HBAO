function k=SIH_demo(image)
c=0.1;alpha=0.2;r=rand;
image=im2double(image);
% im1=image'; aa=im1.CData;
% im=imresize(im1,[256 256]);
im=image';
a=image*im+c;
as=image*im*alpha+r;
as1=tanh(as);
ad=image*im*alpha+c;
k=a+as1+ad;
% f=imhist(k,25);


