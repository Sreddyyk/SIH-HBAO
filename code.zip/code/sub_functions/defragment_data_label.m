function [outdata,outlabel]=defragment_data_label(data,labels)
%output data and labels are sorted(defragmented) according to the unique label classes.

u_lab=unique(labels);
n_lab=length(u_lab);
outdata=[];
outlabel=[];

for cur_lab=1:n_lab
    logi=labels==u_lab(cur_lab);
    feat_now=data(logi,:);
    lab_now=labels(logi);
    
outdata=[outdata;feat_now];
outlabel=[outlabel;lab_now];

end

end