function f=SIH(image)
c=0.1;alpha=0.2;r=rand;
a=image.*image'+c;
as=image*image'*alpha+r;
as1=tanh(as);
ad=image*image'*alpha+c;
k=a+as1+ad;
f=imhist(k,25);


