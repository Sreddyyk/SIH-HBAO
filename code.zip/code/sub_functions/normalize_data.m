function out=normalize_data(data,varargin)
% This function normalize the data between 0 and 1
% input data is the array of numerical data.
% if optional argument is 1 -----> normalize the data between -1 and 1
% if optional argument is 2 -----> standardize the data.

% if optional argument is 3 -----> normalize the data between 0 and 1 along each column.
% if optional argument is 4 -----> normalize the data between -1 and 1 along each column.
% if optional argument is 5 -----> standardize along each column.
out=[];
data_all=data(:);
sz=size(data);
if nargin==2
    if varargin{1}==1
        %--- normalize data between -1 and 1 ---
        data_min=min(data_all);
        data_max=max(data_all);
        out=(data_all-data_min)./(data_max-data_min);
        out=reshape(out,sz);
        out=-1+2*out;
        return
    end
    if varargin{1}==2
        %--- standardize data(mean is 0 and standard deviation is 1) ---
        data_meaned=data_all-mean(data_all);
        out=data_meaned./std(data_all);
        out=reshape(out,sz);
        return
    end
    if varargin{1}==3
        %--- normalize data between 0 and 1 along column ---
        for i=1:sz(2)
        data_min=min(data(:,i));
        data_max=max(data(:,i));
        out(:,i)=(data(:,i)-data_min)./(data_max-data_min);
        end
        return
    end
    if varargin{1}==4
        %--- normalize data between -1 and 1 along column ---
        for i=1:sz(2)
        data_min=min(data(:,i));
        data_max=max(data(:,i));
        out(:,i)=(data(:,i)-data_min)./(data_max-data_min);
        out(:,i)=-1+2*out(:,i);
        end
        return
    end
    if varargin{1}==5
        %--- standardize data along column ---
        for i=1:sz(2)
        data_meaned=data(:,i)-mean(data(:,i));
        out(:,i)=data_meaned./std(data(:,i));
        end
        return
    end
end
data_min=min(data_all);
data_max=max(data_all);
out=(data_all-data_min)./(data_max-data_min);
out=reshape(out,sz);

end
