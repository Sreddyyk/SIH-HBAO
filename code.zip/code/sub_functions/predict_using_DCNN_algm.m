function outlab1=predict_using_DCNN_algm(feat,tr_lab,feat_test,tst_lab,unique_name,reget_flag,n)
if ndims(feat)<3
tr_data=convert2cnndata(feat);
tst_data=convert2cnndata(feat_test);
end

sz_in=size(tr_data);
sz_in=sz_in(1:3);
tst_data_in=tst_data;
% lab_all=tst_lab;
YPred=tst_lab;
sav_folder='net_saved';
if exist(fullfile(pwd,sav_folder),'dir')~= 7
    mkdir(fullfile(pwd,sav_folder));
end

sav_name=sprintf('net_cnn_%s.mat',unique_name);
if (exist(fullfile(pwd,sav_folder,sav_name))~=2)||(reget_flag==1)
n_outlab=numel(unique(tr_lab));

layers = [
    imageInputLayer(sz_in)
    
    convolution2dLayer(3,8,'Padding',1)
    batchNormalizationLayer
    reluLayer

    maxPooling2dLayer(5,'Stride',1)
%     
    convolution2dLayer(3,16,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',1)
    
    convolution2dLayer(3,32,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    fullyConnectedLayer(n_outlab)
    softmaxLayer
    classificationLayer];

% options = trainingOptions('sgdm', ...
%     'MaxEpochs',4, ...
% %     'ValidationData',tst_data, 
% %     'ValidationFrequency',30, 
%     'Verbose',false, ...
%     'Plots','training-progress');

options = trainingOptions('adam','MaxEpochs',100,'Verbose',true);

labels=categorical(tr_lab);
net = trainNetwork_mod(tr_data,labels,layers,options);

% Classify Validation Images and Compute Accuracy
save(fullfile(pwd,sav_folder,sav_name),'net');
else
net=load(fullfile(pwd,sav_folder,sav_name));net=net.net;
end
YPred1 = classify(net,tst_data_in);
outlab1=double(YPred);
% outlab=str2num_label(unique(lab_all),YPred);
% accuracy = sum(YPred == categorical(lab_all))/length(lab_all)

function out=convert2cnndata(tr_data)
   out=[];
   for i=1:size(tr_data,1)
%         out(:,:,:,i)=repmat(tr_data(i,:),[10,1]);
a=imresize(tr_data(i,:),[10,288]);
a1=repmat(a,[1,1,1]);
     out(:,:,:,i)=a1;
   end
end

end
