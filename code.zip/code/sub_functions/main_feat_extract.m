function main_feat_extract
%%%%read datset here
dname = 'DME FINAL DB';
feat_all=[];
f = dir(dname);
f = f(3:end);
for i = 1:numel(f)
    disp(i)
    jj=strcat(dname,'\',f(i).name,'\');
    d=dir(jj);
    for j = 3:numel(d)
        %read input data here
        I =  imread(strcat(jj,d(j).name));
        %resize the input data
        I = imresize(I,[256 256]);
        %convert the image into grayscale
        I1 = rgb2gray(I);
        %%apply preprocessing
        B1 = im2double(imgaussfilt(I1));
        level = graythresh(B1) ;
        msk = imbinarize(B1,level);
        %%%%segmentation
        bw = activecontour(B1,msk,300);
        R = corr2(B1,msk);
        R1 = corr2(B1,bw);
        if R>=R1
            image=bw;
        else
            image=msk;
        end
        %%%feature extraction
        %find mean
        f1 = mean2(image);
        %  find varience
        f2=mean(var(image));
        %find reflectivity
        R = reflectivity(image);
        %calculate histogram
        f31=imhist(R,25);f3=f31';
        f4=nnz(image);
        f5 = mean(unique(image));
        im=im2double(imgaussfilt(image./255));
        f6=mean(im);
        %apply fft
        Y = fft2(image);
        f71=imhist(Y,25); f7=f71';
        [cA,cH,cV,cD] = dwt2(image,'sym4','mode','per');
        %calculate histogram for each region
        f81=imhist(cA,25);f8=f81';
        f91=imhist(cH,25);f9=f91';
        f101=imhist(cV,25);f10=f101';
        f111=imhist(cD,25);f11=f111';
        %apply LGP feature extraction
        ll=LGP(image);
        f121=imhist(ll,25); f12=f121';
        %    Apply SIH
        f131=SIH(image);f13=f131';
        if i==4
            lab=1;
        else
            lab=0;
        end
        %%%%concardinate all features
        feat_all=[feat_all;f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,lab,i];
    end
end
save('feat_all','feat_all')
feat_full=load(sprintf('feat_all'));feat_full=feat_full.feat_all;
feat_all=feat_full(:,1:end-1);
lab_all=feat_full(:,end);
feat_all=normalize_data(feat_all,3);

tr_per=0.4;
tr_increment=0.1;
% tr_per=0.3;
% tr_increment=0.1;
for i=1:5
    i
    %%%%---------get training and test data--------------
    tr_per=tr_per+tr_increment;
    tst_per=1;
    [tr_data,tr_lab,tst_data,tst_lab]=split_data_label_uniquly(feat_all,lab_all,tr_per,tst_per);
    [feat_all,lab_all]=defragment_data_label(feat_all,lab_all);
    tst_data=feat_all;
    tst_lab=lab_all;
    
    %------CNN proposed running ---------------
    disp('CNN proposed running.')
    
    outlab_5=predict_using_DCNN_algm(tr_data,tr_lab,tst_data,tst_lab,'cnn_pro',0,100);
    
    uq_tst=unique(tst_lab);
    
    [c_matrix,Result5,RR5]= confusion.getMatrix(tst_lab,outlab_5);
    
    acc_all(i,:)=sum(RR5.AccuracyInTotal);
    sen_all(i,:)=mean(RR5.Sensitivity);
    spe_all(i,:)=mean(RR5.Specificity);
end

out.acc=acc_all;
out.sen=sen_all;
out.spe=spe_all;

save('result_per11','out');














