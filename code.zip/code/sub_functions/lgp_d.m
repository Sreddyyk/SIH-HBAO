function [LL,L] = lgp_d(I)
% I=imresize(I,[32 32]);
I = double(I);

L = [];
for ch = 1:size(I,3)
    
    Ic = im2col(padarray(I(:,:,ch),[1 1],'replicate','both'),[3,3],'sliding');
    Gr = abs(Ic([1:4 6:9],:)-repmat(Ic(5,:),[8,1]));
    Th = sum(Gr,1)/8;
    Bits = Gr>repmat(Th,[8,1]);
    
    L =bi2de(Bits');% [L;imhist(uint8(bi2de(Bits')))];
    
end
L=reshape(L,size(I,1),size(I,2));
% L = L/(size(I,1)*size(I,2));

LL=imhist(uint8(L),8);
LL=LL';
end