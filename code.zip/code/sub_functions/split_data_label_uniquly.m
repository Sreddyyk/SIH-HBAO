function [tr_data,tr_lab,tst_data,tst_lab]=split_data_label_uniquly(data,labels,tr_per,tst_per)
%this function splits the data using given Training percentage 'tr_per' and split remaining data using testing percentage 'tst_per'
%output data and labels are sorted(defragmented) according to the unique label classes.
u_lab=unique(labels);
n_lab=length(u_lab);

% sz_feat=size(data);
% tr_upto=round(tr_per.*sz_feat(1));
% tst_upto=round(tst_per.*(sz_feat(1)-tr_upto));


tr_data=[];
tr_lab=[];
tst_data=[];
tst_lab=[];

% logi=labels==u_lab(1);
% feat_now=data(logi,:);
% lab_now=labels(logi);
% tr_data=feat_now(1:tr_upto,:);
% tr_lab=lab_now(1:tr_upto,:);
% tst_data=feat_now(tr_upto+1:tr_upto+tst_upto,:);
% tst_lab=lab_now(tr_upto+1:tr_upto+tst_upto,:);   

for cur_lab=1:n_lab
    logi=labels==u_lab(cur_lab);
    feat_now=data(logi,:);
    lab_now=labels(logi);
    
    sz_feat=size(feat_now);
    tr_upto=round(tr_per.*sz_feat(1));
    tst_upto=round(tst_per.*(sz_feat(1)-tr_upto));

tr_d=feat_now(1:tr_upto,:);
tr_l=lab_now(1:tr_upto,:);
tst_d=feat_now(tr_upto+1:tr_upto+tst_upto,:);
tst_l=lab_now(tr_upto+1:tr_upto+tst_upto,:);

tr_data=[tr_data;tr_d];
tr_lab=[tr_lab;tr_l];
tst_data=[tst_data;tst_d];
tst_lab=[tst_lab;tst_l];

end

end