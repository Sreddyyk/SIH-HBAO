function [cm]=choose_colormap(length_in,choice)
% MATLAB COLORMAPS
% 
% 1. parula
% 2. jet
% 3. hsv
% 4. hot
% 5. cool
% 6. spring
% 7. summer
% 8. autumn
% 9. winter
% 10. gray
% 11. bone
% 12. copper
% 13. pink
% 14. lines
% 15. colorcube
% 16. prism
% 17. flag
% 18. white
% 19. custom 1 (dark pale standard)
% 20. custom 2 (dark light pale standard)
% 21. custom 3 (vivid pale standard)
% 22. custom 4 (google colors)
% 23. custom 5 (basel (color from piratepal of R))
% 24. custom 6 (bony (color from piratepal of R))
% 25. custom 7 (xmen (color from piratepal of R))

switch(choice)
    case 1
        cm = parula(length_in);
    case 2
        cm = jet(length_in);
    case 3
        cm = hsv(length_in);
    case 4
        cm = hot(length_in);
    case 5
        cm = cool(length_in);
    case 6
        cm = spring(length_in);
    case 7
        cm = summer(length_in);
    case 8
        cm = autumn(length_in);
    case 9
        cm = winter(length_in);
    case 10
        cm = gray(length_in);
    case 11
        cm = bone(length_in);
    case 12
        cm = copper(length_in);
    case 13
        cm = pink(length_in);
    case 14
        cm = lines(length_in);
    case 15
        cm = colorcube(length_in);
    case 16
        cm = prism(length_in);
    case 17
        cm = flag(length_in);
    case 18
        cm = white(length_in);
    case 19
        cm=custom_color_1(length_in);%dark pale standard
    case 20
        cm=custom_color_2(length_in);%dark light pale standard
    case 21
        cm=custom_color_3(length_in);%vivid pale standard
    case 22
        cm=custom_color_4(length_in);%google colors
    case 23
        cm=custom_color_5(length_in);%basel (color from piratepal of R)
    case 24
        cm=custom_color_6(length_in);%bony (color from piratepal of R)
    case 25
        cm=custom_color_7(length_in);%xmen (color from piratepal of R)
end

    function out=custom_color_1(length_in)
        color_aray=[
            0,0,0;%black
            0.1961,0.5961,0.3176;%pale green
            0.5882,0,0.7843;%pale violet
            1,0,0;%red
            0,0,1;%blue
            0.5,0.25,0.25;%dark brown
            0,0.59,0.59;%pale greenish blue
            0.8235,0.5804,0;%yellowish dark orange
            0.6824,0.6039,0.1569%
            ];
        out=color_aray(1:length_in,:);
    end
    function out=custom_color_2(length_in)
        color_aray=[
            0,0.5,1;%dark sky blue
            1,0.5,0.25;%light gray orange
            0,0.5,0.25;%dark gray green
            1,0,1;
            0.5,0.25,0.25;%dark gray brown
            0.5,0,1;%red
%             0.6024,0.6039,0.1069;%red
            0.5,0.5,0.5;%medium gray
            1,0.5,1;%light pink
            ];
        out=color_aray(1:length_in,:);
    end
    function out=custom_color_3(length_in)
        color_aray=[
            1,0,0.5;%pink vivid
            0,0.5,1;%blue vivid
            0,1,0.5;%green vivid
            1,0.5,0;%orange
            0.5,0.5,0;%greenish yellow
            0.5,0.25,0.25;%dark pale brown
            0.88,0.88,0;
            0.5,0.5,0.5;%gray
            ];
        out=color_aray(1:length_in,:);
    end
    function out=custom_color_4(length_in)
        color_aray=[
            66,133,244;%blue
            219,68,55;%blue
            244,160,0;%green
            15,157,88;%
            0,0,0;%
             0.5,0.25,0.25;%dark pale brown
%             0.88,0.88,0;
             227,55,127;%pink
			 131,21,122;%violet
            ]./255;
        out=color_aray(1:length_in,:);
    end
    function out=custom_color_5(length_in)
        color_aray=[
            14,69,160;%blue
            230,0,16;%red
            25,138,47;%green
            228,59,136;%pink
            246,84,13;%orange
            24,135,232;%light blue
            145,191,26;%light green
            252,181,15
            0,0,0;%black
            ]./255;
        out=color_aray(1:length_in,:);
    end
    function out=custom_color_6(length_in)
        color_aray=[
            227,55,127;%pink
            248,173,86;%sandel
            241,169,196;%light pink
            141,209,242;%light blue
            80,59,142;%dark violet
            231,237,241;%slight gray
            254,248,141;%slight sandel
            25,128,195%blue
            131,21,122;%violet
            ]./255;
        out=color_aray(1:length_in,:);
    end
    function out=custom_color_7(length_in)
        color_aray=[
            11,85,191;%blue
            239,0,8;%red
            23,166,5;%green
            248,141,66;%orange
            137,137,137;%gray
            247,104,176;%pink
            170,78,26;%brown
            25,128,195%yellow
            233,183,32;%violet
            ]./255;
        out=color_aray(1:length_in,:);
    end
end