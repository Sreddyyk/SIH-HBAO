function validateClasses( value )
% validateClasses   Throw an error if the value for Classes is not valid.

%   Copyright 2018 The MathWorks, Inc.

if ~iIsAuto(value)
    if ~isvector(value) || ~iIsValidDataType(value)
        error(message('nnet_cnn:layer:ClassificationOutputLayer:InvalidClasses'));
    end
    if iHasDuplicates(value)
         error(message('nnet_cnn:layer:ClassificationOutputLayer:DuplicateClasses'));
    end
end
end

function tf = iIsAuto(val)
tf = isequal(string(val), "auto");
end

function tf = iIsValidDataType(value)
tf = iscategorical(value) || iscellstr(value) || isstring(value);
end

function tf = iHasDuplicates(value)
tf = ~isequal(value, unique(value, 'stable'));
end