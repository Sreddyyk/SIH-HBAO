classdef NoQuantization < nnet.internal.cnn.layer.Quantization
% NoQuantization   Quantization that performs no quantization
    
%   Copyright 2018 The MathWorks, Inc.
    
    properties(Constant)
        Name = 'None'
    end
    
    methods
        function varargout = quantize( ~, varargin )
        % Quantize   Quantize parameters
        %
        % [A, B, ...] = quantize( this, a, b, ... )
        varargout = varargin ;
        end
        
        function varargout = remapped( ~, varargin )
        % Remapped   Quantize parameters and remap back to single
        %
        % [A, B, ...] = remapped( this, a, b, ... )
        varargout = varargin ;
        end
    end
end

