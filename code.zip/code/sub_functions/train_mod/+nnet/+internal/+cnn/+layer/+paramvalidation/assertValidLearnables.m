function assertValidLearnables(value, sz)
%assertValidLearnables   Validate a single learnable value
%
% assertValidLearnables(value, size) tests that the dlarray in value is a
% valid learnable value with the correct size.

%   Copyright 2019 The MathWorks, Inc.

% Class of the value should be checked by the system that this layer is
% being used in.  

% Contents of the dlarray may be any supported numeric dlarray-contents
% class. We don't want to allow logicals.
if islogical(value)
    % Use a (slow) call to validateattributes to generate a standard
    % class-mismatch error
    validateattributes(gather(extractdata(value)), {'single', 'double'}, {});
end

if ~isequal(size(value), sz)
    % Use a (slow) call to validateattributes to generate a standard
    % size-mismatch error
    validateattributes(value, {class(value)}, {'size', sz});
end

end
