classdef GlobalAveragePoolingStrategy < nnet.internal.cnn.layer.util...
        .ExecutionStrategy
    % GlobalAveragePoolingStrategy   Propagation functions for global
    % average pooling. 
    %
    %   The global average pooling computes the mean over the spatial
    %   dimension of an input with size n1 x ... x nD x C x N, where C is
    %   number of channels and N the number of samples. The output size is
    %   1 x ... x 1 x C x N.
    %
    %   These functions are used for both CPU and GPU implementations.
    %   
    %   Properties:
    %       NumDims   The number of spatial dimensions of the input.
    %       E.g. for images, NumDims = 2.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(Access=private)
        NumDims
    end
    
    methods
        function this = GlobalAveragePoolingStrategy(numDims)
            this.NumDims = numDims;
        end
        
        function Z = forward(this, X)
            Z = mean(X, 1:this.NumDims);
        end
        
        function dX = backward(this, X, dZ)
            sz = arrayfun(@(i) size(X,i), 1:(this.NumDims+2));
            dX = 1/prod(sz(1:this.NumDims)) * ones(sz) .* dZ;
        end
    end
end
