classdef RandomCropImageTransform < nnet.internal.cnn.layer.InputTransform
    % RandomCropImageTransform   Image transform for random crops
    %   This class randomly crops an image to the size specified during
    %   construction. This size should equal the input size of the image input
    %   layer.
    
    %   Copyright 2015-2019 The MathWorks, Inc.
    
    properties (Constant)
        Type = 'randcrop';
        Hyperparams = {};
    end
    
    properties   
        % DataSize   Size of the image that this transform will transform
        DataSize
        
        % CropSize   Height and width of the cropped image.
        CropSize
    end
    
    methods
        %------------------------------------------------------------------
        % Return a random crop transform. Input is the size of the cropped
        % image and should equal the size of the input image layer when
        % used in a network.
        %------------------------------------------------------------------
        function this = RandomCropImageTransform(inputImageSize)
            this.DataSize = inputImageSize;
            this.CropSize = inputImageSize(1:2);                         
        end
        
        %------------------------------------------------------------------
        % serialize   Serialize an image transform to a structure 
        %------------------------------------------------------------------
        function S = serialize( this )
            S.Version = 1.0;
            S.Type = this.Type;
            S.ImageSize = this.DataSize;
        end

        function outputSize = forwardPropagateSize(this, inputSize)
            if(~this.inputSizeIsGreaterThanOrEqualToCropSize(inputSize))
                outputSize = NaN(1, 3);
            else
                outputSize = [this.CropSize inputSize(3)];
            end
        end
    end
    
    methods(Access = protected)
        
        %------------------------------------------------------------------
        % Transform implementation. Input is a batch of images. Output is a
        % batch of randomly cropped images.
        %------------------------------------------------------------------
        function y = doTransform(this, batch)
            
            % Size of images in batch.
            [M, N, C, numImagesInBatch] = size(batch);
            
            maxShift = [M N] - this.CropSize;
            
            % random translations for cropping
            rowShift = this.randomShift(maxShift(1), numImagesInBatch);
            colShift = this.randomShift(maxShift(2), numImagesInBatch);
            
            rowRange = bsxfun(@plus, 1:this.CropSize(1), rowShift);
            colRange = bsxfun(@plus, 1:this.CropSize(2), colShift);
            
            y = zeros(...
                [this.CropSize C numImagesInBatch], ...
                'like', batch);
            
            for i = 1:numImagesInBatch
                r = rowRange(i,:);
                c = colRange(i,:);
                % Crop image
                y(:,:,:,i) = batch(r,c,:,i);
            end
        end
        
        %------------------------------------------------------------------
        % Return random shifts to apply to the image. Overloading this
        % method is useful for testing.
        %------------------------------------------------------------------
        function indices = randomShift(~, imax, N)
            indices = randi([0 imax], N, 1);
        end
        
        function tf = inputSizeIsGreaterThanOrEqualToCropSize(this, inputSize)
            tf = (inputSize(1) >= this.CropSize(1)) && (inputSize(2) >= this.CropSize(2));
        end
    end
end

