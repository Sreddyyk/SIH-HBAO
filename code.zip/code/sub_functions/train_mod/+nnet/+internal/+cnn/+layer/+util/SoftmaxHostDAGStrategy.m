classdef SoftmaxHostDAGStrategy < nnet.internal.cnn.layer.util.SoftmaxDAGStrategy
    % SoftmaxHostDAGStrategy   Execution strategy for running the softmax
    % layer on the host

    %   Copyright 2019 The MathWorks, Inc.
        
    methods
        function [X, memory] = forward(~, X, channelDim)
            X = nnet.internal.cnnhost.softmaxForward(X, channelDim);
            memory = [];
        end
        
        function [dZ, dW] = backward(~, Z, dZ, channelDim)
            Z = nnet.internal.cnn.util.boundAwayFromZero(Z);
            dZ = nnet.internal.cnnhost.softmaxBackward(Z, dZ, channelDim);
            dW = [];
        end
    end
    
end