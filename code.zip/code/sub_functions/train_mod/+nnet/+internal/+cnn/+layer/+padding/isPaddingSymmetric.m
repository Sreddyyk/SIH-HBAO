function tf = isPaddingSymmetric(paddingSize)
% isPaddingSymmetric   Determine if padding is Symmetric or not
%
%   tf = isPaddingSymmetric(paddingSize) returns true if padding is
%   symmetric and false if it is asymmetric.
%
%   Input:
%       paddingSize             - A 1-by-2xN vector for the padding in the 
%                                 format [dim1Start dim1End dim2Start dim2End dim3Start...].
%
%   Output:
%       tf                      - True if padding is symmetric, false if it
%                                 is asymmetric.

%   Copyright 2017-2018 The MathWorks, Inc.
 
tf = true;
 for i=1:2:(length(paddingSize)-1)
     
     tf = tf && ( paddingSize(i) == paddingSize(i+1) );
     
 end
end