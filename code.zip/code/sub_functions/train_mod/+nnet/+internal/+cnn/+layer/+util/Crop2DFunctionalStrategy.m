classdef Crop2DFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy
    % Crop2DFunctionalStrategy    dlarray method strategy
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        % Strategy to use for cropping (center or manual).
        CropStrategy
    end
    
    methods
        %------------------------------------------------------------------
        function this = Crop2DFunctionalStrategy(cropStrategy)
            this.CropStrategy = cropStrategy;
        end
        
        %------------------------------------------------------------------
        function  [Z, memory] = forward(this, X)
            Z = this.CropStrategy.forward(X);
            memory = [];
        end
    end
end