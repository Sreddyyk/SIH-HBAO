function heightWidthAndDepthPadding = calculateHeightWidthAndDepthPadding(paddingSize)
% calculateHeightWidthAndDepthPadding   Calculate the padding along the height,
% width and depth
%
%   heightAndWidthPadding = calculateHeightAndWidthPadding(paddingSize)
%   takes the 1-by-6 vector paddingSize and returns the 1-by-3 vector
%   heightWidthAndDepthPadding.
%
%   Input:
%       paddingSize                  - A 1-by-6 vector for the padding in
%                                      the format [top bottom left right
%                                      front back].
%
%   Output:
%       heightWidthAndDepthPadding   - A 1-by-3 vector for the height,
%                                      width and depth padding in the
%                                      format [height width depth].

%   Copyright 2018 The MathWorks, Inc.

totalPaddingHeight = sum(paddingSize(1:2));
totalPaddingWidth = sum(paddingSize(3:4));
totalPaddingDepth = sum(paddingSize(5:6));
heightWidthAndDepthPadding = [totalPaddingHeight totalPaddingWidth totalPaddingDepth];
end