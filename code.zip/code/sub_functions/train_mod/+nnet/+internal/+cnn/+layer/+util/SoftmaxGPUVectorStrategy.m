classdef SoftmaxGPUVectorStrategy < nnet.internal.cnn.layer.util.SoftmaxGPUDAGStrategy
    % SoftmaxGPUVectorStrategy   Execution strategy for running the softmax
    % layer on the GPU with vector inputs

    %   Copyright 2017-2019 The MathWorks, Inc.
    methods
        function [Z, memory] = forward(this, X, ~)
            [Z, memory] = forward@nnet.internal.cnn.layer.util.SoftmaxGPUDAGStrategy(this, X, 1);
        end
        
        function [dX,dW] = backward(this, Z, dZ, ~)
            [dX, dW] = backward@nnet.internal.cnn.layer.util.SoftmaxGPUDAGStrategy(this, Z, dZ, 1);
        end
    end
end