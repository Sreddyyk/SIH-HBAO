classdef(Abstract) GraphExecutor < nnet.internal.cnn.layer.Layer 
    % GraphExecutor    Base class for executors of layer graphs
    %
    % Used for functional behavior. The derived class has to override
    % the methods unused here whose default behavior is to error if needed.
    %
    % In its current form, it only accepts topologically-sorted segments of
    % the layer graph with a single input (to the first layer in the
    % graph), a single output (from the last layer), and containing no
    % Input or Output layers.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        % Name (char array)   A name for the layer
        Name
    end
    
        
    properties( Dependent )
        % OriginalLayers  The layers being wrapped
        OriginalLayers
    end
    
    properties
        Connections
    end

    properties( Dependent, SetAccess = private )
        % HasSizeDetermined   True for layers with size determined.
        HasSizeDetermined
    end
    
    properties( Access = protected )
        % LayerGraphExecutionInfo   Stores variables needed for efficient
        % execution of the graph
        LayerGraphExecutionInfo
        
        % PrivateOriginalLayers  Concrete copy of the wrapped layers fused
        % by this FusedLayer
        PrivateOriginalLayers        
    end
        
    methods
        function obj = GraphExecutor(name, originalLayerGraph,...
                layerGraphExecutionInfo)
            % Construct from original internal layer graph.
            % Do not compute LayerGraphExecutionInfo if provided.
            
            if nargin == 3
                obj.LayerGraphExecutionInfo = layerGraphExecutionInfo;
            else
                % Validate that layerGraph has correct properties
                assert( isdag(originalLayerGraph.getAugmentedDigraph()), ...
                    "LayerGraph used to create Fused Layer is not a Directed Acyclic Graph" );
                assert( isSorted(originalLayerGraph), ...
                    "LayerGraph used to create Fused Layer is not sorted" );
                
                obj.LayerGraphExecutionInfo = nnet.internal.cnn.util.LayerGraphExecutionInfo(originalLayerGraph);
            end            
            
            obj.Name = name;
            layers = originalLayerGraph.Layers;
            obj.OriginalLayers = layers;
            obj.Connections = originalLayerGraph.Connections;
        end
        
        function layers = get.OriginalLayers( this )
            % When we get the original layers we must update their
            % learnable parameters
            layers = this.restoreLearnables(this.PrivateOriginalLayers);
        end
        
        function this = set.OriginalLayers( this, layers )
            % If we set the OriginalLayers we must update the local copy of
            % the learnable parameters
            this.PrivateOriginalLayers = layers;
            this = cacheLearnables( this );
        end
        
        function tf = get.HasSizeDetermined( this )
            tf = all( cellfun(@(l)l.HasSizeDetermined, this.OriginalLayers) );
        end
       
        % predict   Forward input data through the layer and output the
        % result
        function Z = predict( this, X )
            % Default implementation just predicts on each layer

            listOfBufferInputIndices = this.LayerGraphExecutionInfo.ListOfBufferInputIndices;
            listOfBufferOutputIndices = this.LayerGraphExecutionInfo.ListOfBufferOutputIndices;
            listOfBufferIndicesForClearingForward = this.LayerGraphExecutionInfo.ListOfBufferIndicesForClearingForward;

            % Allocate space for the activations.
            activationsBuffer = cell(this.LayerGraphExecutionInfo.NumActivations,1);
            
            % Loop over topologically sorted layers to perform forward
            % propagation. Clear memory when activations are no longer
            % needed.
            layers = this.OriginalLayers;
            numLayers = numel(layers);
            for i = 1:numLayers
                if i == 1
                        Z = layers{1}.predict(X);
                else
                        XForThisLayer = iGetTheseActivationsFromBuffer( ...
                            activationsBuffer, ...
                            listOfBufferInputIndices{i});
                        Z = layers{i}.predict(XForThisLayer);
                end
                
                activationsBuffer = iAssignToBuffer( ...
                    activationsBuffer, ...
                    listOfBufferOutputIndices{i}, ...
                    Z);
                
                activationsBuffer = iClearActivationsFromBuffer( ...
                    activationsBuffer, ...
                    listOfBufferIndicesForClearingForward{i});
            end
        end
        
        % forward   Forward input data through the layer and output the
        % result.
        function [Z, memory] = forward( this, X )
            % Default implementation just calls forward on each layer and
            % returns the internal activations as a field in the returned
            % memory output

            listOfBufferInputIndices = this.LayerGraphExecutionInfo.ListOfBufferInputIndices;
            listOfBufferOutputIndices = this.LayerGraphExecutionInfo.ListOfBufferOutputIndices;

            % Allocate space for the activations and memory
            numActivations = this.LayerGraphExecutionInfo.NumActivations;
            layers = this.OriginalLayers;
            numLayers = numel(layers);
            activationsBuffer = cell(numActivations,1);
            memoryBuffer = cell(numLayers,1);
            
            % Loop over topologically sorted layers to perform forward
            % propagation.
            for i = 1:numLayers
                if i == 1
                        [Z, memory] = layers{1}.forward(X);
                else
                        XForThisLayer = iGetTheseActivationsFromBuffer( ...
                            activationsBuffer, listOfBufferInputIndices{i});
                        [Z, memory] = layers{i}.forward(XForThisLayer);
                end
                
                outputIndices = listOfBufferOutputIndices{i};
                if i < numLayers
                    % We don't need to buffer the output activations
                    activationsBuffer = iAssignToBuffer( ...
                        activationsBuffer, outputIndices, Z);
                end
                memoryBuffer = iAssignToBuffer( ...
                    memoryBuffer, i, memory );
            end
            
            % The output memory is a combination of the internal memory and
            % the internal activations
            memory = struct( 'internalActivations', {activationsBuffer}, ...
                             'internalMemory', {memoryBuffer} );
        end

        function backward(~)
            iErrorImplementation
        end        
        function forwardPropagateSize(~)
            iErrorImplementation
        end        
        function inferSize(~)
            iErrorImplementation
        end       
        function isValidInputSize(~)
            iErrorImplementation
        end
        function initializeLearnableParameters(~)
            iErrorImplementation
        end        
        function prepareForTraining(~)
            iErrorImplementation
        end
        function prepareForPrediction(~)
            iErrorImplementation
        end 
        function setupForHostPrediction(~)
            iErrorImplementation
        end
        function setupForGPUPrediction(~)
            iErrorImplementation
        end
        function setupForHostTraining(~)
            iErrorImplementation
        end
        function setupForGPUTraining(~)
            iErrorImplementation
        end
    end
    
    %% Overloadable Utilities: default no-op
    methods( Access = protected )
        function this = cacheLearnables( this )
        end
        
        function layers = restoreLearnables( ~, layers )
        end
    end
    
    %% Utilities
    methods( Access = protected )
        function this = callOnLayers( this, F )
            % callOnLayers  Convenience function for modifying the original
            % layers in the fused layer graph
            this.OriginalLayers = cellfun(F, this.OriginalLayers, 'UniformOutput', false);
        end
    end
end

function iErrorImplementation
error('Should not be called')
end

function buffer = iAssignToBuffer( buffer, indices, vals )
if ~isscalar(indices)
    buffer(indices) = vals;
else
    buffer{indices} = vals;
end
end

function XForThisLayer = iGetTheseActivationsFromBuffer(activationsBuffer, inputIndices)
XForThisLayer = activationsBuffer(inputIndices);
if(iscell(XForThisLayer) && (numel(XForThisLayer) == 1))
    XForThisLayer = XForThisLayer{1};
end
end

function activationsBuffer = iClearActivationsFromBuffer(activationsBuffer, indicesToClear)
activationsBuffer = nnet.internal.cnn.util.LayerGraphExecutionInfo.clearActivationsFromBuffer( ...
    activationsBuffer, indicesToClear);
end