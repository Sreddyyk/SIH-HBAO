classdef SequenceFolding < nnet.internal.cnn.layer.Layer
    % SequenceFolding   Sequence folding layer
    %
    % The sequence folding layer combines the observation dimension (N) and
    % the sequence dimension (S) of the input. The layer will have no
    % effect on inputs which do not have a sequence dimension, or have a
    % sequence dimension of unity. For example:
    %
    %   Description         | Size                        | Folded size
    %   ----------------------------------------------------------------------
    %   Images              | H x W x C x N               | H x W x C x N
    %   3-d images          | H x W x D x C x N           | H x W x D x C x N
    %   m-d data            | D1 x D2 x ... x Dm x N      | D1 x D2 x ... x Dm x N
    %   Tabular data        | C x N                       | C x N
    %   1-d sequences       | C x N x S                   | C x (N*S)
    %   Image sequences     | H x W x C x N x S           | H x W x C x (N*S)
    %   m-d sequences       | D1 x D2 x ... x Dm x N x S  | D1 x D2 x ... x Dm x (N*S)
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties
        % LearnableParameters   Learnable parameters for the layer
        %   This layer has no learnable parameters.
        LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();

        % Name (char array)   A name for the layer
        Name
    end
    
    properties (Constant)
        % DefaultName   Default layer's name.
        DefaultName = 'seqfold'
    end
            
    properties (SetAccess = private)
        % InputNames   This layer has one input
        InputNames = {'in'}
        
        % OutputNames   This layer has two outputs
        OutputNames = {'out', 'miniBatchSize'}
        
        % NumInputDimensions   Number of fixed input dimensions. E.g. (H x
        % W x C) = 3 for an image
        NumInputDimensions
    end
    
    properties (Dependent, SetAccess = private)
        % HasSizeDetermined   Specifies if all size parameters are set
        %   If the input size has not been determined, then this will be
        %   set to false, otherwise it will be true
        HasSizeDetermined
    end
    
    methods
        function this = SequenceFolding(name, numInputDimensions)
            this.Name = name;
            this.NumInputDimensions = numInputDimensions;
            
            % The folding layer needs neither X nor Z for backpropagation
            this.NeedsXForBackward = false;
            this.NeedsZForBackward = false;
        end
        
        function Z = predict(this, X)
            % Assume numObs and seqLen are in dimensions
            % (NumInputDimensions + 1) and (NumInputDimensions + 2)
            % respectively
            Z = this.forward(X);
        end
        
        function [Z, memory] = forward(this, X)
            % Assume numObs and seqLen are in dimensions
            % (NumInputDimensions + 1) and (NumInputDimensions + 2)
            % respectively
            N = size(X, this.NumInputDimensions + 1);
            S = size(X, this.NumInputDimensions + 2);
            inputSize = size(X, 1:this.NumInputDimensions);
            
            % Fold sequence dimension into observation dimension
            Z = { reshape( X, [inputSize N*S] ) N };
            
            % Add BackwardSize to memory
            memory.BackwardSize = [inputSize N S];
        end
        
        function [dX, dW] = backward(~, ~, ~, dZ, memory)         
            % Backpropagate through the derivative with respect to the
            % first output
            dZ = dZ{1};
            dX = reshape( dZ, memory.BackwardSize );
            
            dW = [];
        end

        function outputSize = forwardPropagateSize(~, inputSize)
            % Forward propagate the size of the two layer outputs. Note
            % that the outputSize of the first output is identical to the
            % inputSize, because the folding layer does not interfere with
            % fixed input dimensions.
            outputSize = { inputSize 1 };
        end

        function this = inferSize(this, inputSize)
            % Determine the number of dimensions in the input size
            this.NumInputDimensions = numel( inputSize );
        end
        
        function tf = isValidInputSize(this, inputSize)
            % Check if the layer can accept an input of a certain size
            tf = ( numel(inputSize) == this.NumInputDimensions );
        end
        
        function outputSeqLen = forwardPropagateSequenceLength(~, ~, ~)
            % forwardPropagateSequenceLength   The sequence length of the
            % output of the layer given an input sequence length
            
            % The folding layer folds sequences into observations, so the
            % layer returns a sequence length of one
            outputSeqLen = { 1; 1 };
        end
        
        function this = initializeLearnableParameters(this, ~)
        end
        
        function this = prepareForTraining(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.TrainingLearnableParameter.empty();
        end
        
        function this = prepareForPrediction(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
        end
        
        function this = setupForHostPrediction(this)
        end
        
        function this = setupForGPUPrediction(this)           
        end
        
        function this = setupForHostTraining(this)
        end
        
        function this = setupForGPUTraining(this)
        end
        
        function tf = get.HasSizeDetermined(this)
            tf = ~isempty( this.NumInputDimensions );
        end
    end
end
