classdef CustomLayerLegacyStrategy
    % CustomLayerLegacyStrategy   Execution strategy for using a custom
    % intermediate layer in a layer-based environment where the backward
    % method is overridden in the external custom layer.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        LayerVerifier nnet.internal.cnn.layer.util.CustomLayerVerifier
        LearnableParameterNames cell
        IsForwardDefined(1,1) logical
    end

    methods
        function this = CustomLayerLegacyStrategy( ...
                layerVerifier, learnableNames, isForwardDefined)
            this.LayerVerifier = layerVerifier;
            this.LearnableParameterNames = learnableNames;
            this.IsForwardDefined = isForwardDefined;
        end

        function Z = predict(this, layer, X)
            try
                if iscell(X)
                    [Z{1:layer.NumOutputs}] = predict( layer, X{:} );
                else
                    [Z{1:layer.NumOutputs}] = predict( layer, X );
                end
                Z = iUnwrapScalarCell(Z);
            catch cause
                iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomLayer:PredictErrored', class(layer))
            end
            
            this.LayerVerifier.verifyPredictType( layer.OutputNames, iFullType(X), Z );
        end

        function [Z,memory] = forward(this, layer, X)
            try
                if iscell(X)
                    [Z{1:layer.NumOutputs}, userMem] = forward( layer, X{:} );
                else
                    [Z{1:layer.NumOutputs}, userMem] = forward( layer, X );
                end
                Z = iUnwrapScalarCell(Z);
                expectedType = iFullType(X);
                memory = {userMem, iGetSizes(X), expectedType};
            catch cause
                if this.IsForwardDefined
                    iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomLayer:ForwardErrored', class(layer))
                else
                    iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomLayer:PredictErrored', class(layer))
                end
            end
            
            if this.IsForwardDefined
                this.LayerVerifier.verifyForwardType( layer.OutputNames, expectedType, Z );
            else
                this.LayerVerifier.verifyPredictType( layer.OutputNames, expectedType, Z );
            end
        end

        function varargout = backward(this, layer, X, Z, dLdZ, memory)
            try
                userMemory = memory{1};
                inputArgs = iWrapInCell(X,Z,dLdZ,userMemory);
                needsWeightGradients = nargout > 1;
                if ~needsWeightGradients
                    [dX{1:layer.NumInputs}] = backward( layer, inputArgs{:} );
                    dX = iUnwrapScalarCell(dX);
                    varargout = { dX };
                else
                    numParams = numel(this.LearnableParameterNames);
                    [dX{1:layer.NumInputs}, dW{1:numParams}] = ...
                        backward( layer, inputArgs{:} );
                    dX = iUnwrapScalarCell(dX);
                    varargout = { dX, dW };
                end
            catch cause
                iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomLayer:BackwardErrored', class(layer))
            end
            
            expectedSizes = memory{2};
            expectedType = memory{3};
            W = iGetExternalLayerParameters(layer,this.LearnableParameterNames);
            this.LayerVerifier.verifyBackwardSize( layer.InputNames, ...
                expectedSizes, W, varargout{:} );
            this.LayerVerifier.verifyBackwardType( layer.InputNames, ...
                expectedType, varargout{:} );
        end
    end
end

function varargout = iWrapInCell(varargin)
% Wraps each input argument into a cell. [cell1, cell2,  ..., cellN] =
% iWrapInCell( data1, data2, ..., dataN) combinedCell = iWrapInCell( data1,
% data2, data3, ...)
celldata = cell(1,nargin);
for i = 1:nargin
    if ~iscell(varargin{i})
        % Wrap non-cell data into a cell
        celldata{i} = varargin(i);
    else
        % Reshape cell array input to a row vector
        celldata{i} = reshape(varargin{i},1,[]);
    end
end
if nargout == 1
    % If a single output is requested, concatenate all cell outputs into
    % one cell array row vector
    varargout{1} = [ celldata{:} ];
else
    % If multiple outputs are requested, return each wrapped cell
    % separately
    varargout(1:nargout) = celldata(1:nargout);
end
end

function data = iUnwrapScalarCell(cellData)
if iscell(cellData) && isscalar(cellData)
    data = cellData{1};
else
    data = cellData;
end
end

function typeStruct = iFullType(data)
if iscell(data)
    data = data{1};
end

mainClass = class(data);
if mainClass == "gpuArray"
    underlyingClass = classUnderlying(data);
else
    underlyingClass = '';
end

typeStruct = struct( ...
    'Main', mainClass, ...
    'Underlying', underlyingClass );
end

function sz = iGetSizes(data)
if iscell(data)
    sz = cellfun( @size, data, 'UniformOutput', false);
else
    sz = size(data);
end
end

function paramValues = iGetExternalLayerParameters( layer, paramNames )
numParams = numel(paramNames);
paramValues = cell(1,numParams);
for ii=1:numParams
    paramValues{ii} = layer.(paramNames{ii});
end
end

function iThrowWithCause( cause, errorID, varargin )
exception = MException( message( errorID, varargin{:} ) );
exception = exception.addCause( cause );
throwAsCaller( exception );
end