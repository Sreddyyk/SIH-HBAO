classdef GRUGPUReturnLastStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % GRUGPUReturnLastStrategy   Execution strategy for running GRU with
    % cuDNN and returning the last element of the sequence.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X, W, R, b, h0, ~)
            [X, H0, Wc] = iPrepareDataForForward(X, W, R, b, h0);
            [Zfull, H, Ws] = nnet.internal.cnngpu.gruForwardTrain(X, H0, Wc);
            memory.HiddenState = H;
            memory.Workspace = Ws;
            memory.Zfull = Zfull;
            Z = Zfull(:, :, end);
        end
        
        function [dX, dW] = backward(~, X, W, R, b, h0, ~, dZ, memory, ~)
            Z = memory.Zfull;
            dZfull = zeros(size(memory.Zfull), 'like', dZ);
            dZfull(:, :, end) = dZ; 
            
            [H, dH, X, H0, Wc, Ws, hiddenStateSize, dSize] = iPrepareDataForBackward(X, W, R, b, h0, memory);

            args = { Z, H, dZfull, dH, X, H0, Wc, Ws };
            
            [dX, ~, dWcudnn] = nnet.internal.cnngpu.gruBackward( args{:} );

            % Convert to DLT weights format
            [dIW, dRW, dB] = nnet.internal.cnngpu.util.GRUWeightsConverter.fromCudnnDerivative(dWcudnn, hiddenStateSize, dSize);

            dW{1} = dIW;
            dW{2} = dRW;
            dW{3} = dB;
        end
    end
end

function [X, H0, Wc] = iPrepareDataForForward(X, W, R, b, h0)
% Prepare data passed into the strategy for the internal
% forward method

% Convert to cuDNN weights format
Wc = nnet.internal.cnngpu.util.GRUWeightsConverter.toCudnn(W, R, b);
% Expand initial states along batch dimension if necessary
N = size( X, 2 );
H0 = iExpandBatchDimension(h0, N);
end

function V = iExpandBatchDimension(V, N)
if size(V, 2) == 1
    V = repmat(V, 1, N);
end
end

function [H, dH, X, H0, Wc, Ws, numHidden, D] = iPrepareDataForBackward(X, W, R, b, h0, memory)
% Prepare data passed into the strategy for the internal
% backward method

% Convert to cuDNN weights format
Wc = nnet.internal.cnngpu.util.GRUWeightsConverter.toCudnn(W, R, b);
% Determine problem dimensions
N = iGetBatchDimension( X );
[D, numHidden] = iGetInputAndHiddenDimensions( W );
% Expand initial states along batch dimension if necessary
H0 = iExpandBatchDimension(h0, N);
H = memory.HiddenState;
Ws = memory.Workspace;
dH = zeros( size(H), 'like', H );
end

function N = iGetBatchDimension( X )
N = size( X, 2 );
end

function [D, H] = iGetInputAndHiddenDimensions( W )
[threeH, D] = size( W );
H = threeH./3;
end
