classdef TransposedConvolution3DFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy
    % TransposedConvolution3DFunctionalStrategy    dlarray method strategy
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X, ...
                weights, bias, ...
                cropping, ... % [TLF; BRB] or 'same'
                stride, ~)
            
            % TODO (g2000679): use internal API            
            Z = dltranspconv(X, weights, bias, ...
                'Stride', stride, ...
                'Cropping', cropping);
            
            memory = [];
        end
    end
end