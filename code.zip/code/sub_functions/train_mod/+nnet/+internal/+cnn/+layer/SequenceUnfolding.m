classdef SequenceUnfolding < nnet.internal.cnn.layer.Layer
    % SequenceUnfolding   Sequence unfolding layer
    %
    % The sequence unfolding layer restores the observation dimension (N)
    % and the sequence dimension (S) of the input. The layer will have no
    % effect on inputs which do not have a sequence dimension, or have a
    % sequence dimension of unity. For example:
    %
    %   Description         | Size                        | Unfolded size
    %   ----------------------------------------------------------------------
    %   Images              | H x W x C x N               | H x W x C x N
    %   3-d images          | H x W x D x C x N           | H x W x D x C x N
    %   m-d data            | D1 x D2 x ... x Dm x N      | D1 x D2 x ... x Dm x N
    %   Tabular data        | C x N                       | C x N
    %   1-d sequences       | C x (N*S)                   | C x N x S
    %   Image sequences     | H x W x C x (N*S)           | H x W x C x N x S
    %   m-d sequences       | D1 x D2 x ... x Dm x (N*S)  | D1 x D2 x ... x Dm x N x S
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties
        % LearnableParameters   Learnable parameters for the layer
        %   This layer has no learnable parameters.
        LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();

        % Name (char array)   A name for the layer
        Name
    end
    
    properties (Constant)
        % DefaultName   Default layer's name.
        DefaultName = 'sequnfold'
    end
            
    properties (SetAccess = private)
        % InputNames   This layer has two inputs
        InputNames = {'in', 'miniBatchSize'}
        
        % OutputNames   This layer has one output
        OutputNames = {'out'}
        
        % NumInputDimensions   Number of fixed input dimensions. E.g. (H x
        % W x C) = 3 for an image
        NumInputDimensions
    end
    
    properties (Dependent, SetAccess = private)
        % HasSizeDetermined   Specifies if all size parameters are set
        %   If the input size has not been determined, then this will be
        %   set to false, otherwise it will be true
        HasSizeDetermined
    end
    
    methods
        function this = SequenceUnfolding(name, numInputDimensions)
            this.Name = name;
            this.NumInputDimensions = numInputDimensions;
            
            % The unfolding layer needs neither X or Z for backpropagation
            this.NeedsXForBackward = false;
            this.NeedsZForBackward = false;
        end
        
        function Z = predict(this, inputsX)
            Z = this.forward( inputsX );
        end
        
        function [Z, memory] = forward(this, inputsX)
            % Unpack inputs
            X = inputsX{1};
            N = inputsX{2};
            NS = size( X, this.NumInputDimensions + 1 );
            S = NS/N;
            iAssertNonnegativeInteger(S);
            inputSize = size(X, 1:this.NumInputDimensions);
            
            % Unfold sequence and observation dimensions
            Z = X;
            if S > 1
                Z = reshape( X, [inputSize N S] );
            end
            
            % Add BackwardSize to memory for backpropagation
            memory.BackwardSize = [inputSize N*S];
        end
        
        function [dInputsX, dW] = backward(~, ~, ~, dZ, memory)           
            % Backward
            dX = reshape( dZ, memory.BackwardSize );
            
            dInputsX = { dX [] };
            
            dW = [];
        end

        function outputSize = forwardPropagateSize(~, inputSize)
            % Forward propagate the size of the layer output. Note that the
            % outputSize is identical to the inputSize, because the
            % unfolding layer does not interfere with fixed input
            % dimensions.
            outputSize = inputSize{1};
        end

        function this = inferSize(this, inputSize)
            % Determine the number of dimensions in the input size
            this.NumInputDimensions = numel( inputSize{1} );
            
            % Error if the miniBatchSize input to the layer is not scalar
            if ~isscalar( inputSize{2} )
                iThrowIncorrectMiniBatchSizeError();
            end
        end
        
        function tf = isValidInputSize(this, inputSize)
            % Check if the layer can accept an input of a certain size
            tf = ( numel(inputSize{1}) == this.NumInputDimensions ) && ...
                isscalar(inputSize{2});
        end
        
        function outputSeqLen = forwardPropagateSequenceLength(~, inputSeqLen, ~)
            % forwardPropagateSequenceLength   The sequence length of the
            % output of the layer given an input sequence length
            
            % The unfolding layer re-constructs sequences from
            % observations, so the layer can return an arbitrary sequence
            % length, and only an input sequence length of one is valid.
            if ~iInputSeqLenIsOne( inputSeqLen )
                % The following error will be caught and re-thrown by the
                % Network Analyzer
                iThrowIncorrectSeqLenError();
            end
            outputSeqLen = { iArbitrarySeqLen() };
        end
        
        function this = initializeLearnableParameters(this, ~)
        end
        
        function this = prepareForTraining(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.TrainingLearnableParameter.empty();
        end
        
        function this = prepareForPrediction(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
        end
        
        function this = setupForHostPrediction(this)
        end
        
        function this = setupForGPUPrediction(this)           
        end
        
        function this = setupForHostTraining(this)
        end
        
        function this = setupForGPUTraining(this)
        end
        
        function tf = get.HasSizeDetermined(this)
            tf = ~isempty( this.NumInputDimensions );
        end
    end
end

function iAssertNonnegativeInteger(x)
% Assert x is a nonnegative integer
if ~iIsNonnegativeInteger(x)
    iThrowExceptionFromErrorID('nnet_cnn:layer:SequenceUnfoldingLayer:InvalidSequenceLength', num2str(x))
end
end

function tf = iIsNonnegativeInteger(x)
tf = (x > 0) && (mod(x,1) == 0);
end

function exception = iThrowExceptionFromErrorID(errorID, varargin)
exception = MException(message(errorID, varargin{:}));
throwAsCaller(exception);
end

function tf = iInputSeqLenIsOne(x)
tf = all( cellfun(@(s) isequal(s,1), x) );
end

function iThrowIncorrectMiniBatchSizeError()
error( message('nnet_cnn:layer:SequenceUnfoldingLayer:MiniBatchSizeMustBeScalar') );
end

function iThrowIncorrectSeqLenError()
error( message('nnet_cnn:layer:SequenceUnfoldingLayer:InputSeqLenMustBeOne') );
end

function seq = iArbitrarySeqLen()
% Token to describe an arbitrary sequence length
seq = nnet.internal.cnn.util.arbitrarySequenceLengthToken();
end