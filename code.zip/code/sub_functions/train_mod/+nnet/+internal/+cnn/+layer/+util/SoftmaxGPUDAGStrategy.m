classdef SoftmaxGPUDAGStrategy < nnet.internal.cnn.layer.util.SoftmaxDAGStrategy
    % SoftmaxGPUDAGStrategy   Execution strategy for running the softmax
    % layer in a DAG network, overloaded to ensure it runs on the GPU
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [X, memory] = forward(~, X, channelDim)
            X = nnet.internal.cnngpu.softmaxForwardND(X, channelDim);
            memory = [];
        end
        
        function [dZ, dW] = backward(~, Z, dZ, channelDim)
            Z = nnet.internal.cnn.util.boundAwayFromZero(Z);
            dZ = nnet.internal.cnngpu.softmaxBackwardND(Z, dZ, channelDim);
            dW = [];
        end
    end
    
end
