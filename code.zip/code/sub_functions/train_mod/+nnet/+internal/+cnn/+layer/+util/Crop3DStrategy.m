classdef Crop3DStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % Crop using [X Y Z] location.
    
    % Copyright 2019 The MathWorks, Inc.
    properties
        Location
    end
    
    methods
        
        %------------------------------------------------------------------
        function [Z,memory] = forward(this, inputs)
            % unpack inputs
            X = inputs{1};
            [H, W, D, ~] = size(inputs{2});
            
            [rows, cols, planes] = cropWindow(this, size(X), [H, W, D]);
            
            Z = X(rows, cols, planes, :, :);
            memory = [];
        end
        
        %------------------------------------------------------------------
        function [outputGrad, dW] = backward(this, inputs, dZ)
            % route dZ to uncropped regions of X.
            X = inputs{1};
            [H, W, D, ~] = size(inputs{2});
            
            [rows, cols, planes] = cropWindow(this, size(X), [H, W, D]);
            
            dX = zeros(size(X), 'like', X);
            dX(rows, cols, planes, :, :) = dZ;
            
            % pack output gradients. There is no gradient w.r.t to second
            % input.
            outputGrad = {dX, zeros(size(inputs{2}), 'like', inputs{2})};
            
            dW = [];
        end
    end
    
    methods(Abstract)
        %------------------------------------------------------------------
        [rows, cols, planes] = cropWindow(this, inputSize, outputSize)
    end
end
