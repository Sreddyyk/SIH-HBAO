classdef GlobalMaxPooling2DHostStrategy < nnet.internal.cnn.layer.util...
        .ExecutionStrategy
    % GlobalMaxPooling2DHostStrategy   Execution strategy for running the max pooling 
    % on the host
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X)
            Z = nnet.internal.cnnhost.poolingMaxForward2D(X, ...
                size(X,1), size(X,2), ...
                0, 0, ...
                0, 0, ...
                1, 1);
            memory = [];
        end

        function [dX,dW] = backward(~, ~, dZ, X)
            dX = builtin('_maxpoolBackward', dZ, X, [size(X,1) size(X,2)], ...
                [0, 0, 0, 0], ...
                [1, 1]);
            dW = [];
        end
    end
end