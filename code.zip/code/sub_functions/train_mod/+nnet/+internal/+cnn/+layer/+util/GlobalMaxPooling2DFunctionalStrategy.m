classdef GlobalMaxPooling2DFunctionalStrategy < nnet.internal.cnn.layer.util.FunctionalStrategy
    % GlobalMaxPooling2DFunctionalStrategy   Calls into the dlarray method
    % maxpool
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X)
            
            % TODO: use internal API
            Z = maxpool(X, [size(X,1) size(X,2)], ...
                'Padding', [0, 0; 0, 0], ...
                'Stride', [1 1]);
            
            memory = [];
        end
    end
end
