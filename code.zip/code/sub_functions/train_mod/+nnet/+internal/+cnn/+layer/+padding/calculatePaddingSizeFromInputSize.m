function paddingSize = calculatePaddingSizeFromInputSize( ...
    paddingMode, paddingSize, filterOrPoolSize, stride, spatialInputSize)
% calculatePaddingSizeFromInputSize   Calculate the padding size based on
% the input size.
%
%   paddingSize = calculatePaddingSizeFromInputSize(paddingMode,
%   paddingSize, filterSize, stride, spatialInputSize) calculates the
%   padding size based on the spatial input size. This is useful if you
%   need to recalculate the padding size because your layer receives data
%   with a different input size.
%
%   This function works for 2D and 3D layers.
%
%   Inputs:
%       paddingMode             - The padding mode. Either the string
%                                 'same' or 'manual'. If it is 'manual',
%                                 then the function simply returns the
%                                 value of paddingSize that was passed in.
%       paddingSize             - A 1-by-4 vector for the padding in the 
%                                 format [top bottom left right].
%                               - A 1-by-6 vector for the padding in the
%                                 format [top bottom left right front back].
%       filterOrPoolSize        - A 1-by-2 vector [r s] where r is the
%                                 height and s is the width of a
%                                 filter/pooling region.
%                               - A 1-by-3 vector [r s t] where r is the
%                                 height, s is the width and t is the depth
%                                 of a filter/pooling region.
%       stride                  - A 1-by-2 vector [u v] where u is the
%                                 vertical stride and v is the horizontal 
%                                 stride.
%                               - A 1-by-3 vector [u v w] where u is the
%                                 vertical stride, v is the horizontal
%                                 stride and w is the stride in the depth
%                                 direction.
%       spatialInputSize        - A 1-by-2 vector [h w] where h is the
%                                 height of the input and w is the width of
%                                 the input.
%                               - A 1-by-3 vector [h w d] where h is the
%                                 height of the input, w is the width of
%                                 the input and d is the depth of the input.
%
%   Output:
%       paddingSize             - A 1-by-4 vector for the padding in the 
%                                 format [top bottom left right].
%                               - A 1-by-6 vector for the padding in the
%                                 format [top bottom left right front back].

%   Copyright 2019 The MathWorks, Inc.

if string(paddingMode) == "same"
    paddingSize = nnet.internal.cnn.layer.padding.calculateSamePadding( ...
        filterOrPoolSize, stride, spatialInputSize);
end

end