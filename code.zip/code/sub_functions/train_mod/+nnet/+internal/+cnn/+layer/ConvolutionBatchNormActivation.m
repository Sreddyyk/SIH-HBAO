classdef ConvolutionBatchNormActivation < nnet.internal.cnn.layer.FusedLayer
    % ConvolutionBatchNormActivation  Fused N-D Convolution + BatchNorm +
    % optional Relu in a single layer
    
    %   Copyright 2019 The MathWorks, Inc.
    
    %% Public properties
    properties( Constant )
        % DefaultName   Default layer's name.
        DefaultName = 'convBatchNorm'
        
        % LayerFuser  Knows how to substitute this layer into a LayerGraph
        LayerFuser = nnet.internal.cnn.optimizer.SequenceLayerFuser( ...
            nnet.internal.cnn.optimizer.FusedLayerFactory( ...
              "nnet.internal.cnn.layer.ConvolutionBatchNormActivation" ), ...
              { ["nnet.internal.cnn.layer.Convolution2D"; ...
                 "nnet.internal.cnn.layer.BatchNormalization"; ...
                 "nnet.internal.cnn.layer.ReLU"], ...
                ["nnet.internal.cnn.layer.Convolution2D"; ...
                 "nnet.internal.cnn.layer.BatchNormalization"] }, false );
    end
    
    % Copies of read-only parameters
    properties( SetAccess = private )
        Stride
        DilationFactor
        PaddingSize
        NumFilters
        NumChannels
        Epsilon
    end

    % Convenience accessors for parameters by name
    properties( Dependent, SetAccess = private )
        Weights
        Bias
        Scale
        Offset
    end
    
    % Utility properties
    properties( Dependent, Access = private )
        ConvolutionLayer
        BatchNormLayer
        ReluLayer
    end
    
    properties( Access = private )
        % ExecutionStrategy  Strategy for the fused layer if supported
        ExecutionStrategy
        
        % OriginalConvolutionWeightsOnHost  Cache the original convolution
        % weights but ensure they are stored on the host to relieve GPU
        % memory pressure
        OriginalConvolutionWeightsOnHost
        
        % OriginalConvolutionBiasOnHost  Cache the original convolution
        % bias but ensure it is are stored on the host to relieve GPU
        % memory pressure
        OriginalConvolutionBiasOnHost
        
        % LayerIsFinalized  If this fused layer is not finalized, allow
        % it to be constructed but flag and call underlying layers during
        % propagation
        LayerIsFinalized = true
    end
    
    %% Property Setters and Getters
    methods
        function weights = get.Weights(this)
            weights = this.LearnableParameters(1);
        end
        
        function bias = get.Bias(this)
            bias = this.LearnableParameters(2);
        end
        
        function scale = get.Scale(this)
            scale = this.LearnableParameters(nnet.internal.cnn.layer.BatchNormalization.ScaleIndex+2);
        end
        
        function offset = get.Offset(this)
            offset = this.LearnableParameters(nnet.internal.cnn.layer.BatchNormalization.OffsetIndex+2);
        end
        
        function layer = get.ConvolutionLayer(this)
            layer = this.OriginalLayers{1};
        end
        
        function layer = get.BatchNormLayer(this)
            layer = this.OriginalLayers{2};
        end
        
        function layer = get.ReluLayer(this)
            layer = this.OriginalLayers{3};
        end
            
    end

    %% Initialization methods
    methods
        
        function obj = ConvolutionBatchNormActivation( name, layerGraph )
            % Constructor copies some read-only parameters for faster access
            obj = obj@nnet.internal.cnn.layer.FusedLayer( name, layerGraph );
            convLayer = layerGraph.Layers{1};
            obj.Stride = convLayer.Stride;
            obj.DilationFactor = convLayer.DilationFactor;
            obj.PaddingSize = convLayer.PaddingSize;
            obj.NumFilters = convLayer.NumFilters;
            bnLayer = layerGraph.Layers{2};
            obj.NumChannels = bnLayer.NumChannels;
            obj.Epsilon = bnLayer.Epsilon;
        end
                
        function this = prepareForPrediction(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2prediction(this.LearnableParameters);
            this = prepareForPrediction@nnet.internal.cnn.layer.FusedLayer(this);
        end
        
        function this = prepareForTraining(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2training(this.LearnableParameters);
            this.IsTraining = true;
        end

        function this = setupForHostPrediction(this)
            this = setHostStrategy(this);
            % Setup required on the underlying layers to support
            % activations
            this = callOnPrivateOriginalLayers( this, @setupForHostPrediction );
            % Set properties on cached weights
            this.LearnableParameters(1).UseGPU = false;
            this.LearnableParameters(2).UseGPU = false;
            this.LearnableParameters(3).UseGPU = false;
            this.LearnableParameters(4).UseGPU = false;
        end
        
        function this = setupForGPUPrediction(this)
            this = setGPUStrategy(this);
            % Setup required on the underlying layers to support
            % activations
            this = callOnPrivateOriginalLayers( this, @setupForGPUPrediction );
            % Set properties on cached weights
            this.LearnableParameters(1).UseGPU = true;
            this.LearnableParameters(2).UseGPU = true;
            this.LearnableParameters(3).UseGPU = true;
            this.LearnableParameters(4).UseGPU = true;
        end
        
        function this = setupForHostTraining(this)
            this = this.setHostStrategy();
        end
        
        function this = setupForGPUTraining(this)
            this = this.setGPUStrategy();
        end
    end
    
    %% Propagation methods
    methods
        
        % predict   Forward input data through the layer and output the result
        function Z = predict( this, X )
            if this.LayerIsFinalized && ~isempty(this.ExecutionStrategy)
                Z = this.ExecutionStrategy.forward( X, ...
                    this.LearnableParameters(1).Value, ...
                    this.LearnableParameters(2).Value, ...
                    this.PaddingSize(1), this.PaddingSize(3), ...
                    this.PaddingSize(2), this.PaddingSize(4), ...
                    this.Stride(1), this.Stride(2), ...
                    this.DilationFactor(1), this.DilationFactor(2)); 
            else
                Z = predict@nnet.internal.cnn.layer.FusedLayer( this, X );
            end
        end

    end
    
    %% Overloaded Utilities
    methods( Access = protected )
        
        function this = cacheLearnables( this )
            % cacheLearnables  Overload the base class so that as well as
            % caching the parameters from the original layers, an
            % additional scale and offset are computed to be applied to the
            % convolution
            this = cacheLearnables@nnet.internal.cnn.layer.FusedLayer(this);
            
            % Copy the original convolutional learnables to a host cache
            this.OriginalConvolutionWeightsOnHost = gather(this.LearnableParameters(1).Value);
            this.OriginalConvolutionBiasOnHost = gather(this.LearnableParameters(2).Value);
            
            % Get the scale and offset and apply to the convolutional
            % weights.
            trainedMean = this.PrivateOriginalLayers{2}.TrainedMean;
            trainedVariance = this.PrivateOriginalLayers{2}.TrainedVariance;
            %
            % Check for unfinalized BatchNorm before using empty statistics
            if isempty(trainedMean) || isempty(trainedVariance)
                this.LayerIsFinalized = false;
            else
                denominator = sqrt(trainedVariance + this.PrivateOriginalLayers{2}.Epsilon);
                % Convolution filter dim becomes output channel dim, so scale
                % is applied to the bias channels but the weight filter dim.
                biasMultiplier = this.Scale.Value./denominator;
                weightMultiplier = shiftdim(biasMultiplier, -1); % Apply to filters
                biasIncrement = this.Offset.Value - biasMultiplier.*trainedMean;
                this.LearnableParameters(1).Value = this.LearnableParameters(1).Value.*weightMultiplier;
                this.LearnableParameters(2).Value = this.LearnableParameters(2).Value.*biasMultiplier + biasIncrement;
            end
        end
        
        function layers = restoreLearnables( this, layers )
            % restoreLearnables  Copy learnable parameters back into the
            % original layers - overload to copy the original convolution
            % learnables not the modified ones
            layers{1}.LearnableParameters(1).Value = this.OriginalConvolutionWeightsOnHost;
            layers{1}.LearnableParameters(2).Value = this.OriginalConvolutionBiasOnHost;
            layers{2}.LearnableParameters = this.LearnableParameters(3:4);
        end
    end
    
    %% Utility methods
    methods( Access = private )
        
        function this = setHostStrategy( this )
            if isscalar(this.NumFilters)
                if numel(this.PrivateOriginalLayers) == 3
                    this.ExecutionStrategy = nnet.internal.cnn.layer.util.ConvolutionReLUHostStrategy;
                else
                    noDilation = isequal(this.ConvolutionLayer.DilationFactor, [1 1]);
                    if nnet.internal.cnnhost.useMKLDNN && noDilation
                        this.ExecutionStrategy = nnet.internal.cnn.layer.util.Convolution2DHostMkldnnStrategy();
                    else
                        this.ExecutionStrategy = nnet.internal.cnn.layer.util.Convolution2DHostStridedConvStrategy();
                    end
                end
            else
                this.ExecutionStrategy = [];
            end
        end
        
        function this = setGPUStrategy( this )
            if isscalar(this.NumFilters)
                if numel(this.PrivateOriginalLayers) == 3
                    this.ExecutionStrategy = nnet.internal.cnn.layer.util.ConvolutionReLUGPUStrategy;
                else
                    this.ExecutionStrategy = nnet.internal.cnn.layer.util.Convolution2DGPUStrategy;
                end
            else
                this.ExecutionStrategy = [];
            end
        end
        
        function this = callOnPrivateOriginalLayers( this, F )
            % callOnPrivateOriginalLayers  Convenience function for
            % modifying the original layers in the fused layer graph
            % without going through the Dependent property OriginalLayers
            % which would trigger a call to restoreLearnables
            this.PrivateOriginalLayers = cellfun(F, this.PrivateOriginalLayers, 'UniformOutput', false);
        end

    end
    
end
