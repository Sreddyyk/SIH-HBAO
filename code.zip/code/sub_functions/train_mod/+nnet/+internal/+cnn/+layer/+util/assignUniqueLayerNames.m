function [larray,generatedNames] = assignUniqueLayerNames(larray)
% ASSIGNUNIQUELAYERNAMES   Generate and assign unique layer names 
%
%   larray = ASSIGNUNIQUELAYERNAMES(larray) modifies the Name property of
%   each layer in the input larray such that each name is unique and
%   non-empty. larray can be an array of external layers or a cell array of
%   internal layers.
%
%   [larray,generatedNames] = ASSIGNUNIQUELAYERNAMES(larray) modifies the
%   Name property of each layer in larray and additionally returns the
%   generated names as the cellstr generatedNames.

%   Copyright 2018-2019 The MathWorks, Inc.

if isa(larray,'nnet.cnn.layer.Layer')
    internalLayers = nnet.internal.cnn.layer.util.ExternalInternalConverter.getInternalLayers(larray);
else
    internalLayers = larray;
end

numLayers = numel( larray );

original = string.empty(numLayers,0);
default = string.empty(numLayers,0);
for ii = 1:numLayers
    original(ii) = string(internalLayers{ii}.Name);
    default(ii) = string(internalLayers{ii}.DefaultName);
end

% Make non-empty layer names unique
hasName = (original ~= "");
generatedNames(hasName)  = iRenameDuplicated(original(hasName));
% For layers with empty name, generate a unique name based on the layer's
% default name. Don't reuse names of layers that had a non-empty name,
% neither before nor after making them unique.
generatedNames(~hasName) = iRenameDuplicated(default(~hasName),...
     [generatedNames(hasName) original(hasName)]);

% Convert to column cell string format
generatedNames = cellstr(generatedNames)';

% Assign the new names back into the layers
if isa(larray,'nnet.cnn.layer.Layer')
    for i=1:numel(larray)
        larray(i).Name = generatedNames{i};
    end
else
    for i=1:numel(larray)
        larray{i}.Name = generatedNames{i};
    end
end
end

function duplicated = iGetDuplicatedNames(names)
% Generate list of duplicated names
[~,i] = unique(names);
i = setdiff(1:numel(names), i);
duplicated = unique(names(i));
end

function renamed = iRenameDuplicated(names, avoid)
% Makes a list of unique names, avoiding using the names that were
% duplicated and the names specified in 'avoid'
if nargin < 2
    avoid = string.empty();
end
dup = iGetDuplicatedNames(names);
exclude = [avoid(:); dup(:)];
renamed = matlab.lang.makeUniqueStrings( names, exclude);
end