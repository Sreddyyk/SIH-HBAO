classdef LeakyReLUFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy
    % LeakyReLUFunctionalStrategy    Calls into the dlarray method
    % leakyrelu
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X, scale)
            
            % TODO: use internal API            
            Z = leakyrelu(X, scale);            
            
            memory = [];
        end
    end
end
