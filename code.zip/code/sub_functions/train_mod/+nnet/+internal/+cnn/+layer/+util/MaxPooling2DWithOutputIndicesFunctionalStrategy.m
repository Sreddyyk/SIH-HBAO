classdef MaxPooling2DWithOutputIndicesFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy
    % MaxPooling2DWithOutputIndicesFunctionalStrategy    Calls into the dlarray maxpool method
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X, ...
                poolHeight, poolWidth, ...
                topPad, leftPad, ...
                bottomPad, rightPad, ...
                verticalStride, horizontalStride)
            
            % TODO: use internal API
            [M, indices, sz] = maxpool(X, [poolHeight poolWidth], ...
                'Padding', [topPad, leftPad; bottomPad, rightPad], ...
                'Stride', [verticalStride horizontalStride]);
            
            Z = {M, indices, sz};
            
            memory = [];
        end
    end
end
