function reducedMean = computeMeanOfMeans( X, dims, numSamples )
% computeMeanOfMeans   Compute the mean of X along the dimensions specified
% in dims. Note that X can be containing mean values. numSamples is an
% array of the same size as X which is used to compute the weighted average
% of the mean values based on the number of samples that contributed to
% that mean.

%   Copyright 2018-2019 The MathWorks, Inc.

if nargin<3
    % Each mean value of X contributes equally to the total mean
    numSamples = ones( size(X) );
end

if isempty( X )
    reducedMean = [];
elseif isempty( dims )
    % No further reduction is required
    reducedMean = X;
elseif all(size(X,dims) == 1)
    % Data which is already reduced in the specified dimensions does not
    % require further averaging.
    reducedMean = X;
else
    % Compute the mean over each reduction dimension.
    samplesPerDim = sum( numSamples, dims );
    reducedMean = sum( X.*numSamples, dims ) ./ samplesPerDim;
end
end