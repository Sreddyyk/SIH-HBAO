function tf = isInputSizeLessThanPoolSize(inputSize, poolSize)
% isInputSizeLessThanPoolSize   Determine if the input size is less than the pool size
%
%   tf = isInputSizeLessThanPoolSize(inputSize, poolSize) returns true if the size of the input
%   is less than the pooling window size in any dimension, false otherwise.
%
%   Input:
%       inputSize               - A 1-by-N vector with the size of the input data for 
%                                 each dimension. 
%       poolSize                - A 1-by-M vector with the pooling window size for
%                                 each pooling dimension.
%
%   Output:
%       tf                      - if the size of the input is less than the pooling
%                                 window size, false otherwise.

%   Copyright 2019 The MathWorks, Inc.

dim = length(poolSize);
tf = any(inputSize(1:dim) < poolSize);
 
end
