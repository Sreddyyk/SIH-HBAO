classdef Quantization 
% Quantization   Quantization scheme for deep learning
%  
% Abstract base class for specifying    

%   Copyright 2018 The MathWorks, Inc.
    
    properties(Constant, Abstract)
        Name
    end
    
    methods(Abstract)
        % Quantize   Quantize parameters
        %
        % [A, B, ...] = quantize( this, a, b, ... )
        varargout = quantize( this, varargin )
        
        % Remapped   Quantize parameters and remap back to single
        %
        % [A, B, ...] = remapped( this, a, b, ... )
        varargout = remapped( this, varargin )
    end
end

