classdef FunctionalStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % FunctionalStrategy    Base class for dlarray execution strategies
    %
    % It implements backward by erroring, since the backward pass is dealt
    % with by the autodiff framework.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [dX,dW] = backward(~, ~, ~)
            % Internal diagnostics
            error('This method should not be called.')
        end
    end
end