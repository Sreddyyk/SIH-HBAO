classdef GroupedConvolutionReLU < nnet.internal.cnn.layer.FusedLayer
    % GroupedConvolutionReLU  Fused N-D Grouped-Convolution + Relu in a single layer
    
    %   Copyright 2019 The MathWorks, Inc.
    
    %% Public properties
    properties( Constant )
        % DefaultName   Default layer's name.
        DefaultName = 'groupedConvRelu'
        
        % LayerFuser  Knows how to substitute this layer into a LayerGraph
        LayerFuser = nnet.internal.cnn.optimizer.SequenceLayerFuser( ...
            nnet.internal.cnn.optimizer.FusedLayerFactory( ...
              "nnet.internal.cnn.layer.GroupedConvolutionReLU" ), ...
                ["nnet.internal.cnn.layer.GroupedConvolution2D"; ...
                 "nnet.internal.cnn.layer.ReLU"] );
    end
    
    % Copies of read-only parameters
    properties( SetAccess = private )
        EffectiveFilterSize
        Stride
        DilationFactor
        PaddingMode
        PaddingSize
        NumGroups
        NumFilters
    end

    % Convenience accessors for weights by name
    properties( Dependent, SetAccess = private )
        Weights
        Bias
    end
    
    %% Utility properties
    properties( Dependent, Access = private )
        GroupedConvolutionLayer
        ReluLayer
    end
    
    properties( Access = private )
        % ExecutionStrategy  Strategy for the fused layer if supported
        ExecutionStrategy
    end
    
    %% Property Setters and Getters
    methods
        function weights = get.Weights(this)
            weights = this.LearnableParameters(1);
        end
        
        function bias = get.Bias(this)
            bias = this.LearnableParameters(2);
        end
        
        function layer = get.GroupedConvolutionLayer(this)
            layer = this.OriginalLayers{1};
        end
        
        function layer = get.ReluLayer(this)
            layer = this.OriginalLayers{2};
        end
            
    end

    %% Initialization methods
    methods
        
        function obj = GroupedConvolutionReLU( name, layerGraph )
            layerGraphExecutionInfo = nnet.internal.cnn.util.LayerGraphExecutionInfo(iExplicitGraphInfo());
            % Constructor copies some read-only parameters for faster access
            obj = obj@nnet.internal.cnn.layer.FusedLayer( name, layerGraph, layerGraphExecutionInfo );
            groupedConvLayer = layerGraph.Layers{1};
            obj.EffectiveFilterSize = groupedConvLayer.EffectiveFilterSize;
            obj.Stride = groupedConvLayer.Stride;
            obj.DilationFactor = groupedConvLayer.DilationFactor;
            obj.PaddingMode = groupedConvLayer.PaddingMode;
            obj.PaddingSize = groupedConvLayer.PaddingSize;
            obj.NumGroups = groupedConvLayer.NumGroups;
            obj.NumFilters = groupedConvLayer.NumFiltersPerGroup*groupedConvLayer.NumGroups;
        end
        
        function this = prepareForTraining(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2training(this.LearnableParameters);
            this = prepareForTraining@nnet.internal.cnn.layer.FusedLayer(this);
        end
                
        function this = prepareForPrediction(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2prediction(this.LearnableParameters);
            this = prepareForPrediction@nnet.internal.cnn.layer.FusedLayer(this);
        end

        function this = setupForHostPrediction(this)
            this = setHostStrategy(this);
            % Setup required on the underlying layers to support
            % activations
            this = setupForHostPrediction@nnet.internal.cnn.layer.FusedLayer(this);
            % Set properties on cached weights
            this.LearnableParameters(1).UseGPU = false;
            this.LearnableParameters(2).UseGPU = false;
        end
        
        function this = setupForGPUPrediction(this)
            this = setGPUStrategy(this);
            % Setup required on the underlying layers to support
            % activations
            this = setupForGPUPrediction@nnet.internal.cnn.layer.FusedLayer(this);
            % Set properties on cached weights
            this.LearnableParameters(1).UseGPU = true;
            this.LearnableParameters(2).UseGPU = true;
        end
        
        function this = setupForHostTraining(this)
            this = setHostStrategy(this);
            % If propagation is through the original layers, they must be
            % updated too
            if isempty(this.ExecutionStrategy)
                this = setupForHostTraining@nnet.internal.cnn.layer.FusedLayer(this);
            end
        end
        
        function this = setupForGPUTraining(this)
            this = setGPUStrategy(this);
            % If propagation is through the original layers, they must be
            % updated too
            if isempty(this.ExecutionStrategy)
                this = setupForGPUTraining@nnet.internal.cnn.layer.FusedLayer(this);
            end
        end
        
    end
    
    %% Propagation methods
    methods
        
        % predict   Forward input data through the layer and output the result
        function Z = predict( this, X )
            if ~isempty(this.ExecutionStrategy)
                inputSize = size(X,1:2);
                paddingSize = iCalculatePaddingSizeFromInputSize( ...
                    this.PaddingMode, this.PaddingSize, ...
                    this.EffectiveFilterSize, this.Stride, inputSize );
                % Note that padding is stored as [top bottom left right] but
                % the function expects [top left bottom right].
                Z = this.ExecutionStrategy.forward( X, ...
                    this.LearnableParameters(1).Value, ...
                    this.LearnableParameters(2).Value, ...
                    paddingSize(1), paddingSize(3), ...
                    paddingSize(2), paddingSize(4), ...
                    this.Stride(1), this.Stride(2), ...
                    this.DilationFactor(1), this.DilationFactor(2), ...
                    this.NumGroups);
            else
                Z = predict@nnet.internal.cnn.layer.FusedLayer( this, X );
            end
        end
        
        % forward   Forward input data through the layer and output the
        % result, with any memory needed for backpropagation
        function [Z, memory] = forward( this, X )
            if ~isempty(this.ExecutionStrategy)
                Z = predict( this, X );
                memory = [];
            else
                [Z, memory] = forward@nnet.internal.cnn.layer.FusedLayer( this, X );
            end
        end
        
        % backward    Back propagate the derivative of the loss function
        % through the layer
        function varargout = backward( this, X, Z, dLossdZ, memory )
            if ~isempty(this.ExecutionStrategy)
                inputSize = size(X,1:2);
                paddingSize = iCalculatePaddingSizeFromInputSize( ...
                    this.PaddingMode, ...
                    this.PaddingSize, ...
                    this.EffectiveFilterSize, ...
                    this.Stride, inputSize );
                [varargout{1:nargout}] = this.ExecutionStrategy.backward( ...
                    X, this.LearnableParameters(1).Value, Z, dLossdZ, ...
                    paddingSize(1), paddingSize(3), ...
                    paddingSize(2), paddingSize(4), ...
                    this.Stride(1), this.Stride(2), ...
                    this.DilationFactor(1), this.DilationFactor(2), ...
                    this.NumGroups);
            else
                [varargout{1:nargout}] = ...
                    backward@nnet.internal.cnn.layer.FusedLayer( this, ...
                    X, Z, dLossdZ, memory );
            end
        end

    end
    
    %% Utility methods
    methods( Access = private )
        
        function this = setHostStrategy( this )
            if isscalar(this.NumFilters)
                this.ExecutionStrategy = nnet.internal.cnn.layer.util.ConvolutionReLUHostStrategy;
            else
                this.ExecutionStrategy = [];
            end
        end
        
        function this = setGPUStrategy( this )
            if isscalar(this.NumFilters)
                this.ExecutionStrategy = nnet.internal.cnn.layer.util.ConvolutionReLUGPUStrategy;
            else
                this.ExecutionStrategy = [];
            end
        end
    end
    
end

function paddingSize = iCalculatePaddingSizeFromInputSize( ...
    paddingMode, paddingSize, filterOrPoolSize, stride, spatialInputSize)
paddingSize = nnet.internal.cnn.layer.padding.calculatePaddingSizeFromInputSize( ...
    paddingMode, paddingSize, filterOrPoolSize, stride, spatialInputSize);
end

function info = iExplicitGraphInfo()
% Information about the graph of ConvReLU layer needed for the propagation

info.NumActivations = 2;
info.ListOfBufferInputIndices = {double.empty(1,0);1};
info.ListOfBufferOutputIndices = {1;2};
info.ListOfBufferIndicesForClearingForward = {[];1};
info.ListOfBufferIndicesForClearingBackward = {1;2};
end
