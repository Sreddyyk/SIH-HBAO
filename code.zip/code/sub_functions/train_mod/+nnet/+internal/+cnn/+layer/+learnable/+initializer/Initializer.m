classdef Initializer
    % Initializer   Interface for learnable parameter initializers

    %   Copyright 2018 The MathWorks, Inc.

    properties
        % Name    Initializer name (string)
        Name
        
        % Fcn    Function to initializer the learnable parameter
        Fcn
    end

    methods (Abstract)
        % Initialize parameters
        initialize(this, paramSize, paramName)

        % Convert to struct ready for serialization        
        toStruct(this)
    end

    methods (Static)
        % Create from struct
        function this = fromStruct(s)
            if ~isempty(s.ConstructorArguments)
                this = feval(s.Class, s.ConstructorArguments{:});
            else
                this = feval(s.Class);
            end
        end
    end
    
    methods (Access = protected, Abstract)
        % Function to check equality of initializers
        privateIsEqual(this, anotherInitializer)
    end
    
    % Public methods common to all initializers
    methods       
        function tf = isequal(this, anotherInitializer)
            tf = privateIsEqual(this, anotherInitializer);
        end
        
        function tf = isequaln(this, anotherInitializer)
            tf = privateIsEqual(this, anotherInitializer);
        end
    end    
end