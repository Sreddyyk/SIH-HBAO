classdef FullyConnectedGPU3DImageStrategy < nnet.internal.cnn.layer.util.FullyConnectedImageStrategy
    % FullyConnectedHostImageStrategy   Execution strategy for running the
    % fully connected layer on the GPU with image inputs

    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function X = sendToDevice(~, X)
            X = gpuArray(X);
        end
        
        function Z = convolveForward(~, X, weights)
            Z = nnet.internal.cnngpu.convolveForwardND(X, weights, [0, 0, 0],...
                                                                   [1, 1, 1],...
                                                                   [1, 1, 1]);
        end
        
        function dX = convolveBackwardData(~, X, weights, dZ)
            dX = nnet.internal.cnngpu.convolveBackwardDataND(X, weights, dZ, [0, 0, 0],...
                                                                   [1, 1, 1],...
                                                                   [1, 1, 1]);
        end
        
        function dW = convolveBackwardFilter(~, X, weights, dZ)
            dW = nnet.internal.cnngpu.convolveBackwardFilterND(X, weights, dZ, [0, 0, 0],...
                                                                   [1, 1, 1],...
                                                                   [1, 1, 1]);
        end
        
        function dB = convolveBackwardBias(~, dZ)
            dB = nnet.internal.cnngpu.convolveBackwardBiasND(3, dZ);
        end
    end
end