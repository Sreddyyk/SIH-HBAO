classdef BatchNormalization < ...
        nnet.internal.cnn.layer.FunctionalStatefulLayer ...
        & nnet.internal.cnn.layer.Finalizable ...
        & nnet.internal.cnn.layer.CPUFusableLayer
    % BatchNormalization   Implementation of the batch normalization layer
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    properties
        % LearnableParameters   Learnable parameters for the layer
        % (Vector of
        % nnet.internal.cnn.layer.learnable.PredictionLearnableParameter)
        LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
        
        % Name  A name for the layer (char vector)
        Name
        % Epsilon  Offset for variance to avoid divide-by-zero (double
        % scalar)
        Epsilon
        
        % NumTrainingSamples  Number of samples used to compute
        % TrainedMean and TrainedVariance.
        NumTrainingSamples = 0;
        
        % Decay factors for moving statistics
        MeanDecay
        VarianceDecay
    end
    
    properties (Constant)
        % DefaultName   Default layer's name.
        DefaultName = 'batchnorm'
    end
    
    properties (SetAccess = private)
        % InputNames   This layer has a single input
        InputNames = {'in'}
        
        % OutputNames   This layer has a single output
        OutputNames = {'out'}
        
        % NumChannels  Number of channels in the input. Leave as [] to
        % infer later.
        NumChannels
    end
    
    properties (Dependent, SetAccess = private)       
        % HasSizeDetermined   Specifies if all size parameters are set
        %   Both NumChannels and ChannelDim need to be set for this to be
        %   true.
        HasSizeDetermined
    end
   
    properties
        % ChannelDim  The channel dimension in the input. Leave as [] to
        % infer later.
        ChannelDim
    end
    
    properties(Access = private)
        ExecutionStrategy
        
        IsTraining
        IsInFunctionalMode
        
        % The trained values should be cached on the GPU during to improve
        % performance. This should be hidden from the caller, which always
        % receives a host-side copy.
        PrivateTrainedMean
        PrivateTrainedVariance
        
        ParamTableCreator = nnet.internal.cnn.layer.util.ParamTableCreator;
    end
    
    properties (Dependent)
        % Learnable Parameters (nnet.internal.cnn.layer.LearnableParameter)
        Offset
        Scale
        % TrainedMean  Per-channel mean of the layer input data, determined
        % during training.
        TrainedMean
        % TrainedVariance  Per-channel variance of the layer input data,
        % determined during training.
        TrainedVariance
        % Learnables    Cell array of learnable parameters
        Learnables
        % State    Table with moving statistics
        State
    end
    
    properties(Dependent, SetAccess=private)
        % ExpectedSize    Expected external size of the parameters
        ExpectedSize
    end
    
    properties(SetAccess=private)
        % StateNames    Names of state parameters
        StateNames = ["TrainedMean"; "TrainedVariance"]
    end
    
    properties (Constant, Access = {?nnet.internal.cnn.layer.ConvolutionBatchNormActivation, ?nnet.internal.cnn.layer.GroupedConvolutionBatchNormActivation})
        % OffsetIndex  Index of Offset within LearnableParameters
        OffsetIndex = 1;
        % ScaleIndex  Index of Scale within LearnableParameters
        ScaleIndex = 2;
    end
    
    properties(SetAccess=protected, GetAccess=?nnet.internal.cnn.dlnetwork)
        LearnablesNames = ["Offset" "Scale"]
    end
    
    methods (Access = private)
        function this = initializePopulationStatistics(this)
            this.PrivateTrainedMean = nnet.internal.cnn.layer.util.CachedParameter([]);
            this.PrivateTrainedVariance = nnet.internal.cnn.layer.util.CachedParameter([]);
            this.NumTrainingSamples = 0;
        end
    end
    
    methods
        function this = BatchNormalization(name, numChannels, Epsilon)
            % BatchNormalization   Constructor for a BatchNormalization layer
            %
            %   Create a batch normalization layer with the following
            %   compulsory parameters:
            %
            %       name        - Name for the layer
            %       numChannels - The number of channels that the input to the
            %                     layer will have. Use [] to leave it unset.
            %       Epsilon     - Scalar specifying variance offset to avoid
            %                     divide-by-zero.
            
            this.Name = name;
            
            % Set Hyper-parameters
            this.NumChannels = numChannels;
            this.Epsilon = Epsilon;
            
            this.ChannelDim = [];
            
            % Initialize population statistics
            this = initializePopulationStatistics(this);
            
            % Set up LearnableParameters
            this.Offset = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter();
            this.Scale = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter();
            % Set default initializers. The casual constructor overwrites
            % these values, which are set only for internal code that
            % bypasses it.
            this.Offset.Initializer = iInternalInitializer('zeros');
            this.Scale.Initializer = iInternalInitializer('ones');
            
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.BatchNormalizationHostStrategy();
            this.IsTraining = false;
            this.IsInFunctionalMode = false;
            
            this.MeanDecay = .1;
            this.VarianceDecay = .1;
            
            % BatchNormalization layer needs X but not Z for the backward
            % pass
            this.NeedsXForBackward = true;
            this.NeedsZForBackward = false;
        end
        
        function [Z, memory] = forward( this, X )
            % forward   Forward input data through the layer at training
            % time and output the result
            [Z, memory] = this.ExecutionStrategy.forwardTrain( ...
                X, ...
                this.Offset.Value, this.Scale.Value, this.Epsilon, this.ChannelDim );
            if this.IsInFunctionalMode
                % Store the new state in the memory
                batchMean = reshape(memory{1}, this.ExpectedSize);
                batchVar  = reshape(memory{2}, this.ExpectedSize);
                newMean = nnet.internal.cnn.statistics.exponentialMovingAverage(...
                    batchMean, this.TrainedMean, this.MeanDecay);
                newVar = nnet.internal.cnn.statistics.exponentialMovingAverage(...
                    batchVar, this.TrainedVariance, this.VarianceDecay);
                memory = makeStateTable(this, newMean, newVar);
            end
        end
        
        function [Z, state] = predict( this, X )
            % predict   Forward input data through the layer at prediction
            % time and output the result
            
            % The state is empty during predict
            state = [];
            
            % If being called in training mode, use forward. If in predict
            % then we can expect the finalized mean and variance to be
            % available.
            if this.IsTraining
                Z = this.ExecutionStrategy.forwardTrain( ...
                    X, ...
                    this.Offset.Value, this.Scale.Value, this.Epsilon, this.ChannelDim );
                return
            end
            
            this.checkPropertiesAreFinalized()
            
            if this.IsInFunctionalMode
                trainedMean = this.PrivateTrainedMean;
                trainedVariance = this.PrivateTrainedVariance;
            else
                trainedMean = this.PrivateTrainedMean.Value;
                trainedVariance = this.PrivateTrainedVariance.Value;
            end
            Z = this.ExecutionStrategy.forwardPredict( ...
                X, ...
                this.Offset.Value, this.Scale.Value, this.Epsilon, ...
                trainedMean, trainedVariance, this.ChannelDim );
        end
        
        function varargout = backward( this, X, ~, dZ, memory )
            % backward    Back propagate the derivative of the loss function
            % through the layer
            % Z is not used for backward propagation with
            % BatchNormalization. Setting it as empty gives the same answer
            [ varargout{1:nargout} ] = this.ExecutionStrategy.backward([], dZ, X, ...
                this.Scale.Value, this.Epsilon, memory, this.ChannelDim);
        end

        function layer = finalize(layer, X, ~, memory )
            % Update running estimates of input mean and variance over the
            % training population.
            [batchMean, invSqrtVarPlusEps] = deal(memory{:});
            batchVar = 1./invSqrtVarPlusEps.^2 - layer.Epsilon;
            N = numel(X) ./ numel(batchMean); % How many input samples per channel
            
            [newMean, newVar, newN] = iMergeStats( ...
                layer.TrainedMean, layer.TrainedVariance, layer.NumTrainingSamples, ...
                batchMean, batchVar, N);
            
            % Always make sure the final parameters are on the host
            layer.TrainedMean = gather(newMean);
            layer.TrainedVariance = gather(newVar);
            layer.NumTrainingSamples = gather(newN);
        end
        
        function layer = mergeFinalized(layer, layer2)
            % Merge two partially finalized layer objects
            [newMean, newVar, newN] = iMergeStats( ...
                layer.TrainedMean, layer.TrainedVariance, layer.NumTrainingSamples, ...
                layer2.TrainedMean, layer2.TrainedVariance, layer2.NumTrainingSamples);
            
            layer.TrainedMean = newMean;
            layer.TrainedVariance = newVar;
            layer.NumTrainingSamples = newN;
        end
        
        function checkPropertiesAreFinalized(this)
            % checkPropertiesAreFinalized  Throw an error if TrainedMean or
            % TrainedVariance is not finalized
            if isempty(this.TrainedMean) || isempty(this.TrainedVariance)
                error( message('nnet_cnn:layer:BatchNormalizationLayer:NotFinalized') );
            end
        end
        
        function this = inferSize(this, inputSize)
            % inferSize     Infer the number of channels based on the input size
            
            numInputDims = numel(inputSize);
            if numInputDims == 1
                error(message('nnet_cnn:layer:BatchNormalizationLayer:OneDInputSize'))
            elseif numInputDims == 2
                % For internal diagnostics
                error("Invalid input size")
            else
                % numInputDims >= 3
                this = this.inferNumChannels(inputSize);
                this.ChannelDim = numInputDims;
            end           
        end
        
        function this = inferNumChannels(this, inputSize)
            if isempty(this.NumChannels)
                this.NumChannels = inputSize(end);
            end
        end
        
        function tf = isValidInputSize(this, inputSize)
            % isValidInputSize   Check if the layer can accept an input of
            % a certain size. Any input with the right number of channels
            % (third dimension for 4-D arrays and fourth dimension for 5-D
            % arrays) can be accepted. Assume inferSize has been called
            % with the same argument inputSize.
            if ~this.HasSizeDetermined
                % If we haven't yet specified a size, any size is fine.
                tf = true;
                return
            end
            
            numInputDims = numel(inputSize);
            
            if numInputDims >= 3
                N = inputSize(numInputDims);
            else
                % For internal diagnostics
                error("Invalid input size")       
            end

            tf = (N == this.NumChannels && numInputDims == this.ChannelDim);
        end
        
        function outputSize = forwardPropagateSize(~, inputSize)
            % forwardPropagateSize    Output the size of the layer based on
            % the input size
            outputSize = inputSize;
        end
        
        function this = initializeLearnableParameters(this, precision)
            % initializeLearnableParameters    Initialize learnable
            % parameters using their initializer
            sz = [ones(1,this.ChannelDim-1) this.NumChannels];
            if isempty(this.Offset.Value)
                % Initialize only if it is empty
                offset = this.Offset.Initializer.initialize(sz, 'Offset');
                this.Offset.Value = precision.cast(offset);
            else
                % Cast to desired precision
                this.Offset.Value = precision.cast(this.Offset.Value);
            end
            
            if isempty(this.Scale.Value)
                % Initialize only if it is empty
                scale = this.Scale.Initializer.initialize(sz, 'Scale');
                this.Scale.Value = precision.cast(scale);
            else
                % Cast to desired precision
                this.Scale.Value = precision.cast(this.Scale.Value);
            end
            
            % Also cast the population statistics
            this.TrainedMean = precision.cast(this.TrainedMean);
            this.TrainedVariance = precision.cast(this.TrainedVariance);
        end
        
        function this = prepareForTraining(this)
            % prepareForTraining   Prepare this layer for training
            %   Before this layer can be used for training, we need to
            %   convert the learnable parameters to use the class
            %   TrainingLearnableParameter.
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2training(this.LearnableParameters);
            this.IsTraining = true;
            
            this = initializePopulationStatistics(this);
        end
        
        function this = prepareForPrediction(this)
            % prepareForPrediction   Prepare this layer for prediction
            %   Before this layer can be used for prediction, we need to
            %   convert the learnable parameters to use the class
            %   PredictionLearnableParameter.
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2prediction(this.LearnableParameters);
            this.IsTraining = false;
        end
        
        function this = setupForHostPrediction(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.BatchNormalizationHostStrategy();
            this.LearnableParameters(1).UseGPU = false;
            this.LearnableParameters(2).UseGPU = false;
            this.PrivateTrainedMean.UseGPU = false;
            this.PrivateTrainedVariance.UseGPU = false;
        end
        
        function this = setupForGPUPrediction(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.BatchNormalizationGPUStrategy();
            this.LearnableParameters(1).UseGPU = true;
            this.LearnableParameters(2).UseGPU = true;
            this.PrivateTrainedMean.UseGPU = true;
            this.PrivateTrainedVariance.UseGPU = true;
        end
        
        function this = setupForHostTraining(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.BatchNormalizationHostStrategy();
            % Also make sure any trained parameters are gathered
            [this.TrainedMean, this.TrainedVariance] = ...
                gather(this.TrainedMean, this.TrainedVariance);
        end
        
        function this = setupForGPUTraining(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.BatchNormalizationGPUStrategy();
        end
        
        % setupForFunctional   Prepare this layer for functional (dlarray)
        % strategy
        function this = setupForFunctional(this)
            this = setupForFunctional@nnet.internal.cnn.layer.FunctionalStatefulLayer(this);
            % In functional mode the statistics are stored directly as
            % numeric arrays, rather than in CachedParameter objects.
            if ~this.IsInFunctionalMode
                this.PrivateTrainedMean = this.PrivateTrainedMean.Value;
                this.PrivateTrainedVariance = this.PrivateTrainedVariance.Value;
            end
            this.IsInFunctionalMode = true;
        end
        
        % revertSetupForFunctional   Revert strategy to Host, and
        % Learnables to numeric.
        function this = revertSetupForFunctional(this)
            this.PrivateTrainedMean = nnet.internal.cnn.layer.util.CachedParameter(this.PrivateTrainedMean);
            this.PrivateTrainedVariance = nnet.internal.cnn.layer.util.CachedParameter(this.PrivateTrainedVariance);
            this = revertSetupForFunctional@nnet.internal.cnn.layer.FunctionalStatefulLayer(this);
            this.IsInFunctionalMode = false;
        end
        
        function tf = get.HasSizeDetermined(this)
            tf = ~isempty( this.NumChannels ) && ~isempty( this.ChannelDim );
        end 
        
        % Setter and getter for learnable parameters.
        % These allow addressing the learnable parameters by name.
        function value = get.Offset(this)
            value = this.LearnableParameters(this.OffsetIndex);
        end
        
        function this = set.Offset(this, value)
            this.LearnableParameters(this.OffsetIndex) = value;
        end
        
        function value = get.Scale(this)
            value = this.LearnableParameters(this.ScaleIndex);
        end
        
        function this = set.Scale(this, value)
            this.LearnableParameters(this.ScaleIndex) = value;
        end
        
        function value = get.TrainedMean(this)
            if this.IsInFunctionalMode
                value = this.PrivateTrainedMean;
            else
                value = this.PrivateTrainedMean.HostValue;
            end
        end
        
        function value = get.TrainedVariance(this)
            if this.IsInFunctionalMode
                value = this.PrivateTrainedVariance;
            else
                value = this.PrivateTrainedVariance.HostValue;
            end
        end
        
        function this = set.TrainedMean(this, value)
            if this.IsInFunctionalMode
                this.PrivateTrainedMean = value;
            else
                this.PrivateTrainedMean.Value = value;
            end
        end
        
        function this = set.TrainedVariance(this, value)
            if this.IsInFunctionalMode
                this.PrivateTrainedVariance = value;
            else
                this.PrivateTrainedVariance.Value = value;
            end
        end
        
        function learnables = get.Learnables(this)
            % Assume setupForFunctional has been called
            w = this.Offset.Value;
            b = this.Scale.Value;
            learnables = {w, b};
        end
        
        function this = set.Learnables(this, learnables)
            % Assume setupForFunctional has been called    
            expSize = this.ExpectedSize;
            nnet.internal.cnn.layer.paramvalidation.assertValidLearnables(learnables{1}, expSize);
            nnet.internal.cnn.layer.paramvalidation.assertValidLearnables(learnables{2}, expSize);
            
            this.LearnableParameters(this.OffsetIndex).Value = learnables{1};
            this.LearnableParameters(this.ScaleIndex).Value = learnables{2};
        end 
        
        function t = get.State(this)
            t = makeStateTable(this, this.TrainedMean, this.TrainedVariance);
        end
        
        function this = set.State(this, state)
            % Assume setupForFunctional has been called
            nnet.internal.cnn.layer.util.ParamTableCreator.assertTableContents(state, ...
                this.Name, this.StateNames);
            
            % We have already asserted that the table contains values in the order we
            % expect, so we can directly index them out.
            v = state.Value;
            mean = v{1};
            var = v{2};
            
            expectedClass = {'single'};
            expectedAttributes = {'size', this.ExpectedSize};
            validateattributes(mean, expectedClass, expectedAttributes,...
                '', this.StateNames(1));
            validateattributes(var, expectedClass, expectedAttributes,...
                '', this.StateNames(2));
            
            this.TrainedMean = mean;
            this.TrainedVariance = var;
        end        
        
        function sz = get.ExpectedSize(this)
            % Assumes HasSizeDetermined
            sz = [ones(1,this.ChannelDim-1) this.NumChannels];
        end
    end
    
    methods (Hidden)
        function layerArgs = getFusedArguments(layer)
            % getFusedArguments  Returned the arguments needed to call the
            % layer in a fused network.
            layerArgs = { 'batchnorm', layer.Offset.Value, ...
                layer.Scale.Value, layer.Epsilon, layer.TrainedMean, ...
                layer.TrainedVariance };
        end

        function tf = isFusable(layer, ~, numDataDimensions)
            % isFusable  Indicates if the layer is fusable in a given network.
            tf = isempty(layer.ChannelDim) || (numDataDimensions == (layer.ChannelDim-1));
        end
    end
    
    methods(Access=protected)
        function this = setFunctionalStrategy(this)
            this.ExecutionStrategy = ...
                nnet.internal.cnn.layer.util.BatchNormalizationFunctionalStrategy();
        end

        function this = initializeStates(this)
            % initializeStates    Zero as init value if empty
            precision = nnet.internal.cnn.util.Precision('single');
            if isempty(this.TrainedMean)
                this.TrainedMean = zeros(precision, this.ExpectedSize);
            else
                this.TrainedMean = precision.cast(this.TrainedMean);
            end
            
            if isempty(this.TrainedVariance)
                this.TrainedVariance = ones(precision, this.ExpectedSize);
            else
                this.TrainedVariance = precision.cast(this.TrainedVariance);
            end            
        end        
    end
    
    methods(Access=private)
        function tbl = makeStateTable(this, mean, var)
            persistent protoTable
            if isempty(protoTable)
                protoTable = create(this.ParamTableCreator, ...
                "", this.StateNames, ...
                {[]; []});
            end
            
            % Assume setupForFunctional has been called
            tbl = protoTable;
            lname = string(this.Name);
            tbl.Layer = [lname; lname];
            tbl.Value = {mean; var};
        end
    end
end


function initializer = iInternalInitializer(name)
initializer = nnet.internal.cnn.layer.learnable.initializer...
    .initializerFactory(name);
end

function [mean3, var3, N3] = iMergeStats(mean1, var1, N1, mean2, var2, N2)
% Calculate the combined population mean and variance given two smaller
% population means and variances.

if N1 == 0
    % No samples in first stats, so just use second
    N3 = N2;
    mean3 = mean2;
    var3 = var2;
    
elseif N2 == 0
    % No samples in second stats, so just use first
    N3 = N1;
    mean3 = mean1;
    var3 = var1;
    
else
    % Calculate combined mean and number of samples
    N3 = N1 + N2;
    ratio = N2 ./ N3;
    mean3 = (1-ratio).*mean1 + ratio.*mean2;
    % Use the calculated mean to calculate an updated variance
    var3 = (1-ratio) .* (var1 + mean1.^2) ...
        + ratio .* (var2 + mean2.^2) ...
        - mean3.^2;
end
end
