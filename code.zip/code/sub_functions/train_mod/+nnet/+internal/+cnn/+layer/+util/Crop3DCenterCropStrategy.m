classdef Crop3DCenterCropStrategy < nnet.internal.cnn.layer.util.Crop3DStrategy
    % Center crop.
    
    % Copyright 2019 The MathWorks, Inc.
    methods
       
        %------------------------------------------------------------------
        function [rows, cols, planes] = cropWindow(~, sz, outputSize)
            % Position crop window in center of feature map of size sz.
            centerX = floor(sz(1:3)/2 + 1);
            centerWindow = floor(outputSize/2 + 1);
            
            offset = centerX - centerWindow + 1;
            
            R = offset(1);
            C = offset(2);
            P = offset(3);
            
            H = outputSize(1);
            W = outputSize(2);
            D = outputSize(3);
            
            rows   = R:(R + H - 1);
            cols   = C:(C + W - 1);
            planes = P:(P + D - 1);
        end
    end
end