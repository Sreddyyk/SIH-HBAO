function propertyList = getPublicVisibleProperties( obj )
metaLayer = metaclass(obj);
allProperties = metaLayer.PropertyList;
propertyList = {};
for ii=1:numel(allProperties)
    prop = allProperties(ii);
    if ~prop.Hidden && all(strcmp(prop.GetAccess,'public'))
        propertyList{end+1} = prop.Name; %#ok<AGROW>
    end
end
end