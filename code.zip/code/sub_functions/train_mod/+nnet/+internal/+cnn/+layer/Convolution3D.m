classdef Convolution3D < nnet.internal.cnn.layer.FunctionalLayer ...
    & nnet.internal.cnn.layer.CPUFusableLayer
    % Convolution3D   Implementation of the 3D convolution layer
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties
        % LearnableParameters   Learnable parameters for the layer
        % (Vector of nnet.internal.cnn.layer.learnable.PredictionLearnableParameter)
        LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
        
        % Name (char array)   A name for the layer
        Name
        
        % Stride (vector of int) Stride for each dimension
        Stride
        
        % DilationFactor (vector of int) Dilation factor for each dimension
        DilationFactor
        
        % PaddingSize   The padding applied to the input along the edges
        %   The padding that is applied along the edges. This is a row
        %   vector [t b l r f bk] where t is the padding to the top, b is the
        %   padding applied to the bottom, l is the padding applied to the
        %   left, r is the padding applied to the right and f, bk are paddings applied
        %   to front and back .
        PaddingSize   
    end
    
    properties (Constant)
        % DefaultName   Default layer's name.
        DefaultName = 'conv3d'
    end
    
    properties (SetAccess = private)
        % InputNames   This layer has a single input
        InputNames = {'in'}
        
        % OutputNames   This layer has a single output
        OutputNames = {'out'}
        
        % HasSizeDetermined   True for layers with size determined.
        HasSizeDetermined
        
        % Hyper-parameters
        
        % FilterSize  (1x3 int vector)  Size of each filter expressed in
        % height x width x depth
        FilterSize
        
        % NumChannels (int)   The number of channels that the input to the
        % layer will have. [] if it has to be inferred later
        NumChannels
        
        % NumFilters (int)  The number of filters in the layer
        NumFilters
        
        % PaddingMode   The mode used to determine the padding
        %   The mode used to calculate the PaddingSize property. This can
        %   be:
        %       'manual'    - PaddingSize is specified manually.
        %       'same'      - PaddingSize will be calculated so that the
        %                     output size is the same size as the input
        %                     when the stride is 1. More generally, the
        %                     output size will be ceil(inputSize/stride),
        %                     where inputSize is the height and width of
        %                     the input.
        PaddingMode
    end
    
    properties(Access = private)
        ExecutionStrategy
    end
    
    properties (Dependent)
        % Learnable Parameters (nnet.internal.cnn.layer.LearnableParameter)
        Weights
        Bias
        Learnables
    end
    
    properties(SetAccess=protected, GetAccess=?nnet.internal.cnn.dlnetwork)
        LearnablesNames = ["Weights" "Bias"]
    end
    
    properties (Dependent, SetAccess = private)
        % Effective filter size which takes into account dilation
        EffectiveFilterSize
        
        % Expected Weights size
        ExtWeightsSize
        
        % Expected Bias size
        ExtBiasSize
    end
    
    properties (Constant, Access = private)
        % WeightsIndex  Index of the Weights into the LearnableParameter
        %               vector
        WeightsIndex = 1;
        
        % BiasIndex     Index of the Bias into the LearnableParameter
        %               vector
        BiasIndex = 2;
    end
    
    methods
        function this = Convolution3D( ...
                name, filterSize, numChannels, numFilters, stride, dilationFactor, paddingMode, paddingSize)
            % Convolution3D   Constructor for a Convolution3D layer
            %
            %   Create a 3D convolutional layer with the following
            %   compulsory parameters:
            %
            %       name            - Name for the layer
            %       filterSize      - Size of the filters [height x width x depth]
            %       numChannels     - The number of channels that the input
            %                       to the layer will have. [] if it has to
            %                       be determined later
            %       numFilters      - The number of filters in the layer
            %       dilationFactor  - A vector specifying the dilation factor for
            %                       each dimension [height width depth]
            %       stride          - A vector specifying the stride for
            %                       each dimension [height width depth]
            %       paddingMode     - A string, 'manual' or 'same'.
            %       paddingSize     - A vector specifying the padding for
            %                       each dimension [top bottom left right front back]
            
            this.Name = name;
            
            % Set Hyper-parameters
            this.FilterSize = filterSize;
            this.NumChannels = numChannels;
            this.HasSizeDetermined = ~isempty( numChannels ) && ~iIsTheStringSame(paddingMode);
            this.NumFilters = numFilters;
            this.Stride = stride;
            this.DilationFactor = dilationFactor;
            this.PaddingMode = paddingMode;
            this.PaddingSize = paddingSize;
            
            % Set weights and bias to be LearnableParameter
            this.Weights = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter();
            this.Bias = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter();
            % Set default initializers. convolution2dLayer overwrites these
            % values, which are set only for internal code that bypasses
            % convolution2dLayer.
            this.Weights.Initializer = iInternalInitializer('narrow-normal');
            this.Bias.Initializer = iInternalInitializer('zeros');
            
            this = this.setHostStrategy();
        end
        
        function Z = predict( this, X )
            % predict   Forward input data through the layer and output the result
            Z = this.forward(X);
        end
        
        function [Z, memory] = forward( this, X )
            % forward   Forward propagate data during training
            inputSize = [size(X,1) size(X,2) size(X,3)];
            paddingSize = iCalculatePaddingSizeFromInputSize( ...
                this.PaddingMode, this.PaddingSize, this.EffectiveFilterSize, ...
                this.Stride, inputSize );
            Z = this.ExecutionStrategy.forward(X, this.Weights.Value, ...
                this.Bias.Value, paddingSize, this.Stride, ...
                this.DilationFactor);
            memory = [];
        end
        
        function varargout = backward( this, X, ~, dZ, ~ )
            % backward    Back propagate the derivative of the loss function
            % through the layer
            inputSize = [size(X,1) size(X,2) size(X,3)];
            paddingSize = iCalculatePaddingSizeFromInputSize( ...
                this.PaddingMode, this.PaddingSize, this.EffectiveFilterSize, ...
                this.Stride, inputSize );
            [varargout{1:nargout}] = this.ExecutionStrategy.backward( ...
                X, this.Weights.Value, dZ, ...
                paddingSize, this.Stride, this.DilationFactor);
        end
        
        function this = inferSize(this, inputSize)
            % inferSize     Infer the number of channels based on the input size
            this.NumChannels = iNumChannelsFromInputSize(inputSize);
            
            if iIsTheStringSame(this.PaddingMode)
                this.PaddingSize = iCalculateSamePadding( ...
                    this.EffectiveFilterSize, this.Stride, inputSize(1:3));
                
                % If the padding is set to 'same', the size will always
                % need to be determined again because we will need to
                % recalculate the padding.
                this.HasSizeDetermined = false;
            else
                this.HasSizeDetermined = true;
            end
        end
        
        function tf = isValidInputSize(this, inputSize)
            % isValidInputSize   Check if the layer can accept an input of
            % a certain size
            tf = numel(inputSize)==4 && ...
                this.isFilterSizeSmallerThanImage( inputSize ) && ...
                this.numFilterChannelsMatchesNumImageChannels( inputSize );
        end
        
        function outputSize = forwardPropagateSize(this, inputSize)
            % forwardPropagateSize    Output the size of the layer based on
            % the input size
            paddingSize = iCalculatePaddingSizeFromInputSize( ...
                this.PaddingMode, this.PaddingSize, this.EffectiveFilterSize, ...
                this.Stride, inputSize(1:3));
            heightAndWidthPadding = iCalculateHeightAndWidthPadding(paddingSize);
            outputHeightAndWidth = floor((inputSize(1:3) + ...
                heightAndWidthPadding - this.EffectiveFilterSize)./this.Stride) + 1;
            outputSize = [outputHeightAndWidth sum(this.NumFilters)];
        end
        
        function this = initializeLearnableParameters(this, precision)
            % initializeLearnableParameters    Initialize learnable
            % parameters using their initializer
            
            if isempty(this.Weights.Value)
                % Initialize only if it is empty
                weightsSize = [this.FilterSize, this.NumChannels, this.NumFilters];
                weights = this.Weights.Initializer.initialize(weightsSize, 'Weights');
                this.Weights.Value = precision.cast(weights); 
            else
                % Cast to desired precision
                this.Weights.Value = precision.cast(this.Weights.Value);
            end
            
            if isempty(this.Bias.Value)
                % Initialize only if it is empty
                biasSize = [1, 1, 1, this.NumFilters];
                bias = this.Bias.Initializer.initialize(biasSize, 'Bias');
                this.Bias.Value = precision.cast(bias);
            else
                % Cast to desired precision
                this.Bias.Value = precision.cast(this.Bias.Value);
            end
        end
        
        function this = prepareForTraining(this)
            % prepareForTraining   Prepare this layer for training
            %   Before this layer can be used for training, we need to
            %   convert the learnable parameters to use the class
            %   TrainingLearnableParameter.
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2training(this.LearnableParameters);
        end
        
        function this = prepareForPrediction(this)
            % prepareForPrediction   Prepare this layer for prediction
            %   Before this layer can be used for prediction, we need to
            %   convert the learnable parameters to use the class
            %   PredictionLearnableParameter.
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2prediction(this.LearnableParameters);
        end
        
        function this = setupForHostPrediction(this)
            this = this.setHostStrategy();
            this.LearnableParameters(1).UseGPU = false;
            this.LearnableParameters(2).UseGPU = false;
        end
        
        function this = setupForGPUPrediction(this)
            this = this.setGPUStrategy();
            this.LearnableParameters(1).UseGPU = true;
            this.LearnableParameters(2).UseGPU = true;
        end
        
        function this = setupForHostTraining(this)
            this = this.setHostStrategy();
        end
        
        function this = setupForGPUTraining(this)
            this = this.setGPUStrategy();
        end
        
        % Setter and getter for Weights and Bias
        % These make easier to address into the vector of LearnableParameters
        % giving a name to each index of the vector
        function weights = get.Weights(this)
            weights = this.LearnableParameters(this.WeightsIndex);
        end
        
        function this = set.Weights(this, weights)
            this.LearnableParameters(this.WeightsIndex) = weights;
        end
        
        function bias = get.Bias(this)
            bias = this.LearnableParameters(this.BiasIndex);
        end
        
        function this = set.Bias(this, bias)
            this.LearnableParameters(this.BiasIndex) = bias;
        end
        
        function learnables = get.Learnables(this)
            % Assume setupForFunctional has been called
            w = this.Weights.Value;
            b = this.Bias.Value;
            learnables = {w, b};
        end
        
        function this = set.Learnables(this, learnables)
            % Assume setupForFunctional has been called
            nnet.internal.cnn.layer.paramvalidation.assertValidLearnables(learnables{1}, this.ExtWeightsSize);
            nnet.internal.cnn.layer.paramvalidation.assertValidLearnables(learnables{2}, this.ExtBiasSize);
            
            this.LearnableParameters(this.WeightsIndex).Value = learnables{1};
            this.LearnableParameters(this.BiasIndex).Value = learnables{2};
        end
        
        function dilatedFilterSize = get.EffectiveFilterSize(this)
            % Dilation is equivalent to adding extra zeros in between the
            % elements of the filter so that it leads to the following
            % effective filter size:
            % dilatedFilterSize = filterSize +
            % (filterSize - 1) * (dilationFactor - 1)
            % or, simplifying:
            dilatedFilterSize = (this.FilterSize - 1) .* this.DilationFactor + 1;
        end
        
        function sz = get.ExtWeightsSize(this)
            expectedNumChannels = iExpectedNumChannels(this.NumChannels);
            sz = [this.FilterSize expectedNumChannels this.NumFilters];
        end
        
        function sz = get.ExtBiasSize(this)
            sz = [1 1 1 this.NumFilters];
        end 
    end
    
    methods(Access = private)       
        function tf = isFilterSizeSmallerThanImage( this, inputSize )
            % The size of the image is given by the first two dimensions of the input size
            imageSize = inputSize(1:3);
            
            % Need to take padding as well as dilation factor into account when comparing
            % image size and filter size
            heightAndWidthPadding = iCalculateHeightAndWidthPadding(this.PaddingSize);
            tf = all( this.EffectiveFilterSize <= imageSize + heightAndWidthPadding );
        end
        
        function tf = numFilterChannelsMatchesNumImageChannels( this, inputSize )
            numImageChannels = inputSize(4);
            tf = isempty(this.NumChannels) || this.NumChannels == numImageChannels;
        end
        
        function this = setHostStrategy(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.Convolution3DHostStridedConvStrategy();
        end
        
        function this = setGPUStrategy(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.Convolution3DGPUStrategy();
        end
    end
    
    methods(Access=protected)
        function this = setFunctionalStrategy(this)
            this.ExecutionStrategy = ...
                nnet.internal.cnn.layer.util.Convolution3DFunctionalStrategy();
        end
    end
    
    methods (Hidden)
        function layerArgs = getFusedArguments(layer)
            % getFusedArguments  Returned the arguments needed to call the
            % layer in a fused network.
            import nnet.internal.cnn.layer.*
            grps = layer.NumFilters;
            padding = CPUGenericFusedLayer.shufflePadding(layer.PaddingSize);
            b = layer.Bias.Value;
            if ~any(b) && all(isfinite(b))
                b = [];
            end
            layerArgs = { 'conv', layer.Weights.Value, ...
                padding, layer.Stride, layer.DilationFactor, b, grps };
        end

        function tf = isFusable(layer, precision, numDataDimensions)
            % isFusable  Indicates if the layer is fusable in a given network.
            tf = (numDataDimensions == 3) && (class(layer.Weights.Value) == precision);
        end
    end
end

function numChannels = iNumChannelsFromInputSize(inputSize)
% iNumChannelsFromInputSize   The number of channels is the fourth element
% in inputSize. If inputSize doesn't have four elements, then it is
% implicitly 1.
if numel(inputSize)<4
    numChannels = 1;
else
    numChannels = inputSize(4);
end
end

function expectedNumChannels = iExpectedNumChannels(NumChannels)
expectedNumChannels = NumChannels;
if isempty(expectedNumChannels)
    expectedNumChannels = NaN;
end
end

function tf = iIsTheStringSame(x)
tf = nnet.internal.cnn.layer.padding.isTheStringSame(x);
end

function paddingSize = iCalculatePaddingSizeFromInputSize( ...
    paddingMode, paddingSize, filterOrPoolSize, stride, spatialInputSize)
paddingSize = nnet.internal.cnn.layer.padding.calculatePaddingSizeFromInputSize( ...
    paddingMode, paddingSize, filterOrPoolSize, stride, spatialInputSize);
end

function totalPadding = iCalculateHeightAndWidthPadding(paddingSize)
totalPadding = nnet.internal.cnn.layer.padding.calculateHeightWidthAndDepthPadding(paddingSize);
end

function paddingSize = iCalculateSamePadding(filterSize, stride, inputSize)
paddingSize = nnet.internal.cnn.layer.padding.calculateSamePadding(filterSize, stride, inputSize);
end

function initializer = iInternalInitializer(name)
initializer = nnet.internal.cnn.layer.learnable.initializer...
    .initializerFactory(name);
end