function validate3DSizeParameter( value, parameterName )
% validateSizeParameter   Throw an error if the size parameter with name 
% given by the string parameterName is invalid.

%   Copyright 2018 The MathWorks, Inc.

validateattributes(value, {'numeric'}, ...
    {'nonempty', 'real', 'integer', 'positive'});

if ~(isscalar(value) || iIsRowVectorOfThree(value))
    error(message('nnet_cnn:layer:Layer:ParamMustBeScalarOrTriple', parameterName));
end
end

function tf = iIsRowVectorOfThree(x)
tf = isrow(x) && numel(x)==3;
end

