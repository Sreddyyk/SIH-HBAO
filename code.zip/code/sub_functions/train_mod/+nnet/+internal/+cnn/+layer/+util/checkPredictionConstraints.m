function checkPredictionConstraints(analyzedLayers)
% checkPredictionConstraints   Check that layerArrayOrGraph satisfies the
% built-in and prediction constraints through the network analyzer.

%   Copyright 2018-2019 The MathWorks, Inc.

% Apply built-in constraints
analyzedLayers.applyConstraints(); 
analyzedLayers.applyConstraints(iCustomPredictionConstraint());
analyzedLayers.applyConstraints(iInputLayersConstraint());
analyzedLayers.throwIssuesIfAny()
end

function constraint = iCustomPredictionConstraint()
constraint = nnet.internal.cnn.analyzer.constraints.customConstraints...
    .Prediction;
end

function constraint = iInputLayersConstraint()
constraint = nnet.internal.cnn.analyzer.constraints.train.InputLayers;
end