classdef LSTMGeneralStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % LSTMGeneralStrategy   Execution strategy for running LSTM with a
    % general set of options. This strategy is used for both host and GPU
    % implementations.
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties
        % Options   Struct containing five fields:
        %           - Activation
        %           - dActivation
        %           - RecurrentActivation
        %           - dRecurrentActivation
        %           - ReturnLast
        Options
    end
    
    methods
        function this = LSTMGeneralStrategy(activation, recurrentActivation, returnSequence)
            % Determine activation structs
            activationStruct = iGetActivation( activation );
            recurrentActivationStruct = iGetRecurrentActivation( recurrentActivation );
            
            % Gather options struct
            options.Activation = activationStruct.Fcn;
            options.dActivation = activationStruct.dFcn;
            options.RecurrentActivation = recurrentActivationStruct.Fcn;
            options.dRecurrentActivation = recurrentActivationStruct.dFcn;
            options.ReturnLast = ~returnSequence;
            this.Options = options;
        end
        
        function [Y, memory] = forward(this, X, W, R, b, c0, y0)
            learnable.W = W;
            learnable.R = R;
            learnable.b = b;
            state.c0 = c0;
            state.y0 = y0;
            [Y, HS, CS] = nnet.internal.cnnhost.lstmForwardGeneral(X, learnable, state, this.Options);
            memory.HiddenState = HS;
            memory.CellState = CS;
        end
        
        function varargout = backward(this, X, W, R, b, c0, y0, Y, memory, dZ)
            learnable.W = W;
            learnable.R = R;
            learnable.b = b;
            state.c0 = c0;
            state.y0 = y0;
            outputs.Y = Y;
            outputs.HS = memory.HiddenState;
            outputs.CS = memory.CellState;
            derivatives.dZ = dZ;
            derivatives.dHS = iInitializeStateDerivatives( memory.HiddenState );
            derivatives.dCS = iInitializeStateDerivatives( memory.CellState );
            [ varargout{1:nargout} ] =  nnet.internal.cnnhost.lstmBackwardGeneral(X, learnable, state, outputs, derivatives, this.Options);
        end
    end
end

function act = iGetActivation( activation )
switch activation
    case 'tanh'
        act.Fcn = @tanh;
        act.dFcn = @iTanhDiff;
    case 'softsign'
        act.Fcn = @iSoftSign;
        act.dFcn = @iSoftSignDiff;
end
end

function act = iGetRecurrentActivation( activation )
switch activation
    case 'sigmoid'
        act.Fcn = @iSigmoid;
        act.dFcn = @iSigmoidDiff;
    case 'hard-sigmoid'
        act.Fcn = @nnet.internal.cnnhost.hardSigmoidForward;
        act.dFcn = @nnet.internal.cnnhost.hardSigmoidBackward;
end
end

function ds = iInitializeStateDerivatives( s )
ds = zeros( size(s(:, :, end)), 'like', s );
end

%% Activation functions and derivatives
function y = iSigmoid(x)
y = 1./(1 + exp(-x));
end

function y = iSigmoidDiff(x)
y = ( 0.5.*sech(0.5.*x) ).^2;
end

function y = iTanhDiff(x)
y = sech(x).^2;
end

function y = iSoftSign(x)
y = x./(1 + abs(x));
end

function y = iSoftSignDiff(x)
y = (1 + abs(x)).^-2;
end