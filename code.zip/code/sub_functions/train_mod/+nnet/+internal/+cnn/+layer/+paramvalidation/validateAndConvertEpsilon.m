function epsilon = validateAndConvertEpsilon( value, minValue )
% validateAndConvertEpsilon   Throw an error if the value for Epsilon is
% not valid. minValue is supposed to be a double. Used by batch
% normalization layer. The returned value is always a double >= minValue.

%   Copyright 2018 The MathWorks, Inc.

validateattributes(value, {'numeric'}, ...
    {'scalar','finite','real','nonnegative'});

if value >= minValue 
    epsilon = double(value);
elseif minValue - value < eps(value)    
    % The distance between minValue and value is smaller than eps(value),
    % round it to minValue.
    epsilon = minValue;
else 
    exception = MException('MATLAB:notGreaterEqual', ...
        ['Expected input to be a scalar with value >= ' num2str(minValue) '.']);
    throw(exception);
end
end