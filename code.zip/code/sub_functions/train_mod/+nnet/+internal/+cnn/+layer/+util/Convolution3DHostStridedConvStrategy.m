classdef Convolution3DHostStridedConvStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % Convolution3DHostStridedConvStrategy   Execution strategy for running the convolution on the host
    
    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X, ...
                weights, bias, ...
                padding, stride, dilation)
            
            [paddingTLF, paddingBRB] = convertPaddingToHostAPIformat(padding);
            Z = nnet.internal.cnnhost.stridedConv3D( ...
                X, weights, ...
                paddingTLF, paddingBRB, stride, dilation);
            
            Z = Z + bias;
            memory = [];
        end
        
        function [dX,dW] = backward( ~, ...
                X, weights, dZ, ...
                padding, stride, dilation)
            
            needsWeightGradients = nargout > 1;
            [paddingTLF, paddingBRB] = convertPaddingToHostAPIformat(padding);
            dX = nnet.internal.cnnhost.convolveBackwardData3D( ...
                X, weights, dZ, ...
                paddingTLF, paddingBRB, stride, dilation);
            if needsWeightGradients
                dW{1} = nnet.internal.cnnhost.convolveBackwardFilter3D( ...
                    X, weights, dZ, ...
                    paddingTLF, paddingBRB, stride, dilation);
                dW{2} = nnet.internal.cnnhost.convolveBackwardBias3D(dZ);
            end
        end
    end
end

function [paddingTLF, paddingBRB] = convertPaddingToHostAPIformat(paddingSizeIn)
% Converts padding from [top bottom left right front back] to
% [top left front bottom right back]

padTop = paddingSizeIn(1);
padBottom = paddingSizeIn(2);
padLeft = paddingSizeIn(3);
padRight = paddingSizeIn(4);
padFront = paddingSizeIn(5);
padBack = paddingSizeIn(6);

paddingTLF = [padTop, padLeft, padFront];
paddingBRB = [padBottom, padRight, padBack];

end

