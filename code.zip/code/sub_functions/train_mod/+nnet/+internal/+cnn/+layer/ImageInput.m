classdef ImageInput < nnet.internal.cnn.layer.InputLayer ...
    & nnet.internal.cnn.layer.CPUFusableLayer
    % ImageInput   Image input layer
    
    %   Copyright 2015-2019 The MathWorks, Inc.
    
    properties
        % Name (char array)   A name for the layer
        Name
    end
    
    properties (Constant)
        % DefaultName   Default layer's name.
        DefaultName = 'imageinput'
    end
    
    properties (SetAccess = private)
        % HasSizeDetermined   True for layers with size determined.
        HasSizeDetermined
        
        % InputSize (vector of int)     Size of the input [height x width x
        %                               channels ]
        InputSize
        
        % Transforms        Normalization object.
        Transforms
        
        % TrainTransforms   Vector of InputTransform objects.
        TrainTransforms
    end
    
    properties(Dependent)
        % Mean   The average training image. Stored when the user
        %        requests zero centering or zscore normalization.
        Mean
        
        % Std    The standard deviation of training images. Stored when the 
        %        user requests zscore normalization.
        Std
        
        % Min    The minimum of training images. Stored when the user
        %        requests rescaling.
        Min
        
        % Max    The maximum of training images. Stored when the user
        %        requests rescaling.
        Max
        
        % NormalizationDimensions   A char vector describing the dimensions
        % to normalize over.
        NormalizationDimension        
    end
    
    properties(Access = private)
        PrivateNormalizationDimension = 'auto'
    end
    
    methods
        function this = ImageInput(name, inputSize, normalization, augmentations)
            % Input  Constructor for the layer
            this.Name = name;
            this.InputSize = inputSize;
            % Store transforms as row vectors. We always combine transforms
            % using horzcat.
            this.Transforms      = reshape(normalization, 1, []);
            this.TrainTransforms = reshape(augmentations, 1, []);
            this.HasSizeDetermined = true;
            
            % ImageInput layer doesn't need X or Z for the backward pass
            this.NeedsXForBackward = false;
            this.NeedsZForBackward = false;
            
            this.InputValidationStrategy = ...
                nnet.internal.cnn.layer.util.ImageInputValidator(this.InputSize);
        end
        
        function Z = predict( this, X )
            % predict   Forward propagation at test time
            
            % Run normalization
            Z = this.Transforms.apply(X);
        end
        
        function [Z, memory] = forward( this, X )
            % forward   Forward propagation at training time
            
            % Run augmentations, followed by normalization
            Z = this.Transforms.apply( ...
                this.TrainTransforms.apply(X));
            memory = [];
        end
        
        function [dX,dW] = backward( ~, ~, ~, ~, ~ )
            % backward  Return empty value
            dX = [];
            dW = [];
        end
        
        function outputSize = forwardPropagateSize(this, ~)
            % forwardPropagateSize  Output the size of the layer
            outputSize = this.InputSize;
        end
        
        function this = inferSize(this, ~)
            % inferSize     no-op since this layer has nothing that can be
            %               inferred
        end
        
        function tf = isValidInputSize(this, inputSize)
            % isValidInputSize   Check if the layer can accept an input of
            % a certain size
            tf = isequal( inputSize, this.InputSize );
        end
        
        function this = initializeLearnableParameters(this, precision)
            this.Mean = precision.cast(this.Mean);
            this.Std = precision.cast(this.Std);
            this.Min = precision.cast(this.Min);
            this.Max = precision.cast(this.Max);
        end
        
        function this = prepareForTraining(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.TrainingLearnableParameter.empty();
        end
        
        function this = prepareForPrediction(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
        end
        
        function this = setupForHostPrediction(this)
            this.Transforms = setupForHostTransform(this.Transforms);
        end
        
        function this = setupForGPUPrediction(this)
            this.Transforms = setupForGPUTransform(this.Transforms);
        end
        
        function this = setupForHostTraining(this)
            this.Mean = gather(this.Mean);
            this.Std = gather(this.Std);
            this.Min = gather(this.Min);
            this.Max = gather(this.Max);
        end
        
        function this = setupForGPUTraining(this)
        end

        function value = get.NormalizationDimension(this)
            value = this.PrivateNormalizationDimension;
        end
        
        function this = set.NormalizationDimension(this,value)
            this.PrivateNormalizationDimension = value;
            % Update the normalization dimension in the underlying transform
            if ~isempty(this.Transforms) && ~iIsCustomNormalization(this.Transforms)
                this.Transforms.NormalizationDimension = value;
            else
                % This case should have been caught throug the external
                % layer API.
            end
        end
        
        function tf = isValidTrainingImageSize(this, trainingImageSize)
            % isValidTrainingImageSize   True if the training image size is
            % valid for this network
            
            imageSizeAfterTransforms = trainingImageSize;
            for i = 1:numel(this.TrainTransforms)
                imageSizeAfterTransforms = this.TrainTransforms(i).forwardPropagateSize(imageSizeAfterTransforms);
            end
            tf = isequal(this.InputSize, imageSizeAfterTransforms);
        end
        
        function I = get.Mean(this)
            % Get average image or mean per channel from internal transform
            if iIsStatisticUsed(this.Transforms,'Mean')
                I = this.Transforms.Mean;
            else
                I = [];
            end
        end
        
        function this = set.Mean(this, val)
            % Update value of Mean. Forwards to transform set.Mean method.
            % Assume val is either 1x1xC, or HxWxC or empty.
            if iIsStatisticUsed(this.Transforms,'Mean')
                this.Transforms.Mean = val;
            end
        end
        
        function I = get.Std(this)
            % Get standard deviation from internal transform
            if iIsStatisticUsed(this.Transforms,'StandardDeviation')
                I = this.Transforms.Std;
            else
                I = [];
            end
        end
        
        function this = set.Std(this, val)
            % Update value of Std. Forwards to transform set.Std method.
            % Assume val is either 1x1xC, or HxWxC or empty.
            if iIsStatisticUsed(this.Transforms,'StandardDeviation')
                this.Transforms.Std = val;
            end
        end
        
        function I = get.Min(this)
            % Get minimum from internal transform
            if iIsStatisticUsed(this.Transforms,'Min')
                I = this.Transforms.Min;
            else
                I = [];
            end
        end
        
        function this = set.Min(this, val)
            % Update value of Min. Forwards to transform set.Min method.
            % Assume val is either 1x1xC, or HxWxC or empty.
            if iIsStatisticUsed(this.Transforms,'Min')
                this.Transforms.Min = val;
            end
        end
        
        function I = get.Max(this)
            % Get maximum from internal transform
            if iIsStatisticUsed(this.Transforms,'Max')
                I = this.Transforms.Max;
            else
                I = [];
            end
        end
        
        function this = set.Max(this, val)
            % Update value of Max. Forwards to transform set.Max method.
            % Assume val is either 1x1xC, or HxWxC or empty.
            if iIsStatisticUsed(this.Transforms,'Max')
                this.Transforms.Max = val;
            end
        end
        
        function this = reset(this)
            if ~isempty(this.Transforms)
                this.Transforms = reset(this.Transforms);
            end
        end
        
        function this = initialize(this, stats)
            if ~isempty(this.Transforms)
                this.Transforms = initialize(this.Transforms, stats);
            end
        end
        
        function tf = needsInitialization(this)
            tf = ~isempty(this.Transforms) && needsInitialization(this.Transforms);
        end
    end
    
    methods (Hidden)
        function layerArgs = getFusedArguments(layer)
            % getFusedArguments  Returned the arguments needed to call the
            % layer in a fused network.
            n = numel(layer.Transforms);
            supportedTransforms = [
                "nnet.internal.cnn.layer.RescaleNormalization"
                "nnet.internal.cnn.layer.ZeroCenterNormalization"
                "nnet.internal.cnn.layer.ZScoreNormalization"
            ];
            if (n > 1) || ((n == 1) && ~any(supportedTransforms == class(layer.Transforms(1))))
                % Layer can be fused through external layers.
                layerArgs = { 'external', @(X) layer.Transforms.apply(X), 1, 1 };
            else
                % No transforms, or supported transforms.
                if n == 0
                    layerArgs = { 'input' };
                elseif isa(layer.Transforms(1), 'nnet.internal.cnn.layer.ZeroCenterNormalization')
                    layerArgs = { 'input', 'meancenter', layer.Transforms(1).Mean };
                elseif isa(layer.Transforms(1), 'nnet.internal.cnn.layer.ZScoreNormalization')
                    layerArgs = { 'input', 'zscore', layer.Transforms(1).Mean, ...
                        layer.Transforms(1).Std };
                else
                    assert(isa(layer.Transforms(1), 'nnet.internal.cnn.layer.RescaleNormalization'));
                    layerArgs = { 'input', 'rescale', layer.Transforms(1).Min, ...
                        layer.Transforms(1).Max, layer.Transforms(1).TargetMin, ...
                        layer.Transforms(1).TargetMax };
                end
            end
        end

        function tf = isFusable(layer, ~, numDataDimensions)
            % isFusable  Indicates if the layer is fusable in a given network.

            % Number of data dimensions must agree with the input dimensions.
            tf = (length(layer.InputSize)-1) == numDataDimensions;
        end
    end
end

function tf = iIsStatisticUsed(transform,statsName)
tf = ~isempty(transform) && ismember(statsName,transform.Hyperparams);
end

function tf = iIsCustomNormalization(normalization)
tf = isa(normalization,'nnet.internal.cnn.layer.CustomNormalization');
end