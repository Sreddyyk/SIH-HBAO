classdef Flatten < nnet.internal.cnn.layer.Layer
    % Flatten   Flatten the spatial dimensions of a tensor
    %
    % The flatten layer flattens the spatial dimensions of the input into a
    % single channel. The layer preserves the observation dimension (N) and
    % the sequence dimension (S) after flattening. For example:
    %
    %   Description         | Size                        | Flattened size
    %   ----------------------------------------------------------------------
    %   Images              | H x W x C x N               | (H*W*C) x N
    %   3-d images          | H x W x D x C x N           | (H*W*D*C) x N
    %   m-d data            | D1 x D2 x ... x Dm x N      | (D1*D2*...*Dm) x N
    %   Tabular data        | C x N                       | C x N
    %   1-d sequences       | C x N x S                   | C x N x S
    %   Image sequences     | H x W x C x N x S           | (H*W*C) x N x S
    %   m-d sequences       | D1 x D2 x ... x Dm x N x S  | (D1*D2*...*Dm) x N x S
    
    %   Copyright 2018 The MathWorks, Inc.
    
    properties
        % LearnableParameters   Learnable parameters for the layer
        %   This layer has no learnable parameters.
        LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
        
        % Name (char array)   A name for the layer
        Name
    end
    
    properties (Constant)
        % DefaultName   Default layer's name.
        DefaultName = 'flatten'
    end
    
    properties (SetAccess = private)
        % InputNames   This layer has a single input
        InputNames = {'in'}
        
        % OutputNames   This layer has a single output
        OutputNames = {'out'}
        
        % NumFlattenDimensions   The number of input dims to be flattened
        NumFlattenDimensions
    end
    
    properties (Dependent, SetAccess = private)
        % HasSizeDetermined   Specifies if all size parameters are set
        %   If the number of input dimensions has not been determined, then
        %   this will be set to false, otherwise it will be true.
        HasSizeDetermined
    end
    
    methods
        function this = Flatten(name, numFlattenDimensions)
            % Flatten  Constructor for the layer
            this.Name = name;
            this.NumFlattenDimensions = numFlattenDimensions;
            
            % Flatten does not need X or Z for the backward pass
            this.NeedsXForBackward = false;
            this.NeedsZForBackward = false;
        end
        
        function Z = predict( this, X )
            % predict   Forward input data through the layer and output the result
            Z = this.forward( X );
        end
        
        function [Z, memory] = forward( this, X )
            % predict   Forward input data through the layer and output the result
            inputTensorSize = iTensorSize( X, this.NumFlattenDimensions + 1 );
            outputTensorSize = [prod(inputTensorSize(1:this.NumFlattenDimensions)) ...
                inputTensorSize(this.NumFlattenDimensions+1:end)];
            Z = reshape( X, outputTensorSize );
            
            memory.InputTensorSize = inputTensorSize;
        end
        
        function [dX, dW] = backward( ~, ~, ~, dZ, memory )
            % backward    Back propagate the derivative of the loss function
            % through the layer
            dX = reshape( dZ, memory.InputTensorSize );
            dW = [];
        end
        
        function outputSize = forwardPropagateSize(~, inputSize)
            % forwardPropagateSize  Output the size of the layer based on
            %                       the input size
            outputSize = prod( inputSize );
        end
        
        function this = inferSize(this, inputSize)
            % inferSize
            this.NumFlattenDimensions = numel( inputSize );
        end
        
        function tf = isValidInputSize(this, inputSize)
            % isValidInputSize   Check if the layer can accept an input of
            % a certain size
            tf = numel(inputSize) == this.NumFlattenDimensions;
        end
        
        function this = initializeLearnableParameters(this, ~)
            % initializeLearnableParameters     no-op since there are no
            %                                   learnable parameters
        end
        
        function outputSeqLen = forwardPropagateSequenceLength(~, inputSeqLen, ~)
            % forwardPropagateSequenceLength   The sequence length of the
            % output of the layer given an input sequence length
            
            % Propagate arbitrary sequence length
            outputSeqLen = inputSeqLen;
        end
        
        function this = prepareForTraining(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.TrainingLearnableParameter.empty();
        end
        
        function this = prepareForPrediction(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
        end
        
        function this = setupForHostPrediction(this)
        end
        
        function this = setupForGPUPrediction(this)
        end
        
        function this = setupForHostTraining(this)
        end
        
        function this = setupForGPUTraining(this)
        end
        
        function tf = get.HasSizeDetermined(this)
            tf = ~isempty( this.NumFlattenDimensions );
        end
    end
end

function tensorSize = iTensorSize( X, numInputDimensions )
% Use for-loop to determine input size. This avoids issues due to trailing
% singleton dimensions. 
% E.g. 
% 
%   size( ones(3, 2, 1) ) == [3 2]
% 
% whereas
%
%   iTensorSize( ones(3, 2, 1), 3 ) == [3 2 1]
% 
tensorSize = size( X );
numSizeDims = numel( tensorSize );
if numSizeDims < numInputDimensions
    % Add missing dimensions to tensor size
    for ii = (1 + numSizeDims):numInputDimensions
        tensorSize( ii ) = size( X, ii );
    end
end
end