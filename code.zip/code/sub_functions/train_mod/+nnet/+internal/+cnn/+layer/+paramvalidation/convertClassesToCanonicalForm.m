function convertedValue = convertClassesToCanonicalForm( value )
% convertClassesToCanonicalForm   Convert Classes to canonical form, a
% categorical column vector.

%   Copyright 2018 The MathWorks, Inc.

value = rmmissing(value);

switch class(value)
    case 'cell'
        convertedValue = categorical(value, value);
    case 'string'
        convertedValue = categorical(value, value);
    case 'categorical'
        classNames = categories(value);
        if isordinal(value)
            convertedValue = categorical(classNames, classNames, 'Ordinal', true);
        else
            convertedValue = categorical(classNames, classNames);
        end
    otherwise
        error('Invalid class for value')
end

convertedValue = convertedValue(:);
end