classdef AveragePooling3D < nnet.internal.cnn.layer.FunctionalLayer ...
        & nnet.internal.cnn.layer.CPUFusableLayer
    % AveragePooling3D   Average 3D pooling layer implementation
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties
        % LearnableParameters   Learnable parameters for the layer
        %   This layer has no learnable parameters.
        LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();

        % Name (char array)   A name for the layer
        Name
                        
        % Stride   The vertical, horizontal and depth stride
        %   The step size for traversing the input vertically and
        %   horizontally. This is a vector [u v w] where u is the vertical
        %   stride, v is the horizontal stride and w is the stride in the
        %   depth direction.
        Stride
                        
        % PaddingSize   The padding applied to the input along the edges
        %   The padding that is applied along the edges. This is a row
        %   vector [t b l r f k] where t is the padding to the top, b is
        %   the padding applied to the bottom, l is the padding applied to
        %   the left, r is the padding applied to the right, f is the
        %   padding applied to the front, and k is the padding applied to
        %   the back.
        PaddingSize
    end
    
    properties (Constant)
        % DefaultName   Default layer's name.
        DefaultName = 'avgpool3d'
    end
        
    properties (SetAccess = private)
        % InputNames   This layer has a single input
        InputNames = {'in'}
        
        % OutputNames   This layer has a single output
        OutputNames = {'out'}
        
        % HasSizeDetermined   Specifies if all size parameters are set
        HasSizeDetermined

        % PoolSize   The height, width and depth of a pooling region
        %   The size the pooling regions. This is a vector [h w d] where h is
        %   the height of a pooling region, w is the width of a pooling
        %   region and d is the depth of a pooling region.
        PoolSize
        
        % PaddingMode   The mode used to determine the padding
        %   The mode used to calculate the PaddingSize property. This can
        %   be:
        %       'manual'    - PaddingSize is specified manually. 
        %       'same'      - PaddingSize will be calculated so that the 
        %                     output size is the same size as the input 
        %                     when the stride is 1. More generally, the
        %                     output size will be ceil(inputSize/stride),
        %                     where inputSize is the height, width and
        %                     depth of the input.
        PaddingMode
    end
    
    properties
        % Learnables   Empty
        Learnables
    end
    
    properties(SetAccess=protected, GetAccess=?nnet.internal.cnn.dlnetwork)
        % LearnablesNames   Empty
        LearnablesNames
    end
    
    properties(Access = private)
        ExecutionStrategy
    end
    
    methods
        function this = AveragePooling3D( ...
                name, poolSize, stride, paddingMode, paddingSize)
            this.Name = name;
            
            % Size is determined if padding mode is not 'same'.
            this.HasSizeDetermined = ~iIsTheStringSame(paddingMode);
            
            % Set hyperparameters
            this.PoolSize = poolSize;
            this.Stride = stride;
            this.PaddingMode = paddingMode;
            this.PaddingSize = paddingSize;
            
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.AveragePooling3DHostStrategy();
            % AveragePooling3D layer needs X but not Z for the backward
            % pass
            this.NeedsXForBackward = true;
            this.NeedsZForBackward = false;
        end
        
        function Z = predict( this, X )
            % Note that padding is stored as [top bottom left right front back] but
            % the function expects [top left front bottom right back].
            inputSize = size(X,1:3);
            paddingSize = iCalculatePaddingSizeFromInputSize( ...
                this.PaddingMode, this.PaddingSize, this.PoolSize, ...
                this.Stride, inputSize );
            Z = this.ExecutionStrategy.forward(...
                X, ...
                [this.PoolSize(1), this.PoolSize(2), this.PoolSize(3)], ...
                [paddingSize(1), paddingSize(3), paddingSize(5)], ...
                [paddingSize(2), paddingSize(4), paddingSize(6)], ...
                [this.Stride(1), this.Stride(2), this.Stride(3)]);
        end
        
        function [dX,dW] = backward(this, X, ~, dZ, ~)
            % Note that padding is stored as [top bottom left right front back] but
            % the function expects [top left front bottom right back].
            % Z is not used for backward propagation with AveragePooling3D
            % Passing dZ as Z gives the same answer 
            inputSize = size(X,1:3);
            paddingSize = iCalculatePaddingSizeFromInputSize( ...
                this.PaddingMode, this.PaddingSize, this.PoolSize, ...
                this.Stride, inputSize );
            [dX,dW] = this.ExecutionStrategy.backward(...
                dZ, dZ, X, ...
                [this.PoolSize(1), this.PoolSize(2), this.PoolSize(3)], ...
                [paddingSize(1), paddingSize(3), paddingSize(5)], ...
                [paddingSize(2), paddingSize(4), paddingSize(6)], ...
                [this.Stride(1), this.Stride(2), this.Stride(3)]);
        end

        function outputSize = forwardPropagateSize(this, inputSize)
            paddingSize = iCalculatePaddingSizeFromInputSize( ...
                this.PaddingMode, this.PaddingSize, this.PoolSize, ...
                this.Stride, inputSize(1:3));
            heightWidthAndDepthPadding = iCalculateHeightWidthAndDepthPadding(paddingSize);
            outputHeightWidthAndDepth = floor((inputSize(1:3) + heightWidthAndDepthPadding - this.PoolSize)./this.Stride) + 1;
            outputMaps = inputSize(4);
            outputSize = [outputHeightWidthAndDepth outputMaps];
        end

        function this = inferSize(this, inputSize)
            if iIsTheStringSame(this.PaddingMode)
                this.PaddingSize = iCalculateSamePadding( ...
                    this.PoolSize, this.Stride, inputSize(1:3));
                
                % If the padding is set to 'same', the size will always
                % need to be determined again because we will need to
                % recalculate the padding.
                this.HasSizeDetermined = false;
            else
                this.HasSizeDetermined = true;
            end
        end
        
        function tf = isValidInputSize(this, inputSize)
            % isValidInputSize   Check if the layer can accept an input of
            % a certain size
            heightWidthAndDepthPadding = iCalculateHeightWidthAndDepthPadding(this.PaddingSize);
            tf = all( this.PoolSize <= inputSize(1:3) + heightWidthAndDepthPadding ) && ...
                numel(inputSize)==4;
        end        

        function this = initializeLearnableParameters(this, ~)
        end
        
        function this = prepareForTraining(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.TrainingLearnableParameter.empty();
        end
        
        function this = prepareForPrediction(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
        end
        
        function this = setupForHostPrediction(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.AveragePooling3DHostStrategy();
        end
        
        function this = setupForGPUPrediction(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.AveragePooling3DGPUStrategy();
        end
        
        function this = setupForHostTraining(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.AveragePooling3DHostStrategy();
        end
        
        function this = setupForGPUTraining(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.AveragePooling3DGPUStrategy();
        end
    end
    
    methods(Access=protected)
        function this = setFunctionalStrategy(this)
            this.ExecutionStrategy = ...
                nnet.internal.cnn.layer.util.AveragePooling3DFunctionalStrategy();
        end
    end
    
    methods (Hidden)
        function layerArgs = getFusedArguments(layer)
            % getFusedArguments  Returned the arguments needed to call the
            % layer in a fused network.
            import nnet.internal.cnn.layer.*
            layerArgs = { 'avgpool', layer.PoolSize, ...
                CPUGenericFusedLayer.shufflePadding(layer.PaddingSize),...
                layer.Stride };
        end

        function tf = isFusable(~, ~, numDataDimensions)
            % isFusable  Indicates if the layer is fusable in a given network.
            tf = numDataDimensions == 3;
        end
    end
end

function tf = iIsTheStringSame(x)
tf = nnet.internal.cnn.layer.padding.isTheStringSame(x);
end

function paddingSize = iCalculatePaddingSizeFromInputSize( ...
    paddingMode, paddingSize, filterOrPoolSize, stride, spatialInputSize)
paddingSize = nnet.internal.cnn.layer.padding.calculatePaddingSizeFromInputSize( ...
    paddingMode, paddingSize, filterOrPoolSize, stride, spatialInputSize);
end

function heightWidthAndDepthPadding = iCalculateHeightWidthAndDepthPadding(paddingSize)
heightWidthAndDepthPadding = nnet.internal.cnn.layer.padding.calculateHeightWidthAndDepthPadding(paddingSize);
end

function paddingSize = iCalculateSamePadding(poolSize, stride, inputSize)
paddingSize = nnet.internal.cnn.layer.padding.calculateSamePadding(poolSize, stride, inputSize);
end
