classdef Crop3D < nnet.internal.cnn.layer.FunctionalLayer
    % Internal 3D Crop layer.
    
    % Copyright 2019 The MathWorks, Inc.
    properties
        LearnableParameters = [];
        
        % Name
        Name
    end
    
    properties (Constant)
        % DefaultName Default layer's name
        DefaultName = 'crop3d'
    end
    
    properties(SetAccess = private)
        % InputNames
        InputNames = {'in','ref'}
        
        % OutputNames
        OutputNames = {'out'}
        
        % HasSizeDetermined True for layers with size determined.
        HasSizeDetermined = true;       
        
        % CropLocation: 'centercrop' or [X Y Z] location of cropping window. 
        CropLocation
    end
    
    properties
        % Learnables   Empty
        Learnables
    end
    
    properties(SetAccess=protected, GetAccess=?nnet.internal.cnn.dlnetwork)
        % LearnablesNames   Empty
        LearnablesNames
    end
    
    properties(Access = private)
        ExecutionStrategy
        CropStrategy
    end
    
    methods
        function this = Crop3D(name, cropLocation)
            this.Name = name;
            this.CropLocation = cropLocation;
            
            if strcmp(this.CropLocation, 'centercrop')
                this.CropStrategy = nnet.internal.cnn.layer.util.Crop3DCenterCropStrategy();
            else
                this.CropStrategy = nnet.internal.cnn.layer.util.Crop3DManualCropStrategy();
                this.CropStrategy.Location = cropLocation;
            end
            
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.Crop3DHostStrategy(this.CropStrategy);
            
            % crop3D layer needs X but not Z for the backward
            % pass
            this.NeedsXForBackward = true;
            this.NeedsZForBackward = false;
        end
        
        %------------------------------------------------------------------
        function Z = predict(this, inputs)
            Z = this.ExecutionStrategy.forward(inputs);
        end
        
        %------------------------------------------------------------------
        function  [dX, dW] = backward(this, inputs, ~, dZ, ~)
            [dX, dW] = this.ExecutionStrategy.backward(inputs, dZ);
        end
        
        %------------------------------------------------------------------
        function outputSize = forwardPropagateSize(~, inputSizeInCell)
            
            firstInputSize = inputSizeInCell{1}; % input to be cropped
            secondInputSize = inputSizeInCell{2}; % reference in
            
            H = secondInputSize(1);
            W = secondInputSize(2);
            D = secondInputSize(3);
            C = firstInputSize(4);
            
            outputSize = [H W D C];
        end
        
        %------------------------------------------------------------------
        function this = inferSize(this, varargin)            
        end
        
        %------------------------------------------------------------------
        function TF = isValidInputSize(this, inputSizeInCell)
            % cropping window should be within bounds of first input
            % feature map.
            
            firstInputSize = inputSizeInCell{1};
            secondInputSize = inputSizeInCell{2};
            
            H = secondInputSize(1);
            W = secondInputSize(2);
            D = secondInputSize(3);
            
            [rows, cols, planes] = this.CropStrategy.cropWindow(firstInputSize, [H, W, D]);

            TF = iIsValidInputSize(firstInputSize, H, W, D, rows, cols, planes);
            
        end              
       
        %------------------------------------------------------------------
        % initializeLearnableParameters    Initialize learnable parameters
        % using their initializer
        function this = initializeLearnableParameters(this, ~)
            % no-op: crop has no learnable parameters.
        end
        
        %------------------------------------------------------------------
        % prepareForTraining   Prepare the layer for training
        function this = prepareForTraining(this)
            % no-op: crop has no learnable parameters.
        end
        
        %------------------------------------------------------------------
        % prepareForPrediction   Prepare the layer for prediction
        function this = prepareForPrediction(this)
            % no-op: crop has no learnable parameters.
        end
        
        %------------------------------------------------------------------
        % setupForHostPrediction   Prepare this layer for host prediction
        function this = setupForHostPrediction(this)
           this.ExecutionStrategy = nnet.internal.cnn.layer.util.Crop3DHostStrategy(this.CropStrategy);
        end
        
        %------------------------------------------------------------------
        % setupForGPUPrediction   Prepare this layer for GPU prediction
        function this = setupForGPUPrediction(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.Crop3DGPUStrategy(this.CropStrategy);
        end
        
        %------------------------------------------------------------------
        % setupForHostTraining   Prepare this layer for host training
        function this = setupForHostTraining(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.Crop3DHostStrategy(this.CropStrategy);
        end
        
        %------------------------------------------------------------------
        % setupForGPUTraining   Prepare this layer for GPU training
        function this = setupForGPUTraining(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.Crop3DGPUStrategy(this.CropStrategy);
        end
    end
    
    methods(Access=protected)
        function this = setFunctionalStrategy(this)
            this.ExecutionStrategy = ...
                nnet.internal.cnn.layer.util.Crop3DFunctionalStrategy(this.CropStrategy);
        end
    end
end

%--------------------------------------------------------------------------
function TF = iIsNotNullWindow(H,W,D)
TF = H ~= 0 && W ~= 0 && D ~= 0;
end

%--------------------------------------------------------------------------
function TF = iIsValidInputSize(sz, H, W, D, rows, cols, planes)
TF = iIsNotNullWindow(H,W,D) && iIsWithinInputBounds(sz, rows, cols, planes);
end

%--------------------------------------------------------------------------
function TF = iIsWithinInputBounds(inputSize, rows,cols, planes)
TF = (rows(1) >= 1 && rows(end) <= inputSize(1)) ...
    && (cols(1) >= 1 && cols(end) <= inputSize(2)) ...
    && (planes(1) >= 1 && planes(end) <= inputSize(3));
end