classdef(Sealed) SequenceInputValidator < nnet.internal.cnn.layer.util.InputValidationStrategy
    % SequenceInputValidator    Performs checks on sequence input data
    % with regards to the configuration of the sequenceInputLayer.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function this = SequenceInputValidator(inputSize)
            % inputSize is a vector containing the size of all spatial
            % dimensions and the channel dimension.
            this.NumSpatialDims = numel(inputSize)-1;
            this.NumChannels = inputSize(end);
        end
        
        function validateInputFormat(this, sz, fmt)
            this.validateSpatialDimension(fmt);
            this.validateChannelDimension(sz,fmt);
            this.validateSequenceDimensionExists(fmt);
            this.validateNoUnspecifiedDimension(sz,fmt);
        end
    end
end