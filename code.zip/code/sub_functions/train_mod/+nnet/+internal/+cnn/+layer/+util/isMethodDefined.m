function tf = isMethodDefined( obj, methodName )
% isMethodDefined   Queries metaclass to determine if a method with
% methodName is defined directly in the class of the object obj.

%   Copyright 2019 The MathWorks, Inc.

m = metaclass(obj);
functionList = m.MethodList;
idx = strcmp({functionList.Name},methodName);
if any(idx)
    definingClass = functionList(idx).DefiningClass.Name;
    tf = isequal( definingClass, class(obj) );
else
    tf = false;
end
end