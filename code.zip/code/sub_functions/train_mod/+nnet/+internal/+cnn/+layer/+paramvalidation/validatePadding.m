function validatePadding( varargin )
% validatePadding   Throw an error if the padding parameter is invalid.
%
% validatePadding( value ) validates padding for ndims = 2 and parameter
% Padding.
%
% validatePadding( value, d ) validates padding for ndims = d and parameter
% Padding.
%
% validatePadding( value, d, paramName ) validates padding for ndims = d
% and parameter paramName.

%   Copyright 2017-2018 The MathWorks, Inc.

value = varargin{1};
if(nargin > 1)
    ndims = varargin{2};
else
    ndims = 2;
end
if(nargin > 2)
    name = varargin{3};
else
    name = 'Padding';
end

if iIsValidStringOrCharArray(value)
    try
        % This succeeds for partial completion as well
        validatestring(value,{'same'});
    catch 
        % Throw custom error instead of MATLAB:unrecognizedStringChoice
        iThrowParameterNotSameNorNumeric(name);
    end
elseif isnumeric(value)
    iValidatePaddingSize(value, ndims, name);
else
    iThrowParameterNotSameNorNumeric(name);    
end
end

function tf = iIsValidStringOrCharArray(value)
    tf = nnet.internal.cnn.layer.paramvalidation.isValidStringOrCharArray(value);
end

function iValidatePaddingSize(value, ndims, name)
    nnet.internal.cnn.layer.paramvalidation.validatePaddingSize(value,ndims,name);
end

function iThrowParameterNotSameNorNumeric(name)
    error(message('nnet_cnn:layer:Layer:ParameterNotSameNorNumeric',name));
end