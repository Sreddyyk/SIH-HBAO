classdef CustomLayerCustomBackwardFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy
    % CustomLayerFunctionalStrategyWithCustomBackward   Execution strategy
    % for using a custom intermediate layer in a dlnetwork with a custom
    % backward implementation
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(SetAccess=private)
        Method % deep.internal.dlarray.extension.DlarrayMethod
        LearnableParameterNames cell
    end
    
    methods
        function this = CustomLayerCustomBackwardFunctionalStrategy(...
                layer, parametersNames, layerVerifier )
            this.Method = iCustomLayerMethod(layer,layerVerifier);
            this.LearnableParameterNames = parametersNames;
        end
        
        function Z = predict(this, layer, X)
            Z = inference(this,'predict',layer,X);
        end
        
        function [Z, memory] = forward(this, layer, X)
            Z = inference(this,'forward',layer,X);
            % Backward of custom internal layers is not executed explicitly
            % in a dlnetwork so memory will be unused.
            memory = [];
        end
    end
    
    methods(Access=private)
        function Z = inference(this,methodName,layer,X)
            X = iWrapInCell(X);
            % Assume that all inputs/outputs to the layer have the same type
            this.Method = update( this.Method, ...
                methodName, iFullType(X{1}), iGetSizes(X) );
            % Note: Need to apply extension method by requesting ALL layer
            % outputs, otherwise backward signature in
            % CustomLayerDlarrayMethod is wrong
            W = iGetLearnableParameters(layer,this.LearnableParameterNames);
            [Z{1:layer.NumOutputs}] = deep.internal.dlarray.extension.applyExtensionMethod(...
                this.Method, X{:}, W{:} );
            Z = iUnwrapScalarCell(Z);
        end
    end
end

function paramValues = iGetLearnableParameters( layer, paramNames )
numParams = numel(paramNames);
paramValues = cell(1,numParams);
for i=1:numParams
    paramValues{i} = layer.(paramNames{i});
end
end

function sz = iGetSizes(data)
sz = cellfun( @size, data, 'UniformOutput', false);
end

function typeStruct = iFullType(data)
data = extractdata(data);

mainClass = class(data);
if mainClass == "gpuArray"
    underlyingClass = classUnderlying(data);
else
    underlyingClass = '';
end

typeStruct = struct( ...
    'Main', mainClass, ...
    'Underlying', underlyingClass );
end

function X = iWrapInCell(X)
if ~iscell(X)
    X = {X};
end
end

function data = iUnwrapScalarCell(cellData)
if iscell(cellData) && isscalar(cellData)
    data = cellData{1};
else
    data = cellData;
end
end

function method = iCustomLayerMethod(varargin)
method = nnet.internal.cnn.layer.util.CustomLayerMethod(varargin{:});
end