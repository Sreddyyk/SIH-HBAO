function convertedValue = convertResponseNamesToCanonicalForm( value )
% convertResponseNamesToCanonicalForm   Convert ResponseNames to canonical
% form, a cellstr column vector.

%   Copyright 2018 The MathWorks, Inc.

value = rmmissing(value);
if isempty(value)
    convertedValue = {};
else
    value = convertStringsToChars(value);
    if ischar(value)
        value = {value};
    end
    convertedValue = value(:);
end
end