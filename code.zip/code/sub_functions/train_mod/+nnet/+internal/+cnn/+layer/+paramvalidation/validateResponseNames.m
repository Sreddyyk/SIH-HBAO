function validateResponseNames( value )
% validateResponseNames   Throw an error if the value for ResponseNames is
% not valid.

%   Copyright 2018 The MathWorks, Inc.

if ~isempty(value)
    if ~isvector(value) || ~iIsValidDataType(value)
        error(message('nnet_cnn:layer:RegressionOutputLayer:InvalidResponseNames'));
    end
    if iHasDuplicates(value)
         error(message('nnet_cnn:layer:RegressionOutputLayer:DuplicateResponseNames'));
    end
end
end

function tf = iIsValidDataType(value)
tf = iscellstr(value) || isstring(value);
end

function tf = iHasDuplicates(value)
tf = ~isequal(value, unique(value, 'stable'));
end