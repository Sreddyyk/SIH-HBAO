classdef Normal < ...
        nnet.internal.cnn.layer.learnable.initializer.Initializer & ...
        nnet.internal.cnn.layer.learnable.initializer.BasicMixin    
    % Normal    Normal initializer
   
    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function this = Normal()
            this.Name = 'narrow-normal';
            this.Fcn = @(sz) randn(sz) * 0.01;
        end        
    end
end