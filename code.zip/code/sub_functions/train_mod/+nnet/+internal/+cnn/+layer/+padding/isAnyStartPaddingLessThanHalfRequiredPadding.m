function tf = isAnyStartPaddingLessThanHalfRequiredPadding(inputSize, poolSize, paddingSize)
% isAnyStartPaddingLessThanHalfPadding   Determine if the start padding of
% each dimension i is less than half of the minimum amount of padding required for verifying the relation
% inputSize(i) + paddingSize(i) = poolSize(i), rounded to the next greater integer.
%
%   tf = isAnyStartPaddingLessThanHalfPadding(inputSize, poolSize, paddingSize) returns 
%   true if the start padding of any dimension is less than half of the minimum amount
%   of padding required for verifying the relation inputSize(i) + paddingSize(i) = poolSize(i), 
%   rounded to the next greater integer. It returns false otherwise.
%
%   Input:
%       inputSize               - A 1-by-N vector with the size of the input data for 
%                                 each dimension. 
%       poolSize                - A 1-by-M vector with the pooling window size for
%                                 each pooling dimension.
%       paddingSize             - A 1-by-M vector for the padding in the 
%                                 format [dim1Start dim2Start dim3Start...].
%
%   Output:
%       tf                      - true if the start padding of any dimension is less
%                                 than half of the minimum padding required to make
%                                 the poolSize equal the padded input size,
%                                 rounded to the next greater integer; false otherwise.

%   Copyright 2019 The MathWorks, Inc.

tf = false;
 for i=1:length(poolSize)    
     tf = tf || (poolSize(i) > inputSize(i) && ceil( (poolSize(i) - inputSize(i))/2 ) >  paddingSize(i) );
 end
end





