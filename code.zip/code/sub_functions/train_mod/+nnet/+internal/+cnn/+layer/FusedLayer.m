classdef(Abstract) FusedLayer < nnet.internal.cnn.layer.GraphExecutor & ...
        nnet.internal.cnn.layer.Finalizable
    % FusedLayer  Basic fused layer which converts multiple layers into a
    % single layer, but maps externally to the original layer types. This
    % functions correctly but is less efficient than leaving the layer
    % graph alone. The intention is that you overload the predict function
    % to optimize prediction and forward and backward to optimize training.
    %
    % In its current form, FusedLayer only accepts topologically-sorted
    % segments of the layer graph with a single input (to the first layer
    % in the graph), a single output (from the last layer), and containing
    % no Input or Output layers.
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties
        % LearnableParameters   Learnable parameters for the layer
        % (Vector of nnet.internal.cnn.layer.LearnableParameter). By
        % default this is assembled from the original layers in their
        % original order.
        % In a FusedLayer by default, for performance, LearnableParameters
        % are a copy of those in the OriginalLayers, and copied back
        % whenever the OriginalLayers are read.
        LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty()
    end

    properties( Access = protected )       
        % NumLearnablesInOriginalLayers  Tracks the mapping of learnable
        % parameters from the original layers to the local cache
        NumLearnablesInOriginalLayers
    end
    
    properties( SetAccess = private )
        % InputNames   The names of the inputs for this layer
        InputNames
        
        % OutputNames   The names of the outputs for this layer
        OutputNames
    end
    
    methods
        
        function obj = FusedLayer(varargin)
            obj = obj@nnet.internal.cnn.layer.GraphExecutor(varargin{:});
            
            % Set the remaining properties
            originalLayers = obj.OriginalLayers;
            obj.NeedsFinalize = any( cellfun(@iLayerNeedsFinalize, ...
                originalLayers) );
            
            % Copy over some properties from contained graph. Because we
            % allow only one input and output layer, and the input must be
            % topologically sorted, the inputs are the first layer's inputs
            % and the outputs are the last layer's outputs.
            obj.InputNames = originalLayers{1}.InputNames;
            obj.OutputNames = originalLayers{end}.OutputNames;  
        end
        
        % activations  Compute the activations from a specified layer
        % output internal to this fused layer
        function Z = activations( this, X, layerIndex, layerOutputIndex )

            listOfBufferInputIndices = this.LayerGraphExecutionInfo.ListOfBufferInputIndices;
            listOfBufferOutputIndices = this.LayerGraphExecutionInfo.ListOfBufferOutputIndices;
            listOfBufferIndicesForClearingForward = this.LayerGraphExecutionInfo.ListOfBufferIndicesForClearingForward;

            % Allocate space for the activations.
            activationsBuffer = cell(this.LayerGraphExecutionInfo.NumActivations,1);
            
            % Loop over topologically sorted layers to perform forward
            % propagation. Clear memory when activations are no longer
            % needed.
            layers = this.OriginalLayers;
            for i = 1:layerIndex
                if i == 1
                        Z = layers{1}.predict(X);
                else
                        XForThisLayer = iGetTheseActivationsFromBuffer( ...
                            activationsBuffer, ...
                            listOfBufferInputIndices{i});
                        Z = layers{i}.predict(XForThisLayer);
                end
                
                activationsBuffer = iAssignToBuffer( ...
                    activationsBuffer, ...
                    listOfBufferOutputIndices{i}, ...
                    Z);
                
                activationsBuffer = iClearActivationsFromBuffer( ...
                    activationsBuffer, ...
                    listOfBufferIndicesForClearingForward{i});
            end
            
            % Retrieve specified output from the last layer
            if iscell(Z)
                Z = Z(layerOutputIndex);
            end
        end

        % backward    Back propagate the derivative of the loss function
        % through the layer
        function [dLossdZ, dLossdW] = backward( this, X, Z, dLossdZ, mem )
            % Default implementation just backpropagates through each layer
            
            computeGradients = nargout > 1;
            listOfBufferInputIndices = this.LayerGraphExecutionInfo.ListOfBufferInputIndices;
            listOfBufferOutputIndices = this.LayerGraphExecutionInfo.ListOfBufferOutputIndices;
            listOfBufferIndicesForClearingBackward = ...
                this.LayerGraphExecutionInfo.ListOfBufferIndicesForClearingBackward;
            
            % Extract the activations and memory for the internal layers,
            % or compute them if they've not been passed in
            if isempty(mem)
                [~, mem] = forward( this, X );
            end
            activationsBuffer = mem.internalActivations;
            memoryBuffer = mem.internalMemory;
            dLossdW = cell.empty();
            
            % Propagate backwards through layers from the output, deleting
            % activations that are no longer needed as we go
            layers = this.OriginalLayers;
            dLossdXBuffer = cell(this.LayerGraphExecutionInfo.NumActivations,1);
            numLayers = numel(layers);
            for i = numLayers:-1:1
                
                % Preparation
                bufferInputIndices = listOfBufferInputIndices{i};
                bufferOutputIndices = listOfBufferOutputIndices{i};
                learnablesThisLayer = layers{i}.LearnableParameters;
                dLossdWThisLayer = cell(size(learnablesThisLayer));

                % Get layer inputs and outputs
                if i == 1
                    XForThisLayer = X;
                else
                    XForThisLayer = iGetTheseActivationsFromBuffer( ...
                        activationsBuffer, bufferInputIndices);
                end
                mem = iGetTheseActivationsFromBuffer( ...
                    memoryBuffer, i);
                if i == numLayers
                    ZForThisLayer = Z;
                else
                    ZForThisLayer = iGetTheseActivationsFromBuffer( ...
                        activationsBuffer, bufferOutputIndices);
                    dLossdZ = iGetTheseActivationsFromBuffer( ...
                        dLossdXBuffer, bufferOutputIndices);
                end
                
                % Compute either all gradients or only the activations
                % gradients depending on function outputs
                backwardArgs = { XForThisLayer, ZForThisLayer, dLossdZ, mem };
                if computeGradients
                    [dLossdZ, dLossdWThisLayer] = layers{i}.backward( backwardArgs{:} );
                else
                    dLossdZ = layers{i}.backward( backwardArgs{:} );
                end

                if i > 1
                    % Add loss gradient to buffer - literally adding for
                    % layers that have multiple inputs.
                    dLossdXBuffer = iIncrementActivationsInBuffer( ...
                        dLossdXBuffer, bufferInputIndices, dLossdZ);
                
                    % Delete unneeded data
                    indicesToClear = listOfBufferIndicesForClearingBackward{i};
                    if i < numLayers
                        activationsBuffer = iClearActivationsFromBuffer( ...
                            activationsBuffer, indicesToClear );
                    end
                    memoryBuffer = iClearActivationsFromBuffer( ...
                        memoryBuffer, i );
                    dLossdXBuffer = iClearActivationsFromBuffer( ...
                        dLossdXBuffer, indicesToClear );
                end
                
                % Add weights gradients for this layer to output for the
                % whole Fused Layer
                dLossdW = [ dLossdWThisLayer, dLossdW ]; %#ok<AGROW>
            end
        end
        
        % forwardPropagateSize    The size of the output from the layer for
        % a given size of input. The FusedLayer version supports returning
        % the size of the output from one of the OriginalLayers internal to
        % this layer.
        function outputSize = forwardPropagateSize(this, inputSize, originalLayerIndex)
            function outSize = nPropagate( layer, inSize )
                if iIsAnInputLayer(layer)
                    outSize = inSize;
                else
                    outSize = forwardPropagateSize( layer, iUnWrapCell(inSize) );
                end
            end
            if nargin < 3
                outputSize = propagateThroughLayers(this, @nPropagate, inputSize);
            else
                outputSize = propagateThroughLayers( this, ...
                    @nPropagate, inputSize, originalLayerIndex );
            end
            outputSize = iUnWrapCell(outputSize);
        end
        
        % inferSize    Infer the size of the learnable parameters based
        % on the input size
        function this = inferSize(this, inputSize)
            layerIndex = 1;
            function outSize = nInferAndPropagate( layer, inSize )
                this.OriginalLayers{layerIndex} = inferSize( layer, inSize );
                outSize = forwardPropagateSize( layer, iUnWrapCell(inSize) );
                layerIndex = layerIndex + 1;
            end
            propagateThroughLayers( this, @nInferAndPropagate, inputSize );
        end
        
        % isValidInputSize   Check if the layer can accept an input of a
        % certain size
        function tf = isValidInputSize(this, inputSize)
            tf = true;
            function outSize = nPropagate( layer, inSize )
                tf = tf && isValidInputSize( layer, inSize );
                outSize = forwardPropagateSize( layer, inSize );
            end
            propagateThroughLayers( this, @nPropagate, inputSize );
        end
        
        % initializeLearnableParameters    Initialize learnable parameters
        % using their initializer
        function this = initializeLearnableParameters(this, precision)
            this = callOnLayers( this, @(l)initializeLearnableParameters(l, precision) );
        end
        
        % prepareForTraining   Prepare the layer for training
        function this = prepareForTraining(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2training(this.LearnableParameters);
            this = callOnLayers( this, @prepareForTraining );
        end
        
        % prepareForPrediction   Prepare the layer for prediction
        function this = prepareForPrediction(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2prediction(this.LearnableParameters);
            this = callOnLayers( this, @prepareForPrediction );
        end
        
        % setupForHostPrediction   Prepare this layer for host prediction
        function this = setupForHostPrediction(this)
            this = callOnLayers( this, @setupForHostPrediction );
        end
        
        % setupForGPUPrediction   Prepare this layer for GPU prediction
        function this = setupForGPUPrediction(this)
            this = callOnLayers( this, @setupForGPUPrediction );
        end
        
        % setupForHostTraining   Prepare this layer for host training
        function this = setupForHostTraining(this)
            this = callOnLayers( this, @setupForHostTraining );
        end
        
        % setupForGPUTraining   Prepare this layer for GPU training
        function this = setupForGPUTraining(this)
            this = callOnLayers( this, @setupForGPUTraining );
        end

        % finalize  Compute final properties of any internal layers that
        % require finalization during training
        function this = finalize(this, X, Z, mem)
            if ~this.NeedsFinalize
                return;
            end
            listOfBufferInputIndices = this.LayerGraphExecutionInfo.ListOfBufferInputIndices;
            listOfBufferOutputIndices = this.LayerGraphExecutionInfo.ListOfBufferOutputIndices;
            
            % Extract the activations and memory for the internal layers,
            % or compute them if they've not been passed in
            if isempty(mem)
                [~, mem] = forward( this, X );
            end
            activationsBuffer = mem.internalActivations;
            memoryBuffer = mem.internalMemory;
            
            % Propagate activations forward through the layers calling
            % finalize on any layers that support it
            layers = this.OriginalLayers;
            finalizableLayers = cellfun(@iLayerNeedsFinalize, layers);
            lastFinalizableLayer = find( finalizableLayers, 1, 'last' );
            numLayers = numel(layers);
            for i = 1:lastFinalizableLayer
                
                % Preparation
                bufferInputIndices = listOfBufferInputIndices{i};
                bufferOutputIndices = listOfBufferOutputIndices{i};

                % Get layer inputs and outputs
                if i == 1
                    XForThisLayer = X;
                else
                    XForThisLayer = iGetTheseActivationsFromBuffer( ...
                        activationsBuffer, bufferInputIndices);
                end
                mem = iGetTheseActivationsFromBuffer( ...
                    memoryBuffer, bufferOutputIndices);
                if i == numLayers
                    ZForThisLayer = Z;
                else
                    ZForThisLayer = iGetTheseActivationsFromBuffer( ...
                        activationsBuffer, bufferOutputIndices);
                end
                
                % Finalize this layer
                if finalizableLayers(i)
                    % Must act on actual layer property to enact change
                    this.OriginalLayers{i} = ...
                        finalize( layers{i}, XForThisLayer, ZForThisLayer, mem );
                end
            end
        end
        
        % mergeFinalized  Called to fuse results between finalize
        % operations on different batches of observations. FusedLayer
        % implementation calls individually on each internal layer.
        function layer = mergeFinalized(layer, layer2)
            layers1 = layer.OriginalLayers;
            layers2 = layer2.OriginalLayers;
            finalizableLayers = cellfun( @iLayerNeedsFinalize, layers1 );
            lastFinalizableLayer = find( finalizableLayers, 1, 'last' );
            for i = 1:lastFinalizableLayer
                if finalizableLayers(i)
                    layer.OriginalLayers{i} = ...
                        mergeFinalized( layers1{i}, layers2{i} );
                end
            end
        end
        
        % checkPropertiesAreFinalized throw an error if the layer has
        % not been finalized. No operation is needed for FusedLayer.
        function checkPropertiesAreFinalized(~)
        end
    end

    %% Overload
    methods( Access = protected )
        
        function this = cacheLearnables( this )
            % cacheLearnables  Store a local copy of the learnable
            % parameters in the original layers
            thisLearnable = 1;
            for i = 1:numel(this.PrivateOriginalLayers)
                theseLearnables = this.PrivateOriginalLayers{i}.LearnableParameters;
                numLearnables = numel(theseLearnables);
                this.NumLearnablesInOriginalLayers(i) = numLearnables;
                if numLearnables > 0
                    if thisLearnable == 1
                        this.LearnableParameters = theseLearnables;
                    else
                        this.LearnableParameters(thisLearnable:thisLearnable+numLearnables-1) = theseLearnables;
                    end
                    thisLearnable = thisLearnable + numLearnables;
                    
                    % As soon as we've cached the learnables, delete the
                    % originals. We don't want a shared data copy.
                    this.PrivateOriginalLayers{i}.LearnableParameters = theseLearnables([]);
                end
            end
        end
        
        function layers = restoreLearnables( this, layers )
            % restoreLearnables  Copy learnable parameters back into the
            % original layers
            thisLearnable = 1;
            for i = 1:numel(layers)
                numLearnables = this.NumLearnablesInOriginalLayers(i);
                if numLearnables > 0
                    layers{i}.LearnableParameters = this.LearnableParameters(thisLearnable:thisLearnable+numLearnables-1);
                end
                thisLearnable = thisLearnable + numLearnables;
            end
        end
        
    end
    
    %% Utilities
    methods( Access = private )
        
        function [out, buffer] = propagateThroughLayers( this, F, in, stopLayer )
            % propagateThroughLayers  Helper for several functions that
            % just need to straightforwardly propagate data through the
            % original layer graph
            layers = this.OriginalLayers;
            numActivations = this.LayerGraphExecutionInfo.NumActivations;
            listOfBufferInputIndices = this.LayerGraphExecutionInfo.ListOfBufferInputIndices;
            listOfBufferOutputIndices = this.LayerGraphExecutionInfo.ListOfBufferOutputIndices;
            buffer = cell(numActivations, 1);
            numLayers = numel(layers);
            if nargin < 4
                stopLayer = numLayers;
            end
            for i = 1:stopLayer
                bufferInputIndices = listOfBufferInputIndices{i};
                if i > 1
                    in = iRetrieveFromBuffer(buffer, bufferInputIndices);
                end
                
                bufferOutputIndices = listOfBufferOutputIndices{i};
                out = F( layers{i}, in );
                buffer = iAssignToBuffer( buffer, bufferOutputIndices, out );
            end
        end
        
    end
    
end

%% Internal sub-functions
function activationsBuffer = iClearActivationsFromBuffer(activationsBuffer, indicesToClear)
activationsBuffer = nnet.internal.cnn.util.LayerGraphExecutionInfo.clearActivationsFromBuffer( ...
    activationsBuffer, indicesToClear);
end

function XForThisLayer = iGetTheseActivationsFromBuffer(activationsBuffer, inputIndices)
XForThisLayer = activationsBuffer(inputIndices);
if(iscell(XForThisLayer) && (numel(XForThisLayer) == 1))
    XForThisLayer = XForThisLayer{1};
end
end

function activationsBuffer = iIncrementActivationsInBuffer(activationsBuffer, bufferIndices, activations)
activations = iWrapInCell( activations );
    function Y = nAddActivations(X, Y)
        if ~isempty(X)
            Y = X + Y;
        end
    end
activationsBuffer(bufferIndices) = cellfun(@nAddActivations, ...
    activationsBuffer(bufferIndices), activations(:), 'UniformOutput', false);
end

function buffer = iAssignToBuffer( buffer, indices, vals )
if ~isscalar(indices)
    buffer(indices) = vals;
else
    buffer{indices} = vals;
end
end

function tf = iIsAnInputLayer(layer)
tf = isa(layer, 'nnet.internal.cnn.layer.InputLayer');
end

function out = iRetrieveFromBuffer( buffer, indices )
if numel(indices) > 1
    out = buffer(indices);
else
    out = buffer{indices};
end
end

function X = iWrapInCell( X )
if ~iscell(X)
    X = {X};
end
end

function X = iUnWrapCell( X )
if iscell(X) && isscalar(X)
    X = X{1};
end
end

function tf = iLayerNeedsFinalize(layer)
tf = isa(layer, 'nnet.internal.cnn.layer.Finalizable') && layer.NeedsFinalize;
end
