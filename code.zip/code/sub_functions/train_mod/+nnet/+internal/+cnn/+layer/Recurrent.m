classdef (Abstract) Recurrent
    % Recurrent   Mixin for recurrent layers that support state update
    
    %   Copyright 2017 The MathWorks, Inc.
    
    properties (Abstract, SetAccess = private)
        % ReturnSequence   Logical which is true when the layer's output
        % has the same sequence length as the input
        ReturnSequence
    end
    
    properties (Abstract)    
        % DynamicParameters   Dynamic parameters for the layer
        % (Vector of nnet.internal.cnn.layer.dynamic.TrainingDynamicParameter)
        DynamicParameters
    end
    
    methods (Abstract)
        % computeState  Use the inputs and outputs from forward to
        %                   compute state information for this layer
        %
        % Syntax
        %   state = computeState(layer, X, Z, memory, propagateState)
        %
        % Inputs
        %   layer          - a layer
        %   X              - the input to forward for the layer
        %   Z, memory      - the outputs from the layer's forward method
        %   propagateState - true to propagate previous state and false to
        %                    re-initialize the state
        %
        % Outputs
        %   state          - a cell array containing state information
        state = computeState(layer, X, Z, memory, propagateState)
        
        % updateState  Update state information for this layer
        %
        % Syntax
        %   layer = updateState(layer, state)
        %
        % Inputs
        %   state       - a cell array containing state information
        %                 from a previous call to computeState
        %
        % Outputs
        %   layer       - the updated layer
        layer = updateState(layer, state)
    end
end