classdef CustomLayerMethod < deep.internal.dlarray.extension.DlarrayMethod
    % CustomLayerMethod   A CustomLayerMethod is only constructed for
    % custom layers with a backward method used in a dlnetwork. It only
    % received numeric arrays and allows the definition of a custom
    % backward implementation that is used during reverse-mode autodiff.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(SetAccess = private)
        % ExternalCustomLayer   The external custom layer to be used
        ExternalCustomLayer nnet.layer.Layer
        
        % IsForwardTraining   True if the method to be called on the
        % external custom layer is "forward", false if the method to be
        % called is "predict"
        ForwardTraining(1,1) logical
        
        % LayerVerifier   Verifier object for verifying size and type of
        % outputs from the external custom layer
        LayerVerifier nnet.internal.cnn.layer.util.CustomLayerVerifier
        
        % InputSizes   A cell containing a size vector for each input to
        % the layer
        InputSizes cell
        
        % InputType   A struct containing information about the type of the
        % layer input and it's underlying type (if main type is gpuArray).
        InputType struct
        
        % LearnableParameterNames   String array of the names of the
        % Learnables
        LearnableParameterNames cell
        
        % IsForwardDefined   True if the forward method is implemented in
        % the external custom layer
        IsForwardDefined(1,1) logical
        
        % RequiresXinBackward   Logical vector with a flag for each layer
        % input indicating if the data is needed for backward.
        RequiresXinBackward(1,:) logical
        
        % RequiresWinBackward   Logical vector with a flag for each layer
        % learnable parameter indicating if the data is needed for
        % backward.
        RequiresWinBackward(1,:) logical
        
        % RequiresZinBackward   Logical vector with a flag for each layer
        % output indicating if the data is needed for backward.
        RequiresZinBackward(1,:) logical
    end
    
    methods
        
        function this = CustomLayerMethod(layer,layerVerifier)
            this.ExternalCustomLayer = layer;
            this.LayerVerifier = layerVerifier;
            metaLayer = nnet.checklayer.MetaLayer(layer);
            this.IsForwardDefined = metaLayer.IsForwardDefined;
            this.LearnableParameterNames = metaLayer.ParametersNames;
            [this.RequiresXinBackward,this.RequiresWinBackward,this.RequiresZinBackward] = ...
                iWhichInputsAreNeededForBackward( metaLayer );
        end
        
        function this = update(this,forwardMethod,inputType,inputSizes)
            % update   Store extra information about how to execute the
            % CustomLayerMethod. "update" should be called before calling
            % "forward".
            this.ForwardTraining = lower(forwardMethod) == "forward";
            this.InputType = inputType;
            this.InputSizes = inputSizes;
        end
        
        function [inFormats, outFormats] = forwardFormats(~, inFormats, outFormats)
            % forwardFormats   Assume that the formats of input data to the
            % layer are all the same and that the layer returns data with
            % the same dimension labels as the inputs.
            outFormats(:) = inFormats(1);
        end
        
        function [inNeeded, outNeeded] = backwardRequirements(this, ~, ~)
            % backwardRequirements   Returns a mask indicating which inputs
            % and outputs of the CustomLayerMethod's forward method are
            % needed to execute the backward method. Note that the inputs
            % to forward contain the inputs and learnable parameters of the
            % external custom layer.
            inNeeded = [this.RequiresXinBackward,this.RequiresWinBackward];
            outNeeded = this.RequiresZinBackward;
        end
        
        function varargout = forward(this, varargin)
            % [Z1,Z2,...] = forward(X1,X2,...,W1,W2,...)   Forwards numeric
            % array inputs to the external custom layer's forward or
            % predict method and returns the results. Note that "update"
            % needs to be called before executing this forward method.
            
            % Assign the learnable parameters into the external layer
            layer = this.ExternalCustomLayer;
            layer = iSetLayerParameters( layer, this.LearnableParameterNames, ...
                varargin(layer.NumInputs+1:end) );
            layer = iLayerParamFun( layer, this.LearnableParameterNames, ...
                @iExtractDlarrays );
            
            if this.IsForwardDefined
                wrapperMsg = iCustomLayerMsg('ForwardErrored',class(layer));
            else
                wrapperMsg = iCustomLayerMsg('PredictErrored',class(layer));
            end
            
            mem = [];
            if this.ForwardTraining
                [varargout{1:layer.NumOutputs},mem] = iFevalUserCode( ...
                    wrapperMsg, @layer.forward, varargin{1:layer.NumInputs});
            else
                [varargout{1:layer.NumOutputs}] = iFevalUserCode( ...
                    wrapperMsg, @layer.predict, varargin{1:layer.NumInputs});
            end
            
            this.verifyEmptyMemory(mem);
            this.verifyOutputType(varargout);
        end
        
        function varargout = backward(this, varargin)
            % [dLdX1,dLdX2,...dLdW1,dLdW2,...] =
            % backward(dLdZ1,dLdZ2,...,X1,X2,...W1,W2,...,Z1,Z2,...) Calls
            % backward on the external custom layer to compute the
            % gradients of the inpts and learnable parameters with the
            % given inputs. Note that this backward function only receives
            % the layer inputs (Xi), layer parameters (Wk), and layer
            % outputs (Zj) that are needed for the backward computation (as
            % specified by backwardRequirements method).
            
            layer = this.ExternalCustomLayer;
            
            % Extract the adjoints dZ from the input argument list
            [dZ,nextIdx] = iExtractNextValues(varargin,1,layer.NumOutputs);
            
            % Extract the layer input values X used during the forward pass
            X = cell(1,layer.NumInputs);
            [X(this.RequiresXinBackward),nextIdx] = iExtractNextValues(...
                varargin, nextIdx, nnz(this.RequiresXinBackward));
            
            % Extract the learnable parameters W that were used to compute
            % the forward pass through the layer and reassign them into the
            % external layer
            [W,nextIdx] = iExtractNextValues(...
                varargin, nextIdx, nnz(this.RequiresWinBackward) );
            layer = iSetLayerParameters( layer,...
                this.LearnableParameterNames(this.RequiresWinBackward), W );
            
            % Extract the layer output values Z computed during the forward
            % pass through the layer
            Z = cell(1,layer.NumOutputs);
            Z(this.RequiresZinBackward) = iExtractNextValues(...
                varargin, nextIdx, nnz(this.RequiresZinBackward));
            
            % Note: currently the memory output from the forward pass
            % cannot be passed to the backward method of this class.
            memory = {[]};
            inputArgs = [X,Z,dZ,memory];
            
            wrapperMsg = iCustomLayerMsg('BackwardErrored',class(layer));
            [varargout{1:nargout}] = iFevalUserCode( ...
                    wrapperMsg, @layer.backward, inputArgs{:} );

            this.verifyGradientTypeAndSize(varargout);
        end
    end
    
    methods(Access=private)        
        function verifyEmptyMemory(this,mem)
            this.LayerVerifier.verifyEmptyMemoryForAutodiff(mem)
        end
        
        function verifyOutputType(this,Z)
            if this.ForwardTraining && this.IsForwardDefined
                this.LayerVerifier.verifyForwardType( ...
                    this.ExternalCustomLayer.OutputNames, this.InputType, Z );
            else
                this.LayerVerifier.verifyPredictType( ...
                    this.ExternalCustomLayer.OutputNames, this.InputType, Z );
            end
        end
        
        function verifyGradientTypeAndSize(this,grads)
            layer = this.ExternalCustomLayer;
            dLdX = grads(1:layer.NumInputs);
            dLdW = grads(layer.NumInputs+1:end);
            
            W = iGetLayerParameters(layer,this.LearnableParameterNames);
            this.LayerVerifier.verifyBackwardSize( layer.InputNames, ...
                this.InputSizes, W, dLdX, dLdW );
            
            this.LayerVerifier.verifyBackwardType( layer.InputNames, ...
                this.InputType, dLdX, dLdW );
        end
    end
end

function layer = iSetLayerParameters( layer, paramNames , paramValues)
for ii=1:numel(paramNames)
    layer.(paramNames{ii}) = paramValues{ii};
end
end

function paramValues = iGetLayerParameters( layer, paramNames )
numParams = numel(paramNames);
paramValues = cell(1,numParams);
for i=1:numParams
    paramValues{i} = layer.(paramNames{i});
end
end

function layer = iLayerParamFun( layer, paramNames, fun )
for ii=1:numel(paramNames)
    layer.(paramNames{ii}) = fun(layer.(paramNames{ii}));
end
end

function [xNeeded,wNeeded,zNeeded] = iWhichInputsAreNeededForBackward( metaLayer )
backwardInputs = metaLayer.Backward.InputNames;
xIndices = 1 + (1:metaLayer.NumInputs);
zIndices = 1 + metaLayer.NumInputs + (1:metaLayer.NumOutputs);
xNeeded = true(1,metaLayer.NumInputs);
layerObjNeeded = backwardInputs(1)~="~";
wNeeded = repelem( layerObjNeeded, 1, numel(metaLayer.ParametersNames) );
zNeeded = true(1,metaLayer.NumOutputs);
if all(xIndices<numel(backwardInputs))
    xNeeded( backwardInputs(xIndices) == "~" ) = false;
end
if all(zIndices<numel(backwardInputs))
    zNeeded( backwardInputs(zIndices) == "~" ) = false;
end
end

function [values,nextIdx] = iExtractNextValues(valueList,nextIdx,numElements)
values = valueList(nextIdx:nextIdx+numElements-1);
nextIdx = nextIdx + numElements;
end

function data = iExtractDlarrays(data)
if isa(data,'dlarray')
    data = extractdata(data);
end
end

function msg = iCustomLayerMsg(id,varargin)
msg = message("nnet_cnn:internal:cnn:layer:CustomLayer:"+string(id),varargin{:});
end

function varargout = iFevalUserCode(msg,F,varargin)
[varargout{1:nargout}] = nnet.internal.cnn.util.UserCodeException.fevalUserCode(msg,F,varargin{:});
end