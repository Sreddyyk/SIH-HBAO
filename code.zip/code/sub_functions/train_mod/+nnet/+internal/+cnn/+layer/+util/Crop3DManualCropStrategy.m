classdef Crop3DManualCropStrategy < nnet.internal.cnn.layer.util.Crop3DStrategy
    % Crop using [X Y Z] location.
    
    % Copyright 2019 The MathWorks, Inc.
    
    methods
             
        %------------------------------------------------------------------
        function [rows, cols, planes] = cropWindow(this, ~, outputSize)
            % upper-left corner of cropping window.
            R = this.Location(2);
            C = this.Location(1);
            P = this.Location(3);
            
            rows   = R:(R + outputSize(1) - 1);
            cols   = C:(C + outputSize(2) - 1);
            planes = P:(P + outputSize(3) - 1);
            
        end
    end
end
