classdef CustomOutputLayerAutodiffStrategy
    % CustomOutputLayerAutodiffStrategy   Execution strategy for using a
    % custom output layer in a layer-based environment where the
    % backwardLoss method is not overridden in the external custom layer.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        LayerVerifier nnet.internal.cnn.layer.util.CustomLayerVerifier
    end
    
    methods
        function this = CustomOutputLayerAutodiffStrategy(layerVerifier)
            this.LayerVerifier = layerVerifier;
        end
        
        function loss = forwardLoss( this, layer, Y, T )
            try
                loss = forwardLoss( layer, dlarray(Y), T );
            catch cause
                iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomOutputLayer:ForwardLossErrored', class(layer))
            end
            this.LayerVerifier.verifyUnlabeledDlarray( 'forwardLoss', {}, loss )
            loss = extractdata(loss);
            this.LayerVerifier.verifyForwardLossSize( loss );
            this.LayerVerifier.verifyForwardLossType( Y, loss );
        end
        
        function dLdY = backwardLoss( ~, layer, Y, T )
            restore = iSetupCleanupFunction(); %#ok<NASGU>
            Y = iConvertToRecordingDlarray(Y);
            
            % TODO: Note that backwardLoss is called before forwardLoss is
            % executed. We could cache the loss value so that it doesn't
            % need to be computed in forwardLoss.
            try
                loss = forwardLoss( layer, Y, T );
            catch cause
                iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomOutputLayer:ForwardLossErrored', class(layer))
            end
            try
                dLdY = dlgradient( loss, Y );
            catch cause
                iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomOutputLayer:BackwardLossErrored', class(layer))
            end
            dLdY = extractdata( stop(dLdY) );
        end
    end
end

function iThrowWithCause( cause, errorID, varargin )
exception = MException( message( errorID, varargin{:} ) );
exception = exception.addCause( cause );
throwAsCaller( exception );
end

function restore = iSetupCleanupFunction()
persistent tm;
if isempty(tm)
    tm = deep.internal.recording.TapeManager();
end
restore = [];
tracingCount = getTracingCount(tm);
if (tracingCount == 0)
    restore = deep.internal.startTracingAndSetupCleanup(tm);
end
end

function out = iConvertToRecordingDlarray( in )
out = dlarray(in);
out = deep.internal.recording.recordContainer(out);
end