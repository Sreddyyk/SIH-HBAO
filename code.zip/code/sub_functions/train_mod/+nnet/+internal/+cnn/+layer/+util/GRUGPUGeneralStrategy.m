classdef GRUGPUGeneralStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % GRUGPUGeneralStrategy   Execution strategy for running GRU with a
    % general set of options.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X, W, R, b, h0, opts)
            learnable.W = W;
            learnable.R = R;
            learnable.b = b;
            state.h0 = h0;

            [Z, H] = nnet.internal.cnngpu.gruForwardGeneral(X,learnable,state,opts);
            memory.HiddenState = H;
        end
        
        function [dX, dW] = backward(~, X, W, R, b, h0, Z, dZ, memory, opts)
            learnable.W = W;
            learnable.R = R;
            learnable.b = b;
            state.h0 = h0;
            outputs.Z = Z;
            outputs.H = memory.HiddenState;
            derivatives.dZ = dZ;
            
            needsWeightGradients = nargout > 1;
            gruBackward = @nnet.internal.cnngpu.gruBackwardGeneral;
            
            if ~needsWeightGradients
                dX = gruBackward(X, learnable, state, outputs, derivatives, opts);
            else
                [dX, dIW, dRW, dB] = gruBackward(X, learnable, state, outputs, derivatives, opts);
                dW{1} = dIW;
                dW{2} = dRW;
                dW{3} = dB;
            end
        end
    end
end
