classdef FullyConnectedHost3DImageStrategy < nnet.internal.cnn.layer.util.FullyConnectedImageStrategy
    % FullyConnectedHostImageStrategy   Execution strategy for running the
    % fully connected layer on the host with image inputs

    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function X = sendToDevice(~, X)
            % No operation required for the host
        end
        
        function Z = convolveForward(~, X, weights)
             Z = nnet.internal.cnnhost.stridedConv3D(X, weights,...
                                                   [0, 0, 0], [0, 0, 0],...
                                                   [1, 1, 1],...
                                                   [1, 1, 1]);
        end
        
        function dX = convolveBackwardData(~, X, weights, dZ)
             dX = nnet.internal.cnnhost.convolveBackwardData3D(X, weights, dZ,...
                                                   [0, 0, 0], [0, 0, 0],...
                                                   [1, 1, 1],...
                                                   [1, 1, 1] );
        end
        
        function dW = convolveBackwardFilter(~, X, weights, dZ)
             dW =  nnet.internal.cnnhost.convolveBackwardFilter3D(X, weights, dZ,...
                                                   [0, 0, 0], [0, 0, 0],...
                                                   [1, 1, 1],...
                                                   [1, 1, 1] );
        end
        
        function dB = convolveBackwardBias(~, dZ)
            dB = nnet.internal.cnnhost.convolveBackwardBias3D(dZ);
        end
    end
end