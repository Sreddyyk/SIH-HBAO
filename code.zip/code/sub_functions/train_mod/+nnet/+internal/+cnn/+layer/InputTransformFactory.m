classdef InputTransformFactory
    % InputTransformFactory   InputTransform factory class
    %   transform = InputTransformFactory.create(transformType, inputSize)
    % input:
    %   transformType      - the type of transform to create.
    %                         One of:
    %                        'randcrop'
    %                        'randfliplr'
    %                        'zerocenter'
    %                        'zscore'
    %                        'rescale-symmetric'
    %                        'rescale-zero-one'
    %                        'none'
    %   inputSize          - image input size
    % output:
    %   transform          - nnet.internal.cnn.layer.InputTransform
    
    %   Copyright 2015-2019 The MathWorks, Inc.
    
    methods(Static)
        function transform = create(transformType, inputSize)
            % create   Return a nnet.internal.cnn.layer.InputTransform object
            if isa(transformType,'function_handle')
                transform = nnet.internal.cnn.layer.CustomNormalization( ...
                    inputSize, transformType );
            else
                transform = iCreateFromName(transformType,inputSize);
            end
        end
        
        function transform = deserialize( S )
            transform = iCreateFromName( S.Type, S.ImageSize );
            transform = iAssignFields( transform, S );
        end
    end
end

function transform = iCreateFromName(type,inputSize)
constructors = iConstructors();
type = matlab.lang.makeValidName(type);
transform = constructors.(type)(inputSize);
end

function types = iConstructors()
% Returns a struct containing the constructors
types = struct( ...
    'randcrop', @nnet.internal.cnn.layer.RandomCropImageTransform, ...
    'randfliplr', @nnet.internal.cnn.layer.RandomFliplrImageTransform, ...
    'zerocenter', @nnet.internal.cnn.layer.ZeroCenterNormalization, ...
    'zscore', @nnet.internal.cnn.layer.ZScoreNormalization, ...
    'rescale_symmetric', @(sz)nnet.internal.cnn.layer.RescaleNormalization(sz,-1,1), ...
    'rescale_zero_one', @(sz)nnet.internal.cnn.layer.RescaleNormalization(sz,0,1), ...
    'rescale', @(sz)nnet.internal.cnn.layer.RescaleNormalization(sz), ...
    'custom', @nnet.internal.cnn.layer.CustomNormalization, ...
    'none', @(~,~)nnet.internal.cnn.layer.InputTransform.empty);
end

function transform = iAssignFields( transform, S )
fieldAssigners = iFieldAssigners();
transform = fieldAssigners.(S.Type)(transform, S);
end

function fieldAssigners = iFieldAssigners()
noFields = @(transform, ~) transform;
fieldAssigners = struct( ...
    'randcrop', noFields , ...
    'randfliplr', noFields , ...
    'zerocenter', @iAssignZeroCenterFields, ...
    'zscore', @iAssignZScoreFields, ...
    'rescale_symmetric', @iAssignMinMaxFields, ...
    'rescale_zero_one', @iAssignMinMaxFields, ...
    'rescale', @iAssignMinMaxFields, ...
    'custom', @iAssignCustomFcnFields, ...
    'none', noFields );
end

function transform = iAssignZeroCenterFields( transform, S )
if S.Version < 2
    S = iUpgradeZeroCenterVersion1ToVersion2(S);
end
transform.Mean = S.AverageImage;
end

function transform = iAssignZScoreFields( transform, S )
transform.Mean = S.Mean;
transform.Std = S.Std;
end

function transform = iAssignMinMaxFields( transform, S )
transform.Min = S.Min;
transform.Max = S.Max;
transform.TargetMin = S.TargetMin;
transform.TargetMax = S.TargetMax;
end

function transform = iAssignCustomFcnFields( transform, S )
transform.Function = S.Function;
end

function S = iUpgradeZeroCenterVersion1ToVersion2(S)
% Before R2019a, the zerocenter transformation did not include the
% NumTrainingSamples property used at train time.
S.Version = 2.0;
% Note that this is not used anymore but is still assigned for forward
% compatibility (loading 19b input layers in 19a)
S.NumTrainingSamples = 0;
end