function dimString = validateNormalizationDimension( dimString, normalization )
% validateNormalizationDimension   Throw an error if the normalization
% dimension property is invalid or not supported by the normalization type.

%   Copyright 2019 The MathWorks, Inc.

validDimensions = {'auto', 'channel', 'element', 'all' };
dimString = validatestring(dimString, validDimensions);

if isa(normalization,'function_handle') && dimString ~= "auto"
    error( message( 'nnet_cnn:layer:InputLayer:SettingNormDimWhenCustomNormalization' ) )
end

end