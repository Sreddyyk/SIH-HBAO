classdef CustomLayerFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy
    % CustomLayerFunctionalStrategy   Execution strategy for using a custom
    % intermediate layer in a dlnetwork.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        LayerVerifier nnet.internal.cnn.layer.util.CustomLayerVerifier
        IsForwardDefined(1,1) logical
    end
    
    methods
        function this = CustomLayerFunctionalStrategy(layerVerifier, ...
                isForwardDefined)
            this.LayerVerifier = layerVerifier;
            this.IsForwardDefined = isForwardDefined;
        end
        
        function Z = predict(this, layer, X)
            % Assume X are already labelled dlarrays
            [expectedType, Xdims, X] = processInput(this, X);
            
            wrapperMsg = iCustomLayerMsg('PredictErrored',class(layer));
            [Z{1:layer.NumOutputs}] = iFevalUserCode( wrapperMsg, ...
                @layer.predict, X{:} );
            
            this.LayerVerifier.verifyUnlabeledDlarray( 'predict', ...
                layer.OutputNames, Z )
            
            % Reapply dims
            Z = cellfun(@(zi) dlarray(zi, Xdims), Z, 'UniformOutput', false);
            
            % Verify type
            data = cellfun(@(zi) extractdata(zi), Z, 'UniformOutput', false);
            this.LayerVerifier.verifyPredictType( layer.OutputNames, ...
                expectedType, data );
            
            Z = iUnwrapScalarCell(Z);
        end
        
        function [Z, memory] = forward(this, layer, X)
            % Assume X are already labelled dlarrays
            [expectedType, Xdims, X] = processInput(this, X);
            
            if this.IsForwardDefined
                wrapperMsg = iCustomLayerMsg('ForwardErrored',class(layer));
            else
                wrapperMsg = iCustomLayerMsg('PredictErrored',class(layer));
            end
            
            [Z{1:layer.NumOutputs}] = iFevalUserCode( wrapperMsg, ...
                @layer.forward, X{:} );
            
            % Outputs of forward should be unlabeled dlarrays
            if this.IsForwardDefined
                this.LayerVerifier.verifyUnlabeledDlarray( 'forward', ...
                    layer.OutputNames, Z )
            else
                this.LayerVerifier.verifyUnlabeledDlarray( 'predict', ...
                    layer.OutputNames, Z )
            end
            
            % Reapply dims
            Z = cellfun(@(zi) dlarray(zi, Xdims), Z, 'UniformOutput', false);
            
            % Verify type
            data = cellfun(@(zi) extractdata(zi), Z, 'UniformOutput', false);
            if this.IsForwardDefined
                this.LayerVerifier.verifyForwardType( layer.OutputNames, ...
                    expectedType, data );
            else
                this.LayerVerifier.verifyPredictType( layer.OutputNames, ...
                    expectedType, data );
            end
            
            Z = iUnwrapScalarCell(Z);
            memory = [];
        end
    end
    
    methods(Access=private)
        function [expectedType, Xdims, X] = processInput(~, X)
            expectedType = iFullType(X);
            X = iWrapInCell(X);
            % X are already labelled dlarrays. Check all same dims and
            % stripdims
            Xdims = dims(X{1});
            X{1} = stripdims(X{1});
            for i=2:numel(X)
                if ~isequal(dims(X{i}), Xdims)
                    error(iCustomLayerMsg('DifferentDims'))
                end
                X{i} = stripdims(X{i});
            end
        end
    end
end

function X = iWrapInCell(X)
if ~iscell(X)
    X = {X};
end
end

function data = iUnwrapScalarCell(cellData)
if iscell(cellData) && isscalar(cellData)
    data = cellData{1};
else
    data = cellData;
end
end

function typeStruct = iFullType(data)
if iscell(data)
    data = data{1};
end

% Here data is a dlarray
data = extractdata(data);
mainClass = class(data);
if mainClass == "gpuArray"
    underlyingClass = classUnderlying(data);
else
    underlyingClass = '';
end

typeStruct = struct( ...
    'Main', mainClass, ...
    'Underlying', underlyingClass );
end

function msg = iCustomLayerMsg(id,varargin)
msg = message("nnet_cnn:internal:cnn:layer:CustomLayer:"+string(id),varargin{:});
end

function varargout = iFevalUserCode(msg,F,varargin)
[varargout{1:nargout}] = nnet.internal.cnn.util.UserCodeException.fevalUserCode(msg,F,varargin{:});
end