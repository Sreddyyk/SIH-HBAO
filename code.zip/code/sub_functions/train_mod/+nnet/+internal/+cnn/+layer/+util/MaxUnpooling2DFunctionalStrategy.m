classdef MaxUnpooling2DFunctionalStrategy < nnet.internal.cnn.layer.util.FunctionalStrategy
    % MaxUnpooling2DFunctionalStrategy    Calls into the dlarray maxunpool method
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, inputsX)
            % Unpack inputs
            X          = inputsX{1};
            indices    = inputsX{2};
            outputSize = inputsX{3};
            
            % TODO: use internal API
            Z = maxunpool(X, indices, outputSize);
            
            memory = [];
        end
    end
end
