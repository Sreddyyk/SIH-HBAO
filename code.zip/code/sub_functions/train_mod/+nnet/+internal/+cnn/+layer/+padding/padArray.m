function outputArray = padArray(inputArray, paddingSize, paddingValue)
% padArray   Pad a 4D/5D array spatially (in the first two/three dimensions)
%
%   outputArray = padArray(inputArray, paddingSize) takes a 4D/5D array
%   inputArray and a vector paddingSize, and returns a spatially padded
%   array outputArray.
%
%   outputArray = padArray(inputArray, paddingSize, paddingValue) takes an
%   optional scalar paddingValue used to fill the padding. The default
%   value for paddingValue is zero.
%
%   Inputs:
%       inputArray              - A (H)x(W)x(C)x(N)/(H)x(W)x(D)x(C)x(N)
%                                 array which will be
%                                 spatially padded along the H and W 
%                                 (and 'D' )dimensions.
%       paddingSize             - A 1-by-4/1-by-6 vector for the padding in the 
%                                 format [top bottom left right (front back)].
%       paddingValue            - A scalar value for filling the padding (optional).
%
%   Output:
%       outputArray             - A (H+top+bottom)x(W+left+right)x(C)x(N) or
%                                 (H+top+bottom)x(W+left+right)x(D+front+back)x(C)x(N)
%                                 array which has been padded.

%   Copyright 2017-2019 The MathWorks, Inc.

if nargin < 3
    paddingValue = 0;
end

topPad = paddingSize(1);
bottomPad = paddingSize(2);
leftPad = paddingSize(3);
rightPad = paddingSize(4);

numDims = numel(paddingSize)/2;
outputSize = ones(1,numDims);
outputSize(1:ndims(inputArray)) = size(inputArray); 

outputSize(1) = outputSize(1) + topPad + bottomPad;
outputSize(2) = outputSize(2) + leftPad + rightPad;

imageTop = topPad + 1;
imageBottom = topPad + size(inputArray,1);
imageLeft = leftPad + 1;
imageRight = leftPad + size(inputArray,2);


if(numel(paddingSize) == 6)
    frontPad = paddingSize(5);
    backPad = paddingSize(6);
    outputSize(3) = outputSize(3) + frontPad + backPad;
    imageFront = frontPad + 1;
    imageBack = frontPad + size(inputArray,3);
end   
    
outputArray = zeros(outputSize, 'like', inputArray) + paddingValue;


switch numel(paddingSize)
   
    case 4
        outputArray(imageTop:imageBottom, imageLeft:imageRight, :, :) = inputArray;
    case 6
        outputArray(imageTop:imageBottom,...
                    imageLeft:imageRight,...
                    imageFront:imageBack, :, :) = inputArray;
end

end