classdef CPUGenericFusedLayer < nnet.internal.cnn.layer.FusedLayer
    % CPUGenericLayerFuser  Fused layer representing an entire network
    % executed using CPU built-ins.
    
    % Copyright 2019 The MathWorks, Inc.
   
    %% Public properties.
    properties (Constant)
        % DefaultName  Default layer's name.
        DefaultName = 'fusedNetwork';
    end
    
    properties (Access = private)
        % FusedNetworkObj  The object containing the internal fused network
        FusedNetworkObj
    end
    
     properties (SetAccess = private)
        % InputSize  this layer must provide this part of the InputLayer
        % API in order to behave like an input layer.
        InputSize(1,:) double
    end
    
    %% Initialization methods.
    methods
       
        function obj = CPUGenericFusedLayer(name, layerGraph, precision, ...
            nDataDims)
            obj = obj@nnet.internal.cnn.layer.FusedLayer(name, layerGraph);
            nLayers = length(layerGraph.Layers);
            layerInputArguments = cell(1, nLayers);
            for k = 1:nLayers
                if isa(layerGraph.Layers{k}, "nnet.internal.cnn.layer.CustomLayer")
                    customLayer = layerGraph.Layers{k}.ExternalCustomLayer;
                    assert(isa(customLayer, "nnet.internal.cnn.layer.CPUFusableLayer"));
                    layerInputArguments{k} = customLayer.getFusedArguments();
                else
                    assert(isa(layerGraph.Layers{k}, "nnet.internal.cnn.layer.CPUFusableLayer"));
                    layerInputArguments{k} = layerGraph.Layers{k}.getFusedArguments();
                end
            end
            % Fuse the network.
            edgeList = sortrows(layerGraph.Connections, 1:4);
            % Convert to 0-based indices.
            edgeList = edgeList-1;
            % Merge pre-processing layers in to the input.
            if isa(layerGraph.Layers{1}, 'nnet.internal.cnn.layer.ImageInput')
                obj.InputSize = layerGraph.Layers{1}.InputSize;
            end
            % Construct the fused network object.
            obj.FusedNetworkObj = ...
                matlab.internal.math.cnn.MLFusedNetwork(cast([], precision), ...
                    nDataDims, edgeList, layerInputArguments);
        end
        
        function this = prepareForTraining(this)
            % This FusedLayer type is only used for prediction, so this is
            % not allowed
            assert(false, "CPUGenericLayerFuser cannot be used for training");
        end
        
        function this = setupForHostTraining(this)
            % This FusedLayer type is only used for prediction, so this is
            % not allowed
            assert(false, "CPUGenericLayerFuser cannot be used for training");
        end
        
        function this = setupForGPUTraining(this)
            % This FusedLayer type is only used for prediction, so this is
            % not allowed
            assert(false, "CPUGenericLayerFuser cannot be used for training");
        end
        
    end
    
    %% Propagation methods.
    methods
        function Z = predict(this, X)
            % predict   Forward input data through the layer and output the
            % result
            Z = this.FusedNetworkObj.predict(X);
        end
    end
    
    %% Overloaded Utilities
    methods( Access = protected )
        
        function this = cacheLearnables( this )
            % cacheLearnables  Overload the base class so that we do not
            % bother caching learnable parameters. The local cache is not
            % used.
        end
        
        function layers = restoreLearnables( ~, layers )
            % restoreLearnables  Overload the base class to do nothing,
            % since we never cached the learnables in the first place.
        end
        
    end
    
    %% Helper Methods
    methods (Static, Access = public, Hidden = true)
        function p = shufflePadding(p)
            % shufflePadding  Shuffles the padding vector into the format
            % required by the CPU built-ins.
            p = reshape(p, 2, [])';
            p = p(:);
            p = p';
        end
       
   end
end