classdef BatchNormalizationFunctionalStrategy 
    % BatchNormalizationFunctionalStrategy    dlarray method strategy
    
    %   Copyright 2019 The MathWorks, Inc.

    methods
        function [Z, memory] = forwardTrain(~, ...
                X, offset, scale, epsilon, ~)

            [Z,batchMean,batchVar] = ...
                batchnorm(X, offset(:), scale(:), 'Epsilon', epsilon);
            
            memory = {batchMean, batchVar};
        end
        
        function Z = forwardPredict(~, ...
                X, offset, scale, epsilon, ...
                trainedMean, trainedVariance, ~)

            Z = batchnorm(X, offset(:), scale(:), ...
                trainedMean(:), trainedVariance(:), 'Epsilon', epsilon);
        end        
    end
end
