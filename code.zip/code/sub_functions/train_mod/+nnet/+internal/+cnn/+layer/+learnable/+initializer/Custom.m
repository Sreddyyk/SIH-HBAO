classdef Custom < nnet.internal.cnn.layer.learnable.initializer.Initializer  
    % Custom    Initializer for custom functions
   
    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function this = Custom(fcn)
            this.Name = 'custom';
            this.Fcn = fcn;
        end        
        
        function param = initialize(this, paramSize, paramName)
            try 
                param = this.Fcn(paramSize);
            catch e
                throwAsCaller(e)
            end
            validateattributes(param, {'numeric'}, ...
                {'size', paramSize}, '', paramName);
        end
        
        function s = toStruct(this)
            s.Class = class(this);
            s.ConstructorArguments = {this.Fcn};
        end
    end
    
    methods (Access = protected)
        function tf = privateIsEqual(this, anotherInitializer)
            if isa(anotherInitializer, class(this))
                % TODO: need to follow up on this:
                tf = isequal(this.Fcn, anotherInitializer.Fcn);
            else
                tf = false;
            end
        end
    end
end