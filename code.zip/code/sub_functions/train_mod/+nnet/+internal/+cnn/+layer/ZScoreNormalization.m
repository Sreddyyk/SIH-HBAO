classdef ZScoreNormalization < nnet.internal.cnn.layer.InputTransform
    % ZScoreNormalization   Data transform for zscore normalization
    %   This class computes the zscore of any input data by subtracting the 
    %   mean and dividing by the standard deviation.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(Constant)
        Type = 'zscore';
        Hyperparams = { 'Mean', 'StandardDeviation' };
    end
    
    properties
        % DataSize   Size of the data that this transform will transform.
        % DataSize must include the channel dimension even if it is one.
        DataSize
    end
    
    properties(Dependent)
        % Mean   Mean over observations. Can either be a vector
        % with a mean value per data channel or the mean of the training
        % data with the same size as the input data size.
        Mean
        
        % Std   Standard deviation over observations. Can either be a 
        % vector with a std value per data channel or the std of the 
        % training data with the same size as the input data size.
        Std
        
        % NormalizationDimension   Char value that describes which
        % dimensions to normalize via the same statistics.
        NormalizationDimension
    end
    
    properties(Access = private)
        % PrivateUserMean   Mean over observations. Can either be a
        % vector with a mean value per data channel or the mean of the
        % training data with the same size as the input data size.
        PrivateUserMean
        
        % PrivateChannelMeanCache   Mean per channel of the trained mean.
        % This is only needed when retrieving activations with data of
        % larger spatial dimensions than the training data.
        PrivateChannelMeanCache
        
        % PrivateReducedMeanCache   Mean over observations. This is a
        % reduced version of PrivateUserMean based on the
        % NormalizationDimension parameter.
        PrivateReducedMeanCache
        
        % PrivateUserStd   Std over observations. Can either be a
        % vector with a std value per data channel or the std of the
        % training data with the same size as the input data size.
        PrivateUserStd
        
        % PrivateChannelStdCache   Std per channel of the trained mean.
        % This is only needed when retrieving activations with data of
        % larger spatial dimensions than the training data.
        PrivateChannelStdCache
        
        % PrivateReducedStdCache   Std over observations. This is a
        % reduced version of PrivateUserStd based on the
        % NormalizationDimension parameter.
        PrivateReducedStdCache
        
        % PrivateNormalizationDimension   NormalizationDimension specified
        % as char value which describes which dimensions to normalize
        % via the same statistics.
        PrivateNormalizationDimension = 'auto'
    end
    
    methods
        function this = ZScoreNormalization(inputSize)
            this.DataSize = inputSize;
            this = reset(this);
        end
        
        function S = serialize( this )
            S.Version = 1.0;
            S.Type = this.Type;
            S.ImageSize = this.DataSize;
            S.Mean = this.Mean;
            S.Std = this.Std;
        end
        
        function outputSize = forwardPropagateSize(~, inputSize)
            outputSize = inputSize;
        end
        
        function this = set.NormalizationDimension(this,value)
            this.PrivateNormalizationDimension = value;
            % To update the reduced represenations of the statistics based 
            % on the new NormalizationDimension value, reassign the statistics.
            this.Mean = this.Mean;
            this.Std = this.Std;
        end
        
        function value = get.NormalizationDimension(this)
            value = this.PrivateNormalizationDimension;
        end
        
        function this = set.Mean(this, value)
            this.PrivateUserMean = value;
            this.PrivateChannelMeanCache.Value = iComputeReducedMean( ...
                value, this.DataSize, 'channel' );
            this.PrivateReducedMeanCache.Value = iComputeReducedMean( ...
                value, this.DataSize, this.NormalizationDimension);
            % Recompute reduced standard deviation
            this.Std = this.Std;
        end
        
        function value = get.Mean(this)
            value = this.PrivateUserMean;
        end
        
        function this = set.Std(this, value)
            this.PrivateUserStd = value;
            this.PrivateChannelStdCache.Value = iComputeReducedStd( ...
                value, this.Mean, this.DataSize, 'channel' );
            this.PrivateReducedStdCache.Value = iComputeReducedStd( ...
                value, this.Mean, this.DataSize, this.NormalizationDimension);
        end
        
        function value = get.Std(this)
            value = this.PrivateUserStd;
        end
        
        function tf = needsInitialization(this)
            tf = isempty(this.Mean) || isempty(this.Std);
        end
        
        function this = setupForGPUTransform(this)
            this.PrivateReducedMeanCache.UseGPU = true;
            this.PrivateChannelMeanCache.UseGPU = true;
            this.PrivateReducedStdCache.UseGPU = true;
            this.PrivateChannelStdCache.UseGPU = true;
        end
        
        function this = setupForHostTransform(this)
            this.PrivateReducedMeanCache.UseGPU = false;
            this.PrivateChannelMeanCache.UseGPU = false;
            this.PrivateReducedStdCache.UseGPU = false;
            this.PrivateChannelStdCache.UseGPU = false;
        end
    end
    
    methods(Access = protected)
        function this = doReset(this)
            this.PrivateUserMean = [];
            this.PrivateReducedMeanCache = iEmptyDoubleParameter();
            this.PrivateChannelMeanCache = iEmptyDoubleParameter();
            this.PrivateUserStd = [];
            this.PrivateReducedStdCache = iEmptyDoubleParameter();
            this.PrivateChannelStdCache = iEmptyDoubleParameter();
        end
        
        function batch = doTransform(this, batch)
            spatialDims = numel(this.DataSize) - 1;
            
            batchSize = ones(1,numel(this.DataSize));
            batchSize(1:ndims(batch)) = size( batch );
            
            if isequal( batchSize(1:spatialDims), this.DataSize(1:spatialDims) )
                assert(~isempty(this.PrivateReducedMeanCache.Value), ...
                    "Mean value is empty");
                assert(~isempty(this.PrivateReducedStdCache.Value), ...
                    "Std value is empty");
                
                stdWithoutZeros = this.PrivateReducedStdCache.Value;
                % To prevent division by zero, set std to 1 where it is 0
                % (see zscore implementation of SMLT)
                stdWithoutZeros(stdWithoutZeros==0) = 1;
                batch = (batch - this.PrivateReducedMeanCache.Value) ...
                    ./ stdWithoutZeros;
            else
                % The size of the input data is different from the size of
                % the training data and the data statistics. This can only
                % occur when calling activations on larger images. Use the
                % per-channel statistics for normalization.
                assert(~isempty(this.PrivateChannelMeanCache.Value), ...
                    "Reduced mean per channel is empty");
                assert(~isempty(this.PrivateChannelStdCache.Value), ...
                    "Reduced std per channel is empty");
                
                stdWithoutZeros = this.PrivateChannelStdCache.Value;
                % To prevent division by zero, set std to 1 where it is 0
                % (see zscore implementation of SMLT)
                stdWithoutZeros(stdWithoutZeros==0) = 1;
                batch = (batch - this.PrivateChannelMeanCache.Value) ...
                    ./ stdWithoutZeros;
            end
        end
        
        function this = doInitialize(this, stats)
            % By default, compute per-channel statistics
            if this.NormalizationDimension == "auto"
                normDim = 'channel';
            else
                normDim = this.NormalizationDimension;
            end
            
            perElementMean = gather( getStatistic(stats,'mean') );
            if isempty(this.Mean)
                
                this.Mean = iComputeReducedMean( perElementMean, ...
                    this.DataSize, normDim );
            end
            
            if isempty(this.Std)
                perElementStd = gather( getStatistic(stats,'std') );
                this.Std = iComputeReducedStd( perElementStd, ...
                    perElementMean, this.DataSize, normDim );
            end
        end
    end
end

function out = iComputeReducedMean(value, dataSize, normDimension)
switch normDimension
    case 'auto'
        out = value;
    case 'element'
        out = value;
    case 'channel'
        spatialDims = 1:(numel(dataSize)-1);
        out = iReduceMean(value, spatialDims);
    case 'all'
        spatialDims = 1:numel(dataSize);
        out = iReduceMean(value, spatialDims);
end
end

function out = iReduceMean(value, dim)
out = nnet.internal.cnn.layer.util.computeMeanOfMeans(value,dim);
end

function out = iComputeReducedStd(stdValue, meanValue, dataSize, normDimension)
switch normDimension
    case 'auto'
        out = stdValue;
    case 'element'
        out = stdValue;
    case 'channel'
        spatialDims = 1:(numel(dataSize)-1);
        out = iReduceStd(stdValue, meanValue, spatialDims);
    case 'all'
        spatialDims = 1:numel(dataSize);
        out = iReduceStd(stdValue, meanValue, spatialDims);
end
end

function out = iReduceStd(dataStd, dataAvg, dims)
out = nnet.internal.cnn.layer.util.computeMeanOfStds(dataStd,dataAvg,dims);
end

function param = iEmptyDoubleParameter()
param = nnet.internal.cnn.layer.util.CachedParameter([]);
end
