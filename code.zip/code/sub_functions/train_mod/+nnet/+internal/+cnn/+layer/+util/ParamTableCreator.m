classdef ParamTableCreator
    % ParamTableCreator   Creates a table of parameters
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(Constant, Access=private)
        TableVariableNames = {'Layer', 'Parameter', 'Value'}
    end
    
    methods
        function t = create(~, layerName, paramNames, paramValues)
            % layerName is a single char for all the parameters.
            % paramNames is a column string vector
            % paramValues is a column cell vector with values.
            N = numel(paramNames);
            Layer = repmat(string(layerName),[N 1]);
            Parameter = paramNames;
            Value = paramValues;
            t = table(Layer, Parameter, Value, 'VariableNames', ...
                nnet.internal.cnn.layer.util.ParamTableCreator.TableVariableNames);
        end
    end
    
    methods(Static)
        function assertTableContents(t, layerName, paramNames)
            % Verify that t is a "Parameter Table": it should contain values for the
            % specified layer and parameters
            
            % Verify that contents match the expected layer and parameter names
            expectedLayer = paramNames;
            expectedLayer(:) = string(layerName);
            
            if ~isequal(t.Layer, expectedLayer) || ~isequal(t.Parameter, paramNames)
                error(message('nnet_cnn:internal:cnn:layer:util:ParamTableCreator:InvalidTable'));
            end
        end
        
        function ok = validateTableStructure(t)
            % Verify that t is a "Parameter Table": it should contain the expected
            % variables and have a column cell array in its Value variable.
            
            expectedVarNames = nnet.internal.cnn.layer.util.ParamTableCreator.TableVariableNames;
            ok = istable(t) && ...
                isequal(t.Properties.VariableNames, expectedVarNames);
            
            % Test value variable
            if ok
                v = t.Value;
                ok = iscell(v) && iEmptyOrColumn(v);
            end
            
            % Test Layer variable
            if ok
                lnames = t.Layer;
                ok = isstring(lnames) && iEmptyOrColumn(lnames);
            end
            
            % Test Parameter variable
            if ok
                pnames = t.Parameter;
                ok = isstring(pnames) && iEmptyOrColumn(pnames);
            end
        end
    end
end

function ok = iEmptyOrColumn(v)
    ok = isempty(v) || iscolumn(v);
end
