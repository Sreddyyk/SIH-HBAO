classdef(Sealed) ImageInputValidator < nnet.internal.cnn.layer.util.InputValidationStrategy
    % ImageInputValidator    Performs checks on image input data with
    % regards to the configuration of the imageInputLayer or the
    % image3dInputLayer.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function this = ImageInputValidator(inputSize)
            % inputSize is a vector containing the size of all spatial
            % dimensions and the channel dimension.
            this.NumSpatialDims = numel(inputSize)-1;
            this.NumChannels = inputSize(end);
        end
        
        function validateInputFormat(this, sz, fmt)
            this.validateSpatialDimension(fmt);
            this.validateChannelDimension(sz,fmt);
            this.validateNoSequenceDimension(fmt);
            this.validateNoUnspecifiedDimension(sz,fmt);
        end
    end
end