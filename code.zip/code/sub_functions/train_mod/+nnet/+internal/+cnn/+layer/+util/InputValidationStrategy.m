classdef(Abstract) InputValidationStrategy
    % InputValidationStrategy    Performs checks on input data
    % with regards to the configuration of the input layer.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(Access = protected)
        NumSpatialDims(1,1) double {mustBeInteger,mustBeNonnegative} = 0
        NumChannels(1,1) double {mustBeInteger,mustBePositive} = 1
    end
    
    methods(Abstract)
        % validateInputFormat   Validate that the size and format of the
        % input data is compatible with the configuration of the input
        % layer. The inputs sz and fmt are vector of type double and char,
        % respectively, with the same number of elements.
        validateInputFormat(this,sz,fmt)
    end
    
    methods(Access = protected)
        function validateChannelDimension(this,sz,fmt)
            % Validate that input has one channel dimension
            channelDimIdx = fmt=='C';
            if ~any(channelDimIdx)
                error(message(iGetFullMsgID('NoChannelDimension')))
            end
            
            % Validate the number of channels of the data matches the
            % expected number of channels in the layer
            actualNumChannels = sz(channelDimIdx);
            if actualNumChannels ~= this.NumChannels
                error(message(iGetFullMsgID('WrongNumberChannels'),...
                    this.NumChannels,actualNumChannels))
            end
        end
        
        function validateSpatialDimension(this,fmt)
            % Validate number of spatial dimensions of the data matches the
            % expected number of channels in the layer
            actualNumSpatialDims = nnz(fmt=='S');
            if actualNumSpatialDims ~= this.NumSpatialDims
                error(message(iGetFullMsgID('WrongNumberSpatialDims'),...
                    this.NumSpatialDims,actualNumSpatialDims))
            end
        end
        
        function validateSequenceDimensionExists(~,fmt)
            % Validate that input has a 'T' dimension
            if ~any(fmt=='T')
                error(message(iGetFullMsgID('NoSequenceDimension')))
            end
        end
        
        function validateNoUnspecifiedDimension(~,sz,fmt)
            % Validate that input doesn't have non-singleton 'U' dimensions
            unspecifiedDimIdx = fmt=='U';
            if any(unspecifiedDimIdx) && any(sz(unspecifiedDimIdx)>1)
                error(message(iGetFullMsgID('InvalidUnspecifiedDimension')))
            end
        end
        
        function validateNoSequenceDimension(~,fmt)
            % Validate that input doesn't have 'T' dimensions
            if any(fmt=='T')
                error(message(iGetFullMsgID('InvalidSequenceDimension')))
            end
        end
    end
end

function msg = iGetFullMsgID(id)
msg = ['nnet_cnn:internal:cnn:layer:util:InputValidationStrategy:',id];
end