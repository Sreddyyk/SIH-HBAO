classdef Ones < ...
        nnet.internal.cnn.layer.learnable.initializer.Initializer & ...
        nnet.internal.cnn.layer.learnable.initializer.BasicMixin    
    % Ones    Ones initializer
   
    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function this = Ones()
            this.Name = 'ones';
            this.Fcn = @ones;
        end        
    end
end