function weights = randScaledVariance(sz, ...
                                      distribution, ...
                                      varianceNormalization, ...
                                      scale, ...
                                      inIdx, ...
                                      outIdx)
% randScaledVariance    Create array of random weights with scaled variance
%
%     distribution              - Distribution to sample weights from 
%                                 specified as one of the following:
%                                  - 'normal': Sample weights from 
%                                    independent zero-mean normal 
%                                    distributions.
%                                  - 'uniform': Sample weights from 
%                                    independent zero-mean uniform 
%                                    distributions.
%     
%     varianceNormalization     - Normalization of the variance of 'normal'
%                                 and 'uniform' distributions. This can be:
%                                 - 'none': no normalization. 
%                                 - 'inputs': divide variance by 
%                                   sqrt(numInputs), where numInputs is the
%                                   number of input elements that affect a
%                                   single output element.
%                                 - 'outputs': divide variance by 
%                                   sqrt(numOutputs) where numOutputs is
%                                   the number of output elements that are
%                                   affected by a single input element.
%                                 - 'mean': divide by 
%                                   sqrt((numInputs + numOutputs)/2).
%
%     scale                      - Scalar multiplier of the weights.
%
%     inIdx                     - Indices of sz such that numInputs =
%                                 prod(sz(InIdx))
%
%     outIdx                    - Indices of sz such that numOutputs =
%                                 prod(sz(OutIdx))

%   Copyright 2018 The MathWorks, Inc.

multiplier = iMultiplier(sz, varianceNormalization, scale, inIdx, outIdx);
randFcn = iRandFcn(distribution);
weights = randFcn(sz) * multiplier;
end

function multiplier = iMultiplier(sz, varianceNormalization, scale, ...
    inIdx, outIdx)
multiplier = nnet.internal.cnn.layer.learnable.initializer.util...
    .computeMultiplier(sz, varianceNormalization, scale, inIdx, outIdx);
end

function randFcn = iRandFcn(distribution)
switch distribution
    case 'normal'
        randFcn = @(sz) randn(sz);
    case 'uniform'
        % sqrt(3) standardizes variance to 1
        randFcn = @(sz) sqrt(3) * (2 * rand(sz) - 1);    
    otherwise
        % For internal diagnostics
        assert('Invalid distribution')
end
end