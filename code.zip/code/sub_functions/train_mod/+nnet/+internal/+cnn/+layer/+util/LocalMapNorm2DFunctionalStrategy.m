classdef LocalMapNorm2DFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy
    % LocalMapNorm2DFunctionalStrategy    Execution strategy for running
    % local response normalization with dlarray
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X, windowSize, alpha, beta, k)
            
            Z = crosschannelnorm(X, windowSize, 'Alpha', alpha, 'Beta', beta, 'K', k);
            
            memory = [];
        end
    end
end
