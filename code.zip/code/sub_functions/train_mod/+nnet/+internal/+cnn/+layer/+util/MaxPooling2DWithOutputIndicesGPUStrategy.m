classdef MaxPooling2DWithOutputIndicesGPUStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    %  MaxPooling2DWithOutputIndicesGPUStrategy  Execution strategy for
    %  running the max pooling with output indices output on the GPU.
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(this, X, ...
                poolHeight, poolWidth, ...
                topPad, leftPad, ...
                bottomPad, rightPad, ...
                verticalStride, horizontalStride)
            
            poolSize = [poolHeight poolWidth];
            inputSize = size(X);
            outOfBoundPoolingWin = iInputSizeIsLessThanPoolSize(inputSize, poolSize);
            requiresManualPadding = iAnyStartPaddingIsLessThanHalfRequiredPadding(inputSize, poolSize, [topPad leftPad]);
            
            if outOfBoundPoolingWin && requiresManualPadding
                paddingSize = [topPad bottomPad leftPad rightPad];
                X_pad = iPadArray(X, paddingSize);
                [argmax, M] = maxPoolingWithOutputIndicesForward(this, X_pad, poolHeight, poolWidth, ... 
                    0, 0, 0, 0, verticalStride, horizontalStride);
                argmax = iUnpadArray(argmax, paddingSize);
            else
               [argmax, M] = maxPoolingWithOutputIndicesForward(this, X, poolHeight, poolWidth, ... 
                        topPad, leftPad, bottomPad, rightPad, verticalStride, horizontalStride);
            end
            
            [indices, sz] = argmaxIndices(this, X, argmax);
            if numel(M) ~= numel(indices)
                % The number of indices must equal the number of elements
                % in the output feature map. They are not equal when the
                % input feature map contains NaN in the entire pooling
                % region.
                error(message('nnet_cnn:layer:MaxPooling2DLayer:NotEnoughIndices'));
            end
            
            % pack output
            Z = {M, indices, sz};
            
            memory = [];
        end
        
        function [dX,dW] = backward(~, Z, dZ, X, ...
                poolHeight, poolWidth, ...
                topPad, leftPad, ...
                bottomPad, rightPad, ...
                verticalStride, horizontalStride)
            
            poolSize = [poolHeight poolWidth];
            inputSize = size(X);
            outOfBoundPoolingWin = iInputSizeIsLessThanPoolSize(inputSize, poolSize);
            requiresManualPadding = iAnyStartPaddingIsLessThanHalfRequiredPadding(inputSize, poolSize, [topPad leftPad]);
            
            if outOfBoundPoolingWin && requiresManualPadding
                paddingSize = [topPad bottomPad leftPad rightPad];
                X = iPadArray(X, paddingSize);
                dX = nnet.internal.cnngpu.poolingMaxBackward2D(...
                    Z{1}, dZ{1}, X, ...
                    poolHeight, poolWidth, ...
                    0, 0, ...
                    0, 0, ...
                    verticalStride, horizontalStride);
                dX = iUnpadArray(dX, paddingSize);
            else
                dX = nnet.internal.cnngpu.poolingMaxBackward2D(...
                    Z{1}, dZ{1}, X, ...
                    poolHeight, poolWidth, ...
                    topPad, leftPad, ...
                    bottomPad, rightPad, ...
                    verticalStride, horizontalStride);
            end
            dW = [];
        end
        
        function [indices, sz] = argmaxIndices(~, X, argmax)
            % get indices.
            indices = find(argmax);
            indicesInOutput = argmax(indices);
            
            % sort indices so that the order matches the linear index order
            % of the output M.
            [~, ord] = sort(indicesInOutput);
            indices = indices(ord);
            
            % convert linear index to subscripts.
            [H, W, C, N] = size(X);
            sz = [H, W, C, N];
        end
        
        function [argmax, M] = maxPoolingWithOutputIndicesForward(~, X, poolHeight, poolWidth, ... 
            topPad, leftPad, bottomPad, rightPad, verticalStride, horizontalStride)
            M = nnet.internal.cnngpu.poolingMaxForward2D(X, ...
                        poolHeight, poolWidth, ...
                        topPad, leftPad, ...
                        bottomPad, rightPad, ...
                        verticalStride, horizontalStride);

            dZ = cast(reshape(1:numel(M), size(M)), 'like', M);
            
            argmax = nnet.internal.cnngpu.poolingMaxBackward2D(...
                M, dZ, X, ...
                poolHeight, poolWidth, ...
                topPad, leftPad, ...
                bottomPad, rightPad, ...
                verticalStride, horizontalStride);
        end
    end
end

function tf = iInputSizeIsLessThanPoolSize(inputSize, poolSize)
tf = nnet.internal.cnn.layer.padding.isInputSizeLessThanPoolSize(inputSize, poolSize);
end

function tf = iAnyStartPaddingIsLessThanHalfRequiredPadding(inputSize, poolSize, paddingSize)
tf = nnet.internal.cnn.layer.padding.isAnyStartPaddingLessThanHalfRequiredPadding(inputSize, poolSize, paddingSize);
end

function outputArray = iPadArray(inputArray, paddingSize)
outputArray = nnet.internal.cnn.layer.padding.padArray(inputArray, paddingSize, -Inf);
end

function outputArray = iUnpadArray(inputArray, paddingSize)
outputArray = nnet.internal.cnn.layer.padding.unpadArray(inputArray, paddingSize);
end
