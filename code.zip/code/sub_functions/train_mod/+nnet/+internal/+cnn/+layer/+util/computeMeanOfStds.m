function reducedStd = computeMeanOfStds( stdValue, meanValue, dims, numSamples, biasCorrect )
% computeMeanOfStds   Reduce the standard deviation values in array stdValue
% along the dimensions specified by dims. To compute the combined standard
% deviation, the mean values are needed. Optionally, specify the number of
% samples that contributed to the given std and mean values in numSamples
% (otherwise equal contribution of each element in stdValue assumed).
% To compute the unbiased standard deviation, set biasCorrect to true,
% provide numSamples, and make sure that the intermediate stdValue was
% computed without bias correction (weighting scheme w=1).

%   Copyright 2019 The MathWorks, Inc.

if nargin<4
    % Each std and mean value contributes equally to the total mean
    numSamples = ones( size(stdValue) );
end
if nargin<5
    biasCorrect = false;
end

if isempty( stdValue )
    reducedStd = [];
elseif isempty( dims )
    % No further reduction is required
    reducedStd = stdValue;
elseif all(size(stdValue,dims) == 1)
    % Data which is already reduced in the specified dimensions does not
    % require further reduction.
    reducedStd = stdValue;
else
    % Assume zero mean if meanValue is unset
    if isempty(meanValue)
        meanValue = zeros(size(stdValue));
    end
    
    % The variance of the pooled set is the mean of the variances plus the
    % variance of the means.
    samplesPerDim = sum( numSamples, dims );
    reducedMean = sum( meanValue.*numSamples, dims ) ./ samplesPerDim;
    varValue = stdValue.^2;
    varValue = sum( numSamples.*varValue + numSamples.*(meanValue-reducedMean).^2, dims );
    varValue = varValue ./ samplesPerDim;
    
    % Bias correct the result
    if biasCorrect
        nm1 = max(samplesPerDim - 1, 1);
        % Bias-correct the result
        varValue = varValue .* (samplesPerDim./nm1);
    end
    
    % Calculate derived summary statistics
    reducedStd = sqrt(varValue);
end
end