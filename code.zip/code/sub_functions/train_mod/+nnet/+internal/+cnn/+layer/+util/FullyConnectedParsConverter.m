classdef FullyConnectedParsConverter
    % FullyConnectedParsConverter   Converts internal-external fully
    % connected parameters
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods    
        function extPars = toExternal(~, intPars, numNeurons, parsName)
            % Internal to external format.
            if isequal(parsName, 'Weights')
                if isempty(intPars)
                    % If no weights have been defined, return "empty" for
                    % weights
                    extPars = [];
                elseif ismatrix(intPars)
                    % If the weights are in a 2d matrix, then they can just be
                    % returned as after reshaping
                    extPars = reshape(intPars, numNeurons, []);
                else % Default case: 4d array
                    % In case the internal weights are 4-D we need to reshape
                    % them to 2-D.
                    extPars = reshape(intPars, [], numNeurons);
                    extPars = extPars';
                end
            elseif isequal(parsName, 'Bias')
                if isempty(intPars)
                    extPars = [];
                else
                    extPars = reshape(intPars, numNeurons, 1);
                end
            else
                error('Wrong parameter name')
            end
        end
        
        function intPars = toInternal(~, extPars, inputSize, numNeurons,...
                obsDim, parsName)
            % External to internal format. required size is the internal size: 
            %
            % [inputSize numNeurons] if numel(inputSize) == 3 or 4.
            %
            % [numNeurons inputSize] if numel(inputSize) == 1.
            if isequal(parsName, 'Weights')
                weights = extPars;
                if (numel(inputSize) == 3 || numel(inputSize) == 4)
                    requiredSize = [inputSize numNeurons];
                    if isequal( iGetNDSize(weights, numel(requiredSize)), requiredSize )
                        % Weights are the right size -- nothing to do
                    elseif isempty( weights )
                        % Weights are empty -- nothing we can do
                    elseif ismatrix( weights ) 
                        % Weights are 2D -- need to transpose and reshape to 4D
                        % Transpose is needed since the user would set
                        % it as [output input] instead of [input output].
                        weights = reshape( weights', requiredSize );
                    elseif numel(inputSize) == 3 && ndims(weights)== 5 % 2D input, 3D weight
                        weights = reshape( weights, requiredSize );
                    elseif numel(inputSize) == 4 && ndims(weights)== 4 % 3D input, 2D weight
                        weights = reshape( weights, requiredSize );
                    else
                        % There are three possibilities and this is a fourth state
                        % therefore something has gone wrong
                        warning( message('nnet_cnn:internal:cnn:layer:FullyConnected:InvalidState') );
                    end
                elseif isscalar(inputSize)
                    requiredSize = [numNeurons inputSize];
                    currentSize = iGetNDSize(weights,obsDim);
                    if isequal( currentSize, requiredSize )
                        % Weights are the right size -- nothing to do
                    elseif isempty( weights )
                        % Weights are empty -- nothing we can do
                    elseif isequal( currentSize, fliplr(requiredSize) )
                        % Weights need to be transposed
                        weights = weights';
                    elseif isequal( [currentSize(end) prod(currentSize(1:(end-1)))] , requiredSize )
                        % currentSize(end) corresponds to the numNeurons in the
                        % FC layer and currentSize(1:(end-1)) corresponds to
                        % InputSize
                        weights = reshape( weights, [prod(currentSize(1:(end-1))) currentSize(end)] );
                        weights = weights';
                    else
                        % Weights are incorrect size
                        warning( message('nnet_cnn:internal:cnn:layer:FullyConnected:InvalidState') );
                    end
                end
                intPars = weights;
            elseif isequal(parsName, 'Bias')
                bias = extPars;
                if (numel(inputSize) == 3 || numel(inputSize) == 4)
                    requiredSize = ones(1,obsDim-1);
                    requiredSize(end) = numNeurons;
                    if isequal( iGetNDSize( bias, numel(requiredSize) ), requiredSize )
                        % Biases are the right size -- nothing to do
                    elseif isempty( bias )
                        % Biases are empty -- nothing we can do
                    elseif ismatrix( bias) || (ndims(bias) == 3 && numel(requiredSize) == 4) || (ndims(bias) == 4 && numel(requiredSize) == 3)
                        % Biases are 2d -- need to reshaped to 3d or 4d
                        % Biases are 3d -- need to be reshaped to 4d
                        % Biases are 4d -- need to be reshaped to 3d
                        bias = reshape(bias, requiredSize);
                    end
                elseif isscalar(inputSize)
                    requiredSize = [numNeurons 1];
                    if isequal( size(bias), requiredSize )
                        % Biases are the right size -- nothing to do
                    elseif isempty( bias )
                        % Biases are empty -- nothing we can do
                    elseif isequal ( size(bias), fliplr(requiredSize) )
                        % Transpose the bias
                        bias = bias';
                    else
                        %                     if isequal( size(bias), expWrongSize )
                        % Biases are 3d or 4d -- need to reshape to 2d
                        bias = reshape(bias, requiredSize);
                    end
                end
                intPars = bias;                
            else
                error('Wrong parameter name')
            end
        end        
    end
end

function sz = iGetNDSize(X, N)
sz = ones(1,N);
sz(1:ndims(X)) = size(X);
end