classdef PredictionLearnableParameter < nnet.internal.cnn.layer.learnable.LearnableParameter
    % PredictionLearnableParameter   Learnable parameter for use at prediction time
    %
    %   This class is used to represent a learnable parameter at prediction
    %   time, and it is slightly more complex than the representation used
    %   at training time.
    %
    %   This class can be used in GPU mode or host mode, and this is
    %   controlled by setting the property "UseGPU".
    %
    %   1) When "UseGPU" is false, the "Value" property will return the 
    %   host array stored in "PrivateValue".
    %   2) When "UseGPU" is true, the "Value" property will return a
    %   gpuArray stored in "CacheHandle".
    
    %   Copyright 2016-2019 The MathWorks, Inc.
    
    properties(Dependent)
        % Value   The value of the learnable parameter
        Value
    end
    
    properties(Access = private)        
        % CacheHandle   A handle class which holds a copy of the learnable parameter on the GPU
        CacheHandle
    end
    
    properties(SetAccess = private)
        % HostValue   The value of the learnable parameter
        HostValue
    end
    
    properties
        % UseGPU   A boolean value which determines if the GPU is used
        UseGPU
        
        % LearnRateFactor   Multiplier for the learning rate for this parameter
        %   A scalar double.
        LearnRateFactor

        % L2Factor   Multiplier for the L2 regularizer for this parameter
        %   A scalar double.
        L2Factor
        
        % Initializer   Function to initialize this parameter.
        Initializer
    end
    
    methods
        function this = PredictionLearnableParameter()
            this.UseGPU = false;
            this.CacheHandle = nnet.internal.cnn.layer.learnable.CacheHandle();
            this.Initializer = iDefaultInitializer();
        end
        
        function this = set.Value(this, val)
            this.HostValue = gather(val); % Just in case we are given a gpuArray!
            
            % Update the cache based on a new HostValue. We always switch
            % to a new cache if the value is changed to avoid inadvertently
            % linking two copies of a parameter.
            if this.UseGPU
                this.CacheHandle = nnet.internal.cnn.layer.learnable.CacheHandle(gpuArray(this.HostValue));
                clearOnDeviceReset( this.CacheHandle );
            else
                % If not using the GPU, just create a new empty cache
                this.CacheHandle = nnet.internal.cnn.layer.learnable.CacheHandle();
            end
        end
        
        function val = get.Value(this)
            if this.UseGPU
                % Make sure the cache is filled, and get hold of the
                % contents.
                if this.CacheHandle.isEmpty()
                    this.CacheHandle.fillCache(gpuArray(this.HostValue));
                    clearOnDeviceReset( this.CacheHandle );
                end
                val = this.CacheHandle.Value;
                
            else
                val = this.HostValue;
            end
        end
        
    end
    
    methods(Hidden)
        function tf = hasCachedGpuArray(this)
            % hasCachedGpuArray  For testing whether a GPU array is cached,
            % which means this object can only be deserialized onto a
            % machine with a GPU.
            tf = isa(this.CacheHandle.Value, 'gpuArray');
        end
    end
    
    methods(Static)
        function obj = fromStruct(s)
            obj = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter();
            obj.Value = s.Value;
            obj.LearnRateFactor = s.LearnRateFactor;
            obj.L2Factor = s.L2Factor;
            if ~isfield(s, 'Initializer') || ~isfield(s.Initializer, 'ConstructorArguments')
                s.Version = 2;
                s.Initializer = iDefaultInitializerStruct();
            end
            obj.Initializer = nnet.internal.cnn.layer.learnable...
                .initializer.Initializer.fromStruct(s.Initializer);
        end
    end
end

function init = iDefaultInitializer()
init = nnet.internal.cnn.layer.learnable.initializer.Zeros();
end

function s = iDefaultInitializerStruct()
s = toStruct(iDefaultInitializer());
end
