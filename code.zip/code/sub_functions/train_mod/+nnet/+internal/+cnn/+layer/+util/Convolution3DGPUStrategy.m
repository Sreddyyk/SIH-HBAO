classdef Convolution3DGPUStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % Convolution3DGPUStrategy   Execution strategy for running the
    % 3D convolution on the GPU
    
    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X, ...
                weights, bias, ...
                paddingSize, stride, dilation)
            % paddingSize is formatted as [t b l r f bk] 
            if iPaddingIsSymmetric(paddingSize)
                Z = nnet.internal.cnngpu.convolveForwardND( ...
                    X, weights, ...
                    [paddingSize(1), paddingSize(3), paddingSize(5)],[],...
                    stride, dilation) + bias;
            else
                X = iPadArray(X, paddingSize);
                Z = nnet.internal.cnngpu.convolveForwardND( ...
                    X, weights, ...
                    [0,0,0], [],  stride, dilation) + bias;
            end
            memory = [];
        end
        
        function [dX,dW] = backward(~, ...
                X, weights, dZ, ...
                paddingSize, stride, dilation)
            
            needsWeightGradients = nargout > 1;
            % paddingSize is formatted as [t b l r f bk] 
            if iPaddingIsSymmetric(paddingSize)
                dX = nnet.internal.cnngpu.convolveBackwardDataND( ...
                    X, weights, dZ, ...
                    [paddingSize(1), paddingSize(3), paddingSize(5)],[],...
                    stride, dilation);
                if needsWeightGradients
                    dW{1} = nnet.internal.cnngpu.convolveBackwardFilterND( ...
                        X, weights, dZ, ...
                        [paddingSize(1), paddingSize(3), paddingSize(5)],[],    ...
                        stride, dilation);
                end
            else
                X = iPadArray(X, paddingSize);
                dX = nnet.internal.cnngpu.convolveBackwardDataND( ...
                    X, weights, dZ, ...
                    [0,0,0], [], stride, dilation);
                dX = iUnpadArray(dX, paddingSize);
                if needsWeightGradients
                    dW{1} = nnet.internal.cnngpu.convolveBackwardFilterND( ...
                        X, weights, dZ, ...
                        [0,0,0],[], stride, dilation);
                end
            end
            if needsWeightGradients
                dW{2} = nnet.internal.cnngpu.convolveBackwardBiasND(3,dZ);
            end
        end
        
    end
end

function tf = iPaddingIsSymmetric(paddingSize)
tf = nnet.internal.cnn.layer.padding.isPaddingSymmetric(paddingSize);
end

function outputArray = iPadArray(inputArray, paddingSize)
outputArray = nnet.internal.cnn.layer.padding.padArray(inputArray, paddingSize);
end

function outputArray = iUnpadArray(inputArray, paddingSize)
outputArray = nnet.internal.cnn.layer.padding.unpadArray(inputArray, paddingSize);
end
