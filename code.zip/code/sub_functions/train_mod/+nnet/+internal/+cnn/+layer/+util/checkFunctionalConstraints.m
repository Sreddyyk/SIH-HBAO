function checkFunctionalConstraints(analyzedLayers)
% checkFunctionalConstraints   Check that layer graph satisfies the
% built-in and functional constraints through the network analyzer.
% Avoids the built-in architecture constraints that do not apply here.

%   Copyright 2019 The MathWorks, Inc.

for c = iBuiltInConstraints'
    analyzedLayers.applyConstraints(c);
end
analyzedLayers.applyConstraints(iCustomFunctionalConstraint());
analyzedLayers.applyConstraints(iCustomFunctionalConnectionsConstraint());
analyzedLayers.throwIssuesIfAny()
end

function c = iBuiltInConstraints
c = [
    nnet.internal.cnn.analyzer.constraints.ConnectedComponents
    nnet.internal.cnn.analyzer.constraints.CustomLayers
    nnet.internal.cnn.analyzer.constraints.LSTM
    nnet.internal.cnn.analyzer.constraints.Names
    nnet.internal.cnn.analyzer.constraints.Propagation
    ];
end

function constraint = iCustomFunctionalConstraint()
constraint = ...
    nnet.internal.cnn.analyzer.constraints.customConstraints.Functional;
end
function constraint = iCustomFunctionalConnectionsConstraint()
constraint = ...
    nnet.internal.cnn.analyzer.constraints.customConstraints.FunctionalConnections;
end
