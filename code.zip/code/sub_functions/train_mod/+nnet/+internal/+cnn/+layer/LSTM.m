classdef LSTM < nnet.internal.cnn.layer.FunctionalStatefulLayer ...
        & nnet.internal.cnn.layer.Recurrent
    % LSTM   Implementation of the LSTM layer
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    properties
        % LearnableParameters   Learnable parameters for the layer
        % (Vector of nnet.internal.cnn.layer.learnable.PredictionLearnableParameter)
        LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
        
        % DynamicParameters   Dynamic parameters for the layer
        % (Vector of nnet.internal.cnn.layer.dynamic.TrainingDynamicParameter)
        DynamicParameters = nnet.internal.cnn.layer.dynamic.TrainingDynamicParameter.empty();
        
        % InitialCellState   Initial value of the cell state
        InitialCellState
        
        % Initial hidden state   Initial value of the hidden state
        InitialHiddenState

        % Name (char array)   A name for the layer
        Name
    end
    
    properties (Constant)
        % DefaultName   Default layer's name
        DefaultName = 'lstm'
    end
    
    properties (SetAccess = private)
        % InputNames   This layer has a single input
        InputNames = {'in'}
        
        % OutputNames   This layer has a single output
        OutputNames = {'out'}
        
        % InputSize (int) Size of the input vector
        InputSize
        
        % HiddenSize (int) Size of the hidden weights in the layer
        HiddenSize
        
        % ReturnSequence (logical) If true, output is a sequence. Otherwise
        % output is the last element in a sequence.
        ReturnSequence
        
        % RememberCellState (logical) If true, cell state is remembered
        RememberCellState
        
        % RememberHiddenState (logical) If true, hidden state is remembered
        RememberHiddenState
        
        % Activation   (char) Activation function
        Activation
        
        % RecurrentActivation   (char) Recurrent activation function
        RecurrentActivation
    end
    
    properties(Access = private)
        ExecutionStrategy
        
        ParamTableCreator = nnet.internal.cnn.layer.util.ParamTableCreator;       
    end
    
    properties (Dependent)
        % Learnable Parameters (nnet.internal.cnn.layer.LearnableParameter)
        InputWeights
        RecurrentWeights
        Bias
        % Dynamic Parameters (nnet.internal.cnn.layer.DynamicParameter)
        CellState
        HiddenState
        % Learnables    Cell array of learnable parameters
        Learnables
        % State    Table with cell and hidden states
        State
    end
    
    properties(SetAccess=protected, GetAccess=?nnet.internal.cnn.dlnetwork)
        LearnablesNames = ["InputWeights" "RecurrentWeights" "Bias"]
    end    
    
    properties(Constant)
        % StateNames    Names of state parameters
        StateNames = ["HiddenState"; "CellState"]
    end
    
    properties (Dependent, SetAccess = private)
        % HasSizeDetermined   Specifies if all size parameters are set
        %   If the input size has not been determined, then this will be
        %   set to false, otherwise it will be true
        HasSizeDetermined        
    end
    
    properties (Constant, Access = private)
        % InputWeightsIndex   Index of the Weights into the
        % LearnableParameters vector
        InputWeightsIndex = 1;
        
        % RecurentWeightsIndex   Index of the Recurrent Weights into the
        % LearnableParameters vector
        RecurrentWeightsIndex = 2;
        
        % BiasIndex   Index of the Bias into the LearnableParameters vector
        BiasIndex = 3;
        
        % CellStateIndex   Index of the cell state into the
        % DynamicParameters vector
        CellStateIndex = 1;
        
        % HiddenStateIndex   Index of the hidden state into the
        % DynamicParameters vector
        HiddenStateIndex = 2;
    end
    
    methods
        function this = LSTM(name, inputSize, hiddenSize, ...
                rememberCellState, rememberHiddenState, returnSequence, ...
                activation, recurrentActivation)
            % LSTM   Constructor for an LSTM layer
            %
            %   Create an LSTM layer with the following
            %   compulsory parameters:
            %
            %   name                - Name for the layer [char array]
            %   inputSize           - Size of the input vector [int]
            %   hiddenSize          - Size of the hidden units [int]
            %   rememberCellState   - Remember the cell state [logical]
            %   rememberHiddenState - Remember the hidden state [logical]
            %   returnSequence      - Output as a sequence [logical]
            %   activation          - Activation function 'tanh'/'softsign'
            %   recurrentActivation - Recurrent activation function 'sigmoid'/'hard-sigmoid'
           
            % Set layer name
            this.Name = name;
            
            % Set parameters
            this.InputSize = inputSize;
            this.HiddenSize = hiddenSize;
            this.RememberCellState = rememberCellState;
            this.RememberHiddenState = rememberHiddenState;
            this.ReturnSequence = returnSequence;
            this.Activation = activation;
            this.RecurrentActivation = recurrentActivation;
           
            % Set weights and bias to be LearnableParameter
            this.InputWeights = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter();
            this.RecurrentWeights = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter();
            this.Bias = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter();
            % Set default initializers. The external layer constructor
            % overwrites these values, which are set only for internal code
            % that bypasses the casual API.
            this.InputWeights.Initializer = iInternalInitializer('narrow-normal');
            this.RecurrentWeights.Initializer = iInternalInitializer('narrow-normal');
            this.Bias.Initializer = iInternalInitializer('zeros');
            
            % Set dynamic parameters
            this.CellState = nnet.internal.cnn.layer.dynamic.TrainingDynamicParameter();
            this.HiddenState = nnet.internal.cnn.layer.dynamic.TrainingDynamicParameter();
            
            % Initialize with host execution strategy
            this.ExecutionStrategy = this.getHostStrategy();
        end
        
        function [Z, memory] = forward( this, X )
            % forward   Forward input data through the layer at training
            % time and output the result
            [Z, memory] = this.ExecutionStrategy.forward( ...
                X, this.InputWeights.Value, this.RecurrentWeights.Value, ...
                this.Bias.Value, this.CellState.Value, this.HiddenState.Value);
            if hasFunctionalStrategy(this)
                memory = makeStateTable(this, memory.HiddenState, memory.CellState);
            end
        end
        
        function [Z, state] = predict( this, X )
            % predict   Forward input data through the layer at prediction
            % time and output the result
            if hasFunctionalStrategy(this) && nargout == 2
                [Z, state] = forward(this, X);
            else
                Z = forward(this, X);
            end
        end
        
        function [dX, dW] = backward( this, X, Z, dZ, memory, ~ )
            % backward    Back propagate the derivative of the loss function
            % through the layer
            args = { X, this.InputWeights.Value, this.RecurrentWeights.Value, ...
                this.Bias.Value, this.CellState.Value, this.HiddenState.Value, ...
                Z, memory, dZ };
            needsWeightGradients = nargout > 1;
            if ~needsWeightGradients
                dX = this.ExecutionStrategy.backward( args{:} );
            else
                [dX, dIW, dRW, dB] = this.ExecutionStrategy.backward( args{:} );
                dW{this.InputWeightsIndex} = dIW;
                dW{this.RecurrentWeightsIndex} = dRW;
                dW{this.BiasIndex} = dB;
            end
        end
        
        function this = inferSize(this, inputSize)
            if ~this.HasSizeDetermined
                this.InputSize = prod(inputSize);
            end
        end
        
        function outputSize = forwardPropagateSize(this, ~)
            outputSize = this.HiddenSize;
        end
        
        function tf = isValidInputSize(this, inputSize)
            % isValidInputSize   Check if the layer can accept an input of
            % a certain size
            scalar = isscalar(inputSize);
            if ~scalar && ~this.hasFunctionalStrategy()
                iThrowNonScalarInputSizeError(inputSize);
            end
            consistentWithInferredSize = true;
            if this.HasSizeDetermined
                consistentWithInferredSize = isequal(this.InputSize, prod(inputSize));
            end
            tf = consistentWithInferredSize;
        end
        
        function outputSeqLen = forwardPropagateSequenceLength(this, inputSeqLen, ~)
            % forwardPropagateSequenceLength   The sequence length of the
            % output of the layer given an input sequence length
            
            % The output sequence length of a recurrent layer depends on
            % the OutputMode (ReturnSequence) of the layer
            if this.ReturnSequence
                outputSeqLen = inputSeqLen;
            else
                outputSeqLen = { 1 };
            end
        end
        
        function this = initializeLearnableParameters(this, precision)
            % initializeLearnableParameters    Initialize learnable
            % parameters using their initializer
            
            if isempty(this.InputWeights.Value)
                % Initialize only if it is empty
                weightsSize = [4*this.HiddenSize, this.InputSize];
                weights = this.InputWeights.Initializer.initialize(...
                    weightsSize, 'InputWeights');
                this.InputWeights.Value = precision.cast(weights);
            else
                % Cast to desired precision
                this.InputWeights.Value = precision.cast(this.InputWeights.Value);
            end
            
            if isempty(this.RecurrentWeights.Value)
                % Initialize only if it is empty
                weightsSize = [4*this.HiddenSize, this.HiddenSize];
                weights = this.RecurrentWeights.Initializer.initialize(...
                    weightsSize, 'RecurrentWeights');
                this.RecurrentWeights.Value = precision.cast(weights);
            else
                % Cast to desired precision
                this.RecurrentWeights.Value = precision.cast(this.RecurrentWeights.Value);
            end
            
            if isempty(this.Bias.Value)
                % Initialize only if it is empty
                biasSize = [4*this.HiddenSize, 1];               
                bias = this.Bias.Initializer.initialize(biasSize, 'Bias');
                this.Bias.Value = precision.cast(bias);
            else
                % Cast to desired precision
                this.Bias.Value = precision.cast(this.Bias.Value);
            end
        end
        
        function this = initializeDynamicParameters(this, precision)
           % initializeDynamicParameters   Initialize dynamic parameters
           
           % Cell state
           if isempty(this.InitialCellState)
               parameterSize = [this.HiddenSize 1];
               this.InitialCellState = iInitializeConstant(parameterSize, precision);
           else
               this.InitialCellState = precision.cast(this.InitialCellState);
           end
           % Set the running cell state
           this.CellState.Value = this.InitialCellState;
           this.CellState.Remember = this.RememberCellState;
           
           % Hidden units
           if isempty(this.InitialHiddenState)
               parameterSize = [this.HiddenSize 1];
               this.InitialHiddenState = iInitializeConstant(parameterSize, precision);
           else
               this.InitialHiddenState = precision.cast(this.InitialHiddenState);
           end
           % Set the running hidden state
           this.HiddenState.Value = this.InitialHiddenState;
           this.HiddenState.Remember = this.RememberHiddenState;
        end
        
        function this = updateDynamicParameters(this, Z, memory)
            % updateDynamicParameters   Update the dynamic parameters of
            % the layer using "Z" and "memory" - the outputs of the forward
            % propagation method.
            
            % Update the cell state
            if this.DynamicParameters(this.CellStateIndex).Remember
                this.DynamicParameters(this.CellStateIndex).Value = memory.CellState(:, :, end);
            end
            
            % Update the hidden state
            if this.DynamicParameters(this.HiddenStateIndex).Remember 
                this.DynamicParameters(this.HiddenStateIndex).Value = Z(:, :, end);
            end
        end
        
        function state = computeState(this, ~, Z, memory, propagateState)
            % state{1} - store cell state
            % state{2} - store hidden state
            state = cell(2,1);
            if propagateState
                state{1} = memory.CellState(:, :, end);
                state{2} = Z(:, :, end);
            else
                state{1} = this.InitialCellState;
                state{2} = this.InitialHiddenState;
            end
        end
        
        function this = updateState(this, state)
            % Update the cell state
            if this.DynamicParameters(this.CellStateIndex).Remember
                this.DynamicParameters(this.CellStateIndex).Value = state{1};
            end
            
            % Update the hidden state
            if this.DynamicParameters(this.HiddenStateIndex).Remember
                this.DynamicParameters(this.HiddenStateIndex).Value = state{2};
            end
        end        
        
        function this = prepareForTraining(this)
            % prepareForTraining   Prepare this layer for training
            %   Before this layer can be used for training, we need to
            %   convert the learnable parameters to use the class
            %   TrainingLearnableParameter.
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2training(this.LearnableParameters);
        end
        
        function this = prepareForPrediction(this)
            % prepareForPrediction   Prepare this layer for prediction
            %   Before this layer can be used for prediction, we need to
            %   convert the learnable parameters to use the class
            %   PredictionLearnableParameter.
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2prediction(this.LearnableParameters);
        end
        
        function this = setupForHostPrediction(this)        
            this.ExecutionStrategy = this.getHostStrategy();
            this.LearnableParameters(1).UseGPU = false;
            this.LearnableParameters(2).UseGPU = false;
            this.LearnableParameters(3).UseGPU = false;
        end
        
        function this = setupForGPUPrediction(this)
            this.ExecutionStrategy = this.getGPUStrategy();
            this.LearnableParameters(1).UseGPU = true;
            this.LearnableParameters(2).UseGPU = true;
            this.LearnableParameters(3).UseGPU = true;
        end
        
        function this = setupForHostTraining(this)
            this.ExecutionStrategy = this.getHostStrategy();
        end
        
        function this = setupForGPUTraining(this)
            this.ExecutionStrategy = this.getGPUStrategy();
        end
        
        % Setter and getter for InputWeights, RecurrentWeights and Bias
        % These make easier to address into the vector of LearnableParameters
        % giving a name to each index of the vector
        function weights = get.InputWeights(this)
            weights = this.LearnableParameters(this.InputWeightsIndex);
        end
        
        function this = set.InputWeights(this, weights)
            this.LearnableParameters(this.InputWeightsIndex) = weights;
        end
        
        function weights = get.RecurrentWeights(this)
            weights = this.LearnableParameters(this.RecurrentWeightsIndex);
        end
        
        function this = set.RecurrentWeights(this, weights)
            this.LearnableParameters(this.RecurrentWeightsIndex) = weights;
        end
        
        function bias = get.Bias(this)
            bias = this.LearnableParameters(this.BiasIndex);
        end
        
        function this = set.Bias(this, bias)
            this.LearnableParameters(this.BiasIndex) = bias;
        end
        
        % Setter and getter for CellState and HiddenState
        function state = get.CellState(this)
            state = this.DynamicParameters(this.CellStateIndex);
        end
        
        function this = set.CellState(this, state)
            this.DynamicParameters(this.CellStateIndex) = state;
        end
        
        function state = get.HiddenState(this)
            state = this.DynamicParameters(this.HiddenStateIndex);
        end
        
        function this = set.HiddenState(this, state)
            this.DynamicParameters(this.HiddenStateIndex) = state;
        end
        
        % Getter for HasSizeDetermined
        function tf = get.HasSizeDetermined(this)
            tf = ~isempty( this.InputSize );
        end 
        
        function learnables = get.Learnables(this)
            % Assume setupForFunctional has been called
            inW = this.InputWeights.Value;
            recW = this.RecurrentWeights.Value;
            b = this.Bias.Value;
            learnables = {inW, recW, b};
        end
        
        function this = set.Learnables(this, learnables)
            % Assume setupForFunctional has been called
            hiddenSize = this.HiddenSize;
            nnet.internal.cnn.layer.paramvalidation.assertValidLearnables(learnables{1}, [4*hiddenSize, this.InputSize]);
            nnet.internal.cnn.layer.paramvalidation.assertValidLearnables(learnables{2}, [4*hiddenSize, hiddenSize]);
            nnet.internal.cnn.layer.paramvalidation.assertValidLearnables(learnables{3}, [4*hiddenSize, 1]);
            
            this.LearnableParameters(this.InputWeightsIndex).Value = learnables{1};
            this.LearnableParameters(this.RecurrentWeightsIndex).Value = learnables{2};
            this.LearnableParameters(this.BiasIndex).Value = learnables{3};
        end
        
        function t = get.State(this)
            t = makeStateTable(this, this.HiddenState.Value, this.CellState.Value);
        end
        
        function this = set.State(this, state)
            % Assume setupForFunctional has been called
            nnet.internal.cnn.layer.util.ParamTableCreator.assertTableContents(state, ...
                this.Name, this.StateNames);
            
            % We have already asserted that the table contains values in the order we
            % expect, so we can directly index them out.
            v = state.Value;
            hiddenState = v{1};
            cellState = v{2};
            
            expectedClass = {'single'};
            expectedAttributes = {'size', [this.HiddenSize NaN]};
            validateattributes(cellState, expectedClass, expectedAttributes);
            validateattributes(hiddenState, expectedClass, expectedAttributes);
            
            this.CellState.Value = cellState;
            this.HiddenState.Value = hiddenState;
        end
    end
    
    methods(Access = private)
        function executionStrategy = getHostStrategy(this)
            if ~this.hasDefaultActivations()
                executionStrategy = nnet.internal.cnn.layer.util.LSTMGeneralStrategy( ...
                    this.Activation, ...
                    this.RecurrentActivation, ...
                    this.ReturnSequence );
            elseif this.ReturnSequence
                executionStrategy = nnet.internal.cnn.layer.util.LSTMHostStrategy();
            else
                executionStrategy = nnet.internal.cnn.layer.util.LSTMHostReturnLastStrategy();
            end
        end
        
        function executionStrategy = getGPUStrategy(this)
            if ~this.hasDefaultActivations()
                executionStrategy = nnet.internal.cnn.layer.util.LSTMGeneralStrategy( ...
                    this.Activation, ...
                    this.RecurrentActivation, ...
                    this.ReturnSequence );
            elseif this.ReturnSequence
                executionStrategy = nnet.internal.cnn.layer.util.LSTMGPUStrategy();
            else
                executionStrategy = nnet.internal.cnn.layer.util.LSTMGPUReturnLastStrategy();
            end
        end
        
        function tf = hasDefaultActivations(this)
            tf = ismember( this.Activation, {'tanh'} ) && ismember( this.RecurrentActivation, {'sigmoid'} );
        end
        
        function tf = hasFunctionalStrategy(this)
            tf = isa(this.ExecutionStrategy, ...
                    'nnet.internal.cnn.layer.util.LSTMFunctionalStrategy');
        end
        
        function tbl = makeStateTable(this, hiddenstate, cellstate)
            persistent protoTable
            if isempty(protoTable)
                protoTable = create(this.ParamTableCreator, ...
                "", this.StateNames, ...
                {[]; []});
            end
            
            % Assume setupForFunctional has been called
            tbl = protoTable;
            lname = string(this.Name);
            tbl.Layer = [lname; lname];
            tbl.Value = {hiddenstate; cellstate};
        end
    end
    
    methods(Access=protected)
        function this = setFunctionalStrategy(this)
            if ~this.hasDefaultActivations()
                error(message(...
                    'nnet_cnn:internal:cnn:layer:LSTM:NonDefaultActivFunctional'))
            end
            if this.ReturnSequence
                this.ExecutionStrategy = ...
                    nnet.internal.cnn.layer.util.LSTMFunctionalStrategy;
            else
                this.ExecutionStrategy = ...
                    nnet.internal.cnn.layer.util.LSTMFunctionalReturnLastStrategy;
            end
        end

        function this = initializeStates(this)
            % initializeStates    Zero as init value if empty
            precision = nnet.internal.cnn.util.Precision('single');
            this = initializeDynamicParameters(this, precision);
        end        
    end    
end

function parameter = iInitializeConstant(parameterSize, precision)
parameter = precision.cast( ...
    zeros(parameterSize) );
end

function initializer = iInternalInitializer(name)
initializer = nnet.internal.cnn.layer.learnable.initializer...
    .initializerFactory(name);
end

function iThrowNonScalarInputSizeError(inputSize)
error( message('nnet_cnn:internal:cnn:layer:LSTM:NonScalarInputSize', ...
    iSizeToString(inputSize)) );
end

function str = iSizeToString(sz)
str = join(string(sz), matlab.internal.display.getDimensionSpecifier);
end