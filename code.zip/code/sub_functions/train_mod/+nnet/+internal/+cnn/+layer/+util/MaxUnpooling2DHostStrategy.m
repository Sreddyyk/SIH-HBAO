classdef MaxUnpooling2DHostStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % MaxUnpooling2DHostStrategy   Execution strategy for running the max unpooling on the host
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, inputsX)
            % Unpack inputs
            X          = inputsX{1};
            indices    = inputsX{2};
            outputSize = inputsX{3};
            
            % Allocate output
            Z = zeros(outputSize, 'like', X);
            
            % Unpool
            Z(indices) = X(1:numel(X));
            
            % Assign empty memory
            memory = [];
        end
        
        function [dXOut, dW] = backward(~, inputsX, dZ)
            % Unpack inputs
            X       = inputsX{1};
            indices = inputsX{2};
            
            % Allocate output
            dX = zeros(size(X), 'like', dZ);
            
            % Assign pooled values into derivative
            dX(1:numel(X)) = dZ(indices);
            
            % Return empty for non-differentiable outputs
            dXOut = {dX, [], []};
            
            % Return empty dW since there are no learnable parameters
            dW = [];
        end
    end
end