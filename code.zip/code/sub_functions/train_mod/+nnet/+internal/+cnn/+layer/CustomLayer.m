classdef CustomLayer < nnet.internal.cnn.layer.FunctionalLayer
    % CustomLayer    Internal custom convolutional neural network layer
    
    %   Copyright 2017-2019 The MathWorks, Inc.

    properties (Dependent)
        % Name (char array)
        Name
        
        % LearnableParameters   Learnable parameters for the layer
        % (Vector of nnet.internal.cnn.layer.LearnableParameter)
        LearnableParameters
        
        % Learnables    Cell array with learnable parameters values
        Learnables
    end
    
    properties (Constant)
        % DefaultName   Default layer's name. This will be assigned in case
        % the user leaves an empty name.
        DefaultName = 'layer';
    end
    
    properties(Access = private)
        % LearnableParameters   Private storage for LearnableParameters
        PrivateLearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
    end
    
    properties (Access = private, Dependent)
        % NumParameters   Number of learnable parameters
        NumParameters
    end
    
    properties (SetAccess = private, Dependent)
        % InputNames (cellstr)  Names of the inputs to the layer
        InputNames
        
        % OutputNames (cellstr)   Names of the outputs from the layer
        OutputNames
        
        % NumInputs (double)   Number of inputs to the layer
        NumInputs
        
        % NumOutputs (double)   Number of outputs from the layer
        NumOutputs
    end
    
    properties (SetAccess = private)
        % HasSizeDetermined   Always true for custom layers
        HasSizeDetermined = true;
        
        % ExternalCustomLayer (nnet.layer.Layer)   The
        % corresponding external custom layer
        ExternalCustomLayer
        
        % LayerVerifier
        % (nnet.internal.cnn.layer.util.CustomLayerVerifier)
        LayerVerifier
        
        % Execution strategy   Execution strategy of the layer
        %   The execution strategy determines how forward and backward
        %   operations are performed.
        ExecutionStrategy
        
        % LearnablesSizes    Sizes of Learnables
        LearnablesSizes
        
        % IsFunctional   True if the layer is using a functional strategy
        IsFunctional = false;
    end
    
    properties (Hidden, SetAccess = private)
        % ReturnSequence   True for recurrent layers which return sequence
        ReturnSequence
        
        % DynamicParameters   Dynamic parameters for the layer
        % (Vector of nnet.internal.cnn.layer.dynamic.TrainingDynamicParameter)
        DynamicParameters = nnet.internal.cnn.layer.dynamic.TrainingDynamicParameter.empty();
    end
    
    properties (SetAccess=protected, GetAccess=?nnet.internal.cnn.dlnetwork)
        % LearnablesNames   String array of the names of the Learnables
        LearnablesNames
    end    
    
    methods
        function this = CustomLayer( anExternalCustomLayer, aLayerVerifier )
            this.ExternalCustomLayer = anExternalCustomLayer;
            [parametersNames, parameters] = iDiscoverLearnableParameters( anExternalCustomLayer );
            this.LearnablesNames = parametersNames;
            this.LearnableParameters = parameters;
            this = updateLearnablesSizes(this);
            aLayerVerifier.LayerClass = class( anExternalCustomLayer );
            aLayerVerifier.LearnableParametersNames = iStringToCellstr(...
                parametersNames);
            this.LayerVerifier = aLayerVerifier;
            this.ReturnSequence = iDetermineReturnSequence( anExternalCustomLayer );
            this.NeedsXForBackward = iIsXUsedInBackward( anExternalCustomLayer );
            this.NeedsZForBackward = iIsZUsedInBackward( anExternalCustomLayer );
            this.ExecutionStrategy = this.getLayerStrategy();
        end
        
        function Z = predict( this, X )
            % predict   Forward input data through the external custom layer
            % and output the result
            Z = this.ExecutionStrategy.predict( this.ExternalCustomLayer, X );
        end
        
        function [Z, memory] = forward( this, X )
            % forward   Forward input data through the external custom layer
            % and output the result
            [Z, memory] = this.ExecutionStrategy.forward( this.ExternalCustomLayer, X );
        end
        
        function varargout = backward( this, varargin )
            % backward   Back propagate the derivative of the loss function
            % through the external custom layer
            [varargout{1:nargout}] = this.ExecutionStrategy.backward( ...
                this.ExternalCustomLayer, varargin{:} );
        end
        
        function outputSize = forwardPropagateSize(this, inputSize)
            % forwardPropagateSize   The size of the output from the layer
            % for a given size of input
            
            % Initialize learnable parameters since 'forward' will use them
            precision = nnet.internal.cnn.util.Precision('single');
            this = this.initializeLearnableParameters(precision);
            
            % We then need to setup for host prediction. This is because if
            % the weights were already initialized, then they could be GPU
            % values
            this = this.prepareForPrediction();
            this = this.setupForHostPrediction();
                
            % Compute the output size by forwarding a two-observation
            % tensor through the layer and determining the output size
            % without the observation dimension. This is more robust in the
            % the case of trailing singleton dimension in the
            % one-observation scenario.
            fakeData = iNObsInputData( inputSize, 2, this.IsFunctional );
            output = this.predict( fakeData );
            outputSize = iGetFixedDimSizes( output );
        end
        
        function this = inferSize(this, ~)
            % We cannot infer the size of a custom layer so this is a no-op
        end
        
        function tf = isValidInputSize(this, inputSize)
            % isValidInputSize   Validate inputSize by generating fake
            % data and trying to propagate it through the layer and back
            
            % Initialize learnable parameters since 'forward' will use them
            precision = nnet.internal.cnn.util.Precision('single');
            this = this.initializeLearnableParameters(precision);
            
            % We then need to setup for host prediction. This is because if
            % the weights were already initialized, then they could be GPU
            % values
            this = this.prepareForPrediction();
            this = this.setupForHostPrediction();
            
            tf = true;
            fakeData = iNObsInputData( inputSize, 1, this.IsFunctional );
            try
                % Test predict/forward/backward methods don't error
                [Z, memory] = this.forward( fakeData );
                dLdZ = iNObsInputData( iGetSizes(Z), 1, this.IsFunctional );
                
                if ~this.IsFunctional
                    % Must request the outputs or dLdW won't be computed
                    [~, ~] = this.backward( fakeData, Z, dLdZ, memory );
                end
                
                Zpred = this.predict( fakeData ); %#ok<NASGU>
            catch cause
                rethrow( cause );
            end
        end
        
        function outputSeqLen = forwardPropagateSequenceLength(this, inputSeqLen, inputSize)
            % forwardPropagateSequenceLength   The sequence length of the
            % output of the layer given an input sequence length
            
            if iHasSequenceLengthOne(inputSeqLen)
                % If the input is one, we can assume the output is one
                outputSeqLen = repmat( {1}, this.NumOutputs, 1 );
                
            elseif iIsReturnSequenceDefined(this.ExternalCustomLayer)
                % If we have a custom recurrent layer we can query the
                % ReturnSequence property
                if this.ReturnSequence
                    outputSeqLen = inputSeqLen;
                else
                    outputSeqLen = { 1 };
                end
                
            else
                % Otherwise, we must call the forward method to determine
                % whether the layer can process sequences
                outputSeqLen = this.determineOutputSeqLen(inputSeqLen, inputSize);
                
            end
        end
        
        function this = initializeLearnableParameters(this, precision)
            % initializeLearnableParameters   Cast the learnable parameters
            % using the appropriate precision
            for ii=1:this.NumParameters
                % Cast the external learnable parmaeters
                this.ExternalCustomLayer.(this.LearnablesNames{ii}) = precision.cast( ...
                    this.ExternalCustomLayer.(this.LearnablesNames{ii}) );
                % Update the internal values
                this.LearnableParameters(ii).Value = this.ExternalCustomLayer.(this.LearnablesNames{ii});
                if this.IsFunctional
                    this.LearnableParameters(ii).Value = dlarray(this.LearnableParameters(ii).Value);
                end
            end
        end
        
        function state = computeState( this, X, Z, memory, propagate )
            % computeState   Compute candidate new state for recurrent
            % layer
            try
                [X,Z] = iWrapInCell(X,Z);
                state = computeState( this.ExternalCustomLayer, X{:}, Z{:}, memory, propagate );
            catch cause
                iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomLayer:ComputeStateErrored', class(this.ExternalCustomLayer))
            end
        end
        
        function this = updateState( this, state )
            % updateState   Update the state variables of a recurrent layer
            try
                this.ExternalCustomLayer = updateState( this.ExternalCustomLayer, state );
            catch cause
                iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomLayer:UpdateStateErrored', class(this.ExternalCustomLayer))
            end
        end
        
        function this = prepareForTraining(this)
            % prepareForTraining   Prepare this layer for training
            %   Before this layer can be used for training, we need to
            %   convert the learnable parameters to use the class
            %   TrainingLearnableParameter.
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2training(this.LearnableParameters);
        end
        
        function this = prepareForPrediction(this)
            % prepareForPrediction   Prepare this layer for prediction
            %   Before this layer can be used for prediction, we need to
            %   convert the learnable parameters to use the class
            %   PredictionLearnableParameter.
            
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2prediction(this.LearnableParameters);
        end
        
        function this = setupForHostPrediction(this)
            for ii = 1:this.NumParameters
                this.LearnableParameters(ii).UseGPU = false;
            end
        end
        
        function this = setupForGPUPrediction(this)
            for ii = 1:this.NumParameters
                this.LearnableParameters(ii).UseGPU = true;
            end
        end
        
        function this = setupForHostTraining(this)
            % no-op
        end
        
        function this = setupForGPUTraining(this)
            % no-op
        end
        
        function name = get.Name(this)
            name = this.ExternalCustomLayer.Name;
        end
        
        function this = set.Name(this, aName)
            this.ExternalCustomLayer.Name = aName;
        end
        
        function name = get.InputNames(this)
            name = this.ExternalCustomLayer.InputNames;
        end
        
        function name = get.OutputNames(this)
            name = this.ExternalCustomLayer.OutputNames;
        end
        
        function name = get.NumInputs(this)
            name = this.ExternalCustomLayer.NumInputs;
        end
        
        function name = get.NumOutputs(this)
            name = this.ExternalCustomLayer.NumOutputs;
        end
        
        function learnableParameters = get.LearnableParameters(this)
            learnableParameters = this.PrivateLearnableParameters;
        end
        
        function this = set.LearnableParameters(this, learnableParameters)
            
            % Update internal learnable parameters
            this.PrivateLearnableParameters = learnableParameters;
            
            % Update external learnable parameters
            externalLayer = this.ExternalCustomLayer;
            names = this.LearnablesNames;
            for ii=1:this.NumParameters
                externalLayer.(names{ii}) = learnableParameters(ii).Value;
            end
            this.ExternalCustomLayer = externalLayer;
        end
        
        function numParameters = get.NumParameters( this )
            numParameters = numel( this.LearnablesNames );
        end
        
        function learnables = get.Learnables(this)
            % Assume setupForFunctional has been called
            learnables = cell(1,this.NumParameters);
            for ii=1:this.NumParameters
                p = this.LearnableParameters(ii).Value;
                learnables{ii} = p;
            end
        end
        
        function this = set.Learnables(this, learnables)
            % Assume setupForFunctional has been called
            
            learnableParameters = this.LearnableParameters;
            expSizes = this.LearnablesSizes;
            for ii=1:this.NumParameters
                nnet.internal.cnn.layer.paramvalidation.assertValidLearnables(learnables{ii}, expSizes{ii});
                learnableParameters(ii).Value = learnables{ii};
            end
            this.LearnableParameters = learnableParameters;
        end
    end
    
    methods
        % setupForFunctional   Prepare this layer for functional (dlarray)
        % strategy
        function this = setupForFunctional(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2training(this.LearnableParameters);
            this = setFunctionalStrategy(this);
            learnableParameters = this.LearnableParameters;
            for i=1:numel(this.LearnableParameters)                
                learnableParameters(i).Value = ...
                    single( dlarray( learnableParameters(i).Value ) );
            end
            this.LearnableParameters = learnableParameters;
            this.IsFunctional = true;
        end

        % revertSetupForFunctional   Revert strategy to Host, and
        % Learnables to numeric.
        function this = revertSetupForFunctional(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2prediction(this.LearnableParameters);
            this = setupForHostPrediction(this);            
            this.ExecutionStrategy = this.getLayerStrategy();
            
            learnableParameters = this.LearnableParameters;
            for i=1:numel(this.LearnableParameters)                
                learnableParameters(i).Value = ...
                    extractdata( learnableParameters(i).Value );
            end
            this.LearnableParameters = learnableParameters;
            this.IsFunctional = false;
        end
    end   
    
    methods (Access = private)
        function outputSeqLen = determineOutputSeqLen(this, inputSeqLen, inputSize)
            % determineOutputSeqLen   Determine if the layer can propagate
            % a sequence by forward sequence data through the forward
            % method
            
            % Initialize learnable parameters since 'forward' will use them
            precision = nnet.internal.cnn.util.Precision('single');
            this = this.initializeLearnableParameters(precision);
            
            % We then need to setup for host prediction. This is because if
            % the weights were already initialized, then they could be GPU
            % values
            this = this.prepareForPrediction();
            this = this.setupForHostPrediction();
            
            % Compute the output sequence length by forwarding a tensor
            % with two observations and three time steps through the layer.
            % two-observation, sequence length three tensor through the
            % layer
            fakeX = iInputDataWithSeqLen( inputSize, inputSeqLen );
            try
                % Test predict
                predZ = this.predict( fakeX );
                predZ = iWrapInCell(predZ);
                
                % Test forward
                [fakeZ, memory] = this.forward( fakeX );
                fakeZ = iWrapInCell(fakeZ);
                
                % Test backward
                fakeDZ = fakeZ;
                fakeDX = this.backward( fakeX, fakeZ, fakeDZ, memory );
                fakeDX = iWrapInCell(fakeDX);
                
                % Get output size
                outputSize = iGetOutputSize( fakeZ, inputSize );
                slP = iGetSeqLen( predZ, outputSize );
                slZ = iGetSeqLen( fakeZ, outputSize );
                slDX = iGetSeqLen( fakeDX, inputSize );
                
                % Gather sequence lengths
                seqLen = [ slP; slZ; slDX ];
                seqLen = iValidateSeqLen( seqLen );
                outputSeqLen = seqLen(1:this.NumOutputs);
                outputSeqLen = outputSeqLen(:);
            catch cause
                iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomLayer:InvalidSeqLen', class(this.ExternalCustomLayer))
            end
        end
        
        function strategy = getLayerStrategy(this)
            isForwardDefined = iIsForwardDefined( this.ExternalCustomLayer );
            learnableParameterNames = iStringToCellstr(this.LearnablesNames);
            if iIsBackwardDefined(this.ExternalCustomLayer)
                strategy = nnet.internal.cnn.layer.util.CustomLayerLegacyStrategy(...
                    this.LayerVerifier, learnableParameterNames, isForwardDefined );
            else
                strategy = nnet.internal.cnn.layer.util.CustomLayerAutodiffStrategy(...
                    this.LayerVerifier, learnableParameterNames, isForwardDefined );
            end
        end
        
        function this = updateLearnablesSizes(this)
            this.LearnablesSizes = cell(1,this.NumParameters);
            for ii=1:this.NumParameters
                this.LearnablesSizes{ii} = size(this.LearnableParameters(ii).Value);
            end            
        end
    end
    
    methods(Access=protected)
        function this = setFunctionalStrategy(this)
            if iIsBackwardDefined(this.ExternalCustomLayer)
                this.ExecutionStrategy = ...
                    nnet.internal.cnn.layer.util.CustomLayerCustomBackwardFunctionalStrategy(...
                    this.ExternalCustomLayer, ...
                    iStringToCellstr(this.LearnablesNames), ...
                    this.LayerVerifier );
            else
                this.ExecutionStrategy = ...
                    nnet.internal.cnn.layer.util.CustomLayerFunctionalStrategy(...
                    this.LayerVerifier, ...
                    iIsForwardDefined( this.ExternalCustomLayer ) );
            end
        end
    end
end

function [names, parameters] = iDiscoverLearnableParameters( externalLayer )
% iDiscoverLearnableParameters   Discover learnable parameters
% declared by the user and add them to the internal learnable
% parameters and track them with a learnable parameters list

names = string.empty();
parameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();

propertyList = iPropertyList(externalLayer);
for ii=1:numel(propertyList)
    if isprop(propertyList(ii), 'Learnable') && propertyList(ii).Learnable
        name = propertyList(ii).Name;
        
        % Store the parameter name
        names(end+1) = string(name); %#ok<AGROW>
        
        % Create and store matching learnable parameter
        initialValue = externalLayer.(name);
        learnRateFactor = getLearnRateFactor( externalLayer, name );
        l2Factor = getL2Factor( externalLayer, name );
        parameter = iNewPredictionLearnableParameter( initialValue, learnRateFactor, l2Factor );
        parameters(end+1) = parameter; %#ok<AGROW>
    end
end
end

function learnableParameter = iNewPredictionLearnableParameter( value, learnRateFactor, l2Factor )
learnableParameter = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter;
learnableParameter.Value = value;
learnableParameter.LearnRateFactor = learnRateFactor;
learnableParameter.L2Factor = l2Factor;
end

function propertyList = iPropertyList( layer )
metaLayer = metaclass(layer);
propertyList = metaLayer.PropertyList.findobj( ...
    'GetAccess', 'public', 'SetAccess', 'public');
end

function data = iNObsInputData( inputSizes, numObs, isFunctional )
inputSizes = iWrapInCell(inputSizes);
numInputs = numel(inputSizes);
data = cell(1,numInputs);
for i = 1:numInputs
    data{i} = iArbitrarySingleData([inputSizes{i} numObs]);
end

if isFunctional
    for j = 1:numInputs
        data{j} = dlarray(data{j});
    end
end

if numInputs == 1
    data = data{:};
end
end

function data = iInputDataWithSeqLen( inputSizes, seqLengths )
% Generate a sequence tensor based on the input sizes and sequence lengths
numObs = 2;
if iscell(inputSizes)
    % Multi-input case
    numInputs = numel(inputSizes);
    data = cell(1,numInputs);
    for i = 1:numInputs
        sl = iAssignSeqLen( seqLengths{i} );
        data{i} = iArbitrarySingleData([inputSizes{i} numObs sl]);
    end
else
    % Single input case
    sl = iAssignSeqLen( seqLengths{1} );
    data = iArbitrarySingleData([inputSizes numObs sl]);
end
end

function data = iArbitrarySingleData(sz)
if isscalar(sz)
    sz = [sz 1];
end
data = ones(sz,'single');
end

function tf = iHasSequenceLengthOne( seqLen )
tf = all( cellfun(@(s) isequal(s,1), seqLen) );
end

function assignedSeqLen = iAssignSeqLen( inputSeqLen )
if ~isnumeric(inputSeqLen)
    % If the inputSeqLen passed to forwardPropagateSequenceLength is not
    % numeric, we assume it is the arbitrary sequence token defined in
    % nnet.internal.cnn.util.arbitrarySequenceLengthToken(). For custom
    % layers, we will assign a numeric value of 3 to represent the
    % tokenized value
    assignedSeqLen = iNumericSeqLen();
else
    % Otherwise, we assign the numeric quantity passed to
    % forwardPropagateSequenceLength
    assignedSeqLen = inputSeqLen;
end 
end

function seqLen = iValidateSeqLen( outputSeqLen )
seqLen = cellfun(@iNumericSeqLenToToken, outputSeqLen, 'UniformOutput', false);
end

function seqLen = iNumericSeqLenToToken( seqLen )
% The forward method must not have shrunk the sequence dimension of the
% data, so we assert that the seqLen is equal to the numeric sequence
% length that we specified with creating input data
assert( seqLen == iNumericSeqLen() )

% Provided we meet the above assert, we can map the sequence length back to
% the arbitrary token
seqLen = iArbitrarySeqLen();
end

function seq = iArbitrarySeqLen()
% Token to describe an arbitrary sequence length
seq = nnet.internal.cnn.util.arbitrarySequenceLengthToken();
end

function seq = iNumericSeqLen()
% Numeric sequence length > 1 to propagate through layer
seq = 3;
end

function outputSizes = iGetFixedDimSizes( twoObsOutputs )
% Wrap in cell for easier processing
twoObsOutputs = iWrapInCell(twoObsOutputs);
numOutputs = numel(twoObsOutputs);
outputSizes = cell(1,numOutputs);
for i = 1:numOutputs
    dims = ndims(twoObsOutputs{1});
    outputSizes{i} = iNDSize( twoObsOutputs{i}, dims-1 );
end
% Unwrap if cell only has one entry
if numOutputs==1
    outputSizes = outputSizes{1};
end
end

function sz = iNDSize(x,n)
[sz{1:max(n,ndims(x))}] = size(x);
sz = [sz{1:n}];
end

function outputSize = iGetOutputSize(data, inputSizes)
% Assume outputSize has same number of dimensions as inputSize
outputSize = cell(numel(data), 1);
for ii = 1:numel(data)
    outputSize{ii} = iNDSize(data{ii}, numel(inputSizes{ii}));
end
end

function seqLen = iGetSeqLen(data, inputSizes)
inputSizes = iWrapInCell(inputSizes);
data = iWrapInCell(data);
numInputs = numel(inputSizes);
seqLen = cell(numInputs,1);
for i = 1:numInputs
    seqDim = numel(inputSizes{i}) + 2;
    seqLen{i} = size(data{i}, seqDim);
end
end

function sz = iGetSizes(data)
data = iWrapInCell(data);

    function sz = iGetSize(x)
        try
            x = stripdims(x);
        catch
        end
        sz = size(x);
    end

sz = cellfun( @iGetSize, data, 'UniformOutput', false);
end

function tf = iIsReturnSequenceDefined( externalLayer )
tf = isprop(externalLayer,'ReturnSequence') ...
    && islogical(externalLayer.ReturnSequence) ...
    && isscalar(externalLayer.ReturnSequence) ...
    && ~isempty(externalLayer.ReturnSequence);
end

function returnSequence = iDetermineReturnSequence( externalLayer )
returnSequence = true;
if iIsReturnSequenceDefined( externalLayer )
    returnSequence = externalLayer.ReturnSequence;
end
end

function iThrowWithCause( cause, errorID, varargin )
exception = MException( message( errorID, varargin{:} ) );
exception = exception.addCause( cause );
throwAsCaller( exception );
end

function varargout = iWrapInCell(varargin)
% Wraps each input argument into a cell.
% [cell1, cell2,  ..., cellN] = iWrapInCell( data1, data2, ..., dataN)
% combinedCell = iWrapInCell( data1, data2, data3, ...)
celldata = cell(1,nargin);
for i = 1:nargin
    if ~iscell(varargin{i})
        % Wrap non-cell data into a cell
        celldata{i} = varargin(i);
    else
        % Reshape cell array input to a row vector
        celldata{i} = reshape(varargin{i},1,[]);
    end
end
if nargout == 1
    % If a single output is requested, concatenate all cell outputs into
    % one cell array row vector
    varargout{1} = [ celldata{:} ];
else
    % If multiple outputs are requested, return each wrapped cell separately
    varargout(1:nargout) = celldata(1:nargout);
end
end

function tf = iIsXUsedInBackward( externalLayer )
% Determine if input X of the forward method needs to be preserved to
% compute backward. This information is only needed for training.
if iIsBackwardDefined(externalLayer)
    inputArgs = iGetInputArgsBackward( externalLayer );
    xIndices = 2 : externalLayer.NumInputs+1;
    if any(xIndices>numel(inputArgs))
        % The input argument list is shortened (probably because varargin is
        % used). We need to assume that X is needed for backward.
        tf = true;
    else
        xArgs = inputArgs(xIndices);
        % For layers with multiple inputs, all inputs used for forward propagation
        % (X1,...,XN) must be unused (i.e. replaced by the argument placeholder (~))
        % in the backward method to enable the memory optimization.
        tf = ~all( ismember(xArgs,'~') );
    end
else
    tf = false;
end
end

function tf = iIsZUsedInBackward( externalLayer )
% Determine if output Z of the forward method needs to be preserved to
% compute backward. This information is only needed for training.
if iIsBackwardDefined(externalLayer)
    inputArgs = iGetInputArgsBackward( externalLayer );
    zIndices = externalLayer.NumInputs+2 : externalLayer.NumInputs+externalLayer.NumOutputs+1;
    if any(zIndices>numel(inputArgs))
        % The input argument list is shortened (probably because varargin is
        % used). We need to assume that Z is needed for backward.
        tf = true;
    else
        zArgs = inputArgs(zIndices);
        % For layers with multiple outputs, all outputs used for forward propagation
        % (Z1,...,ZM) must be unused (i.e. replaced by the argument placeholder (~))
        % in the backward method to enable the memory optimization.
        tf = ~all( ismember(zArgs,'~') );
    end
else
    tf = false;
end
end

function tf = iIsBackwardDefined( externalLayer )
% Return true if backward was overridden in the external custom layer
tf = nnet.internal.cnn.layer.util.isMethodDefined(externalLayer, 'backward');
end

function tf = iIsForwardDefined( externalLayer )
% Return true if forward was overridden in the external custom layer
tf = nnet.internal.cnn.layer.util.isMethodDefined(externalLayer, 'forward');
end

function inputArgs = iGetInputArgsBackward( externalLayer )
m = metaclass( externalLayer );
methodList = m.MethodList;
idx = ismember({methodList.Name},'backward');
backward = methodList(idx);
inputArgs = backward.InputNames;
end

function learnableParameterNames = iStringToCellstr(learnablesNames)
learnableParameterNames = cellstr(learnablesNames);
end
