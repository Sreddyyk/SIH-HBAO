classdef TransposedConvolution3DHostStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % TransposedConvolution3DHostStrategy
    %     Execution strategy for running transposed convolution on the host
    
    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X, ...
                weights, bias, ...
                TLFPad, BRBPad, ...
                stride, outputSizeOffset)
            
            sz = nnet.internal.cnn.layer.TransposedConvolution3D.outputSize(...
                X, weights, ...
                TLFPad, BRBPad, ...
                stride, outputSizeOffset);
            
            imageHeight = sz(1);
            imageWidth  = sz(2);
            imageDepth = sz(3);

            Z = nnet.internal.cnnhost.convolveBackwardData3DCore(...
                [imageHeight, imageWidth, imageDepth], weights, X, ...
                TLFPad, BRBPad, stride);
  
            % add bias
            Z = Z + bias;
            
            memory = [];
        end
        
        function [dX, dW] = backward( ~, ...
                X, weights, dZ, ...
                TLFPad, BRBPad, stride)
            needsWeightGradients = nargout > 1;
            
                dX = nnet.internal.cnnhost.stridedConv3D( ...
                    dZ, weights, ...
                    TLFPad, BRBPad, stride);
                
                if needsWeightGradients
                    dW{1} = nnet.internal.cnnhost.convolveBackwardFilter3D( ...
                        dZ, weights, X, ...
                        TLFPad, BRBPad, stride);
                    dW{2} = nnet.internal.cnnhost.convolveBackwardBias3D(dZ);
                end
        end
        
    end
    
end
