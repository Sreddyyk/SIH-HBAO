classdef BiLSTMGeneralStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % BiLSTMGeneralStrategy   Execution strategy for running BiLSTM with a
    % general set of options. This strategy is used for both host and GPU
    % implementations.
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties
        % Options   Struct containing five fields:
        %           - Activation
        %           - dActivation
        %           - RecurrentActivation
        %           - dRecurrentActivation
        %           - ReturnLast
        Options
    end
    
    methods
        function this = BiLSTMGeneralStrategy(activation, recurrentActivation, returnSequence)
            % Determine activation structs
            activationStruct = iGetActivation( activation );
            recurrentActivationStruct = iGetRecurrentActivation( recurrentActivation );
            
            % Gather options struct
            options.Activation = activationStruct.Fcn;
            options.dActivation = activationStruct.dFcn;
            options.RecurrentActivation = recurrentActivationStruct.Fcn;
            options.dRecurrentActivation = recurrentActivationStruct.dFcn;
            options.ReturnLast = ~returnSequence;
            this.Options = options;
        end
        
        function [Y, memory] = forward(this, X, W, R, b, c0, y0)
            % Split data into forward/backward sequences
            [Wf, Rf, bf, Wb, Rb, bb] = iSplitWeights(W, R, b);
            [c0f, y0f, c0b, y0b] = iSplitStates(c0, y0);
            
            % Forward sequence
            [learnablef, statef] = iArray2Struct(Wf, Rf, bf, y0f, c0f, [], [], [], []);
            [Yf, Hf, Cf] = nnet.internal.cnnhost.lstmForwardGeneral(X, learnablef, statef, this.Options);
            
            % Backward sequence
            [learnableb, stateb] = iArray2Struct(Wb, Rb, bb, y0b, c0b, [], [], [], []);
            [Yb, Hb, Cb] = nnet.internal.cnnhost.lstmForwardGeneral(flip(X, 3), learnableb, stateb, this.Options);
            
            % Concatenate outputs
            Y = cat(1, Yf, flip(Yb, 3));
            H = cat(1, Hf, Hb);
            C = cat(1, Cf, Cb);
            
            % Allocate memory
            memory.HiddenState = H;
            memory.CellState = C;
        end
        
        function [dX, dW, dR, dB] = backward(this, X, W, R, b, c0, y0, Y, memory, dY)
            % Split data into forward/backward sequences
            [Wf, Rf, bf, Wb, Rb, bb] = iSplitWeights(W, R, b);
            [c0f, y0f, c0b, y0b] = iSplitStates(c0, y0);
            H = memory.HiddenState;
            C = memory.CellState;
            [Yf, Hf, Cf, dYf, Yb, Hb, Cb, dYb] = iSplitForwardOutputs(Y, H, C, dY);
            
            % Forward sequence
            [learnablef, statef, outputsf, derivativesf] = iArray2Struct(Wf, Rf, bf, y0f, c0f, Yf, Hf, Cf, dYf);
            [dXf, dWeightsf{1:(nargout-1)}] =  nnet.internal.cnnhost.lstmBackwardGeneral(X, learnablef, statef, outputsf, derivativesf, this.Options);
            
            % Backward sequence
            [learnableb, stateb, outputsb, derivativesb] = iArray2Struct(Wb, Rb, bb, y0b, c0b, flip(Yb, 3), Hb, Cb, flip(dYb, 3));
            [dXb, dWeightsb{1:(nargout-1)}] = nnet.internal.cnnhost.lstmBackwardGeneral(flip(X, 3), learnableb, stateb, outputsb, derivativesb, this.Options);
            
            % Concatenate outputs
            dX = dXf + flip(dXb, 3);
            needsWeightGradients = nargout > 1;
            if needsWeightGradients
                % Concatenate weights derivatives
                [dWf, dRf, dBf] = deal( dWeightsf{:} );
                [dWb, dRb, dBb] = deal( dWeightsb{:} );
                dW = cat(1, dWf, dWb);
                dR = cat(1, dRf, dRb);
                dB = cat(1, dBf, dBb);
            end
        end
    end
end

%% Data manipulation
function [Wf, Rf, bf, Wb, Rb, bb] = iSplitWeights(W, R, b)
[Wf, Wb] = iSplitAcrossFirstDimension( W );
[Rf, Rb] = iSplitAcrossFirstDimension( R );
[bf, bb] = iSplitAcrossFirstDimension( b );
end

function [c0f, y0f, c0b, y0b] = iSplitStates(c0, y0)
[c0f, c0b] = iSplitAcrossFirstDimension( c0 );
[y0f, y0b] = iSplitAcrossFirstDimension( y0 );
end

function [Yf, Hf, Cf, dYf, Yb, Hb, Cb, dYb] = iSplitForwardOutputs(Y, H, C, dY)
[Yf, Yb] = iSplitAcrossFirstDimension( Y );
[Hf, Hb] = iSplitAcrossFirstDimension( H );
[Cf, Cb] = iSplitAcrossFirstDimension( C );
[dYf, dYb] = iSplitAcrossFirstDimension( dY );
end

function [Zf, Zb] = iSplitAcrossFirstDimension( Z )
H = 0.5*size(Z, 1);
fInd = 1:H;
bInd = H + fInd;
Zf = Z(fInd, :, :);
Zb = Z(bInd, :, :);
end

function [learnable, state, outputs, derivatives] = iArray2Struct(W, R, b, y0, c0, Y, H, C, dY)
learnable.W = W;
learnable.R = R;
learnable.b = b;
state.y0 = y0;
state.c0 = c0;
outputs.Y = Y;
outputs.HS = H;
outputs.CS = C;
derivatives.dZ = dY;
[h, n] = size(H, 1, 2);
derivatives.dHS = zeros( [h n], 'like', dY );
derivatives.dCS = zeros( [h n], 'like', dY );
end

%% Activation helpers
function act = iGetActivation( activation )
switch activation
    case 'tanh'
        act.Fcn = @tanh;
        act.dFcn = @iTanhDiff;
    case 'softsign'
        act.Fcn = @iSoftSign;
        act.dFcn = @iSoftSignDiff;
end
end

function act = iGetRecurrentActivation( activation )
switch activation
    case 'sigmoid'
        act.Fcn = @iSigmoid;
        act.dFcn = @iSigmoidDiff;
    case 'hard-sigmoid'
        act.Fcn = @nnet.internal.cnnhost.hardSigmoidForward;
        act.dFcn = @nnet.internal.cnnhost.hardSigmoidBackward;
end
end

%% Activation functions and derivatives
function y = iSigmoid(x)
y = 1./(1 + exp(-x));
end

function y = iSigmoidDiff(x)
y = ( 0.5.*sech(0.5.*x) ).^2;
end

function y = iTanhDiff(x)
y = sech(x).^2;
end

function y = iSoftSign(x)
y = x./(1 + abs(x));
end

function y = iSoftSignDiff(x)
y = (1 + abs(x)).^-2;
end