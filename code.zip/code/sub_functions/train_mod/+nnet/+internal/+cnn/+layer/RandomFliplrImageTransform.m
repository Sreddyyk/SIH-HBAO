classdef RandomFliplrImageTransform < nnet.internal.cnn.layer.InputTransform
    % RandonFliplrImageTransform   Image transformation for random vetical flips
    %   This class randomly flips an image along the vertical axis (i.e. 
    %   fliplr)
    
    %   Copyright 2015-2019 The MathWorks, Inc.
    
    properties (Constant)
        Type = 'randfliplr';
        Hyperparams = {}
    end
        
    properties
        % DataSize   Size of the image that this transform will transform
        DataSize
    end
    
    methods
        %------------------------------------------------------------------
        % Returns a random flip transform. Input to constructor is the size
        % of the image, which should match the image size set in the image
        % input layer. 
        %------------------------------------------------------------------             
        function this = RandomFliplrImageTransform(inputImageSize) 
            this.DataSize = inputImageSize;        
        end
        
        %------------------------------------------------------------------
        % serialize   Serialize an image transform to a structure 
        %------------------------------------------------------------------
        function S = serialize( this )
            S.Version = 1.0;
            S.Type = this.Type;
            S.ImageSize = this.DataSize;
        end

        function outputSize = forwardPropagateSize(~, inputSize)
            outputSize = inputSize;
        end
    end
    
    methods(Access = protected)
        %------------------------------------------------------------------
        % Transform implementation. Input is a batch of images. Output is a
        % batch of images where each image is randomly flipped.
        %------------------------------------------------------------------
        function batch = doTransform(this, batch)
            numImagesInBatch = size(batch,4);
            flipImg = this.randomFlip(numImagesInBatch);
            batch(:,:,:,flipImg) = fliplr(batch(:,:,:,flipImg));
        end
        
        function ind = randomFlip(~, N)
            ind = logical(randi([0 1], N, 1));
        end
    end
end

