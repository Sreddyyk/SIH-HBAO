classdef (Abstract) FunctionalStatefulLayer < ...
        nnet.internal.cnn.layer.FunctionalLayer
    % FunctionalStatefulLayer   Interface for functional stateful layers
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties (Abstract)
        % State    Table with layer's states
        State
    end
          
    methods
        % setupForFunctional   Prepare this layer for functional (dlarray)
        % strategy
        function this = setupForFunctional(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2training(this.LearnableParameters);
            this = setFunctionalStrategy(this);
            for i=1:numel(this.LearnableParameters)                
                this.LearnableParameters(i).Value = ...
                    single( dlarray( this.LearnableParameters(i).Value ) );
            end
            this = initializeStates(this);
        end
    end
    
    methods(Abstract, Access=protected)
        % setFunctionalStrategy   Set the layer execution strategy to
        % functional.
        this = setFunctionalStrategy(this)
        this = initializeStates(this)        
    end
end
