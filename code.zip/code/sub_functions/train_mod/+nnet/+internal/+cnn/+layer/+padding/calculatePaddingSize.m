function paddingSize = calculatePaddingSize(padding, dims)
% calculatePaddingSize   Calculate the padding size from the user input
%
%   paddingSize = calculatePaddingSize(padding) takes a user specified
%   padding option, and determines what the padding size is. It is assumed
%   the the padding is being calculated for a two dimensional input.
%
%   paddingSize = calculatePaddingSize(padding, dims) takes a further
%   dimensionality argument dims, and determines the padding size.
%
%   Input:
%       padding                 - This will be a user specified padding
%                                 option. It can be:
%                                   - The charater array or string 'same',
%                                     or some kind of partial match for 
%                                     'same' like 'sa' or 'Same'.
%                                   - A single number (for any value of dims).
%                                   - A 1-by-2 vector (for dims = 1 or 2).
%                                   - A 1-by-3 vector (for dims = 3).
%                                   - A 2-by-1 matrix (for dims = 1).
%                                   - A 2-by-2 matrix (for dims = 2).
%                                   - A 2-by-3 matrix (for dims = 3).
%                                   - A 1-by-4 vector (for dims = 2).
%                                   - A 1-by-6 vector (for dims = 3).
%       dims                    - Number of dimensions of the input the
%                                 padding must be applied to (default value
%                                 is 2).
%
%   Output:
%       paddingSize             - A 1-by-2 vector for the padding in the 
%                                 format [top bottom] for dims = 1.
%                                 A 1-by-4 vector for the padding in the 
%                                 format [top bottom left right] for dims = 2.
%                                 A 1-by-6 vector for the padding in the 
%                                 format [top bottom left right front back] 
%                                 for dims = 3.

%   Copyright 2017-2019 The MathWorks, Inc.

if nargin < 2
    dims=2;
end

if iIsValidStringOrCharArray(padding)
    % "validatestring" is being used here like an assertion. In practice,
    % whenever we reach this code, we will already have sucessfully called
    % "validatestring" during the parsing of input arguments.
    validatestring(padding,{'same'});
    paddingSize = [];
else
    paddingSize = iExpandPadding(padding, dims);
end
end

function tf = iIsValidStringOrCharArray(value)
tf = nnet.internal.cnn.layer.paramvalidation.isValidStringOrCharArray(value);
end

function paddingExpanded = iExpandPadding(padding, dims)
% The input padding is expanded in the format [top bottom] for 1D data (dims=1),
% [top bottom left right] for 2D data (dims=2), [top bottom left right front back]
% for 3D data (dims=3).
if(isscalar(padding))
    % The same padding is applied to both ends of each dim
    paddingExpanded = repmat(padding,[1 dims*2]);
elseif(iIsMatrixOfTwoByDims(padding,dims))
    % padding is provided in form of a matrix 2xdims, with elements meaning
    % [top left front; bottom right back]
    paddingExpanded = padding(:)';
elseif(iIsRowVectorOfOneByTwoDims(padding,dims)) 
    % padding has already the expected output format
    paddingExpanded = padding;
elseif(iIsRowVectorOfTwo(padding))
    % Input is 2D and padding(1) is applied to both ends of dim 1 and
    % padding(2) to both ends of dim 2.
    paddingExpanded = [padding(1) padding(1) padding(2) padding(2)];
elseif(iIsRowVectorOfThree(padding))
    % Input is 3D and padding(1) is applied to both ends of dim 1,
    % padding(2) to both ends of dim 2, and padding(3) to both ends of dim
    % 3.
    paddingExpanded = [padding(1) padding(1)...
                       padding(2) padding(2)...
                       padding(3) padding(3)];
end
end

function tf = iIsRowVectorOfTwo(x)
tf = isrow(x) && numel(x)==2;
end

function tf = iIsRowVectorOfThree(x)
tf = isrow(x) && numel(x)==3;
end

function tf = iIsRowVectorOfOneByTwoDims(x,dims)
tf = isrow(x) && numel(x)==2*dims;
end

function tf = iIsMatrixOfTwoByDims(x,dims)
% For 3d, dims=3
tf = ismatrix(x) && numel(x)==(2*dims) && size(x,1)==2 && size(x,2)==dims;
end