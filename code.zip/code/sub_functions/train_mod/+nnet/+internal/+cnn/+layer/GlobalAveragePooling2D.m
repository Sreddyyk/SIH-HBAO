classdef GlobalAveragePooling2D < nnet.internal.cnn.layer.FunctionalLayer
    % GlobalAveragePooling2D   Global average pooling
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        % LearnableParameters   Learnable parameters for the layer
        %   This layer has no learnable parameters.
        LearnableParameters = nnet.internal.cnn.layer.learnable...
            .PredictionLearnableParameter.empty();
        
        % Name (char array)   A name for the layer
        Name
    end
    
    properties
        % Learnables   Empty
        Learnables
    end
    
    properties(SetAccess=protected, GetAccess=?nnet.internal.cnn.dlnetwork)
        % LearnablesName   Empty
        LearnablesNames
    end
    
    properties (Constant)
        % DefaultName   Default layer's name.
        DefaultName = 'gap'
    end
    
    properties (SetAccess = private)
        % InputNames   This layer has a single input
        InputNames = {'in'}
        
        % OutputNames   This layer has a single output
        OutputNames = {'out'}
        
        % HasSizeDetermined   True for layers with size determined.
        HasSizeDetermined = true
    end
    
    properties(Access = private)
        ExecutionStrategy
    end
    
    methods
        function this = GlobalAveragePooling2D(name)
            this.Name = name;            
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.GlobalAveragePoolingStrategy(2);            
            this.NeedsXForBackward = true;
            this.NeedsZForBackward = false;
        end
        
        function Z = predict( this, X )
            Z = this.ExecutionStrategy.forward(X);
        end
        
        function [dX,dW] = backward( this, X, ~, dZ, ~ )
            dX = this.ExecutionStrategy.backward(X, dZ);
            dW = [];
        end
        
        function tf = isValidInputSize(~, inputSize)
            tf = numel(inputSize) == 3;
        end
        
        function outputSize = forwardPropagateSize(~, inputSize)
            % Assumes isValidInputSize has been called
            outputSize = [1 1 inputSize(3)];
        end
        
        % No ops:
        function this = inferSize(this, ~)
        end

        function this = initializeLearnableParameters(this, ~)
        end

        function this = prepareForTraining(this)
        end
        
        function this = prepareForPrediction(this)
        end
        
        function this = setupForHostPrediction(this)
        end
        
        function this = setupForGPUPrediction(this)
        end
        
        function this = setupForHostTraining(this)
        end
        
        function this = setupForGPUTraining(this)
        end
    end
    
    methods(Access=protected)
        function this = setFunctionalStrategy(this)
            % No-op
        end
    end
    
end
