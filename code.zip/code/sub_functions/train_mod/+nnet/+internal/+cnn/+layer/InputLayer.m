classdef(Abstract) InputLayer < nnet.internal.cnn.layer.FunctionalLayer
    % InputLayer   Interface for input layers
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    properties (Abstract, SetAccess = private)
        % InputSize   Size of the input, including the number of channels 
        % as last element in InputSize
        InputSize(1,:) double
    end
    
    properties(SetAccess = private)
        % InputNames   Input layers cannot have inputs, because nothing
        %              connects TO and input layer
        InputNames = {}
        
        % OutputNames   Input layers have one output
        OutputNames = {'out'}
    end
    
    properties
        % Learnables   Learnables are empty for input layers
        Learnables
    end

    properties(SetAccess=protected, GetAccess=?nnet.internal.cnn.dlnetwork)
        % LearnablesName   Empty
        LearnablesNames
    end
    
    properties(Access=protected)
        % InputValidationStrategy   Strategy for validating inputs to the
        % layer
        InputValidationStrategy = []
    end
    
    properties
        % LearnableParameters   Learnable parameters for the layer
        %   This layer has no learnable parameters.
        LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
	end

    methods
        % reset   Reset layer properties that need initialization
        %
        % Syntax
        %   layer = reset( layer )
        %
        % Inputs
        %   layer - the layer to be reset
        %
        % Output
        %   layer - the layer with reset properties
        function layer = reset( layer )
            % no-op if not overriden by child class
        end
        
        % initialize   Initialize layer properties based on input statistics
        %
        % Syntax
        %   layer = initialize( layer, X )
        %
        % Inputs
        %   layer - the layer to be initialize
        %   stats - a statistics accumulator object
        %
        % Output
        %   layer - the layer with updated properties
        function layer = initialize( layer, ~ )
            % no-op if not overriden by child class
        end
        
        % mergeInitialized  Combine two partially initialized layer objects.
        %
        % When initializing in parallel, each worker will build up an
        % initialized copy of the layer. These must then be merged together
        % to give one final result.
        %
        % Syntax
        %   layer = mergeInitialized(layer, otherLayer)
        %
        % Inputs
        %   layer, otherLayer - the layers to merge
        %
        % Outputs
        %   layer             - the final merged layer
        function layer = mergeInitialized(layer, ~)
            % no-op if not overriden by child class
        end
        
        % needsInitialization   Returns true if the layer requires
        % initialization (e.g. when normalizations have empty statistics)
        function tf = needsInitialization(~)
            tf = false;
        end
        
        % validateInputFormat   Validate that the size and format of input
        % data is appropriate for the layer and throw an error otherwise.
        function validateInputFormat( this, sz, fmt )
            if ~isempty(this.InputValidationStrategy)
                this.InputValidationStrategy.validateInputFormat(sz,fmt);
            end
        end
    end
    
    methods(Access=protected)
        % No-op: we do not use any particular functional strategy for input
        % layers.
        function this = setFunctionalStrategy(this)
        end
    end
end
