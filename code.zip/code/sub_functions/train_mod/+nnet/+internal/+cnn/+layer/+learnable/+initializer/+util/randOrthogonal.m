function q = randOrthogonal(sz)
% randOrthogonal   Creates random orthogonal weights.
%
% It assumes sz of length 2. If sz(1) > sz(2), q has orthogonal rows, if
% sz(1) < sz(2), it has orthogonal columns, and if sz(1)=sz(2), q is an
% orthogonal matrix.
%
% Ref: Saxe, Andrew M., James L. McClelland, and Surya Ganguli. "Exact
% solutions to the nonlinear dynamics of learning in deep linear neural
% networks." arXiv preprint arXiv:1312.6120 (2013).
    
%   Copyright 2018 The MathWorks, Inc.

assert(length(sz) == 2)

if sz(1) < sz(2)
   q = iOrthogonalColumns(sz(2), sz(1));
   q = q';
else
   q = iOrthogonalColumns(sz(1), sz(2));
end
end

function q = iOrthogonalColumns(m,n)
assert(m >= n)
z = randn(m,n);

% q is m x n with orthogonal columns. r is n x n.
[q,r] = qr(z, 0);

% Since q * r = q * l * l^{-1} * r, l in U(1)^n, we make qr unique by
% choosing a representative in the coset upperTriangular / U(1)^n with all
% diagonal coefficient > 0. This guarantees O(m) left-invariance of the
% measure we are sampling from. In the case m=n, it is the Haar measure of
% O(n). For more info, see https://arxiv.org/abs/math-ph/0609050v2
d = diag(r);
q = q * diag(d ./ abs(d));
end