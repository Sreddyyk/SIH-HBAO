classdef FullyConnectedFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy
    % FullyConnectedFunctionalStrategy    dlarray method strategy
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        ParConverter = ...
            nnet.internal.cnn.layer.util.FullyConnectedParsConverter();
    end
    
    methods
        function [Z, memory] = forward(~, X, weights, bias, ~)
           
            % Here weights and bias have external size, no reshape needed
            
            % TODO: use internal API
            Z = fullyconnect(X, weights, bias(:));
            
            memory = [];
        end
    end
end
