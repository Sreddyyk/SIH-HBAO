function validateSizeParameter( value, parameterName, varargin )
% validateSizeParameter   Throw an error if the size parameter with name
% given by the string parameterName is invalid.

%   Copyright 2017-2018 The MathWorks, Inc.

if(numel(varargin) > 0)
    ndims = varargin{1};
else
    ndims = 2;
end

validateattributes(value, {'numeric'}, ...
    {'nonempty', 'real', 'integer', 'positive'});


switch ndims
    
    case 2
        
        if ~(isscalar(value) || iIsRowVectorOfTwo(value))
            error(message('nnet_cnn:layer:Layer:ParamMustBeScalarOrPair', parameterName));
        end
        
    case 3
        
        if ~(isscalar(value) || iIsRowVectorOfThree(value))
            error(message('nnet_cnn:layer:Layer:ParamMustBeScalarOrTriple', parameterName));
        end
        
    otherwise
        error('Unexpected dimension specification');
end
end

function tf = iIsRowVectorOfTwo(x)
tf = isrow(x) && numel(x)==2;
end

function tf = iIsRowVectorOfThree(x)
tf = isrow(x) && numel(x)==3;
end


