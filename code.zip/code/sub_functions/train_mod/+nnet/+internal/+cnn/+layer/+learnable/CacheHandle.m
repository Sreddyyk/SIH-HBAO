classdef CacheHandle < handle
    % CacheHandle   Handle object used to cache values.
    %
    % Note that all properties are transient so that the cached value does
    % not get saved or sent over the network. On loading/deserializing the
    % cache will be valid, but empty.
    
    %   Copyright 2016-2017 The MathWorks, Inc.
    
    properties (SetAccess = private, Transient)
        Value = []
    end
    
    properties (Access=private, Transient)
        CacheEmpty = true;
    
        % DeviceListener  Listens to the GPU device being deselected in
        % order to flush cached gpuArrays
        DeviceListener
    end
    
    methods
        function this = CacheHandle(value)
            if nargin
                this.Value = value;
                this.CacheEmpty = false;
            else
                this.CacheEmpty = true;
                this.Value = [];
            end
        end
        
        function tf = isEmpty(this)
            tf = this.CacheEmpty;
        end
        
        function fillCache(this, value)
            this.Value = value;
            this.CacheEmpty = false;
        end
        
        function clearCache(this)
            this.CacheEmpty = true;
            this.Value = [];
        end
        
        function tf = eq(param1, param2)
            % eq  Overload eq to ensure this is only testing
            % whether the values are equal, not other properties
            tf = arrayfun( @(p1,p2)isequal(p1.Value, p2.Value), param1, param2 );
        end
        
        function tf = isequal(param1, param2)
            % isequal  Overload isequal to ensure this is only testing
            % whether the values are equal, not other properties
            tf = isequal(param1.Value, param2.Value);
        end
        
        function tf = isequaln(param1, param2)
            % isequaln  Overload isequaln to ensure this is only testing
            % whether the values are equal, not other properties
            tf = isequaln(param1.Value, param2.Value);
        end
        
        function clearOnDeviceReset(this)
            % clearOnDeviceReset  Handle safe caching of gpuArrays by
            % ensuring that the cache is emptied if the GPU device is reset
            if nnet.internal.cnn.util.canUsePCT()
                this.DeviceListener = event.listener( ...
                    parallel.gpu.GPUDeviceManager.instance(), ...
                    'DeviceDeselecting', @(~,~)clearCache(this) );
            end
        end
    end
end
