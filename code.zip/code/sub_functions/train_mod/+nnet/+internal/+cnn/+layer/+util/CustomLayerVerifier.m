classdef CustomLayerVerifier
    % CustomLayerVerifier   Class that holds checks for a custom layer
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    properties
        % LayerClass
        LayerClass
        
        % LearnableParametersNames
        LearnableParametersNames
    end
    
    methods
        function verifyUnlabeledDlarray( this, method, outputNames, Z )
            % verifyUnlabeledDlarray   Verify that when dlarrays are used
            % as inputs to a custom layer (e.g. when backward is not
            % defined) then the outputs are also dlarrays (without labels).
            if iIsScalarCellOrNumeric(Z)
                Z = iUnwrapScalarCell(Z);
                iAssertZIsUnlabeledDlarray(Z,this.LayerClass,method)
            else
                iAssertEachZIsUnlabeledDlarray(Z,this.LayerClass,method,outputNames)
            end
        end
        
        function verifyPredictType( this, outputNames, expectedType, Z )
            % verifyPredictType   Verify that the type of the outputs 
            % returned by a custom layer at predict time is consistent with
            % the type of its inputs.
            if iIsScalarCellOrNumeric(Z)
                Z = iUnwrapScalarCell(Z);
                iAssertZSameTypeAsXInPredict( Z, expectedType, this.LayerClass );
            else
                iAssertEachZSameTypeAsXInPredict( Z, expectedType, outputNames, this.LayerClass );
            end
        end
        
        function verifyForwardType( this, outputNames, expectedType, Z )
            % verifyForwardType   Verify that the type of the outputs
            % returned by a custom layer when forward is called is
            % consistent with the type of its inputs.
            if iIsScalarCellOrNumeric(Z)
                Z = iUnwrapScalarCell(Z);
                iAssertZSameTypeAsXInForward( Z, expectedType, this.LayerClass );
            else
                iAssertEachZSameTypeAsXInForward( Z, expectedType, outputNames, this.LayerClass );
            end
        end
        
        function verifyInferenceSizes( this, outputNames, Zpredict, Zforward)
            % verifyInferenceSizes   Verify the size of the outputs
            % returned by forward and predict methods of a custom layer are
            % the same.
            if iIsScalarCellOrNumeric(Zpredict)
                [Zpredict, Zforward] = iUnwrapScalarCell(Zpredict, Zforward);
                iAssertPredictAndForwardOutputSameSize( ...
                    Zpredict, Zforward, this.LayerClass );
            else
                iAssertEachPredictAndForwardOutputSameSize( ...
                    outputNames, Zpredict, Zforward, this.LayerClass );
            end
        end
 
        function verifyBackwardSize( this, inputNames, sizesX, learnableParameters, dLdX, dLdW )
            % verifyBackwardSize   Verify the size of the outputs returned
            % by a custom layer at the time backward is called is
            % consistent with the layer's inputs and learnable parameters.
            if iIsScalarCellOrNumeric(dLdX)
                [dLdX,sizesX] = iUnwrapScalarCell(dLdX,sizesX);
                iAssertdLdXSameSizeAsX( dLdX, sizesX, this.LayerClass );
            else
                iAssertEachdLdXSameSizeAsX( dLdX, sizesX, inputNames, this.LayerClass );
            end
            verifyWeightGradients = nargin > 5;
            if verifyWeightGradients
                iAssertdLdWSameSizeAsWForEachLearnableParam( dLdW, learnableParameters, this.LearnableParametersNames, this.LayerClass );
            end
        end
        
        function verifyBackwardType( this, inputNames, expectedType, dLdX, dLdW )
            % verifyBackwardType   Verify that the type of the outputs
            % returned by a custom layer when backward is called is
            % consistent with the type of its inputs.
            if iIsScalarCellOrNumeric(dLdX)
                dLdX = iUnwrapScalarCell(dLdX);
                iAssertdLdXSameTypeAsX( dLdX, expectedType, this.LayerClass );
            else
                iAssertdEachLdXSameTypeAsX( dLdX, expectedType, inputNames, this.LayerClass );
            end
            verifyWeightGradients = nargin > 4;
            if verifyWeightGradients
                iAssertdLdWSameTypeAsXForEachLearnableParam( dLdW, expectedType, this.LearnableParametersNames, this.LayerClass );
            end
        end
        
        function verifyForwardLossSize( ~, loss )
            % verifyForwardLossSize   Verify the size of the loss returned
            % by a custom output layer at the time forwardLoss is called
            iAssertScalarLoss( loss );
        end
        
        function verifyForwardLossType( ~, Y, loss )
            % verifyForwardLossType   Verify the type of the loss returned
            % by a custom output layer at the time forwardLoss is called
            iAssertLossSameTypeAsX( loss, Y );
        end
        
        function verifyBackwardLossSize( ~, Y, dLdY )
            % verifyBackwardLoss   Verify the size of the output returned
            % by a custom output layer at the time backwardLoss is called
            iAssertdLdXSameSizeAsXInBackwardLoss( dLdY, Y );
        end
        
        function verifyBackwardLossType( ~, Y, dLdY )
            % verifyBackwardLossType   Verify the type of the output
            % returned by a custom output layer at the time backwardLoss
            % is called
            iAssertdLdXSameTypeAsXInBackwardLoss( dLdY, Y );
        end
        
        function verifyEmptyMemoryForAutodiff( ~, memory )
            iAssertEmptyMemory( memory )
        end
    end
    
    methods (Static)
        function varargout = validateMethodSignatures( aCustomLayer, ~ )
            % validateMethodSignatures   Validate the signatures of
            % predict, forward and backward methods of a custom layer.
            %
            % Inputs:
            %   aCustomLayer - a custom layer to validate
            %   aLayerIndex  - the index of the layer in the array. This
            %                  will be used to build a useful error message
            %
            % Outputs:
            %   diagnostics  - if an output is requested, all errors will be
            %                  collected in diagnostics instead of being thrown
            if iIsACustomOutputLayer( aCustomLayer )
                [forwardLoss, backwardLoss] = iGetOutputLayerMethods( aCustomLayer );
                
                checks = {
                    @()iAssertCorrectForwardLossSignature( forwardLoss )
                    @()iAssertCorrectBackwardLossSignature( backwardLoss ) };
            else
                [predict, forward, backward] = iGetMethods( aCustomLayer );
                numInputs = aCustomLayer.NumInputs;
                numOutputs = aCustomLayer.NumOutputs;
                numLearnableParameters = iValidateLearnableParameters( aCustomLayer );
                isBackwardDefined = iIsMethodDefined( aCustomLayer, 'backward' );
                checks = {
                    @()iAssertCorrectNarginPredict( predict, numInputs )
                    @()iAssertCorrectNargoutPredict( predict, numOutputs )
                    @()iAssertCorrectNarginForward( forward, numInputs )
                    @()iAssertCorrectNargoutForward( forward, numOutputs, isBackwardDefined )
                    @()iAssertCorrectNarginBackward( backward, numInputs, numOutputs )
                    @()iAssertCorrectNargoutBackward( backward, numLearnableParameters, numInputs ) };
            end
            [varargout{1:nargout}] = iEvalCheck( checks{:} );
        end
    end
end

function tf = iIsACustomOutputLayer( aCustomLayer )
tf = isa( aCustomLayer, 'nnet.layer.ClassificationLayer' ) ...
    || isa( aCustomLayer, 'nnet.layer.RegressionLayer' ) ;
end

function [predict, forward, backward] = iGetMethods( aCustomLayer )
% iGetMethods   Get predict/forward/backward methods from a custom layer
m = metaclass( aCustomLayer );
methodList = m.MethodList;
for ii=1:numel(methodList)
    currentMethod = methodList(ii);
    switch currentMethod.Name
        case 'predict'
            predict = currentMethod;
        case 'forward'
            forward = currentMethod;
        case 'backward'
            backward = currentMethod;
        otherwise
    end
end
end

function [forwardLoss, backwardLoss] = iGetOutputLayerMethods( aCustomLayer )
% iGetOutputLayerMethods   Get forwardLoss/backwardLoss methods from a
% custom output layer
m = metaclass( aCustomLayer );
methodList = m.MethodList;
for ii=1:numel(methodList)
    currentMethod = methodList(ii);
    switch currentMethod.Name
        case 'forwardLoss'
            forwardLoss = currentMethod;
        case 'backwardLoss'
            backwardLoss = currentMethod;
        otherwise
    end
end
end

%% Assertions for signatures

function iAssertCorrectNarginPredict( predict, numInputs )
expectedNargin = 1 + numInputs;
arginErrorID = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongPredictNargin';
iAssertInputArguments( predict, expectedNargin, arginErrorID);
end

function iAssertCorrectNargoutPredict( predict, numOutputs )
expectedNargout = numOutputs;
argoutErrorID = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongPredictNargout';
iAssertOutputArguments( predict, expectedNargout, argoutErrorID);
end

function iAssertCorrectNarginForward( forward, numInputs )
expectedNargin = 1 + numInputs;
arginErrorID = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongForwardNargin';
iAssertInputArguments( forward, expectedNargin, arginErrorID);
end

function iAssertCorrectNargoutForward( forward, numOutputs, isBackwardDefined )
% Memory output only required if backward is defined in the custom layer
expectedNargout = isBackwardDefined + numOutputs;
argoutErrorID = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongForwardNargout';
iAssertOutputArguments( forward, expectedNargout, argoutErrorID);
end

function iAssertCorrectNarginBackward( backward, numInputs, numOutputs )
expectedNargin = 2 + numInputs + 2*numOutputs;
arginErrorID = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongBackwardNargin';
iAssertInputArguments( backward, expectedNargin, arginErrorID);
end

function iAssertCorrectNargoutBackward( backward, numLearnableParams, numInputs )
expectedNargout = numInputs + numLearnableParams;
if numLearnableParams > 0
    argoutErrorID = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongBackwardNargoutWithLearnableParams';
    iAssertOutputArguments( backward, expectedNargout, argoutErrorID, numLearnableParams);
else
    argoutErrorID = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongBackwardNargout';
    iAssertOutputArguments( backward, expectedNargout, argoutErrorID);
end
end

function iAssertCorrectForwardLossSignature( forwardLoss )
expectedNargin = 3;
arginErrorID = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongForwardLossNargin';
iAssertInputArguments( forwardLoss, expectedNargin, arginErrorID);

expectedNargout = 1;
argoutErrorID = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongForwardLossNargout';
iAssertOutputArguments( forwardLoss, expectedNargout, argoutErrorID);
end

function iAssertCorrectBackwardLossSignature( backwardLoss )
expectedNargin = 3;
arginErrorID = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongBackwardLossNargin';
iAssertInputArguments( backwardLoss, expectedNargin, arginErrorID);

expectedNargout = 1;
argoutErrorID = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongBackwardLossNargout';
iAssertOutputArguments( backwardLoss, expectedNargout, argoutErrorID);
end

function iAssertEmptyMemory( memory )
if ~isempty(memory)
    iThrow('nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:EmptyMemoryAutodiff');
end
end

%% Assertions for size

function iAssertPredictAndForwardOutputSameSize( Ypred, Yforward, layerClassOrIndex )
if ~iIsEquivalentSize( size(Ypred), size(Yforward) )
    iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongSizePredictForwardSingleOut', ...
        layerClassOrIndex )
end
end

function iAssertEachPredictAndForwardOutputSameSize( outputNames, Ypred, Yforward, layerClassOrIndex )
for ii = 1:numel(outputNames)
    if ~iIsEquivalentSize( size(Ypred{ii}), size(Yforward{ii}) )
        iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongSizePredictForwardMultiOut', ...
            layerClassOrIndex, outputNames{ii} )
    end
end
end

function iAssertdLdXSameSizeAsX( dLdX, XSize, layerClassOrIndex )
dLdXSize = size(dLdX);
if ~iIsEquivalentSize( dLdXSize, XSize )
    iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongSizeOfdLdXSingleIn', layerClassOrIndex, iSizeToString(XSize), iSizeToString(dLdXSize) )
end
end

function iAssertEachdLdXSameSizeAsX( dLdX, XSize, layerInputNames, layerClassOrIndex )
for ii = 1:numel(layerInputNames)
    dLdXSize = size(dLdX{ii});
    if ~iIsEquivalentSize( dLdXSize, XSize{ii} )
        iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongSizeOfdLdXMultiIn', ...
            layerClassOrIndex, layerInputNames{ii}, iSizeToString(XSize{ii}), iSizeToString(dLdXSize) )
    end
end
end

function iAssertdLdWSameSizeAsWForEachLearnableParam( dLdW, learnableParameters, learnableParametersNames, layerClass )
for ii=1:numel(learnableParameters)
    iAssertdLdWSameSizeAsW( dLdW{ii}, learnableParameters{ii}, learnableParametersNames{ii}, layerClass )
end
end

function iAssertdLdWSameSizeAsW( dLdW, W, parameterName, layerNameOrIndex )
WSize = size( W );
dLdWSize = size( dLdW );
if ~iIsEquivalentSize( dLdWSize, WSize )
    iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongSizeOfdLdW', parameterName, layerNameOrIndex, iSizeToString(WSize), iSizeToString(dLdWSize) )
end
end

function iAssertScalarLoss( loss )
if ~isscalar( loss )
    iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:ScalarLoss', iSizeToString( size( loss ) ) )
end
end

function iAssertdLdXSameSizeAsXInBackwardLoss( dLdY, Y )
dLdYSize = size( dLdY );
YSize = size( Y );
if ~iIsEquivalentSize( dLdYSize, YSize )
    iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:WrongSizeOfdLdXInBackwardLoss', iSizeToString(YSize), iSizeToString(dLdYSize) )
end
end

%% Assertions for type

function iAssertSameTypeOfData( testData, expectedType, layerClass, hostErrorID, gpuErrorID, varargin )
% Assert that the data type of testData is the same as the expected type.
% testData must be numeric and expectedType is a struct with the fields 
% "Main" and "Underlying", providing the expected type as a char array.
actualClass = class(testData);
if ~isequal( expectedType.Main, actualClass )
    iThrow( hostErrorID, layerClass, expectedType.Main, actualClass, varargin{:} )
end
if expectedType.Main == "gpuArray"
    actualUnderLyingClass = classUnderlying(testData);
    if ~isequal( expectedType.Underlying, actualUnderLyingClass )
        iThrow( gpuErrorID, layerClass, expectedType.Underlying, actualUnderLyingClass, varargin{:} )
    end
end
end

function iAssertZSameTypeAsXInPredict( Z, typeX, layerClass )
hostError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:PredictInvalidTypeSingleOut';
gpuError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:PredictInvalidUnderlyingTypeSingleOut';
iAssertSameTypeOfData( Z, typeX, layerClass, hostError, gpuError);
end

function iAssertEachZSameTypeAsXInPredict( Z, typeX, outputNames, layerClass )
hostError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:PredictInvalidTypeMultiOut';
gpuError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:PredictInvalidUnderlyingTypeMultiOut';
for ii = 1:numel(outputNames)
    iAssertSameTypeOfData( Z{ii}, typeX, layerClass, hostError, gpuError, outputNames{ii});
end
end

function iAssertZSameTypeAsXInForward( Z, typeX, layerClass )
hostError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:ForwardInvalidTypeSingleOut';
gpuError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:ForwardInvalidUnderlyingTypeSingleOut';
iAssertSameTypeOfData( Z, typeX, layerClass, hostError, gpuError);
end

function iAssertEachZSameTypeAsXInForward( Z, typeX, outputNames, layerClass )
hostError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:ForwardInvalidTypeMultiOut';
gpuError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:ForwardInvalidUnderlyingTypeMultiOut';
for ii = 1:numel(outputNames)
    iAssertSameTypeOfData( Z{ii}, typeX, layerClass, hostError, gpuError, outputNames{ii});
end
end

function iAssertdLdXSameTypeAsX( dLdX, typeX, layerClass )
hostError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:dLdXInvalidTypeSingleIn';
gpuError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:dLdXInvalidUnderlyingTypeSingleIn';
iAssertSameTypeOfData( dLdX, typeX, layerClass, hostError, gpuError);
end

function iAssertdEachLdXSameTypeAsX( dLdX, typeX, inputNames, layerClass )
hostError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:dLdXInvalidTypeMultiIn';
gpuError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:dLdXInvalidUnderlyingTypeMultiIn';
for ii = 1:numel(inputNames)
    iAssertSameTypeOfData( dLdX{ii}, typeX, layerClass, hostError, gpuError, inputNames{ii});
end
end

function iAssertdLdWSameTypeAsXForEachLearnableParam( dLdW, typeX, learnableParametersNames, layerClass )
hostError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:dLdWInvalidType';
gpuError = 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:dLdWInvalidUnderlyingType';
for ii = 1:numel(learnableParametersNames)
    iAssertSameTypeOfData( dLdW{ii}, typeX, layerClass, hostError, gpuError, learnableParametersNames{ii});
end
end

function iAssertLossSameTypeAsX( loss, X )
classX = class(X);
classLoss = class(loss);
if ~isequal( classLoss, classX )
    iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:LossInvalidType', classX, classLoss )
end
if strcmp(classX,'gpuArray')
    classUnderX = classUnderlying(X);
    classUnderLoss = classUnderlying(loss);
    if ~isequal( classUnderX, classUnderLoss )
        iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:LossInvalidUnderlyingType', ...
            classUnderX, classUnderLoss )
    end
end
end

function iAssertdLdXSameTypeAsXInBackwardLoss( dLdX, X )
classX = class(X);
classdLdX = class( dLdX );
if ~isequal( classdLdX, classX )
    iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:dLdXBackwardLossInvalidType', classX, classdLdX )
end
if strcmp(classX,'gpuArray')
    classUnderX = classUnderlying(X);
    classUnderdLdX = classUnderlying(dLdX);
    if ~isequal( classUnderX, classUnderdLdX )
        iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:dLdXBackwardLossInvalidUnderlyingType', ...
            classUnderX, classUnderdLdX )
    end
end
end

function iAssertZIsUnlabeledDlarray(Z,layerClass,method)
if ~isa(Z,'dlarray') || ~isempty( dims(Z) )
    iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:InferenceInvalidDlarraySingleOut', ...
        layerClass, method, class(Z) );
end
end

function iAssertEachZIsUnlabeledDlarray(Z,layerClass,method,outputNames)
for ii = 1:numel(outputNames)
    if ~isa(Z{ii},'dlarray') || ~isempty( dims(Z{ii}) )
        iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:InferenceInvalidDlarrayMultiOut', ...
            layerClass, method, class(Z{ii}), outputNames{ii} );
    end
end
end

%% Helper functions
function diagnostics = iEvalCheck( varargin )
throwError = nargout == 0;
diagnostics = {};
for i = 1:numel(varargin)
    try
        % evaluate function
        varargin{i}()
    catch e
        if throwError
            rethrow(e)
        else
            % Collect error messages if they are not meant to
            % be thrown
            diagnostics{end+1} = e.message; %#ok<AGROW>
        end
    end
end
end

function n = iNargin( currentMethod )
if isempty(currentMethod.InputNames)
    n = 0;
elseif any(contains(currentMethod.InputNames,'varargin'))
    % The exact number of input arguments to the method is not known
    n = [];
else
    n = numel(currentMethod.InputNames);
end
end

function n = iNargout( currentMethod )
if isempty(currentMethod.OutputNames)
    n = 0;
elseif any(contains(currentMethod.OutputNames,'varargout'))
    % The exact number of output arguments to the method is not known
    n = [];
else
    n = numel(currentMethod.OutputNames);
end
end

function numLearnableParameters = iValidateLearnableParameters( aCustomLayer )
% iValidateLearnableParameters   Make sure learnable parameters are valid
% and return the total number of learnable parameters in the layer
m = metaclass( aCustomLayer );
propertyList = m.PropertyList;
numLearnableParameters = 0;
for ii=1:numel(propertyList)
    if iIsLearnableProperty( propertyList(ii) )
        iAssertValidLearnableParameter( propertyList(ii) )
        numLearnableParameters = numLearnableParameters + 1;
    end
end
end

function tf = iIsLearnableProperty( prop )
% iIsLearnableProperty   Return true if prop is a property with "Learnable"
% tag. Since we might assess a layer that does not implement the learnable
% metaclass, we need to make sure that the "Learnable" tag exists before
% checking if it is set to true or false
tf = isprop(prop, 'Learnable') && prop.Learnable;
end

function iAssertValidLearnableParameter( prop )
% iAssertValidLearnableParameter   Assert that prop is a valid learnable
% parameter property. To be valid, it needs to have set and get access
% public, and not being constant
if ~iIsPublic( prop.GetAccess ) || ~iIsPublic( prop.SetAccess )
    iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:NonPublicLearnableParam', prop.Name )
end
if prop.Constant
    iThrow( 'nnet_cnn:internal:cnn:layer:util:CustomLayerVerifier:ConstantLearnableParam', prop.Name )
end
end

function tf = iIsPublic( access )
% An access in a metaclass can be public if it's either 'public' or 'none'
tf = isequal( access, 'public' ) || isequal( access, 'none' );
end

function iAssertInputArguments( method, expectedNargin, errorID)
% iAssertInputArguments   Assert that method has expectedNargin number of
% input arguments. If not, throw errorID error
actualNargin = iNargin( method );
if ~isempty(actualNargin) && actualNargin ~= expectedNargin
    iThrow( errorID, expectedNargin, actualNargin );
end
end

function iAssertOutputArguments( method, expectedNargout, errorID, varargin )
% iAssertOutputArguments   Assert that method has expectedNargout number of
% output arguments. If not, throw errorID error using varargin additional
% parameters
actualNargout = iNargout( method );
if ~isempty(actualNargout) && actualNargout ~= expectedNargout
    iThrow( errorID, expectedNargout, actualNargout, varargin{:} );
end
end

function sizeString = iSizeToString( sizeVector )
% i3DSizeToString   Convert a size retrieved by "size" into a string
% separated by "x".
sizeString = join( string( sizeVector ), "x" );
end

function iThrow( msg, varargin )
error( message( msg, varargin{:} ) )
end

function varargout = iUnwrapScalarCell(varargin)
varargout = cell(1,nargin);
for i = 1:nargin
    if iscell(varargin{i}) && isscalar(varargin{i})
        varargout{i} = varargin{i}{1};
    else
        varargout{i} = varargin{i};        
    end
end
end

function tf = iIsScalarCellOrNumeric(data)
isScalarCell = iscell(data) && isscalar(data);
tf = ~iscell(data) || isScalarCell;
end

function tf = iIsMethodDefined( externalLayer, methodName )
tf = nnet.internal.cnn.layer.util.isMethodDefined(externalLayer, methodName);
end

function tf = iIsEquivalentSize(size1,size2)
tf = nnet.internal.cnn.util.isEquivalentSize(size1,size2);
end