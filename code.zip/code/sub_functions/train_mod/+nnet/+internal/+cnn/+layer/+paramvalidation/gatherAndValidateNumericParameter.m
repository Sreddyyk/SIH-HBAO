function value = gatherAndValidateNumericParameter(value, ...
                                                   attributesToCheck, ...
                                                   expectedSize)
% gatherAndValidateNumericParameter   Gather and validate numeric parameter
%
% value = gatherAndValidateNumericParameter(value, 'default', expectedSize)
% use the default attributes and check that value has the expected size if
% non-empty.
%
% value = gatherAndValidateNumericParameter(value, attributes)
% checks that value respects the attributes specified. expectedSize is
% ignored.

%   Copyright 2018 The MathWorks, Inc.

narginchk(2,3)
if ~isempty(value)
    if isequal(attributesToCheck, 'default')
        % Default attributes. Note checking sparsity is relevant even for
        % higher rank tensors whose size in dims greater than 2 are 1.
        attributes = {'size', expectedSize, 'real', 'nonsparse'};
    else
        attributes = attributesToCheck;
    end
else
    % Ignore attributesToCheck and expectedSize if empty.
    attributes = {};
end

value = gather(value);
classes = {'single', 'double'};
validateattributes(value, classes, attributes);
end