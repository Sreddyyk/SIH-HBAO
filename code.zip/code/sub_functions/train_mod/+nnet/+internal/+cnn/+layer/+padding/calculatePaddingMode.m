function paddingMode = calculatePaddingMode(padding)
% calculatePaddingMode   Calculate the padding mode from the user input
%
%   paddingMode = calculatePaddingMode(padding) takes a user specified
%   padding option, and determines what the padding mode is (either 'same'
%   or 'manual').
%
%   Input:
%       padding                 - This will be a user specified padding
%                                 option. It can be:
%                                   - The charater array or string 'same',
%                                     or some kind of partial match for 
%                                     'same' like 'sa' or 'Same'.
%                                   - A single number.
%                                   - A 1-by-2 vector.
%                                   - A 1-by-4 vector.
%                                   - A 1-by-3 vector.
%                                   - A 2-by-3 matrix.
%
%   Output:
%       paddingMode             - This will either be the character array
%                                 'same' or the character array 'manual'.

%   Copyright 2017-2018 The MathWorks, Inc.

if iIsValidStringOrCharArray(padding)
    paddingMode = validatestring(padding,{'same'});
else
    paddingMode = 'manual';
end
end

function tf = iIsValidStringOrCharArray(value)
tf = nnet.internal.cnn.layer.paramvalidation.isValidStringOrCharArray(value);
end