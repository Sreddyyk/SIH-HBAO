classdef SoftmaxDAGStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % SoftmaxDAGStrategy   Execution strategy for running the softmax layer
    % in a DAG network

    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [X, memory] = forward(~, X, channelDim)
            X = internal_softmax(X, channelDim);
            memory = [];
        end
        
        function [dX, dW] = backward(~, Z, dZ, channelDim)
            dX = internal_softmaxBackward(dZ, Z, channelDim);
            dW = [];
        end
    end
end