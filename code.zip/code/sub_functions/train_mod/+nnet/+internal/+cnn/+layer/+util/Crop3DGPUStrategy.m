classdef Crop3DGPUStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % GPU execution strategy for crop 3D.
    
    % Copyright 2019 The MathWorks, Inc.
    
    properties
        % Strategy to use for cropping (center or manual).
        CropStrategy
    end
    
    methods
        %------------------------------------------------------------------
        function this = Crop3DGPUStrategy(cropStrategy)
            this.CropStrategy = cropStrategy;
        end
        
        %------------------------------------------------------------------
        function  [Z, memory] = forward(this, X)
            % Move data to GPU.
            X = iMoveDataToGPU(X);
            
            [Z, memory] = this.CropStrategy.forward(X);
        end
        
        %------------------------------------------------------------------
        function [dX,dW] = backward(this, X, dZ)
            % Move data to GPU.
            X  = iMoveDataToGPU(X);
            dZ = iMoveDataToGPU(dZ);
            
            [dX, dW] = this.CropStrategy.backward(X,dZ);
        end
    end
end

%--------------------------------------------------------------------------
function data = iMoveDataToGPU(data)
if iscell(data)
    data = cellfun(@(x)gpuArray(x),data,'UniformOutput',false);
else
    data = gpuArray(data);
end
end