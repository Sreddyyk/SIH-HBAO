classdef SoftmaxFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy
    % SoftmaxFunctionalStrategy    Calls into the dlarray method softmax
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X, ~)
            
            % TODO: use internal API
            Z = softmax(X);
            
            memory = [];
        end
    end
end
