classdef GRUFunctionalStrategy < nnet.internal.cnn.layer.util.FunctionalStrategy
    % GRUFunctionalStrategy   Execution strategy for running GRU with a
    % general set of options. This strategy is used for both Host and GPU
    % implementations.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X, W, R, b, h0, options)
            [Z, H] = gru(X, h0, W, R, b);
            memory.HiddenState = H;
            if options.ReturnLast
                Z = iGetLastSequenceElement(Z);
            end
        end
    end
end

function y = iGetLastSequenceElement(y)
% Get the last element of a dlarray in the sequence dimension, and remove
% the singleton 'T' dimension.
timeDim = finddim(y,'T');
if ~isempty(timeDim)
    indexer = repmat({':'}, [1, ndims(y)]);
    indexer{timeDim} = size(y,timeDim);
    y = y(indexer{:});
    % Remove label 'T'
    labels = dims(y);
    labels(timeDim) = [];
    y = dlarray(stripdims(y),labels);
end
end