function validatePaddingSize( varargin )
% validatePaddingSize   Throw an error if the padding size parameter is invalid.
%
% validatePaddingSize( value ) validates padding for ndims = 2 and
% parameter Padding.
%
% validatePaddingSize( value, d ) validates padding for ndims = d and
% parameter Padding.
%
% validatePaddingSize( value, d, paramName ) validates padding for ndims =
% d and parameter paramName.

%   Copyright 2017-2018 The MathWorks, Inc.

value = varargin{1};
if(nargin > 1)
    ndims = varargin{2};
else
    ndims = 2;
end
if(nargin > 2)
    name = varargin{3};
else
    name = 'Padding';
end

validateattributes(value, {'numeric'}, ...
    {'nonempty', 'real', 'integer', 'nonnegative'},'',name);

switch ndims
    
    case 2
        if ~(isscalar(value) || iIsRowVectorOfTwo(value) || iIsMatrixOfTwoByDims(value,ndims) || iIsRowVectorOfOneByTwoDims(value,ndims))
            error(message('nnet_cnn:layer:Layer:ParamMustBeScalarOrTwoOrFour',name));
        end
        
    case 3
        if ~(isscalar(value) || iIsRowVectorOfThree(value) || iIsMatrixOfTwoByDims(value,ndims) || iIsRowVectorOfOneByTwoDims(value,ndims))
            error(message('nnet_cnn:layer:Layer:ParamMustBeScalarOrThreeOrSix',name));
        end
        
    otherwise
        error('Unexpected dimension specification');
end


end

function tf = iIsRowVectorOfTwo(x)
tf = isrow(x) && numel(x)==2;
end

function tf = iIsRowVectorOfThree(x)
tf = isrow(x) && numel(x)==3;
end

function tf = iIsRowVectorOfOneByTwoDims(x,dims)
tf = isrow(x) && numel(x)==2*dims;
end

function tf = iIsMatrixOfTwoByDims(x,ndims)
% For 3D, ndims=3
tf = ismatrix(x) && numel(x)==(2*ndims) && size(x,1)==2 && size(x,2)==ndims ;
end