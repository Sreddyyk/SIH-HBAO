classdef BasicMixin
    % BasicMixin   Mixin implementing basic initializer methods
    %
    % Mixin with basic implementation of methods of interface Initializer.
    % To be inherited from concrete builtin initializers whose constructor
    % does not require additional arguments.
       
    %   Copyright 2018 The MathWorks, Inc.

    methods
        % Initialize parameters
        function param = initialize(this, paramSize, ~)
            param = this.Fcn(paramSize);            
        end
        
        % Convert to struct ready for serialization        
        function s = toStruct(this)
            s.Version = 1;
            s.Class = class(this);
            s.ConstructorArguments = [];
        end
    end
    
    methods (Access = protected)
        function tf = privateIsEqual(this, anotherInitializer)
            % If inherited, "this" is instance of the class that inherits.
            tf = isa(anotherInitializer, class(this));
        end
    end
end