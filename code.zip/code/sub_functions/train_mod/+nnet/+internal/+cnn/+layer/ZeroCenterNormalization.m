classdef ZeroCenterNormalization < nnet.internal.cnn.layer.InputTransform
    % ZeroCenterNormalization   Data transform for zero centering
    %   This class zero centers any input data by subtracting the mean.
    
    %   Copyright 2015-2019 The MathWorks, Inc.
    
    properties(Constant)
        Type = 'zerocenter';
        Hyperparams = { 'Mean' }
    end
    
    properties
        % DataSize   Size of the data that this transform will transform.
        % DataSize must include the channel dimension even if it is one.
        DataSize
    end
    
    properties(Dependent)
        % Mean   Average over observations. Can either be a vector
        % with a mean value per data channel or the average of the training
        % data with the same size as the input data size.
        Mean
        
        % NormalizationDimension   Char value that describes which
        % dimensions to normalize via the same statistics.
        NormalizationDimension
    end
    
    properties(Access = private)
        % PrivateUserMean   Mean over observations. Can either be a
        % vector with a mean value per data channel or the mean of the
        % training data with the same size as the input data size.
        PrivateUserMean
        
        % PrivateReducedMeanCache   Mean over observations. This is a
        % reduced version of PrivateUserMean based on the
        % NormalizationDimension parameter.
        PrivateReducedMeanCache
        
        % PrivateChannelMeanCache   Mean per channel of the trained mean.
        % This is only needed when retrieving activations with data of
        % larger spatial dimensions than the training data.
        PrivateChannelMeanCache
        
        % PrivateNormalizationDimension   NormalizationDimension specified
        % as char value which describes which dimensions to normalize
        % via the same statistics.
        PrivateNormalizationDimension = 'auto'
    end
    
    methods
        function this = ZeroCenterNormalization(inputSize)
            this.DataSize = inputSize;
            this = reset(this);
        end
        
        function S = serialize( this )
            S.Version = 2.0;
            S.Type = this.Type;
            S.ImageSize = this.DataSize;
            S.AverageImage = this.Mean;
            % Serialize NumTrainingSamples for forward compatibility. 
            % It is unused though.
            S.NumTrainingSamples = 0;
        end
        
        function outputSize = forwardPropagateSize(~, inputSize)
            outputSize = inputSize;
        end
        
        function this = set.NormalizationDimension(this,value)
            this.PrivateNormalizationDimension = value;
            % To update the reduced represenations of the statistics based 
            % on the new NormalizationDimension value, reassign the statistics.
            this.Mean = this.Mean;
        end
        
        function value = get.NormalizationDimension(this)
            value = this.PrivateNormalizationDimension;
        end
        
        function this = set.Mean(this, value)
            this.PrivateUserMean = value;
            this.PrivateChannelMeanCache.Value = iComputeReducedMean( ...
                value, this.DataSize, 'channel' );
            this.PrivateReducedMeanCache.Value = iComputeReducedMean( ...
                value, this.DataSize, this.NormalizationDimension);
        end
        
        function dataAverage = get.Mean(this)
            dataAverage = this.PrivateUserMean;
        end
        
        function tf = needsInitialization(this)
            tf = isempty(this.Mean);
        end
        
        function this = setupForGPUTransform(this)
            this.PrivateChannelMeanCache.UseGPU = true;
            this.PrivateReducedMeanCache.UseGPU = true;
        end
        
        function this = setupForHostTransform(this)
            this.PrivateChannelMeanCache.UseGPU = false;
            this.PrivateReducedMeanCache.UseGPU = false;
        end
    end
    
    methods(Access = protected)
        function this = doReset(this)
            this.PrivateUserMean = [];
            this.PrivateChannelMeanCache = iEmptyDoubleParameter();
            this.PrivateReducedMeanCache = iEmptyDoubleParameter();
        end
        
        function batch = doTransform(this, batch)
            spatialDims = numel(this.DataSize) - 1;
            
            batchSize = ones(1,numel(this.DataSize));
            batchSize(1:ndims(batch)) = size( batch );
            
            if isequal( batchSize(1:spatialDims), this.DataSize(1:spatialDims) )
                assert(~isempty(this.PrivateReducedMeanCache.Value), ...
                    "Mean value is empty");
                batch = batch - this.PrivateReducedMeanCache.Value;
            else
                % The size of the input data is different from the size of
                % the training data and the data average. This can only
                % occur when calling activations on larger images. Use the
                % per-channel mean of the data average for normalization.
                assert(~isempty(this.PrivateChannelMeanCache.Value), ...
                    "Reduced mean per channel is empty");
                batch = batch - this.PrivateChannelMeanCache.Value;
            end
        end
        
        function this = doInitialize(this, stats)
            if isempty(this.Mean)
                % By default, compute per-channel statistics
                if this.NormalizationDimension == "auto"
                    normDim = 'channel';
                else
                    normDim = this.NormalizationDimension;
                end
                
                perElementMean = gather( getStatistic(stats,'mean') );
                this.Mean = iComputeReducedMean( perElementMean, ...
                    this.DataSize, normDim );
            end
        end
    end
end

function out = iComputeReducedMean(value, dataSize, normDimension)
switch normDimension
    case 'auto'
        out = value;
    case 'element'
        out = value;
    case 'channel'
        reductionDims = 1:(numel(dataSize)-1);
        out = iReduceMean(value, reductionDims);
    case 'all'
        reductionDims = 1:numel(dataSize);
        out = iReduceMean(value, reductionDims);
end
end

function out = iReduceMean(value, dim)
out = nnet.internal.cnn.layer.util.computeMeanOfMeans(value,dim);
end

function param = iEmptyDoubleParameter()
param = nnet.internal.cnn.layer.util.CachedParameter([]);
end
