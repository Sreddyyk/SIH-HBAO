classdef (Abstract) FunctionalLayer < nnet.internal.cnn.layer.Layer
    % FunctionalLayer   Interface for functional layers
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties (Abstract)
        % Learnables   Values of the learnable parameters for the layer.  
        %
        %    The Learnable property contains a cell array of learnable parameter
        %    values, one for each of the LearnableParameters.  The values in this
        %    cell array must match the ordering of the LearnableParameters.
        Learnables(1,:) cell
    end
       
    properties (Abstract, SetAccess=protected, ...
            GetAccess=?nnet.internal.cnn.dlnetwork)
        % LearnablesNames   String array of the names of the Learnables
        LearnablesNames(1,:) string
    end
          
    methods
        % setupForFunctional   Prepare this layer for functional (dlarray)
        % strategy
        function this = setupForFunctional(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2training(this.LearnableParameters);
            this = setFunctionalStrategy(this);
            for i=1:numel(this.LearnableParameters)                
                this.LearnableParameters(i).Value = ...
                    single( dlarray( this.LearnableParameters(i).Value ) );
            end
        end

        % revertSetupForFunctional   Revert strategy to Host, and
        % Learnables to numeric.
        function this = revertSetupForFunctional(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2prediction(this.LearnableParameters);
            this = setupForHostPrediction(this);
            for i=1:numel(this.LearnableParameters)
                if isa(this.LearnableParameters(i).Value, 'dlarray')
                    this.LearnableParameters(i).Value = ...
                        extractdata(this.LearnableParameters(i).Value);
                end
            end
        end        
    end
    
    methods(Abstract, Access=protected)
        % setFunctionalStrategy   Set the layer execution strategy to
        % functional.
        this = setFunctionalStrategy(this)
    end
end
