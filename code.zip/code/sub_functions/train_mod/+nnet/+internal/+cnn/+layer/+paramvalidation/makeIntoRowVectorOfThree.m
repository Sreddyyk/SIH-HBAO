function rowVectorOfThree = makeIntoRowVectorOfThree(scalarOrRowVectorOfThree)
% makeIntoRowVectorOfThree   Convert into row of three values. Expects scalar
% or already row of three.

%   Copyright 2018 The MathWorks, Inc.

if(iIsRowVectorOfThree(scalarOrRowVectorOfThree))
    rowVectorOfThree = scalarOrRowVectorOfThree;
else
    rowVectorOfThree = [scalarOrRowVectorOfThree scalarOrRowVectorOfThree scalarOrRowVectorOfThree];
end
end

function tf = iIsRowVectorOfThree(x)
tf = isrow(x) && numel(x)==3;
end