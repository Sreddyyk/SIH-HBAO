function outputArray = unpadArray(inputArray, paddingSize)
% unpadArray   "Unpad" or crop a 4D array spatially
%
%   outputArray = unpadArray(inputArray, paddingSize) takes a 4D array that
%   has been spatially padded, and "unpads" it.
%
%       inputArray              - A (H)x(W)x(C)x(N)/(H)x(W)x(D)x(C)x(N)
%                                 array which will be
%                                 spatially padded along the H and W 
%                                 (and 'D' )dimensions.
%       paddingSize             - A 1-by-4/1-by-6 vector for the padding in the 
%                                 format [top bottom left right (front back)].

%
%   Output:
%       outputArray             - A (H)x(W)x(C)x(N)/(H)x(W)x(D)x(C)x(N) array.

%   Copyright 2017-2018 The MathWorks, Inc.

topPad = paddingSize(1);
bottomPad = paddingSize(2);
leftPad = paddingSize(3);
rightPad = paddingSize(4);

imageTop = topPad + 1;
imageBottom = size(inputArray,1) - bottomPad;
imageLeft = leftPad + 1;
imageRight = size(inputArray,2) - rightPad;

switch numel(paddingSize)
    
    case 4
        outputArray = inputArray(imageTop:imageBottom,imageLeft:imageRight,:,:);
        
    case 6
        frontPad = paddingSize(5);
        backPad = paddingSize(6);
        imageFront = frontPad+1;
        imageBack = size(inputArray,3) - backPad;
        outputArray = inputArray(imageTop:imageBottom,imageLeft:imageRight,...
                                 imageFront:imageBack, :, :);
end
