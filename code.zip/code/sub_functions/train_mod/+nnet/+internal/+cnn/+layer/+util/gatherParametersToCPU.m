function inputArguments = gatherParametersToCPU(inputArguments)
% gatherParametersToCPU   Gather layer input parameters into a CPU array
%                         (from for example GPU array).

%   Copyright 2018 The MathWorks, Inc.

inputArguments = iSafeGather(inputArguments);
end

function argument = iSafeGather(argument)
% iSafeGather gathers structs arrays, cells arrays, and nested
% combinations of them.

if isstruct(argument)
    argument = structfun(@iSafeGather, argument, 'UniformOutput', false);
elseif iscell(argument)
    argument = cellfun(@iSafeGather, argument, 'UniformOutput', false);
else
    argument = gather(argument);
end
end