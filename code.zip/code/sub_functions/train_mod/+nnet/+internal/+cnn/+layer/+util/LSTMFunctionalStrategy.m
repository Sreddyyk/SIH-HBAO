classdef LSTMFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy 
    % LSTMFunctionalStrategy    dlarray method strategy
    
    %   Copyright 2019 The MathWorks, Inc.

    methods
        function [Y, memory] = forward(~, X, W, R, b, c0, y0)            
            
            [Y, H, C] = lstm(X, y0, c0, W, R, b);
            memory.CellState = C;
            memory.HiddenState = H;
        end        
    end
end
