classdef Orthogonal < ...
        nnet.internal.cnn.layer.learnable.initializer.Initializer & ...
        nnet.internal.cnn.layer.learnable.initializer.BasicMixin    
    % Orthogonal    Orthogonal initializer
   
    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function this = Orthogonal()
            this.Name = 'orthogonal';
            this.Fcn = @nnet.internal.cnn.layer.learnable.initializer.util...
                .randOrthogonal;
        end        
    end
end