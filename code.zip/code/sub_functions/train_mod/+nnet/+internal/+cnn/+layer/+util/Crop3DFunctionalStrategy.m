classdef Crop3DFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy
    % Crop3DFunctionalStrategy    dlarray method strategy
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        % Strategy to use for cropping (center or manual).
        CropStrategy
    end
    
    methods
        %------------------------------------------------------------------
        function this = Crop3DFunctionalStrategy(cropStrategy)
            this.CropStrategy = cropStrategy;
        end
        
        %------------------------------------------------------------------
        function  [Z, memory] = forward(this, X)
            Z = this.CropStrategy.forward(X);
            memory = [];
        end
    end
end