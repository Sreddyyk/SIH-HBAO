classdef GenericInput < nnet.internal.cnn.layer.InputLayer
    % GenericInput   Generic input layer
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties
        % Name (char array)   A name for the layer
        Name
    end
    
    properties (Constant)
        % DefaultName   Default layer's name.
        DefaultName = 'input'
    end
    
    properties (SetAccess = private)
        % HasSizeDetermined   True for layers with size determined.
        HasSizeDetermined
        
        % InputSize (vector of int)   Size of the input, including the
        % size of each spatial dimension and the number of channels.
        InputSize
        
        % Normalization   An InputTransform object.
        Normalization
    end
    
    properties(Dependent)
        % Mean   The mean of the training data. Stored when the user
        % requests zero center or zscore normalization. Assume the value
        % is either a per channel mean containing as many values as
        % channels, or a full mean of the same size as one observation of
        % the input data.
        Mean
        
        % Std    The standard deviation of the training data. Stored when
        % the user requests zscore normalization. Assume the value is
        % either a standard deviation value per channel, or an array of
        % standard deviations of the same size as one observation of the
        % input data.
        Std
        
        % Min    The minimum of the training data. Stored when the user
        % requests rescaling. Assume the value is either a minimum value
        % per channel, or an array of minima of the same size as one
        % observation of the input data.
        Min
        
        % Max    The maximum of training images. Stored when the user
        % requests rescaling. Assume the value is either a maximum value
        % per channel, or an array of maxima of the same size as one
        % observation of the input data.
        Max
        
        % NormalizationDimensions   A char vector describing the dimensions
        % to normalize over independently.
        NormalizationDimension
    end
    
    properties(Access = private)
        PrivateNormalizationDimension = 'auto'
    end
    
    methods
        function this = GenericInput(name, inputSize, normalization)
            this.Name = name;
            this.InputSize = inputSize;
            this.Normalization = normalization;
            this.HasSizeDetermined = true;
            
            % Input layer doesn't need X or Z for the backward pass
            this.NeedsXForBackward = false;
            this.NeedsZForBackward = false;
            
            this.InputValidationStrategy = ...
                nnet.internal.cnn.layer.util.ImageInputValidator(this.InputSize);
        end
        
        function Z = predict( this, X )
            % predict   Forward propagation at train and test time
            
            % Apply normalization
            Z = this.Normalization.apply(X);
        end
        
        function [dX,dW] = backward( ~, ~, ~, ~, ~ )
            % backward  Return empty value
            dX = [];
            dW = [];
        end
        
        function outputSize = forwardPropagateSize(this, ~)
            % forwardPropagateSize  Output the size of the layer
            outputSize = this.InputSize;
        end
        
        function this = inferSize(this, ~)
            % inferSize     no-op since this layer has nothing that can be
            %               inferred
        end
        
        function tf = isValidInputSize(this, inputSize)
            % isValidInputSize   Check if the layer can accept an input of
            % a certain size
            tf = isequal( inputSize, this.InputSize );
        end
        
        function this = initializeLearnableParameters(this, precision)
            % initializeLearnableParameters     Cast the user provided mean
            % value to the precision used for training and inference.
            this.Mean = precision.cast(this.Mean);
            this.Std = precision.cast(this.Std);
            this.Min = precision.cast(this.Min);
            this.Max = precision.cast(this.Max);
        end
        
        function this = prepareForTraining(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.TrainingLearnableParameter.empty();
        end
        
        function this = prepareForPrediction(this)
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
        end
        
        function this = setupForHostPrediction(this)
            this.Normalization = setupForHostTransform(this.Normalization);
        end
        
        function this = setupForGPUPrediction(this)
            this.Normalization = setupForGPUTransform(this.Normalization);
        end
        
        function this = setupForHostTraining(this)
            this.Mean = gather(this.Mean);
            this.Std = gather(this.Std);
            this.Min = gather(this.Min);
            this.Max = gather(this.Max);
        end
        
        function this = setupForGPUTraining(this)
        end
        
        function value = get.NormalizationDimension(this)
            value = this.PrivateNormalizationDimension;
        end
        
        function this = set.NormalizationDimension(this,value)
            this.PrivateNormalizationDimension = value;
            % Update the normalization dimension in the underlying transform
            if ~isempty(this.Normalization) && ~iIsCustomNormalization(this.Normalization)
                this.Normalization.NormalizationDimension = value;
            else
                % This case should have been caught throug the external
                % layer API.
            end
        end
        
        function I = get.Mean(this)
            % Get the mean from internal normalization transform object.
            if iIsStatisticUsed(this.Normalization,'Mean')
                I = this.Normalization.Mean;
            else
                I = [];
            end
        end
        
        function this = set.Mean(this, val)
            % Update value of Mean. Forwards to transform set.Mean method. 
            if iIsStatisticUsed(this.Normalization,'Mean')
                this.Normalization.Mean = val;
            end
        end
        
        function I = get.Std(this)
            % Get standard deviation from internal transform
            if iIsStatisticUsed(this.Normalization,'StandardDeviation')
                I = this.Normalization.Std;
            else
                I = [];
            end
        end
        
        function this = set.Std(this, val)
            % Update value of Std. Forwards to transform set.Std method.
            if iIsStatisticUsed(this.Normalization,'StandardDeviation')
                this.Normalization.Std = val;
            end
        end
        
        function I = get.Min(this)
            % Get minimum from internal transform
            if iIsStatisticUsed(this.Normalization,'Min')
                I = this.Normalization.Min;
            else
                I = [];
            end
        end
        
        function this = set.Min(this, val)
            % Update value of Min. Forwards to transform set.Min method.
            if iIsStatisticUsed(this.Normalization,'Min')
                this.Normalization.Min = val;
            end
        end
        
        function I = get.Max(this)
            % Get maximum from internal transform
            if iIsStatisticUsed(this.Normalization,'Max')
                I = this.Normalization.Max;
            else
                I = [];
            end
        end
        
        function this = set.Max(this, val)
            % Update value of Max. Forwards to transform set.Max method.
            if iIsStatisticUsed(this.Normalization,'Max')
                this.Normalization.Max = val;
            end
        end
        
        function this = reset(this)
            if ~isempty(this.Normalization)
                this.Normalization = reset(this.Normalization);
            end
        end
        
        function this = initialize(this, stats)
            if ~isempty(this.Normalization)
                this.Normalization = initialize(this.Normalization, stats);
            end
        end
        
        function tf = needsInitialization(this)
            tf = ~isempty(this.Normalization) && needsInitialization(this.Normalization);
        end
        
    end
end

function tf = iIsStatisticUsed(transform,statsName)
tf = ~isempty(transform) && ismember(statsName,transform.Hyperparams);
end

function tf = iIsCustomNormalization(normalization)
tf = isa(normalization,'nnet.internal.cnn.layer.CustomNormalization');
end