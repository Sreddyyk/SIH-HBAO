classdef Convolution3DFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy
    % Convolution3DFunctionalStrategy    dlarray method strategy
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X, ...
                weights, bias, ...
                padding, ... %top bottom left right front back
                stride, dilation)

            % TODO (g2000679): use internal API            
            Z = dlconv(X, weights, bias, ...
                'Stride', stride, ...
                'DilationFactor', dilation, ...
                'Padding', [padding(1:2:end); padding(2:2:end)]);
            
            memory = [];
        end
    end
end
