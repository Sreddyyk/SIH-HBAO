classdef (Abstract) CPUFusableLayer
   % CPUFusableLayer  Interface for layers that can be generically fused
   % on the CPU
   
   % Copyright 2019 The MathWorks, Inc.
    
    methods (Abstract, Hidden)
        layerArgs = getFusedArguments(layer);
        tf = isFusable(layer,precision,numDataDimensions);
    end
    
end