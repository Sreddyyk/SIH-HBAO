classdef LSTMFunctionalReturnLastStrategy < ...
        nnet.internal.cnn.layer.util.LSTMFunctionalStrategy
    % LSTMFunctionalReturnLastStrategy    dlarray method strategy
    
    %   Copyright 2019 The MathWorks, Inc.

    methods
        function [Y, memory] = forward(this, X, W, R, b, c0, y0)
            
            [Y,memory] = ...
                forward@nnet.internal.cnn.layer.util.LSTMFunctionalStrategy(this,...
                X, W, R, b, c0, y0);

            Y = iGetLastSequenceElement(Y);
        end
    end
end

function y = iGetLastSequenceElement(y)
% Get the last element of a dlarray in the sequence dimension, and remove
% the singleton 'T' dimension.
timeDim = finddim(y,'T');
if ~isempty(timeDim)
    indexer = repmat({':'}, [1, ndims(y)]);
    indexer{timeDim} = size(y,timeDim);
    y = y(indexer{:});
    % Remove label 'T'
    labels = dims(y);
    labels(timeDim) = [];
    y = dlarray(stripdims(y),labels);
end
end 