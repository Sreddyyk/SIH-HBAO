classdef InputTransform < matlab.mixin.Heterogeneous
    % InputTransform   Abstract data transform class.

    %   Copyright 2015-2019 The MathWorks, Inc.
    
    properties(Abstract, Constant)
        % Type   The type corresponding to a transformation
        Type(1,:) char
        
        % Hyperparams   List of properties of the transformation that
        % represent hyperparameters.
        Hyperparams cell
    end
    
    properties(Abstract)
        % DataSize   Size of the input data that this transform will transform
        DataSize(1,:) double
    end
    
    methods(Abstract, Access = protected)
        %------------------------------------------------------------------
        % doTransform   Implements an image transformation. Implementations
        % must input a batch of input observations and output a batch of 
        % transformed observations.
        %------------------------------------------------------------------
        doTransform(this)
    end
    
    methods(Abstract)
        %------------------------------------------------------------------
        % serialize   Serialize an image transform to a structure 
        %------------------------------------------------------------------
        S = serialize( this )
    end

    methods(Abstract)
        % forwardPropagateSize   Calculate the output size for this transform
        %   Calculate the output size for this transform based on the input
        %   size. This is needed to check if training images have the
        %   correct dimensions. inputSize is a 3-element vector which is
        %   the size of the input to this layer.
        outputSize = forwardPropagateSize(this, inputSize)
    end
    
    methods
        function this = setupForGPUTransform(this)
            % no-op if not overriden by concrete child class
        end
        
        function this = setupForHostTransform(this)
            % no-op if not overriden by concrete child class
        end
        
        % needsInitialization   Returns true if the transformation requires
        % initialization (e.g. when any required statistics are empty)
        function tf = needsInitialization(~)
            tf = false;
        end
    end
    
    methods(Sealed)
        %------------------------------------------------------------------
        % Applies an array of transforms to a batch of RGB or grayscale
        % images.
        %------------------------------------------------------------------
        function y = apply(this, batch)           
            y = batch;
            for i = 1:numel(this)
                y = doTransform(this(i), y);
            end
        end
        
        %------------------------------------------------------------------
        % Initializes an array of transforms based on input statistics
        %------------------------------------------------------------------
        function this = initialize(this, stats)           
            for i = 1:numel(this)
                this(i) = doInitialize(this(i), stats);
            end
        end
        
        %------------------------------------------------------------------
        % Resets an array of transforms
        %------------------------------------------------------------------
        function this = reset(this)           
            for i = 1:numel(this)
                this(i) = doReset(this(i));
            end
        end
    end
    
    methods(Access = protected)
        %------------------------------------------------------------------
        % doReset  Implements the reset step for an input transformation 
        % Implementations must reset any properties of the InputTransform 
        % that require initialization.
        %------------------------------------------------------------------
        function this = doReset(this)
            % no-op if not overriden by concrete child class
        end        
        
        %------------------------------------------------------------------
        % doInitialize  Implements the initialization step for an input
        % transformation given a statistics accumulator object holding
        % input statistics.
        %------------------------------------------------------------------
        function this = doInitialize(this,~)
            % no-op if not overriden by concrete child class
        end
    end
end