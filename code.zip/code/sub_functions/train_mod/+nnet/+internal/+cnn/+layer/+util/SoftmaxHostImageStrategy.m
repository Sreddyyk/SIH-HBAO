classdef SoftmaxHostImageStrategy < nnet.internal.cnn.layer.util.SoftmaxHostDAGStrategy
    % SoftmaxHostImageStrategy   Execution strategy for running the softmax
    % layer on the host with image inputs

    %   Copyright 2016-2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(this, X, channelDim)
            [Z, memory] = forward@nnet.internal.cnn.layer.util.SoftmaxHostDAGStrategy(this, X, channelDim);
        end
        
        function [dX,dW] = backward(this, Z, dZ, channelDim)
            [dX, dW] = backward@nnet.internal.cnn.layer.util.SoftmaxHostDAGStrategy(this, Z, dZ, channelDim);
        end
    end
end