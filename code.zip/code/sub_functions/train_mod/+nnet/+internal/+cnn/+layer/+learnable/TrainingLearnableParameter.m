classdef TrainingLearnableParameter < nnet.internal.cnn.layer.learnable.LearnableParameter
    % TrainingLearnableParameter   Learnable parameter for use at training time
    %
    %   This class is used to represent learnable parameters during
    %   training. The representation that is used is very simple. the
    %   learnable parameter is stored in the property Value, which can be a
    %   host array, or a gpuArray.
    
    %   Copyright 2016-2019 The MathWorks, Inc.

    properties
        % Value   The value of the learnable parameter
        %   The value of the learnable parameter during training. This can 
        %   be either a host array, or a gpuArray depending on what
        %   hardware resource we are using for training.
        Value

        % LearnRateFactor   Multiplier for the learning rate for this parameter
        %   A scalar double.
        LearnRateFactor

        % L2Factor   Multiplier for the L2 regularizer for this parameter
        %   A scalar double.
        L2Factor
        
        % Initializer   Function to initialize this parameter.
        Initializer
    end
    
    properties( Dependent, SetAccess = private )
        % HostValue  The Value, gathered to the host if necessary
        HostValue
    end
    
    methods
        function val = get.HostValue(this)
            val = gather(this.Value);
        end
    end
    
    methods(Static)
        function obj = fromStruct(s)
            obj = nnet.internal.cnn.layer.learnable.TrainingLearnableParameter();
            obj.Value = s.Value;
            obj.LearnRateFactor = s.LearnRateFactor;
            obj.L2Factor = s.L2Factor;
            if ~isfield(s, 'Initializer') || ~isfield(s.Initializer, 'ConstructorArguments')
                s.Version = 2;
                s.Initializer = iDefaultInitializerStruct();
            end
            obj.Initializer = nnet.internal.cnn.layer.learnable...
                .initializer.Initializer.fromStruct(s.Initializer);
        end
    end
end

function init = iDefaultInitializer()
init = nnet.internal.cnn.layer.learnable.initializer.Zeros();
end

function s = iDefaultInitializerStruct()
s = toStruct(iDefaultInitializer());
end
