classdef CustomLayerAutodiffStrategy
    % CustomLayerAutodiffStrategy   Execution strategy for using a custom
    % intermediate layer in a layer-based environment where the backward
    % method is not overridden in the external custom layer.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        LayerVerifier nnet.internal.cnn.layer.util.CustomLayerVerifier
        LearnableParameterNames cell
        IsForwardDefined(1,1) logical
    end
    
    methods
        function this = CustomLayerAutodiffStrategy( ...
                layerVerifier, learnableNames, isForwardDefined)
            this.LayerVerifier = layerVerifier;
            this.LearnableParameterNames = learnableNames;
            this.IsForwardDefined = isForwardDefined;
        end
        
        function Z = predict(this, layer, X)
            expectedType = iFullType(X);
            X = iConvertToDlarray( iWrapInCell(X) );
            W = iGetExternalLayerParameters(layer,this.LearnableParameterNames);
            W = iConvertToDlarray(W);
            layer = iUpdateExternalLayerParameters( ...
                layer, W, this.LearnableParameterNames );
            try
                [Z{1:layer.NumOutputs}] = predict( layer, X{:} );
            catch cause
                iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomLayer:PredictErrored', class(layer))
            end
            this.LayerVerifier.verifyUnlabeledDlarray( 'predict', layer.OutputNames, Z )
            
            Z = cellfun( @extractdata, Z, 'UniformOutput', false );
            Z = iUnwrapScalarCell(Z);
            this.LayerVerifier.verifyPredictType( layer.OutputNames, expectedType, Z );
        end
        
        function [Z,memory] = forward(this, layer, X)
            expectedType = iFullType(X);
            memory.Restore = iSetupCleanupFunction();
            X = iConvertToRecordingDlarray( iWrapInCell(X) );
            W = iGetExternalLayerParameters(layer,this.LearnableParameterNames);
            W = iConvertToRecordingDlarray(W);
            layer = iUpdateExternalLayerParameters( ...
                layer, W, this.LearnableParameterNames );
            
            try
                [Ztraced{1:layer.NumOutputs}] = forward( layer, X{:} );
            catch cause
                if this.IsForwardDefined
                    iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomLayer:ForwardErrored', class(layer))
                else
                    iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomLayer:PredictErrored', class(layer))
                end
            end
            % Outputs of forward should be unlabeled dlarrays
            if this.IsForwardDefined
                this.LayerVerifier.verifyUnlabeledDlarray( 'forward', layer.OutputNames, Ztraced )
            else
                this.LayerVerifier.verifyUnlabeledDlarray( 'predict', layer.OutputNames, Ztraced )
            end
            
            % Save input and output dlarrays to compute gradients during 
            % backward propagation
            memory.Inputs = X;
            memory.Learnables = W;
            memory.Outputs = Ztraced;
            Ztraced = cellfun( @stop, Ztraced, 'UniformOutput', false);
            
            % Extract numeric data for propagation to the next layer. The
            % layer should have not changed the underlying data type.
            Z = cellfun( @extractdata, Ztraced, 'UniformOutput', false );
            Z = iUnwrapScalarCell(Z);
            if this.IsForwardDefined
                this.LayerVerifier.verifyForwardType( layer.OutputNames, expectedType, Z );
            else
                this.LayerVerifier.verifyPredictType( layer.OutputNames, expectedType, Z );
            end
        end
        
        function varargout = backward(~, layer, ~, ~, dLdZ, memory)
            restore = onCleanup(@()iCleanupHistory(memory));
            Xs = memory.Inputs;
            Zs = memory.Outputs;
            Ws = memory.Learnables;
            dLdZ = iWrapInCell(dLdZ);
            needsWeightGradients = nargout > 1;
            % Only compute weight gradients if requested
            if needsWeightGradients
                XWs = [Xs Ws];
            else
                XWs = Xs;
            end
            % Compute gradients dLdXi and dLdWk from each output (Zj) and
            % gradient (dLdZj) pair (j=1...numOutputs) w.r.t. the inputs Xi
            % (i=1...numInputs) and the learnable parameters Wk (k=1...numParameters).
            try
                dLdXW = deep.internal.propagateAdjoint( dLdZ, Zs, XWs);
            catch cause
                iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomLayer:BackwardErrored', class(layer))
            end
            numInputs = layer.NumInputs;
            varargout{1} = iUnwrapScalarCell(dLdXW(1:numInputs));
            varargout{2} = dLdXW(numInputs+1:end);
        end

    end
end

function varargout = iWrapInCell(varargin)
% Wraps each input argument into a cell. [cell1, cell2,  ..., cellN] =
% iWrapInCell( data1, data2, ..., dataN) combinedCell = iWrapInCell( data1,
% data2, data3, ...)
celldata = cell(1,nargin);
for i = 1:nargin
    if ~iscell(varargin{i})
        % Wrap non-cell data into a cell
        celldata{i} = varargin(i);
    else
        % Reshape cell array input to a row vector
        celldata{i} = reshape(varargin{i},1,[]);
    end
end
if nargout == 1
    % If a single output is requested, concatenate all cell outputs into
    % one cell array row vector
    varargout{1} = [ celldata{:} ];
else
    % If multiple outputs are requested, return each wrapped cell
    % separately
    varargout(1:nargout) = celldata(1:nargout);
end
end

function data = iUnwrapScalarCell(cellData)
if iscell(cellData) && isscalar(cellData)
    data = cellData{1};
else
    data = cellData;
end
end

function typeStruct = iFullType(data)
if iscell(data)
    data = data{1};
end

mainClass = class(data);
if mainClass == "gpuArray"
    underlyingClass = classUnderlying(data);
else
    underlyingClass = '';
end

typeStruct = struct( ...
    'Main', mainClass, ...
    'Underlying', underlyingClass );
end

function paramValues = iGetExternalLayerParameters( layer, paramNames )
numParams = numel(paramNames);
paramValues = cell(1,numParams);
for ii=1:numParams
    paramValues{ii} = layer.(paramNames{ii});
end
end

function layer = iUpdateExternalLayerParameters( layer, paramValues, paramNames )
for ii=1:numel(paramNames)
    layer.(paramNames{ii}) = paramValues{ii};
end
end

function out = iConvertToDlarray( in )
if iscell(in)
    out = cellfun( @iConvertToDlarray, in, 'UniformOutput', false);
else
    out = dlarray(in);
end
end

function out = iConvertToRecordingDlarray( in )
if iscell(in)
    out = cellfun( @iConvertToRecordingDlarray, in, 'UniformOutput', false);
else
    out = dlarray(in);
    out = deep.internal.recording.recordContainer(out);
end
end

function restore = iSetupCleanupFunction()
persistent tm;
if isempty(tm)
    tm = deep.internal.recording.TapeManager();
end
restore = [];
tracingCount = getTracingCount(tm);
if (tracingCount == 0)
    restore = deep.internal.startTracingAndSetupCleanup(tm);
end
end

function iCleanupHistory(history)
history.Restore = [];
end

function iThrowWithCause( cause, errorID, varargin )
exception = MException( message( errorID, varargin{:} ) );
exception = exception.addCause( cause );
throwAsCaller( exception );
end
