classdef Zeros < ...
        nnet.internal.cnn.layer.learnable.initializer.Initializer & ...
        nnet.internal.cnn.layer.learnable.initializer.BasicMixin    
    % Zeros    Zeros initializer
   
    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function this = Zeros()
            this.Name = 'zeros';
            this.Fcn = @zeros;
        end        
    end
end