classdef SoftmaxGPUImageStrategy < nnet.internal.cnn.layer.util.SoftmaxGPUDAGStrategy
    % SoftmaxGPUImageStrategy   Execution strategy for running the softmax
    % layer on the GPU with image inputs

    %   Copyright 2016-2019 The MathWorks, Inc.
end