classdef GlobalMaxPooling3D < nnet.internal.cnn.layer.FunctionalLayer
    % GlobalMaxPooling3D   3-D Global max pooling
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        % LearnableParameters   Learnable parameters for the layer
        %   This layer has no learnable parameters.
        LearnableParameters = nnet.internal.cnn.layer.learnable...
            .PredictionLearnableParameter.empty();
        
        % Name (char array)   A name for the layer
        Name
    end
    
    properties
        % Learnables   Empty
        Learnables
    end
    
    properties(SetAccess=protected, GetAccess=?nnet.internal.cnn.dlnetwork)
        % LearnablesNames   Empty
        LearnablesNames
    end
    
    properties (Constant)
        % DefaultName   Default layer's name.
        DefaultName = 'gmp'
    end
    
    properties (SetAccess = private)
        % InputNames   This layer has a single input
        InputNames = {'in'}
        
        % OutputNames   This layer has a single output
        OutputNames = {'out'}
        
        % HasSizeDetermined   True for layers with size determined.
        HasSizeDetermined = true
    end
    
    properties(Access = private)
        ExecutionStrategy
    end
    
    methods
        function this = GlobalMaxPooling3D(name) 
            this.Name = name;            
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.GlobalMaxPooling3DHostStrategy();            
            this.NeedsXForBackward = true;
            this.NeedsZForBackward = true;
        end
        
        function Z = predict(this, X)
            Z = this.ExecutionStrategy.forward(X);
        end
        
        function [dX,dW] = backward(this, X, Z, dZ, ~)
            [dX, dW] = this.ExecutionStrategy.backward(Z, dZ, X);
        end
        
        function tf = isValidInputSize(~, inputSize)
            tf = numel(inputSize) == 4;
        end
        
        function outputSize = forwardPropagateSize(~, inputSize)
            % Assumes isValidInputSize has been called
            outputSize = [1 1 1 inputSize(4)];
        end
        
        % No ops:
        function this = inferSize(this, ~)
        end

        function this = initializeLearnableParameters(this, ~)
        end

        function this = prepareForTraining(this)
        end
        
        function this = prepareForPrediction(this)
        end
        
        function this = setupForHostPrediction(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.GlobalMaxPooling3DHostStrategy();
        end
        
        function this = setupForGPUPrediction(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.GlobalMaxPooling3DGPUStrategy();
        end
        
        function this = setupForHostTraining(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.GlobalMaxPooling3DHostStrategy();
        end
        
        function this = setupForGPUTraining(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.GlobalMaxPooling3DGPUStrategy();
        end
    end
    
    methods(Access=protected)
        function this = setFunctionalStrategy(this)
            this.ExecutionStrategy = nnet.internal.cnn.layer.util.GlobalMaxPooling3DFunctionalStrategy();
        end
    end
end
