classdef GRU < nnet.internal.cnn.layer.FunctionalStatefulLayer ...
        & nnet.internal.cnn.layer.Recurrent
    % GRU   Implementation of the GRU layer
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        % LearnableParameters   Learnable parameters for the layer
        % (Vector of nnet.internal.cnn.layer.learnable.PredictionLearnableParameter)
        LearnableParameters = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.empty();
        
        % DynamicParameters   Dynamic parameters for the layer
        % (Vector of nnet.internal.cnn.layer.dynamic.TrainingDynamicParameter)
        DynamicParameters = nnet.internal.cnn.layer.dynamic.TrainingDynamicParameter.empty();
        
        % Initial hidden state   Initial value of the hidden state
        InitialHiddenState

        % Name (char array)   A name for the layer
        Name
    end
    
    properties (Constant)
        % DefaultName   Default layer's name
        DefaultName = 'gru'
    end
    
    properties (SetAccess = private)
        % InputNames   This layer has a single input
        InputNames = {'in'}
        
        % OutputNames   This layer has a single output
        OutputNames = {'out'}
        
        % InputSize (int) Size of the input vector
        InputSize
        
        % HiddenSize (int) Size of the hidden weights in the layer
        HiddenSize
        
        % ReturnSequence (logical) If true, output is a sequence. Otherwise
        % output is the last element in a sequence.
        ReturnSequence
        
        % RememberHiddenState (logical) If true, hidden state is remembered
        RememberHiddenState
        
        % Activation   (char) Activation function
        Activation
        
        % RecurrentActivation   (char) Recurrent activation function
        RecurrentActivation

        % ResetGateMode (char) If 'after-multiplication', the reset
        % variable is applied after matrix multiplication. Otherwise it is
        % applied before matrix multiplication
        ResetGateMode
    end
    
    properties(Access = private)
        ExecutionStrategy
        
        ParamTableCreator = nnet.internal.cnn.layer.util.ParamTableCreator;       
    end
    
    properties (Dependent)
        % Learnable Parameters (nnet.internal.cnn.layer.LearnableParameter)
        InputWeights
        RecurrentWeights
        Bias
        % Dynamic Parameters (nnet.internal.cnn.layer.DynamicParameter)
        HiddenState
        % Learnables    Cell array of learnable parameters
        Learnables
        % State    Table with hidden states
        State
    end
    
    properties(SetAccess=protected, GetAccess=?nnet.internal.cnn.dlnetwork)
        LearnablesNames = ["InputWeights" "RecurrentWeights" "Bias"]
    end    
    
    properties(Constant)
        % StateNames    Names of state parameters
        StateNames = "HiddenState"
    end
    
    properties (Dependent, SetAccess = private)
        % HasSizeDetermined   Specifies if all size parameters are set
        %   If the input size has not been determined, then this will be
        %   set to false, otherwise it will be true
        HasSizeDetermined        
    end
    
    properties (Constant, Access = private)
        % InputWeightsIndex   Index of the Weights into the
        % LearnableParameters vector
        InputWeightsIndex = 1;
        
        % RecurentWeightsIndex   Index of the Recurrent Weights into the
        % LearnableParameters vector
        RecurrentWeightsIndex = 2;
        
        % BiasIndex   Index of the Bias into the LearnableParameters vector
        BiasIndex = 3;
        
        % HiddenStateIndex   Index of the hidden state into the
        % DynamicParameters vector
        HiddenStateIndex = 1;
    end
    
    methods
        function this = GRU(name, inputSize, hiddenSize, ...
                rememberHiddenState, returnSequence, ...
                activation, recurrentActivation, resetGateMode)
            % GRU   Constructor for a GRU layer
            %
            %   Create a GRU layer with the following
            %   compulsory parameters:
            %
            %   name                - Name for the layer [char array]
            %   inputSize           - Size of the input vector [int]
            %   hiddenSize          - Size of the hidden units [int]
            %   rememberHiddenState - Remember the hidden state [logical]
            %   returnSequence      - Output as a sequence [logical]
            %   activation          - Activation function 'tanh'/'softsign'
            %   recurrentActivation - Recurrent activation function 'sigmoid'/'hard-sigmoid'
           
            % Set layer name
            this.Name = name;
            
            % Set parameters
            this.InputSize = inputSize;
            this.HiddenSize = hiddenSize;
            this.RememberHiddenState = rememberHiddenState;
            this.ReturnSequence = returnSequence;
            this.Activation = activation;
            this.RecurrentActivation = recurrentActivation;
            this.ResetGateMode = resetGateMode;
            
            % Set weights and bias to be LearnableParameter
            this.InputWeights = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter();
            this.RecurrentWeights = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter();
            this.Bias = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter();
            % Set default initializers. The external layer constructor
            % overwrites these values, which are set only for internal code
            % that bypasses the casual API.
            this.InputWeights.Initializer = iInternalInitializer('narrow-normal');
            this.RecurrentWeights.Initializer = iInternalInitializer('narrow-normal');
            this.Bias.Initializer = iInternalInitializer('zeros');
            
            % Set dynamic parameters
            this.HiddenState = nnet.internal.cnn.layer.dynamic.TrainingDynamicParameter();
            
            % Initialize with host execution strategy
            this.setupForHostTraining();
        end
        
        function [Z, memory] = forward( this, X )
            % forward   Forward input data through the layer at training
            % time and output the result
            opts.ReturnLast = ~this.ReturnSequence;
            opts.StateActivationFunction=this.Activation;
            opts.GateActivationFunction =this.RecurrentActivation;

            [Z, memory] = this.ExecutionStrategy.forward(X,this.InputWeights.Value,...
                                                    this.RecurrentWeights.Value,...
                                                    this.Bias.Value,...
                                                    this.HiddenState.Value,...
                                                    opts);
            if this.hasFunctionalStrategy()
                memory = makeStateTable(this, memory.HiddenState);
            end
        end

        function [Z, state] = predict( this, X )
            % predict   Forward input data through the layer at prediction
            % time and output the result
            if hasFunctionalStrategy(this) && nargout == 2
                [Z, state] = forward(this, X);
            else
                Z = forward(this, X);
            end
        end
        
        function [dX, dW] = backward(this,X,Z,dZ,memory)
            % backward    Back propagate the derivative of the loss function
            % through the layer
            % Get full time history of hidden state and upper layer
            % derivative
            
            opts.ReturnLast = ~this.ReturnSequence;
            opts.StateActivationFunction=this.Activation;
            opts.GateActivationFunction =this.RecurrentActivation;

            [dX, dW] = this.ExecutionStrategy.backward(X,this.InputWeights.Value,...
                                                       this.RecurrentWeights.Value,...
                                                       this.Bias.Value,...
                                                       this.HiddenState.Value,...
                                                       Z, dZ, memory, opts);
        end
        
        function this = inferSize(this, inputSize)
            if ~this.HasSizeDetermined
                this.InputSize = prod(inputSize);
            end
        end
        
        function outputSize = forwardPropagateSize(this, ~)
            outputSize = this.HiddenSize;
        end
        
        function tf = isValidInputSize(this, inputSize)
            % isValidInputSize   Check if the layer can accept an input of
            % a certain size
            scalar = isscalar(inputSize);
            if ~scalar && ~this.hasFunctionalStrategy()
                iThrowNonScalarInputSizeError(inputSize);
            end
            consistentWithInferredSize = true;
            if this.HasSizeDetermined
                consistentWithInferredSize = isequal(this.InputSize, prod(inputSize));
            end
            tf = consistentWithInferredSize;
        end
        
        function outputSeqLen = forwardPropagateSequenceLength(this, inputSeqLen, ~)
            % forwardPropagateSequenceLength   The sequence length of the
            % output of the layer given an input sequence length
            
            % The output sequence length of a recurrent layer depends on
            % the OutputMode (ReturnSequence) of the layer
            if this.ReturnSequence
                outputSeqLen = inputSeqLen;
            else
                outputSeqLen = { 1 };
            end
        end
        
        function this = initializeLearnableParameters(this, precision)
            % initializeLearnableParameters    Initialize learnable
            % parameters using their initializer
            
            if isempty(this.InputWeights.Value)
                % Initialize only if it is empty
                weightsSize = [3*this.HiddenSize, this.InputSize];
                weights = this.InputWeights.Initializer.initialize(...
                    weightsSize, 'InputWeights');
                this.InputWeights.Value = precision.cast(weights);
            else
                % Cast to desired precision
                this.InputWeights.Value = precision.cast(this.InputWeights.Value);
            end
            
            if isempty(this.RecurrentWeights.Value)
                % Initialize only if it is empty
                weightsSize = [3*this.HiddenSize, this.HiddenSize];
                weights = this.RecurrentWeights.Initializer.initialize(...
                    weightsSize, 'RecurrentWeights');
                this.RecurrentWeights.Value = precision.cast(weights);
            else
                % Cast to desired precision
                this.RecurrentWeights.Value = precision.cast(this.RecurrentWeights.Value);
            end
            
            if isempty(this.Bias.Value)
                % Initialize only if it is empty
                biasSize = [3*this.HiddenSize, 1];               
                bias = this.Bias.Initializer.initialize(biasSize, 'Bias');
                this.Bias.Value = precision.cast(bias);
            else
                % Cast to desired precision
                this.Bias.Value = precision.cast(this.Bias.Value);
            end
        end
        
        function this = initializeDynamicParameters(this, precision)
           % initializeDynamicParameters   Initialize dynamic parameters

           % Hidden units
           if isempty(this.InitialHiddenState)
               parameterSize = [this.HiddenSize 1];
               this.InitialHiddenState = iInitializeConstant(parameterSize, precision);
           else
               this.InitialHiddenState = precision.cast(this.InitialHiddenState);
           end
           % Set the running hidden state
           this.HiddenState.Value = this.InitialHiddenState;
           this.HiddenState.Remember = this.RememberHiddenState;
        end
        
        function this = updateDynamicParameters(this, Z, ~)
            % updateDynamicParameters   Update the dynamic parameters of
            % the layer using "Z" - the outputs of the forward propagation
            % method.
            
            % Update the hidden state
            if this.DynamicParameters(this.HiddenStateIndex).Remember 
                this.DynamicParameters(this.HiddenStateIndex).Value = Z(:, :, end);
            end
        end
        
        function state = computeState(this, ~, Z, ~, propagateState)
            % state{1} - store hidden state
            state = cell(1,1);
            if propagateState
                state{this.HiddenStateIndex} = Z(:, :, end);
            else
                state{this.HiddenStateIndex} = this.InitialHiddenState;
            end
        end
        
        function this = updateState(this, state)
            % Update the hidden state
            if this.DynamicParameters(this.HiddenStateIndex).Remember
                this.DynamicParameters(this.HiddenStateIndex).Value = gather(state{1});
            end
        end 
        
        function this = prepareForTraining(this)
            % prepareForTraining   Prepare this layer for training
            %   Before this layer can be used for training, we need to
            %   convert the learnable parameters to use the class
            %   TrainingLearnableParameter.
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2training(this.LearnableParameters);
        end
        
        function this = prepareForPrediction(this)
            % prepareForPrediction   Prepare this layer for prediction
            %   Before this layer can be used for prediction, we need to
            %   convert the learnable parameters to use the class
            %   PredictionLearnableParameter.
            this.LearnableParameters = nnet.internal.cnn.layer.learnable.convert2prediction(this.LearnableParameters);
        end
        
        function this = setupForHostPrediction(this)
            this = this.setupForHostTraining();
            this.LearnableParameters(1).UseGPU = false;
            this.LearnableParameters(2).UseGPU = false;
            this.LearnableParameters(3).UseGPU = false;
        end
        
        function this = setupForGPUPrediction(this)
            this = this.setupForGPUTraining();
            this.LearnableParameters(1).UseGPU = true;
            this.LearnableParameters(2).UseGPU = true;
            this.LearnableParameters(3).UseGPU = true;
        end
        
        function this = setupForHostTraining(this)
            this.ExecutionStrategy = this.getHostStrategy();
        end
        
        function this = setupForGPUTraining(this)
            this.ExecutionStrategy = this.getGPUStrategy();
        end
        
        % Setter and getter for InputWeights, RecurrentWeights and Bias
        % These make easier to address into the vector of LearnableParameters
        % giving a name to each index of the vector
        function weights = get.InputWeights(this)
            weights = this.LearnableParameters(this.InputWeightsIndex);
        end
        
        function this = set.InputWeights(this, weights)
            this.LearnableParameters(this.InputWeightsIndex) = weights;
        end
        
        function weights = get.RecurrentWeights(this)
            weights = this.LearnableParameters(this.RecurrentWeightsIndex);
        end
        
        function this = set.RecurrentWeights(this, weights)
            this.LearnableParameters(this.RecurrentWeightsIndex) = weights;
        end
        
        function bias = get.Bias(this)
            bias = this.LearnableParameters(this.BiasIndex);
        end
        
        function this = set.Bias(this, bias)
            this.LearnableParameters(this.BiasIndex) = bias;
        end
        
        % Setter and getter for HiddenState

        function state = get.HiddenState(this)
            state = this.DynamicParameters(this.HiddenStateIndex);
        end
        
        function this = set.HiddenState(this, state)
            this.DynamicParameters(this.HiddenStateIndex) = state;
        end
        
        % Getter for HasSizeDetermined
        function tf = get.HasSizeDetermined(this)
            tf = ~isempty( this.InputSize );
        end 
        
        function learnables = get.Learnables(this)
            % Assume setupForFunctional has been called
            inW = this.InputWeights.Value;
            recW = this.RecurrentWeights.Value;
            b = this.Bias.Value;
            learnables = {inW, recW, b};
        end
        
        function this = set.Learnables(this, learnables)
            % Assume setupForFunctional has been called
            hiddenSize = this.HiddenSize;
            nnet.internal.cnn.layer.paramvalidation.assertValidLearnables(learnables{1}, [3*hiddenSize, this.InputSize]);
            nnet.internal.cnn.layer.paramvalidation.assertValidLearnables(learnables{2}, [3*hiddenSize, hiddenSize]);
            nnet.internal.cnn.layer.paramvalidation.assertValidLearnables(learnables{3}, [3*hiddenSize, 1]);
            
            this.LearnableParameters(this.InputWeightsIndex).Value = learnables{1};
            this.LearnableParameters(this.RecurrentWeightsIndex).Value = learnables{2};
            this.LearnableParameters(this.BiasIndex).Value = learnables{3};
        end
        
        function t = get.State(this)
            t = makeStateTable(this, this.HiddenState.Value);
        end
        
        function this = set.State(this, state)
            % Assume setupForFunctional has been called
            nnet.internal.cnn.layer.util.ParamTableCreator.assertTableContents(state, ...
                this.Name, this.StateNames);
            
            % We have already asserted that the table contains values in the order we
            % expect, so we can directly index them out.
            v = state.Value;
            hiddenState = v{1};
            
            expectedClass = {'single'};
            expectedAttributes = {'size', [this.HiddenSize NaN]};
            validateattributes(hiddenState, expectedClass, expectedAttributes);
            
            this.HiddenState.Value = hiddenState;
        end
    end
    
    methods(Access = private)
        function executionStrategy = getHostStrategy(this)
            if this.hasDefaultResetGateMode()
                executionStrategy=nnet.internal.cnn.layer.util.GRUHostGeneralStrategy();
            else
                executionStrategy=nnet.internal.cnn.layer.util.GRUResetBeforeMultiplicationGeneralStrategy();            
            end
        end
        
        function executionStrategy = getGPUStrategy(this)
            if this.hasDefaultResetGateMode()
                if this.hasDefaultActivations()
                    if this.ReturnSequence
                        executionStrategy=nnet.internal.cnn.layer.util.GRUGPUStrategy();
                    else
                        executionStrategy=nnet.internal.cnn.layer.util.GRUGPUReturnLastStrategy();
                    end
                else
                    executionStrategy=nnet.internal.cnn.layer.util.GRUGPUGeneralStrategy();
                end
            else
                executionStrategy=nnet.internal.cnn.layer.util.GRUResetBeforeMultiplicationGeneralStrategy();
            end
        end
        
        function tf = hasDefaultActivations(this)
            tf = ismember( this.Activation, {'tanh'} ) && ismember( this.RecurrentActivation, {'sigmoid'} );
        end
        
        function tf = hasDefaultResetGateMode(this)
           tf = ismember( this.ResetGateMode, {'after-multiplication'} ) ;
        end
        
        function tbl = makeStateTable(this, hiddenstate)
            persistent protoTable
            if isempty(protoTable)
                protoTable = create(this.ParamTableCreator, ...
                "", this.StateNames, ...
                {[]});
            end
            
            % Assume setupForFunctional has been called
            tbl = protoTable;
            lname = string(this.Name);
            tbl.Layer = lname;
            tbl.Value = {hiddenstate};
        end
        
        function tf = hasFunctionalStrategy(this)
            tf = isa(this.ExecutionStrategy,'nnet.internal.cnn.layer.util.GRUFunctionalStrategy');
        end
    end
    
    methods(Access=protected)
        function this = setFunctionalStrategy(this)
            if ~this.hasDefaultActivations()
                error(message(...
                    'nnet_cnn:internal:cnn:layer:GRU:NonDefaultActivFunctional'))
            end
            if ~this.hasDefaultResetGateMode()
                error(message(...
                    'nnet_cnn:internal:cnn:layer:GRU:NonDefaultResetGateModeFunctional'))
            end
            this.ExecutionStrategy=nnet.internal.cnn.layer.util.GRUFunctionalStrategy;
        end

        function this = initializeStates(this)
            % initializeStates    Zero as init value if empty
            precision = nnet.internal.cnn.util.Precision('single');
            this = initializeDynamicParameters(this, precision);
        end
    end
end

function parameter = iInitializeConstant(parameterSize, precision)
parameter = precision.cast( ...
    zeros(parameterSize) );
end

function initializer = iInternalInitializer(name)
initializer = nnet.internal.cnn.layer.learnable.initializer...
    .initializerFactory(name);
end

function iThrowNonScalarInputSizeError(inputSize)
error( message('nnet_cnn:internal:cnn:layer:GRU:NonScalarInputSize', ...
    iSizeToString(inputSize)) );
end

function str = iSizeToString(sz)
str = join(string(sz), matlab.internal.display.getDimensionSpecifier);
end