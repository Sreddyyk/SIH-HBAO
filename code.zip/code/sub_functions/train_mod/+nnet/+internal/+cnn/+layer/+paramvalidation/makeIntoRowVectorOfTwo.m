function rowVectorOfTwo = makeIntoRowVectorOfTwo(scalarOrRowVectorOfTwo)
% makeIntoRowVectorOfTwo   Convert into row of two values. Expects scalar
% or already row of two.

%   Copyright 2018 The MathWorks, Inc.

if(iIsRowVectorOfTwo(scalarOrRowVectorOfTwo))
    rowVectorOfTwo = scalarOrRowVectorOfTwo;
else
    rowVectorOfTwo = [scalarOrRowVectorOfTwo scalarOrRowVectorOfTwo];
end
end

function tf = iIsRowVectorOfTwo(x)
tf = isrow(x) && numel(x)==2;
end