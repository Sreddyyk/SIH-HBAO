classdef LearnableParameter
    % LearnableParameter   Interface for learnable parameters

    %   Copyright 2015-2019 The MathWorks, Inc.

    properties(Abstract)
        % Value   The value of the learnable parameter
        %   An array which can be a gpuArray, a host array or a dlarray.
        Value

        % LearnRateFactor   Multiplier for the learning rate for this parameter
        %   A scalar double.
        LearnRateFactor

        % L2Factor   Multiplier for the L2 regularizer for this parameter
        %   A scalar double.
        L2Factor
        
        % Initializer   Function to initializer this parameter
        Initializer
    end
    
    methods(Static, Abstract)
        fromStruct(s)
    end
    
    methods       
        function s = toStruct(this)
            % Convert to a structure ready for serialization
            s.Version = 2;
            s.Value = gather(this.Value);
            s.LearnRateFactor = this.LearnRateFactor;
            s.L2Factor = this.L2Factor;
            s.Initializer = toStruct(this.Initializer);
        end
    end
end
