classdef VarianceScalingMixin
    % VarianceScalingMixin   Mixin for initializers with variance scaling
    %
    % A variance scaling initializer scales the variance of the
    % distribution the parameters are sampled from by the number of inputs
    % and outputs to the layer, which correspond to specific sizes of the
    % parameter, here encoded by the properties InIdx, OutIdx.
    % To be inherited from concrete builtin initializers whose constructor
    % requires arguments inIdx, outIdx.
   
    %   Copyright 2018 The MathWorks, Inc.

    properties
        % InIdx    Indices of paramSize corresponding to the input dims
        % Stored for computing isequal.
        InIdx

        % OutIdx    Indices of paramSize corresponding to the output dims        
        % Stored for computing isequal.
        OutIdx        
    end

    methods
        % Initialize parameters
        function param = initialize(this, paramSize, ~)            
            param = this.Fcn(paramSize);            
        end
        
        % Convert to struct ready for serialization        
        function s = toStruct(this)
            s.Version = 1;
            s.Class = class(this);
            s.ConstructorArguments = {this.InIdx, this.OutIdx};
        end
    end
    
    methods (Access = protected)
        function tf = privateIsEqual(this, anotherInitializer)
            % If inherited, "this" is instance of the class that inherits.
            if isa(anotherInitializer, class(this))
                tf = isequal(this.InIdx, anotherInitializer.InIdx) && ...
                    isequal(this.OutIdx, anotherInitializer.OutIdx);
            else
                tf = false;
            end
        end
    end
end