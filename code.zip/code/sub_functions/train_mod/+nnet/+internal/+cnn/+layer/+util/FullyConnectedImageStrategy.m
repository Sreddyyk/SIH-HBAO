classdef(Abstract) FullyConnectedImageStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % FullyConnectedImageStrategy   Execution strategy for running the fully connected layer on the host
    
    %   Copyright 2016-2019 The MathWorks, Inc.
    
    methods(Abstract)
        % Send data to desired hardware
        X = sendToDevice(~, X)
        
        % Forward convolution
        Z = convolveForward(~, X, weights);
        
        % Backward data convolution
        dX = convolveBackwardData(X, weights, dZ)
        
        % Backward weights convolution
        dW = convolveBackwardFilter(X, weights, dZ)
        
        % Backward bias convolution
        dB = convolveBackwardBias(dZ)
    end
    
    methods
        function [Z, memory] = forward(this, X, weights, bias, observationDim)
            channelDim = observationDim-1;
            if size(X,channelDim) ~= size(weights,channelDim)
                error(message('nnet_cnn:internal:cnn:layer:FullyConnected:InvalidInputData',...
                    size(X,channelDim), size(weights,channelDim)))
            end
            Z = this.forwardConvolveOrMultiply(X, weights, observationDim) + bias;
            memory = [];
        end
        
        function [dX, dW] = backward(this, X, weights, dZ, observationDim)
            channelDim = observationDim-1;
            if size(X,channelDim) ~= size(weights,channelDim)
                error(message('nnet_cnn:internal:cnn:layer:FullyConnected:InvalidInputData',...
                    size(X,channelDim), size(weights,channelDim)))
            end
            dX = this.backwardConvolveOrMultiply(X, weights, dZ, observationDim);
            needsWeightGradients = nargout > 1;
            if needsWeightGradients
                dW{1} = this.backwardWeights(X, weights, dZ, observationDim);
                dW{2} = this.backwardBias(X, weights, dZ, observationDim);
            end
        end
    end
    
    methods(Access = private)
        function Z = forwardConvolveOrMultiply(this, X, weights, observationDim)
            % If the spatial dimensions (obsDim - 1) of weights and X are the same,
            % use a simple multiply, otherwise use convolution
            batchSizeX = size(X,observationDim);
            batchSizeW = size(weights,observationDim);
            if iNonBatchDimsAreEqual(X, weights, observationDim)
                Z = reshape(this.sendToDevice(weights), [], batchSizeW)' ...
                    * reshape(X, [], batchSizeX);
                switch observationDim
                    case 4 % 4D Tensor
                        Z = reshape(Z, 1, 1, batchSizeW, batchSizeX);
                    case 5 % 5D Tensor
                        Z = reshape(Z, 1, 1, 1, batchSizeW, batchSizeX);
                end
            else
                Z = this.convolveForward(X, weights);
            end
        end
        
        function dX = backwardConvolveOrMultiply(this, X, weights, dZ, observationDim)
            % If the spatial dimensions (obsDim - 1) of weights and X are the same,
            % use a simple multiply, otherwise use convolution
            batchSizeW = size(weights,observationDim);
            if iNonBatchDimsAreEqual(X, weights, observationDim)
                dX = reshape(this.sendToDevice(weights), [], batchSizeW) ...
                    * reshape(dZ, batchSizeW, []);
                dX = reshape(dX, size(X));
            else
                dX = this.convolveBackwardData(X, weights, dZ);
            end
        end
        
        function dW = backwardWeights(this, X, weights, dZ, observationDim)
            % If the first three dimensions of weights and X are the same,
            % use a simple multiply, otherwise use convolution
            batchSizeX = size(X,observationDim);
            batchSizeW = size(weights,observationDim);
            if iNonBatchDimsAreEqual(X, weights, observationDim)
                dW = reshape(this.sendToDevice(X), [], batchSizeX) ...
                    * reshape(dZ, batchSizeW, batchSizeX)';
                dW = reshape(dW, size(weights));
            else
                dW = this.convolveBackwardFilter(X, weights, dZ);
            end
        end
        
        function dBias = backwardBias(this, X, weights, dZ, observationDim)
            % If the first n-1 dimensions of weights and X are the same,
            % use a simple sum, otherwise use convolution
            if iNonBatchDimsAreEqual(X, weights, observationDim)
                dBias = sum(this.sendToDevice(dZ), observationDim);
            else
                dBias = this.convolveBackwardBias(dZ);
            end
        end
    end
end

function tf = iNonBatchDimsAreEqual(X, W, batchDim)
% Checks that the size of each dimension (besides the batch dimension which
% is the last dimension) are equal for inputs X and W.
tf = all(size(X,1:batchDim-1) == size(W,1:batchDim-1));
end