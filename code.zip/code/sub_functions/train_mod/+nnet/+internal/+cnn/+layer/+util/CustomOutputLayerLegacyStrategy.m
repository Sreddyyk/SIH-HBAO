classdef CustomOutputLayerLegacyStrategy
    % CustomOutputLayerLegacyStrategy   Execution strategy for using a
    % custom output layer in a layer-based environment where the
    % backwardLoss method is overridden in the external custom layer.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        LayerVerifier nnet.internal.cnn.layer.util.CustomLayerVerifier
    end
    
    methods
        function this = CustomOutputLayerLegacyStrategy(layerVerifier)
            this.LayerVerifier = layerVerifier;
        end
        
        function loss = forwardLoss( this, layer, Y, T )
            try
                loss = forwardLoss( layer, Y, T );
            catch cause
                iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomOutputLayer:ForwardLossErrored', class(layer))
            end
            this.LayerVerifier.verifyForwardLossSize( loss );
            this.LayerVerifier.verifyForwardLossType( Y, loss );
        end
        
        function dX = backwardLoss( this, layer, Y, T )
            try
                dX = backwardLoss( layer, Y, T );
            catch cause
                iThrowWithCause(cause, 'nnet_cnn:internal:cnn:layer:CustomOutputLayer:BackwardLossErrored', class(layer))
            end
            this.LayerVerifier.verifyBackwardLossSize( Y, dX );
            this.LayerVerifier.verifyBackwardLossType( Y, dX );
        end
    end
end

function iThrowWithCause( cause, errorID, varargin )
exception = MException( message( errorID, varargin{:} ) );
exception = exception.addCause( cause );
throwAsCaller( exception );
end
