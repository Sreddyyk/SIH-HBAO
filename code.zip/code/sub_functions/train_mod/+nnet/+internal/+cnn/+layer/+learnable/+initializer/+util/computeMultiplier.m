function multiplier = computeMultiplier(sz, varianceNormalization, ...
    scale, inIdx, outIdx)
% computeMultiplier    The multiplier for variance scaling initializers

%   Copyright 2018 The MathWorks, Inc.

if ~isequal(varianceNormalization, 'none')
    [numInputs, numOutputs] = iComputeNumInputsAndNumOutputs(sz, inIdx, ...
        outIdx);
    if isequal(varianceNormalization, 'inputs') 
        multiplier = scale / sqrt(numInputs);
    elseif isequal(varianceNormalization, 'outputs') 
        multiplier = scale / sqrt(numOutputs);
    else
        % 'mean'
        multiplier = scale * sqrt(2 / (numInputs + numOutputs));
    end
else
    multiplier = scale;
end
end

function [numInputs, numOutputs] = iComputeNumInputsAndNumOutputs(sz, ...
    inIdx, outIdx)
numInputs = prod(sz(inIdx));
numOutputs = prod(sz(outIdx));
end
