classdef GlobalMaxPooling3DFunctionalStrategy < nnet.internal.cnn.layer.util.FunctionalStrategy
    % GlobalMaxPooling3DFunctionalStrategy   Calls into the dlarray method
    % maxpool
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X)
            
            % TODO (g2092546): use internal API
            Z = maxpool(X, size(X,1:3), ...
                'Padding', [0, 0, 0; 0, 0, 0], ...
                'Stride', [1 1 1]);
            
            memory = [];
        end
    end
end
