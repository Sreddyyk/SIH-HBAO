classdef Crop3DHostStrategy < nnet.internal.cnn.layer.util.ExecutionStrategy
    % Host execution strategy for crop 3D.
    
    % Copyright 2019 The MathWorks, Inc.
    
    properties
        % Strategy to use for cropping (center or manual).
        CropStrategy
    end
    
    methods
        %------------------------------------------------------------------
        function this = Crop3DHostStrategy(cropStrategy)
            this.CropStrategy = cropStrategy;
        end
        
        %------------------------------------------------------------------
        function  [Z, memory] = forward(this, X)
            % Gather data to host. 
            X = iGatherDataToHost(X);
            
            [Z, memory] = this.CropStrategy.forward(X);
        end
        
        %------------------------------------------------------------------
        function [dX,dW] = backward(this, X, dZ)
             % Gather data to host. 
            X  = iGatherDataToHost(X);
            dZ = iGatherDataToHost(dZ);
            
            [dX, dW] = this.CropStrategy.backward(X,dZ);
        end
    end
end

%--------------------------------------------------------------------------
function data = iGatherDataToHost(data)
if iscell(data)
    data = cellfun(@(x)gather(x),data,'UniformOutput',false);
else
    data = gather(data);
end
end