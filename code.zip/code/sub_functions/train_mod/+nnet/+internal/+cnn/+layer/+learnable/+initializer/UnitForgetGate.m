classdef UnitForgetGate < ...
        nnet.internal.cnn.layer.learnable.initializer.Initializer & ...
        nnet.internal.cnn.layer.learnable.initializer.BasicMixin        
    % UnitForgetGateLSTM    UnitForgetGateLSTM initializer
   
    %   Copyright 2018 The MathWorks, Inc.
    
    properties
        % RecurrentType   Either LSTM or BiLSTM
        RecurrentType
    end
    
    methods
        % Overwrite toStruct
        function s = toStruct(this)
            s.Version = 1;
            s.Class = class(this);
            s.ConstructorArguments = {this.RecurrentType};
        end
    end
    
    methods (Access = protected)
        % Overwrite privateIsEqual
        function tf = privateIsEqual(this, anotherInitializer)
            if isa(anotherInitializer, class(this))
                tf = isequal(anotherInitializer.RecurrentType, this.RecurrentType);
            else
                tf = false;
            end
        end
    end
    
    methods
        function this = UnitForgetGate(recurrentType)
            this.Name = 'unit-forget-gate';
            % Use internal method as function, otherwise dependency
            % analysis of the compiler does not pick it up.
            this.Fcn = @(sz) this.unitForgetGateFcn(sz, recurrentType);
            this.RecurrentType = recurrentType;
        end        
    end
    
    methods (Access = private)
        function bias = unitForgetGateFcn(~, sz, type)
        % Initialize forget gate bias to unity, and other biases to zero. See
        % http://jmlr.org/proceedings/papers/v37/jozefowicz15.pdf
        if isequal(type, 'LSTM')
            % Assume that the forget gate is the second group of hiddenSize
            % indices, where sz = [4*hiddenSize 1].
            hiddenSize = sz(1)/4;
            assert(~mod(hiddenSize,1) && sz(2) == 1)
            bias = zeros(sz);
            bias(hiddenSize+1:2*hiddenSize) = 1;
        elseif isequal(type, 'BiLSTM')
            % Assume that the forget gates (forward and backward) are the second
            % and 6th group of hiddenSize indices, where sz = [8*hiddenSize 1].
            hiddenSize = sz(1)/8;
            assert(~mod(hiddenSize,1) && sz(2) == 1)
            bias = zeros(sz);
            % forward
            bias(hiddenSize+1:2*hiddenSize) = 1;
            % backward
            bias(5*hiddenSize+1:6*hiddenSize) = 1;
        else
            % For internal diagnostics
            error('Wrong recurrent type')
        end
        end                     
    end
end