classdef ReLUFunctionalStrategy < ...
        nnet.internal.cnn.layer.util.FunctionalStrategy
    % ReLUFunctionalStrategy    Calls into the dlarray method relu
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function [Z, memory] = forward(~, X)
            
            % TODO: use internal API            
            Z = relu(X);            
            
            memory = [];
        end
    end
end
