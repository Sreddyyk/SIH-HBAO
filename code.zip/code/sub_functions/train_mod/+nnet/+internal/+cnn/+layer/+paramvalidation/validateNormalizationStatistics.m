function validateNormalizationStatistics( userValue, statsName, normalization, normDim, inputSize )
% validateNormalizationStatistics   Throw an error if the statistic value
% for the given normalization is invalid. inputSize is a row vector where 
% the last element contains the number of channels.

%   Copyright 2018-2019 The MathWorks, Inc.

% Check that statistic is allowed to be set for given normalization type
if isa(normalization,'function_handle')
    normalization = 'custom';
end

if statsName == "Mean" && ~ismember(normalization,{'zerocenter','zscore'})
    error(message('nnet_cnn:layer:InputLayer:SettingAverageWhenNotZerocenter'));
end

if statsName == "StandardDeviation" && normalization ~= "zscore"
    error(message('nnet_cnn:layer:InputLayer:SettingStdWhenNotZscore'));
end

if statsName == "Min" && ~ismember(normalization,{'rescale-symmetric','rescale-zero-one'})
    error(message('nnet_cnn:layer:InputLayer:SettingMinWhenNotRescale'));
end

if statsName == "Max" && ~ismember(normalization,{'rescale-symmetric','rescale-zero-one'})
    error(message('nnet_cnn:layer:InputLayer:SettingMaxWhenNotRescale'));
end

% All statistics must be numeric, real and finite
validateattributes(userValue, {'numeric'}, {'real', 'finite'});

% In vector sequence case, accept only column vectors as per-channel 
% statistics if inputSize is scalar
if isscalar(inputSize) && ~isempty(userValue) && ~isscalar(userValue)
    validateattributes(userValue, {'numeric'}, {'size', [inputSize 1]});
end

if ~iHasTheRightSize(userValue, inputSize)
    statsPerChannelSize = inputSize;
    statsPerChannelSize(1:end-1) = 1;
    error( message('nnet_cnn:layer:InputLayer:InvalidStatisticsSize',...
        iSizeToString(inputSize), iSizeToString(statsPerChannelSize), statsName ) );
end

if ~iIsConsistentWithNormalizationDimension(userValue,inputSize,normDim)
    expectedSize = iSizeBasedOnNormDim(inputSize,normDim);
    error( message('nnet_cnn:layer:InputLayer:NormDimIncompatibleWithStatisticsSize',...
        "'"+normDim+"'", statsName, iSizeToString(expectedSize) ) );
end
end

function tf = iHasTheRightSize(value, inputSize)
tf = isempty(value) || isscalar(value) || ...
    iIsStatisticPerElement(value,inputSize) || ...
    iIsStatisticPerChannel(value, inputSize);
end

function tf = iIsConsistentWithNormalizationDimension(userValue,inputSize,normDim)
if strcmp(normDim,'auto') || isempty(userValue)
    tf = true;
else
    expectedSize = iSizeBasedOnNormDim(inputSize,normDim);
    tf = isequal( iSizeWithNDims(userValue,numel(inputSize)), expectedSize );
end
end

function sz = iSizeBasedOnNormDim(inputSize,normDim)
switch normDim
    case 'all'
        sz = ones( size(inputSize) );
    case 'channel'
        sz = inputSize;
        sz(1:end-1) = 1;
    case 'element'
        sz = inputSize;
    case 'auto'
        sz = [];
end
end

function tf = iIsStatisticPerElement(value, inputSize)
% The data statistics should have the same size as the inputSize
sz = iSizeWithNDims(value,numel(inputSize));
tf = isequal(sz,inputSize);
end

function tf = iIsStatisticPerChannel(value, inputSize)
% For a statistic-per-channel, there should be one value per channel. The 
% channel dimension is the last dimension in inputSize. 
expectedSize = ones(1,numel(inputSize));
expectedSize(end) = inputSize(end);
sz = iSizeWithNDims(value,numel(inputSize));
tf = isequal(sz,expectedSize);
end

function sz = iSizeWithNDims(x, numDims)
% Determine size of x, up to at least numDims dimensions. If x has
% non-single dimensions greater than numDims, they will also be returned.
%
% For example:
%
% x = rand([3 1])       iSizeWithNDims(x, 1) == 3
% x = rand([3 1])       iSizeWithNDims(x, 3) == [3 1 1]
% x = rand([3 1 3])     iSizeWithNDims(x, 1) == [3 1 3]
% x = rand([3 2 1])     iSizeWithNDims(x, 3) == [3 2 1]
% x = rand([3 2 1 5])   iSizeWithNDims(x, 3) == [3 2 1 5]

% Determine numDims dimensions
sz = size(x, 1:numDims);

% Add any higher dimensions larger than unity
fullSize = size(x);
extraDims = fullSize(numDims+1:end);

if any(extraDims > 1)
    sz = [sz extraDims];
end
end

function str = iSizeToString(inputSize)
str = "[" + num2str(inputSize) + "]";
end