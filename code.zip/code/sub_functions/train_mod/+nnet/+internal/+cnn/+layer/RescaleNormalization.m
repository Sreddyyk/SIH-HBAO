classdef RescaleNormalization < nnet.internal.cnn.layer.InputTransform
    % RescaleNormalization   Data transform for rescaling normalizations
    %   This class maps the minimum and maximum of the input data to a new
    %   minimum and maximum value.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(Constant)
        Type = 'rescale';
        Hyperparams = { 'Min', 'Max' }
    end
    
    properties
        % DataSize   Size of the data that this transform will transform.
        % DataSize must include the channel dimension even if it is one.
        DataSize
        
        % TargetMin
        TargetMin = []
        
        % TargetMax
        TargetMax = []
    end
    
    properties(Dependent)
        % Min   Mininum over observations. Can either be a vector
        % with a minimum value per data channel or the minimum of the
        % training data with the same size as the input data size.
        Min
        
        % Max   Maximum over observations. Can either be a vector with a
        % maximum value per data channel or the maximum of the training
        % data with the same size as the input data size.
        Max
        
        % NormalizationDimension   Char value that describes which
        % dimensions to normalize via the same statistics.
        NormalizationDimension
    end
    
    properties(Access = private)
        % PrivateUserMin   Minimum over observations. Can either be a
        % scalar, a vector with a min value per data channel, or the min of
        % the training data with the same size as the input data size.
        PrivateUserMin
        
        % PrivateChannelMinCache   Minimum per channel of the trained min.
        % This is only needed when retrieving activations with data of
        % larger spatial dimensions than the training data.
        PrivateChannelMinCache
        
        % PrivateReducedMinCache   Minimum over observations. This is a
        % reduced version of PrivateUserMin based on the
        % NormalizationDimension parameter.
        PrivateReducedMinCache
        
        % PrivateUserMax   Maximum over observations. Can either be a
        % scalar, a vector with a max value per data channel, or the max of
        % the training data with the same size as the input data size.
        PrivateUserMax
        
        % PrivateChannelMaxCache   Maximum per channel of the trained max.
        % This is only needed when retrieving activations with data of
        % larger spatial dimensions than the training data.
        PrivateChannelMaxCache
        
        % PrivateReducedMaxCache   Maximum over observations. This is a
        % reduced version of PrivateUserMax based on the
        % NormalizationDimension parameter.
        PrivateReducedMaxCache
        
        % PrivateNormalizationDimension   NormalizationDimension specified
        % as char value which describes which dimensions to normalize
        % via the same statistics.
        PrivateNormalizationDimension = 'auto'
    end
    
    methods
        function this = RescaleNormalization(inputSize,targetMin,targetMax)
            this.DataSize = inputSize;
            if nargin >=3
                this.TargetMin = targetMin;
                this.TargetMax = targetMax;
            end
            this = reset(this);
        end
        
        function S = serialize( this )
            S.Version = 1.0;
            S.Type = this.Type;
            S.ImageSize = this.DataSize;
            S.Min = this.Min;
            S.Max = this.Max;
            S.TargetMin = this.TargetMin;
            S.TargetMax = this.TargetMax;
        end
        
        function outputSize = forwardPropagateSize(~, inputSize)
            outputSize = inputSize;
        end
        
        function this = set.NormalizationDimension(this,value)
            this.PrivateNormalizationDimension = value;
            % To update the reduced represenations of the statistics based
            % on the new NormalizationDimension value, reassign the statistics.
            this.Min = this.Min;
            this.Max = this.Max;
        end
        
        function value = get.NormalizationDimension(this)
            value = this.PrivateNormalizationDimension;
        end
        
        function this = set.Min(this, value)
            this.PrivateUserMin = value;
            this.PrivateChannelMinCache.Value = iComputeReducedMin( ...
                value, this.DataSize, 'channel' );
            this.PrivateReducedMinCache.Value = iComputeReducedMin( ...
                value, this.DataSize, this.NormalizationDimension);
        end
        
        function value = get.Min(this)
            value = this.PrivateUserMin;
        end
        
        function this = set.Max(this, value)
            this.PrivateUserMax = value;
            this.PrivateChannelMaxCache.Value = iComputeReducedMax( ...
                value, this.DataSize, 'channel' );
            this.PrivateReducedMaxCache.Value = iComputeReducedMax( ...
                value, this.DataSize, this.NormalizationDimension);
        end
        
        function value = get.Max(this)
            value = this.PrivateUserMax;
        end
        
        function tf = needsInitialization(this)
            tf = isempty(this.Min) || isempty(this.Max);
        end
        
        function this = setupForGPUTransform(this)
            this.PrivateReducedMinCache.UseGPU = true;
            this.PrivateChannelMinCache.UseGPU = true;
            this.PrivateReducedMaxCache.UseGPU = true;
            this.PrivateChannelMaxCache.UseGPU = true;
        end
        
        function this = setupForHostTransform(this)
            this.PrivateReducedMinCache.UseGPU = false;
            this.PrivateChannelMinCache.UseGPU = false;
            this.PrivateReducedMaxCache.UseGPU = false;
            this.PrivateChannelMaxCache.UseGPU = false;
        end
    end
    
    methods(Access = protected)
        function this = doReset(this)
            this.PrivateUserMin = [];
            this.PrivateUserMax = [];
            this.PrivateReducedMinCache = iEmptyDoubleParameter();
            this.PrivateChannelMinCache = iEmptyDoubleParameter();
            this.PrivateReducedMaxCache = iEmptyDoubleParameter();
            this.PrivateChannelMaxCache = iEmptyDoubleParameter();
        end
        
        function batch = doTransform(this, batch)
            spatialDims = numel(this.DataSize) - 1;
            
            batchSize = ones(1,numel(this.DataSize));
            batchSize(1:ndims(batch)) = size( batch );
            
            if isequal( batchSize(1:spatialDims), this.DataSize(1:spatialDims) )
                assert(~isempty(this.PrivateReducedMinCache.Value), ...
                    "Min value is empty");
                assert(~isempty(this.PrivateReducedMaxCache.Value), ...
                    "Max value is empty");
                
                batch = iRescale( batch, this.TargetMin, this.TargetMax, ...
                    this.PrivateReducedMinCache.Value, ...
                    this.PrivateReducedMaxCache.Value );
            else
                % The size of the input data is different from the size of
                % the training data and the data statistics. This can only
                % occur when calling activations on larger images. Use the
                % per-channel statistics for normalization.
                assert(~isempty(this.PrivateChannelMinCache.Value), ...
                    "Reduced mean per channel is empty");
                assert(~isempty(this.PrivateChannelMaxCache.Value), ...
                    "Reduced std per channel is empty");
                
                batch = iRescale( batch, this.TargetMin, this.TargetMax, ...
                    this.PrivateChannelMinCache.Value, ...
                    this.PrivateChannelMaxCache.Value );
            end
        end
        
        function this = doInitialize(this, stats)
            % By default, compute per-channel statistics
            if this.NormalizationDimension == "auto"
                normDim = 'channel';
            else
                normDim = this.NormalizationDimension;
            end
            
            if isempty(this.Min)
                perElementMin = gather( getStatistic(stats,'min') );
                this.Min = iComputeReducedMin( perElementMin, ...
                    this.DataSize, normDim );
            end
            
            if isempty(this.Max)
                perElementMax = gather( getStatistic(stats,'max') );
                this.Max = iComputeReducedMax( perElementMax, ...
                    this.DataSize, normDim );
            end
        end
    end
end

function out = iComputeReducedMin(value, dataSize, normDimension)
switch normDimension
    case 'auto'
        out = value;
    case 'element'
        out = value;
    case 'channel'
        spatialDims = 1:(numel(dataSize)-1);
        out = iReduce(value, @min, spatialDims);
    case 'all'
        spatialDims = 1:numel(dataSize);
        out = iReduce(value, @min, spatialDims);
end
end

function out = iComputeReducedMax(value, dataSize, normDimension)
switch normDimension
    case 'auto'
        out = value;
    case 'element'
        out = value;
    case 'channel'
        spatialDims = 1:(numel(dataSize)-1);
        out = iReduce(value, @max, spatialDims);
    case 'all'
        spatialDims = 1:numel(dataSize);
        out = iReduce(value, @max, spatialDims);
end
end

function reducedValue = iReduce(value, fcn, spatialDims)
if isempty(spatialDims)
    reducedValue = value;
else
    reducedValue = fcn(value,[],spatialDims);
end
end

function param = iEmptyDoubleParameter()
param = nnet.internal.cnn.layer.util.CachedParameter([]);
end

function data = iRescale(data,tMin,tMax,dMin,dMax)
if isa(data,'dlarray')
    % When the input data has dimension labels then the min and max values
    % passed to rescale must be either scalar or formatted dlarrays. To
    % circumvent this restriction, labels are removed from the input data.
    dimLabels = dims(data);
    data = stripdims(data);
else
    dimLabels = '';
end

data = rescale( data, tMin, tMax, ...
    'InputMin', dMin, ...
    'InputMax', dMax );

if ~isempty(dimLabels)
    data = dlarray(data,dimLabels);
end
end
