function initializer = initializerFactory(init, varargin)
% initializerFactory   Create initializer from value
%
% init can be function_handle (custom initializer), or string (built-in
% initializer). 

%   Copyright 2018 The MathWorks, Inc.

narginchk(1,3)
   
if isa(init, 'function_handle')
    initializer = nnet.internal.cnn.layer.learnable.initializer...
        .Custom(init);
else
    switch string(init)
        case "narrow-normal"
            initializer = nnet.internal.cnn.layer.learnable.initializer...
                .Normal();
        case "glorot"
            initializer = nnet.internal.cnn.layer.learnable.initializer...
                .Glorot(varargin{1}, varargin{2});
        case "he"
            initializer = nnet.internal.cnn.layer.learnable.initializer...
                .He(varargin{1}, varargin{2});
        case "orthogonal"
            initializer = nnet.internal.cnn.layer.learnable.initializer...
                .Orthogonal();
        case "ones"
            initializer = nnet.internal.cnn.layer.learnable.initializer...
                .Ones();
        case "zeros"
            initializer = nnet.internal.cnn.layer.learnable.initializer...
                .Zeros();
        case "unit-forget-gate"
            initializer = nnet.internal.cnn.layer.learnable.initializer...
                .UnitForgetGate(varargin{1});
        otherwise
            % For internal debug
            error('Invalid initializer string')
    end
end
end