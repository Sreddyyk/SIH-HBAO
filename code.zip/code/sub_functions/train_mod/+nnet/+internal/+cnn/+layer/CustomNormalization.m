classdef CustomNormalization < nnet.internal.cnn.layer.InputTransform
    % CustomNormalization   Custom data transform applied to the input data
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties (Constant)
        Type = 'custom';
        Hyperparams = {};
    end
    
    properties
        % DataSize   Size of the data that this transform will transform.
        % DataSize must include the channel dimension even if it is one.
        DataSize

        % Function   Custom function specified by the user that is used for
        % normalizing the input data. Specified as a function handle.
        Function = @(x)x;
    end
    
    methods
        function this = CustomNormalization(inputSize,fcn)
            this.DataSize = inputSize;
            if nargin>=2
                this.Function = fcn;
            end
        end
        
        function S = serialize( this )
            S.Version = 1.0;
            S.Type = this.Type;
            S.ImageSize = this.DataSize;
            S.Function = this.Function;
        end
        
        function outputSize = forwardPropagateSize(~, inputSize)
            outputSize = inputSize;
        end
        
        function tf = needsInitialization(~)
            tf = false;
        end
        
        function this = setupForGPUTransform(this)
        end
        
        function this = setupForHostTransform(this)
        end
        
        function this = set.Function(this,fcn)
            validateattributes(fcn,{'function_handle'},{})
            this.Function = fcn;
        end
    end
    
    methods(Access = protected)        
        function outputBatch = doTransform(this, inputBatch)
            try
                outputBatch = this.Function( inputBatch );
            catch cause
                iThrowWithCause(cause,'nnet_cnn:internal:cnn:layer:CustomNormalization:NormalizeErrored')
            end
            iAssertOutputSizeIsEqualToInputSize( inputBatch, outputBatch )
            iAssertOutputTypeIsEqualToInputType( inputBatch, outputBatch )
        end
    end
end

function iAssertOutputSizeIsEqualToInputSize( inputBatch, outputBatch )
expectedSize = size(inputBatch);
actualSize = size(outputBatch);
if ~isequal( expectedSize, actualSize )
    iThrow('nnet_cnn:internal:cnn:layer:CustomNormalization:WrongSizeOutput', ...
        iSizeToString(expectedSize), iSizeToString(actualSize) )
end
end

function iAssertOutputTypeIsEqualToInputType( inputBatch, outputBatch )
actualClass = class(outputBatch);
expectedClass = class(inputBatch);
if ~isequal( actualClass, expectedClass )
    iThrow('nnet_cnn:internal:cnn:layer:CustomNormalization:WrongTypeOutput', ...
        expectedClass, actualClass )
end
if expectedClass == "gpuArray"
    actualClassUnderlying = classUnderlying(outputBatch);
    expectedClassUnderlying = classUnderlying(inputBatch);
    if ~isequal( actualClassUnderlying, expectedClassUnderlying )
        iThrow('nnet_cnn:internal:cnn:layer:CustomNormalization:WrongUnderlyingTypeOutput', ...
            expectedClassUnderlying, actualClassUnderlying )
    end
end
end

function sizeString = iSizeToString( sizeVector )
% Convert a size retrieved by "size" into a string separated by "x".
sizeString = join( string( sizeVector ), "x" );
end

function iThrowWithCause( cause, errorID, varargin )
exception = MException( message( errorID, varargin{:} ) );
exception = exception.addCause( cause );
throwAsCaller( exception );
end

function iThrow( msg, varargin )
error( message( msg, varargin{:} ) )
end