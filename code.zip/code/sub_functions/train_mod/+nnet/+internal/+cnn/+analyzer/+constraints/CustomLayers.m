classdef CustomLayers < nnet.internal.cnn.analyzer.constraints.Constraint
    % Names         Constraint object to be used by analyzeNetwork.
    %               Detects issues related to custom layers in the network.
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    methods
        
        function testValidateLayer(test)
            % Test whether custom layers is valid
            
            for i = find([test.LayerAnalyzers.IsCustomLayer])
                % Validate the method signature
                try
                    iValidateMethodSignatures(...
                        test.LayerAnalyzers(i).ExternalLayer );
                catch err
                    test.addLayerErrorWithId(i, err.identifier, ...
                        "CustomLayers:BadMethodSignature", err.message);
                    
                    % Don't continue validating after this, the layer is
                    % already invalid.
                    continue;
                end
                
                % Validate the methods behavior.
                try
                    inputSizes = iGetValidUnwrappedInputSizesOrThrow(...
                        test.LayerAnalyzers(i).Inputs );
                catch
                    % This layer has an invalid input. Trying to check the
                    % input size will error because of this, and not
                    % because of the custom layer.
                    continue;
                end
                
                % Validate the behavior on a single observation.
                try
                    test.LayerAnalyzers(i).InternalLayer.isValidInputSize(inputSizes);
                catch err
                    test.addLayerErrorWithId(i, err.identifier, ...
                        "CustomLayers:CustomLayerVerificationFailed", ...
                        err.message, struct('cause', {err.cause}));
                    
                    % This aready failed, don't validate on minibatch.
                    continue;
                end
                
                % Validate the behavior on a minibatch.
                mbInputSizes = iGenerateMiniBatches(inputSizes);
                try
                    test.LayerAnalyzers(i)...
                        .InternalLayer.isValidInputSize(mbInputSizes);
                catch err
                    test.addLayerErrorWithId(i, err.identifier, ...
                        "CustomLayers:CustomLayerVerificationFailed", ...
                        err.message, struct('cause', {err.cause}));
                end
                
                % Validate that the output of forward and predict have the
                % same size. If not, training would error when using
                % validation data or when performing inference after training
                internalLayer = test.LayerAnalyzers(i).InternalLayer;
                isFunctional = test.LayerAnalyzers(i).IsFunctional;
                fakeData = iMiniBatchData( mbInputSizes, isFunctional );
                try
                    Zforward = internalLayer.forward( fakeData );
                    Zpred = internalLayer.predict( fakeData );
                    outputNames = internalLayer.OutputNames;
                    verifyInferenceSizes( internalLayer.LayerVerifier, ...
                        outputNames, Zpred, Zforward )
                catch err
                    test.addLayerErrorWithId(i, err.identifier, ...
                        "CustomLayers:CustomLayerVerificationFailed", ...
                        err.message, struct('cause', {err.cause}));
                end
            end
        end
        
    end
end

function iValidateMethodSignatures(layer)
nnet.internal.cnn.layer.util.CustomLayerVerifier.validateMethodSignatures(layer);
end

function sz = iGetValidUnwrappedInputSizesOrThrow(inputs)
% Extract column of sizes from inputs table
sz = iUnwrapCell( inputs.Size );
if any(~iIsValidSize(sz))
    error('dummy:id', 'A dummy error.')
end
end

function tf = iIsValidSize(sizeVecs)
% Iterate over a cell array of input sizes and returns a logic value
% for each element in the cell, indicating whether that element is a
% valid size vector or not.
sizeVecs = iWrapInCell(sizeVecs);
tf = false(size(sizeVecs));
for i=1:numel(sizeVecs)
    tf(i) = ~isempty(sizeVecs{i}) ...
        && all(iIsNatural(sizeVecs{i}));
end
end

function tf = iIsNatural(v)
% Returns true if a number belongs to the group of natural numbers
try
    validateattributes(v, {'numeric'},{'positive','integer'});
    tf = true;
catch
    tf = false;
end
end

function inputSizes = iGenerateMiniBatches(inputSizes)
numObs = 5;
inputSizes = iWrapInCell(inputSizes);
for i = 1:numel(inputSizes)
    obsDim = numel(inputSizes{i})+1;
    inputSizes{i}(obsDim) = numObs;
end
inputSizes = iUnwrapCell(inputSizes);
end

function data = iWrapInCell(data)
if ~iscell(data)
    data = {data};
end
end

function data = iUnwrapCell(data)
if iscell(data) && isscalar(data)
    data = data{1};
end
end

function data = iMiniBatchData( inputSizes, isFunctional )
inputSizes = iWrapInCell(inputSizes);
numInputs = numel(inputSizes);
data = cell(1,numInputs);
for i = 1:numInputs
    data{i} = ones([inputSizes{i} 1], 'single');
end

if isFunctional
    data = cellfun(@dlarray, data, 'UniformOutput', false);
end

if numInputs == 1
    data = data{:};
end
end