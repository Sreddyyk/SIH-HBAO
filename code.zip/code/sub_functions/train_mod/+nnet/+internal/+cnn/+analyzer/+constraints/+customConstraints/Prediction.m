classdef Prediction < ...
        nnet.internal.cnn.analyzer.constraints.customConstraints.Common
    % Prediction   Constrain object to be used by analyzeNetwork.
    % Detects issues which specifically prevent a layer graph to be used for
    % constructing a network for prediction. These are:
    % * Empty statistics for an input layer with normalization.
    % * Empty TrainedMean or TrainedVariance for a batch normalization layer.
    % * Unset learnable parameters for a layer with learnable parameters.
    % * Empty ClassNames for a classification output layer.
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    methods

        function testUnsetLearnables(test)
            % Test that a layer with unset learnable parameters errors.
            
            [unsetLearnables, idx] = arrayfun(@iHasUnsetLearnables,...
                test.LayerAnalyzers, 'UniformOutput', false);
            
            for i=find(cell2mat(unsetLearnables)')
                for k=idx{i}'
                    test.addLayerError(i, "Prediction:UnsetLearnable",...
                        test.LayerAnalyzers(i).Learnables.Properties.RowNames{k});
                end
            end
        end
        
        function testEmptyTrainedMean(test)
            % Test that a batch normalization layer with empty
            % TrainedMean errors.
            
            emptyTrainedMean = arrayfun(...
                @iHasEmptyTrainedMean, test.LayerAnalyzers);
            
            for i=find(emptyTrainedMean')
                test.addLayerError(i, "Prediction:EmptyTrainedMean");
            end
        end
        
        function testEmptyTrainedVariance(test)
            % Test that a batch normalization layer with empty
            % TrainedVariance errors.
            
            emptyTrainedVariance = arrayfun(...
                @iHasEmptyTrainedVariance, test.LayerAnalyzers);
            
            for i=find(emptyTrainedVariance')
                test.addLayerError(i, "Prediction:EmptyTrainedVariance");
            end
        end        
        
        function testEmptyClassNames(test)
            % Test whether a classification layer has empty ClassNames.
            % In that case, add a warning.
            
            emptyClassNames = arrayfun(...
                @iHasEmptyClassNames, test.LayerAnalyzers);
            
            for i=find(emptyClassNames')
                test.addLayerWarning(i, "Prediction:FillingInClassNames");
            end
        end
        
        function testConsistentResponseNames(test)
            internalLayers = test.NetworkAnalyzer.InternalLayers;
            if iIsRNN(internalLayers)
                if iHasSeq2Seq(internalLayers)
                    % Response: K x N x S. Valid only 0 or 1 ResponseNames
                    multiResponseNamesWithNonVectorResponse = ...
                        arrayfun(@iMultipleResponseNames, ...
                        test.LayerAnalyzers, 'UniformOutput', false);
                    wrongNumberResposeNames = [];
                    actualNumberOfResponses = [];
                else
                    % Response: K x N. Check correct number
                    multiResponseNamesWithNonVectorResponse = [];
                    [wrongNumberResposeNames, actualNumberOfResponses] = ...
                        arrayfun(@iWrongNumberResponseNamesRNN, ...
                        test.LayerAnalyzers, 'UniformOutput', false);
                end
            else
                [multiResponseNamesWithNonVectorResponse, ...
                    wrongNumberResposeNames, actualNumberOfResponses] = ...
                    arrayfun(@iHasInconsistentResponseNamesImage, ...
                    test.LayerAnalyzers, 'UniformOutput', false);
            end
            
            for i=find(cell2mat(multiResponseNamesWithNonVectorResponse)')
                test.addLayerError(i, "Prediction:MultiResponseNamesForNonVectorResponse");
            end
            
            for i=find(cell2mat(wrongNumberResposeNames)')
                test.addLayerError(i, "Prediction:WrongNumberResponseNames", ...
                    string(actualNumberOfResponses(i)));
            end
        end
    end
end

function tf = iHasEmptyTrainedMean(layerAnalyzer)
tf = layerAnalyzer.IsBatchNormalizationLayer &&...
    isempty(layerAnalyzer.ExternalLayer.TrainedMean);
end

function tf = iHasEmptyTrainedVariance(layerAnalyzer)
tf = layerAnalyzer.IsBatchNormalizationLayer &&...
    isempty(layerAnalyzer.ExternalLayer.TrainedVariance);
end

function [tf, idx] = iHasUnsetLearnables(layerAnalyzer)
if iHasLearnables(layerAnalyzer)
    idx = find(~cell2mat(layerAnalyzer.Learnables.Initialized));
    tf = ~isempty(idx);
else
    idx = [];
    tf = false;
end
end

function tf = iHasLearnables(layerAnalyzer)
tf = ~isempty(layerAnalyzer.Learnables);
end

function tf = iHasEmptyClassNames(layerAnalyzer)
tf = layerAnalyzer.IsClassificationLayer &&...
    isempty(layerAnalyzer.ExternalLayer.ClassNames);
end

function tf = iIsRNN(internalLayers)
tf = nnet.internal.cnn.util.isRNN(internalLayers);
end

function tf = iHasSeq2Seq(internalLayers)
tf = nnet.internal.cnn.util.hasSequenceOutput(internalLayers);
end

function tf = iMultipleResponseNames(layerAnalyzer)
% Using the internal layer to fetch ResponseNames guarantees that the
% property exists since in the internal interface.
tf = layerAnalyzer.IsRegressionLayer && ...
    numel(layerAnalyzer.InternalLayer.ResponseNames) > 1;
end

function [tf, actualNumberOfResponses] = ...
    iWrongNumberResponseNamesRNN(layerAnalyzer)
if iMultipleResponseNames(layerAnalyzer) && ...
        ~isequal(layerAnalyzer.Inputs.Size{1}, ...
        numel(layerAnalyzer.ExternalLayer.ResponseNames))
    tf = true;
    actualNumberOfResponses = layerAnalyzer.Inputs.Size{1};
else
    tf = false;
    actualNumberOfResponses = [];
end
end

function [multiResponseNamesForNonVector, wrongNumberResponseNames, ...
    actualNumberOfResponses] = ...
    iHasInconsistentResponseNamesImage(layerAnalyzer)
if iMultipleResponseNames(layerAnalyzer)
    inputSize = layerAnalyzer.Inputs.Size{1};
    if inputSize(1) == 1 && inputSize(2) == 1
        multiResponseNamesForNonVector = false;
        if ~isequal(....
                numel(layerAnalyzer.ExternalLayer.ResponseNames), inputSize(3))
            wrongNumberResponseNames = true;
            actualNumberOfResponses = inputSize(3);
        else
            wrongNumberResponseNames = false;
            actualNumberOfResponses = [];
        end
    else
        multiResponseNamesForNonVector = true;
        wrongNumberResponseNames = false;
        actualNumberOfResponses = [];
    end
else
    multiResponseNamesForNonVector = false;
    wrongNumberResponseNames = false;
    actualNumberOfResponses = [];
end
end