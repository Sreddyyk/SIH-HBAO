classdef ConnectedComponents < nnet.internal.cnn.analyzer.constraints.Constraint
    % ConnectedComponents  Constraint object to be used by analyzeNetwork.
    %                      Tests that the network consists of one connected
    %                      component.
    
    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        
        function testConnectedComponents(test)
            % Test that the network consists of one connected component.
            
            % Construct a digraph and obtain the connected components
            conn = test.NetworkAnalyzer.HiddenConnections.EndNodes;
            n = numel(test.LayerAnalyzers);
            g = digraph(conn(:,1),conn(:,2),[],n);
            bins = conncomp(g, 'Type', 'weak');
            
            if max(bins) == 1
                % The graph just have one component. Everything is alright.
                return;
            end
            
            % Obtain the first element of each component, and the number of
            % layers in that component.
            [~, iComp] = unique(bins, 'stable');
            nComp = hist(bins, 1:max(bins));
            
            % Sort the components by number of layers
            [nComp, i] = sort(nComp(:), 'descend');
            iComp = iComp(i);
            
            % Get the leading layers names
            names = [test.LayerAnalyzers(iComp).Name]';
            displayName = [test.LayerAnalyzers(iComp).DisplayName]';
            
            % Divide in components and isolated layers
            isIsolated = ( nComp == 1 );
            
            isolated.names = names(isIsolated);
            isolated.displayName = displayName(isIsolated);
            
            nonisolated.names = names(~isIsolated);
            nonisolated.displayName = displayName(~isIsolated);
            nonisolated.size = string(nComp(~isIsolated));
            
            if numel(nonisolated.names) > 1
                test.addIssue("E", "Network", nonisolated.names, ...
                    "ConnectedComponents:MultipleComponents", ...
                    [nonisolated.displayName, nonisolated.size]);
            end
            
            if numel(isolated.names)
                test.addIssue("E", "Network", isolated.names, ...
                    "ConnectedComponents:DisconnectedLayers", ...
                    isolated.displayName);
            end                      
            
        end
    end
end