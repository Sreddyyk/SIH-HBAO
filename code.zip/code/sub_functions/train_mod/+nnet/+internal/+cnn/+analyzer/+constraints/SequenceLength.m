classdef SequenceLength < nnet.internal.cnn.analyzer.constraints.Constraint
    % SequenceLength   Constraint object to be used by analyzeNetwork.
    %    Detects inconsistent sequence lengths within network
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    methods
        function testPropagateSequenceLength(test)
            % Propagate sequence lengths through each layer of the network
            % if we have a sequence input layer
            
            % Sequence length analysis is only needed for networks with a
            % single sequence input layer.
            %
            % We do not attempt sequence length analysis for multi-input
            % networks with sequence inputs, as this behavior is not
            % supported. An error is thrown for this behavior in the
            % LSTM constraint.
            if ~any([test.LayerAnalyzers.IsSequenceSpecificLayer]) || ...
                    ~iHasSingleInput(test.LayerAnalyzers) || ...
                    ~iHasSingleOutput(test.LayerAnalyzers)
                return
            end

            % Do sequence length propagation
            test.propagateSeqLen();
        end
    end
    
    methods(Access = private)
        function propagateSeqLen(test)
            % Iterate through topo-sorted layers and propagate sequence
            % lengths
            
            % Don't attempt any checks if we have multi-input sequence
            % layers.
            
            % Initialize arbitrary sequence length
            inputSeqLen = { iArbitrarySeqLen() };
            
            % Initial table. Assume at least one layer.
            inputs = test.LayerAnalyzers(1).Outputs;
            name = { char( test.LayerAnalyzers(1).Name ) };
            inputSize = inputs.Size(1);
            T = table(name, inputSize, inputSeqLen, ...
                'VariableNames', {'Source', 'Size', 'SeqLen'});
            
            numLayers = numel(test.LayerAnalyzers);
            for ii = 2:(numLayers - 1)
                % Get internal layer
                layer = test.LayerAnalyzers(ii).InternalLayer;
                
                try
                    % Get input layer names, sizes and sequence lengths
                    Ti = test.LayerAnalyzers(ii).Inputs;
                    inputNames = Ti.Source;
                    
                    [~, rows] = intersect(T.Source, [inputNames{:}]);
                    inputSizes = T{rows, 'Size'};
                    inputSeqLen = T{rows, 'SeqLen'};
                    
                    % Forward propagate the sequence lengths
                    outputSeqLen = layer.forwardPropagateSequenceLength( inputSeqLen, inputSizes );
                    outputSeqLen = outputSeqLen(:);
                    
                    % Assign outputs into table
                    layerName = char( layer.Name );
                    if numel(layer.OutputNames) > 1
                        outputNames = strcat([layerName '/'], layer.OutputNames)';
                    else
                        outputNames = {layerName};
                    end
                    outputSizes = test.LayerAnalyzers(ii).Outputs{:,'Size'};
                    To = table(outputNames, outputSizes, outputSeqLen, ...
                        'VariableNames', {'Source', 'Size', 'SeqLen'});
                    T = [T; To]; %#ok<AGROW>
                    
                catch error
                    if iIsInternalException( error )
                        % Re-throw nnet_cnn expection thrown by the layer
                        test.addLayerErrorWithId(ii, error.identifier, ...
                            "SequenceLength:ErrorFromLayer", error.message);
                    else
                        % Throw generic invalid sequence length error
                        test.addLayerError(ii, "SequenceLength:InvalidSeqLen");
                    end
                    % Finish sequence length analysis
                    return
                end
            end
        end
    end
end

function seq = iArbitrarySeqLen()
% Token to describe an arbitrary sequence length
seq = nnet.internal.cnn.util.arbitrarySequenceLengthToken();
end

function tf = iIsInternalException( error )
tf = contains(error.identifier, "nnet_cnn");
end

function tf = iHasSingleInput(layerAnalysers)
tf = sum([layerAnalysers.IsInputLayer]) == 1;
end

function tf = iHasSingleOutput(layerAnalysers)
tf = sum([layerAnalysers.IsOutputLayer]) == 1;
end
