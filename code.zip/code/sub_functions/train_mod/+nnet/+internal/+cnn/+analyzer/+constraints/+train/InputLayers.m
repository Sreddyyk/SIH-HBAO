classdef InputLayers < nnet.internal.cnn.analyzer.constraints.Constraint
    % InputLayers   Constraint object to be used by analyzeNetwork.
    %               Detects issues related to the number of input layers
    %                when we use the analyzer in 'trainNetwork'.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        
        function testSeqInputHasOnlyOneInput(test)
           % Sequence input layers can't be combined with multi-input
           % networks. If there's a sequence input layer, it must be the
           % only input.
           
            isSeqInput = [test.LayerAnalyzers.IsSequenceInputLayer];
            isInput = [test.LayerAnalyzers.IsInputLayer];
            
            if any(isSeqInput) && sum(isInput) > 1
                test.addIssue("E", "Network", find(isSeqInput, 1), ...
                    "LSTM:SingleSequenceInputLayer");
            end
        end
        
    end
end