classdef Common < nnet.internal.cnn.analyzer.constraints.Constraint
    % Common   Common constraints for prediction and functional behaviors
    %
    % These are:
    % * Empty statistics for an input layer with normalization.
    % * Empty TrainedMean or TrainedVariance for a batch normalization layer.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        
        function testEmptyStatistics(test)
            % Test whether an input layer with normalization has empty statistics.
            
            [inputIdx,emptyStats] = arrayfun( @iHasNormalizationAndEmptyStatistics, ...
                test.LayerAnalyzers, 'UniformOutput', false );
            inputIdx = [inputIdx{:}];
            
            for i = find(inputIdx)
                switch class(test.LayerAnalyzers(i).ExternalLayer)
                    case "nnet.cnn.layer.ImageInputLayer"
                        errorID = "Prediction:EmptyImage2dStatistics";
                    case "nnet.cnn.layer.Image3DInputLayer"
                        errorID = "Prediction:EmptyImage3dStatistics";
                    case "nnet.cnn.layer.SequenceInputLayer"
                        errorID = "Prediction:EmptySequenceStatistics";
                    otherwise
                        % Should not be hit unless new input layer was
                        % added without updating this list
                        error("unknown input layer")
                end
                normalization = test.LayerAnalyzers(i).ExternalLayer.Normalization;
                for k = 1:numel(emptyStats{i})
                    test.addLayerError(i, errorID, emptyStats{i}{k},"'"+normalization+"'");
                end
            end
        end        
    end
end

function [tf,statsNames] = iHasNormalizationAndEmptyStatistics(layerAnalyzer)
tf = false;
statsNames = {};
externalLayer = layerAnalyzer.ExternalLayer;
if layerAnalyzer.IsInputLayer && isprop(externalLayer,'Normalization')
    allStats = iGetStatisticNames(externalLayer.Normalization);
    for i = 1:numel(allStats)
        if isempty(externalLayer.(allStats{i}))
            tf = true;
            statsNames{end+1} = allStats{i}; %#ok<AGROW>
        end
    end
end
end

function stats = iGetStatisticNames(normalization)
if isa(normalization,'function_handle')
    stats = {};
else
    switch normalization
        case 'none'
            stats = {};
        case 'zerocenter'
            stats = {'Mean'};
        case 'zscore'
            stats = {'Mean','StandardDeviation'};
        case {'rescale-zero-one','rescale-symmetric'}
            stats = {'Min','Max'};
        otherwise
            % Should not be hit unless a new normalization was
            % added without updating this list
            error("unknown normalization")
    end
end
end