classdef Architecture < nnet.internal.cnn.analyzer.constraints.Constraint
    % Architecture  Constraint object to be used by analyzeNetwork.
    %               Detects issues related to the architecture of the
    %               network.
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    methods
        
        function testAtLeastOneInputLayer(test)
            % Test that the network has at least one input layer.
            %
            % At least one input layer is always a valid constraint for
            % both, DAG and series networks.
            
            isInput = [test.LayerAnalyzers.IsInputLayer];
            names = [test.LayerAnalyzers(isInput).Name]';
            
            if isempty(names)
                test.addIssue("E", "Network", [], ...
                    "Architecture:MissingInputLayer");
            end
        end
        
        function testAtLeastOneOutputLayer(test)
            % Test that the network has at least one output layer.
            %
            % At least one output layer is always a valid constraint for
            % both, DAG and series networks.
            
            isOutput = [test.LayerAnalyzers.IsOutputLayer];
            names = [test.LayerAnalyzers(isOutput).Name]';
            
            if isempty(names)
                test.addIssue("E", "Network", [], ...
                    "Architecture:MissingOutputLayer");
            end
        end
        
        function testClassificationMustBePrecededBySoftmax(test)
            % Test that all classification layers are preceded by a softmax
            % layer.
            %
            % The input to a classification layer has to be a probability
            % vector, which is what a softmax layer does.
            
            src = test.InternalConnections(:,1);
            dst = test.InternalConnections(:,3);
            
            for i=1:numel(test.LayerAnalyzers)
                if ~test.LayerAnalyzers(i).IsClassificationLayer
                    continue;
                end
                
                sources = src(dst == i);
                srcSoftmax = [test.LayerAnalyzers(sources).IsSoftmaxLayer];
                
                offending = sources(~srcSoftmax);
                offending = {test.LayerAnalyzers(offending).Name}';
                
                if ~isempty(offending)
                    test.addLayerError(i, ...
                        "Architecture:ClassificationMustBePrecededBySoftmax" );
                end
            end
        end
        
        function testRegressionMustNotBePrecededBySoftmax(test)
            % Test that all regression layers are not preceded by a softmax
            % layer.
            %
            % The input to a regression layer should be able to take any
            % arbitrary values. A softmax layer produces probability
            % vectors, so they are not suitable as the output of a
            % regression.
            
            src = test.InternalConnections(:,1);
            dst = test.InternalConnections(:,3);
            
            for i=1:numel(test.LayerAnalyzers)
                % Exception for deepDreamImage: we need to be able to
                % precede a deepDreamImage custom output layer with a
                % softmax
                if ~test.LayerAnalyzers(i).IsRegressionLayer ||...
                        isa(test.LayerAnalyzers(i).ExternalLayer,...
                        "nnet.internal.cnn.visualize.layer.OptimizeChannelAverageLayer")
                    continue;
                end
                
                sources = src(dst == i);
                srcSoftmax = [test.LayerAnalyzers(sources).IsSoftmaxLayer];
                
                offending = sources(srcSoftmax);
                offending = {test.LayerAnalyzers(offending).Name}';
                
                if ~isempty(offending)
                    test.addLayerError(i, ...
                        "Architecture:RegressionMustNotBePrecededBySoftmax" );
                end
            end
        end
    end
end
