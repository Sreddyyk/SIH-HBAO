classdef LSTM < nnet.internal.cnn.analyzer.constraints.Constraint
    % LSTM  Constrain object to be used by analyzeNetwork.
    %       Detects issues related to LSTM networks.
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    methods
        
        function testRecurrentAndImageLayers(test)
            % Test that image input layers and recurrent layers are not
            % combined in the same network.

            recurrent = [test.LayerAnalyzers.IsRNNLayer];
            imgInput  = [test.LayerAnalyzers.IsImageInputLayer];
            
            rnnLayers = {test.LayerAnalyzers(recurrent).DisplayName
                         test.LayerAnalyzers(recurrent).Type}';
            imgLayers = {test.LayerAnalyzers(imgInput).DisplayName
                         test.LayerAnalyzers(imgInput).Type}';

            if any(recurrent) && any(imgInput)
                test.addIssue("E", "Network", find(recurrent | imgInput), ...
                    "LSTM:RecurrentAndImageLayers", imgLayers, rnnLayers);
            end
        end
        
        function testFlattenAndImageInputLayers(test)
            % Test that image input layers and flatten layers are not
            % combined in the same network.

            flatten = [test.LayerAnalyzers.IsFlattenLayer];
            input = [test.LayerAnalyzers.IsInputLayer];
            seqInput = [test.LayerAnalyzers.IsSequenceInputLayer];
            imgInput = input & ~seqInput;
            
            flattenLayers = {test.LayerAnalyzers(flatten).DisplayName
                         test.LayerAnalyzers(flatten).Type}';
            imgInputLayers = {test.LayerAnalyzers(imgInput).DisplayName
                         test.LayerAnalyzers(imgInput).Type}';

            if any(flatten) && any(imgInput)
                test.addIssue("E", "Network", find(flatten | imgInput), ...
                    "LSTM:ImageInputAndFlattenLayers", flattenLayers, imgInputLayers);
            end
        end
        
        function testImageSpecificAndSequenceInputLayers(test)
            % Test that sequence input layers and image specific layers,
            % such as pixel classification, are not combined in the same network.

            img = [test.LayerAnalyzers.IsImageSpecificLayer];
            seqInput = [test.LayerAnalyzers.IsSequenceInputLayer];
            
            imgLayers = {test.LayerAnalyzers(img).DisplayName
                         test.LayerAnalyzers(img).Type}';
            seqInputLayers = {test.LayerAnalyzers(seqInput).DisplayName
                         test.LayerAnalyzers(seqInput).Type}';

            if any(img) && any(seqInput)
                test.addIssue("E", "Network", find(img | seqInput), ...
                    "LSTM:SequenceInputAndImageLayers", imgLayers, seqInputLayers);
            end
        end
        
        function testLSTMHasOnlyOneOutput(test)
           % Sequence input layers can't be combined with multi-output
           % networks.
           
            isSeqInput = [test.LayerAnalyzers.IsSequenceInputLayer];
            isOutput = [test.LayerAnalyzers.IsOutputLayer];
            
            if any(isSeqInput) && sum(isOutput) > 1
                test.addIssue("E", "Network", find(isSeqInput, 1), ...
                    "LSTM:SequenceInputAndMultipleOutput");
            end
        end
        
    end
end