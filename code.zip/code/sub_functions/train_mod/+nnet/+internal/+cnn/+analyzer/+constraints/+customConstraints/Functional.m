classdef Functional < ...
        nnet.internal.cnn.analyzer.constraints.customConstraints.Common
    % Functional   Constraint object to be used by analyzeNetwork.
    %
    % Detects issues which specifically prevent a layer graph to be used
    % for constructing a network for functional behavior in a custom
    % training loop. These are:
    % * Empty statistics for an input layer with normalization.
    % * Empty TrainedMean or TrainedVariance for a batch normalization layer.
    % * Output layer
    % * Only functional layers - aka layers that have been integrated
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        % TODO: this is temporary till we have a way to specify input size
        function testAtLeastOneInputLayer(test)
            isInput = [test.LayerAnalyzers.IsInputLayer];
            names = [test.LayerAnalyzers(isInput).Name]';
            
            if isempty(names)
                test.addIssue("E", "Network", [], ...
                    "Architecture:MissingInputLayer");
            end
        end
        
        function testNoOutputLayers(test)
            for i=1:numel(test.LayerAnalyzers)
                if test.LayerAnalyzers(i).IsOutputLayer
                    test.addLayerError(i, "Functional:OutputLayer");
                end
            end
        end
        
        function testOnlyFunctionalLayers(test)
            for i=1:numel(test.LayerAnalyzers)
                % Exclude output layers since already caught at no output
                if ~isa(test.LayerAnalyzers(i).InternalLayer, iFunctional)...
                        && ~test.LayerAnalyzers(i).IsOutputLayer
                    test.addLayerError(i, "Functional:NonFunctionalLayer");
                end
            end
        end     
    end
end

function c = iFunctional()
c = 'nnet.internal.cnn.layer.FunctionalLayer';
end
