classdef FunctionalConnections < ...
        nnet.internal.cnn.analyzer.constraints.Connections
    % FunctionalConnections   Functional connections constraint
    %
    % Takes into account that there can be no input or output layer
    % Does this by overloading testMissingConnections in 
    % nnet.internal.cnn.analyzer.constraints.Connections
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function testMissingConnections(test)
            % Test whether a layer is missing a connection to any of its
            % inputs or has unused outputs.
            
            for i=1:numel(test.LayerAnalyzers)
                missingInputs = iIsMissing(test.LayerAnalyzers(i).Inputs);
                missingOutputs = iIsMissing(test.LayerAnalyzers(i).Outputs);
                
                if all(missingInputs) && all(missingOutputs)
                    % This is a disconnected layer, this issue is captured
                    % by the architecture check "testConnectedComponents".
                    continue;
                end
                
                missingInputs = test.LayerAnalyzers(i).Inputs.Port(missingInputs);
                if isempty(missingInputs)
                    % Nothing to do here, everything is alright
                elseif size(test.LayerAnalyzers(i).Inputs,1) == 1
                    % Only one possible input, and it is missing.
                    % Add a message without naming the input.
                    test.addLayerError(i, ...
                        "Connections:MissingInputs" );
                else
                    % Add a message without naming the missing input(s).
                    test.addLayerError(i, ...
                        "Connections:MissingInputs", ...
                        missingInputs );
                end
            end
        end
    end
end

function missing = iIsMissing(tbl)
    if any(tbl.Properties.VariableNames == "Source")
        column = 'Source';
    elseif any(tbl.Properties.VariableNames == "Destination")
        column = 'Destination';
    end
    missing = cellfun(@isempty, tbl.(column));
end
