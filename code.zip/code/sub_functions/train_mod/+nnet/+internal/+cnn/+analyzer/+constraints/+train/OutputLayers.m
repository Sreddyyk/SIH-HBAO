classdef OutputLayers < nnet.internal.cnn.analyzer.constraints.Constraint
    % OutputLayers  Constraint object to be used by analyzeNetwork.
    %               Detects issues related to the number of output layers
    %               when we use the analyzer in 'trainNetwork'.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        
        function testNotMoreThanOneOutputLayer(test)
            % Test that the network does not have more than one output
            % layer.
            %
            % When we call 'trainNetwork', the input layerGraph or layer
            % array should not have more than one output layer. Note that
            % the case where there are zero output layers is dealt with by
            % the 'Architecture' constraint.
            
            isOutput = [test.LayerAnalyzers.IsOutputLayer];
            names = [test.LayerAnalyzers(isOutput).Name]';
            
            if numel(names) > 1
                test.addIssue("E", "Network", names, ...
                    "Architecture:OneOutputLayer", ...
                    [test.LayerAnalyzers(names).DisplayName]');
            end
        end
        
    end
end