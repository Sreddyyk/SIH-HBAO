classdef PredictionDelegate < nnet.internal.cnn.dlnetwork.PropagationDelegate
    %PredictionDelegate   Prediction delegate for dlnetwork
    %   A PredictionDelegate provides MATLAB code generation optimization
    %   for a dlnetwork predict method. It does not apply the generated
    %   code if:
    %     1) the output state is requested, or
    %     2) the output Layer and port differ, or
    %     3) the tape is recording, or
    %     4) the input X size and labels differ
        
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        FileName
    end
    
    methods
        function delegate = PredictionDelegate(net)
            delegate@nnet.internal.cnn.dlnetwork.PropagationDelegate(net);
        end
        
        function delete(delegate)
            if ~isempty(delegate.FileName)
                delete(delegate.FileName)
            end
        end
    
        function delegate = newDelegate(~, net)
            delegate = nnet.internal.cnn.dlnetwork.PredictionDelegate(net);
        end
        
        function tf = isCompatibleLayer(~, layer)
            tf = ~isa(layer,'nnet.internal.cnn.layer.CustomLayer');
        end
        
        function compatible = isCompatibleCall(delegate, ~, X, outputLayerIdx, outputLayerPortIdx, callerNargout)
            % Return true if the optimized code stored in the delegate is compatible with the requested call.
            compatible = (callerNargout <= numel(outputLayerIdx)) && ...
                ~isTraining(delegate) && ...
                inputsMatch(delegate, X, outputLayerIdx, outputLayerPortIdx);
        end
        
        function varargout = predict(delegate, net, X, outputLayerIdx, outputLayerPortIdx)
            [varargout{1:nargout}] = propagate(delegate, net, @predict, X, outputLayerIdx, outputLayerPortIdx);
        end
        
        function varargout = codegen(delegate, net, X, layerIndices, layerOutputIndices)
            % Evaluate network predict and generate code. Output the computed values from predict.
            persistent tm;
            if isempty(tm)
                tm = deep.internal.recording.TapeManager();
            end
            [X, restore, priorTapeCount] = startTracing(delegate, tm, X); %#ok
            numOutputs = numel(layerIndices);
            [outputs{1:numOutputs}] = predict(net, X, layerIndices, layerOutputIndices);
            
            tape = deep.internal.recording.tapeStruct(tm,priorTapeCount);
            inputIDs = deep.internal.recording.getIDs(X);
            outputIDs = deep.internal.recording.getIDs(outputs);
            
            region = deep.internal.recording.convert.tapeToRegion(tape,inputIDs,outputIDs,0);
            
            options.ReuseVariables = true;
            region = optimize(region,options);
            results = regionCode(region);
            constants = results.Workspace.Constants;
            fwdBody = results.Code;
            
            [~,funName] = fileparts(tempname);
            code = wrapBody(delegate,fwdBody,region, funName);
            fileName = makeFileName(delegate,funName);
            fun = deep.internal.inMemoryFunction(string(fileName),string(code));
            if iscell(X)
                fun2 = @(X)fun(X{:},constants);
            else
                fun2 = @(X)fun(X,constants);
            end
            
            delegate.Function = fun2;
            delegate.OutputLayerIndex = layerIndices;
            delegate.OutputLayerPortIndex = layerOutputIndices;
            delegate.FileName = fileName;
            delegate.GeneratedCode = true;
            
            varargout = deep.internal.networkContainerFun(@(x)stopRecording(delegate,x), outputs);
        end
        
        function code = wrapBody(delegate,body,region,funName)
            % The generated code inputs raw data and outputs raw data.
            inputs = codegenArguments(delegate,region.Inputs);
            outputs = codegenArguments(delegate,region.Outputs);
            lines = {['function [' outputs '] = ' funName '(' inputs ', constants)']
                     body
                     'end'
                    };
            code = join(lines,newline);
            code = code{1};
        end
        
    end
end

