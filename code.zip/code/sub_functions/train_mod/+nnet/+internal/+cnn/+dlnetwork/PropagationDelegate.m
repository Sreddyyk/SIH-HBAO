classdef(Abstract) PropagationDelegate < handle
    %PropagationDelegate   Base class for dlnetwork delegates
    %   A PropagationDelegate provides a base class for MATLAB codegen
    %   support for dlnetwork forward and predict methods. It provides a
    %   warmup period of normal evaluation before triggering code
    %   generation.
    
    %   Copyright 2019-2020 The MathWorks, Inc.
    
    properties
        CompatibleNetwork = false
        Warmup = nnet.internal.cnn.dlnetwork.PropagationDelegate.InitialWarmup
        GeneratedCode = false
        OutputLayerIndex
        OutputLayerPortIndex
        InputTemplate
        OutputTemplate
        Function
    end

    properties (Constant)
        InitialWarmup = 5;
    end
    
    methods (Abstract)
        codegen(delegate, net, X, layerIndices, layerOutputIndices)
        isCompatibleCall(delegate, net, X, outputLayerIdx, outputLayerPortIdx, callerNargout)
        isCompatibleLayer(delegate, layer)
        newDelegate(delegate, net)
    end
    
    methods
        
        function delegate = PropagationDelegate(net)
            delegate.CompatibleNetwork = iIsCompatibleNetwork(delegate,net);
        end
        
        function tf = inputsMatch(delegate, X, outputLayerIdx, outputLayerPortIdx)
            % Return true iff we have generated code and the new inputs are
            % compatible with the inputs for the generated code.
            tf = ~delegate.GeneratedCode || ...
                 (isCompatible(delegate.InputTemplate,X) && ...
                  isequal(delegate.OutputLayerIndex, outputLayerIdx) && ...
                  isequal(delegate.OutputLayerPortIndex, outputLayerPortIdx));
        end
        
        function warmupDone = decrementAndCheckWarmup(delegate)
            % Return true iff the warmup count is 0. Mutates the delegate to decrement the
            % count.
            warmupDone = delegate.Warmup == 0;
            if ~warmupDone
                delegate.Warmup = delegate.Warmup - 1;
            end
        end
        
        function varargout = propagate(delegate, net, forwardFcn, X, layerIndices, layerOutputIndices)
            % propagate   Forward propagate data through a dlnetwork or codegen equivalent
            %
            % Inputs:
            %   delegate            = delegate 
            %   net                 = dlnetwork
            %   forwardFcn          = function to be called on each layer
            %                         (i.e. forward/predict)
            %   X                   = input specified as labelled dlarray
            %   layerIndices        = indices of layers for which values
            %                         are returned
            %   layerOutputIndices  = indices of layer outputs, taking a
            %                         value of one unless a layer has
            %                         multiple outputs
            %
            % Outputs:
            %   varargout           = output dlarrays as specified by
            %                         layerIndices and layerOutputIndices,
            %                         plus an additional state variable
            if delegate.CompatibleNetwork && isCompatibleCall(delegate, net, X, layerIndices, layerOutputIndices, nargout) && decrementAndCheckWarmup(delegate)
                if delegate.GeneratedCode
                    X = extractFromDlarray(delegate.InputTemplate,X);
                    numDlarrayOutputs = numDlarrayTemplates(delegate.OutputTemplate);
                    [varargout{1:numDlarrayOutputs}] = feval(delegate.Function,X);
                    varargout = createDlarray(delegate.OutputTemplate, varargout);
                else
                    nout = length(layerIndices);
                    delegate.InputTemplate = deep.internal.recording.DataTemplate(X);
                    [varargout{1:nout}] = codegen(delegate, net, X, layerIndices, layerOutputIndices);
                    delegate.OutputTemplate = deep.internal.recording.DataTemplate(varargout);
                end
            else
                [varargout{1:nargout}] = forwardFcn(net, X, layerIndices, layerOutputIndices);
            end
        end
        
        function training = isTraining(~)
            persistent tm;
            if isempty(tm)
                tm = deep.internal.recording.TapeManager();
            end
            training = getTracingCount(tm) > 0;
        end
        
        function [inputs, restore, tapeSize] = startTracing(~,tm,inputs)
            % Trace both forward and backward passes (if any).
            restore1 = deep.internal.recording.TapeGuard;
            startTracing(tm);
            restore2 = deep.internal.recording.TapeGuard;
            startTracing(tm);
            restore = {restore1 restore2};
            inputs = deep.internal.recording.recordContainer(inputs);
            tapeSize = getTapeSize(tm);
        end
        
        function fileName = makeFileName(~,funname)
            fileName = ['inmem:///deep_predict/' funname '.m'];
        end
        
        function str = codegenArguments(~,vars)
            parts = {vars.Name};
            if isscalar(parts)
                str = parts{1};
                return;
            end
            parts(1:end-1) = strcat(parts(1:end-1),',');
            breaks = 5:5:length(parts)-1;
            if ~isempty(breaks)
                continuation = ['...' newline];
                parts(breaks) = strcat(parts(breaks),{continuation});
            end
            str = join(parts,'');
            str = str{1};
        end
        
        function x = stopRecording(~,x)
            if isa(x, 'dlarray')
                x = stop(x);
            end
        end
    end
end

function compatible = iIsCompatibleNetwork(delegate,net)
layers = net.OriginalLayers;
numLayers = numel(layers);
compatible = true;
for i = 1:numLayers
    if ~isCompatibleLayer(delegate,layers{i})
        compatible = false;
        break;
    end
end
end
