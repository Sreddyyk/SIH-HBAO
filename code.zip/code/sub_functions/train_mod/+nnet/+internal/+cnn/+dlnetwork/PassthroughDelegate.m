classdef PassthroughDelegate < handle
    %PassthroughDelegate   Dlnetwork delegate which performs a simple passthrough
    
    %   Copyright 2019 The MathWorks, Inc.

    methods
        function varargout = predict(~, net, X, layerIndices, layerOutputIndices)
            [varargout{1:nargout}] = predict(net, X, layerIndices, layerOutputIndices);
        end
    
        function delegate = newDelegate(~, ~)
            delegate = nnet.internal.cnn.dlnetwork.PassthroughDelegate;
        end
    end
end
