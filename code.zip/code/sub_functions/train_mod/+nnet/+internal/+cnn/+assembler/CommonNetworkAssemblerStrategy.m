classdef (Abstract) CommonNetworkAssemblerStrategy < ...
        nnet.internal.cnn.assembler.NetworkAssemblerStrategy & ...
        nnet.internal.cnn.assembler.InitializeMixin
    % CommonNetworkAssemblerStrategy   Implementation of common methods of
    % Series and DAG network assembler strategies.

    %   Copyright 2018-2019 The MathWorks, Inc.
    
    methods(Sealed)
        function internalLayers = fixIssues(~, internalLayers, analysis)
            % Currently, the only issue to be fixed is the empty class
            % names.
            if ~isempty(analysis.Issues)
                idx = iHasEmptyClassNamesIssue(analysis.Issues);
                for i=find(idx)'
                    layerIndex = iGetLayerIndex(analysis, i);
                    assert(iIsClassificationLayer(internalLayers{layerIndex}),...   
                        'Empty class names issue for non-classification layer.');    
                    internalLayers = iSetDefaultClassNames(...  
                        internalLayers, layerIndex); 
                end
            end
        end
        
        function internalNetwork = prepareNetworkForHostPrediction(~, ...
                internalNetwork)
            internalNetwork = internalNetwork.prepareNetworkForPrediction();
            internalNetwork = internalNetwork.setupNetworkForHostPrediction();
        end
        
        function internalNetwork = prepareNetworkForTraining(~, ...
                internalNetwork, executionSettings)
            internalNetwork = internalNetwork.prepareNetworkForTraining(...
                executionSettings);
        end
        
        function externalNetwork = resetState(~, externalNetwork)
            % Reset the network state, so that if the network is recurrent
            % it is configured for prediction on an arbitrary mini-batch
            % size
            externalNetwork = externalNetwork.resetState();
        end
    end
end

function idx = iHasEmptyClassNamesIssue(issues)
emptyClassNamesId = ...
    'nnet_cnn:internal:cnn:analyzer:constraints:Prediction:FillingInClassNames';
idx = strcmp(issues.Id, emptyClassNamesId);
end

function tf = iIsClassificationLayer(internalLayer)
tf = isa(internalLayer, 'nnet.internal.cnn.layer.ClassificationLayer');
end

function index = iGetLayerIndex(analysis, i)
layerName = analysis.Issues.Layers{i};
index = find([analysis.LayerAnalyzers.Name] == layerName);
end

function internalLayers = iSetDefaultClassNames(internalLayers, layerIndex)
internalLayers{layerIndex}.Categories = 'default';
end
