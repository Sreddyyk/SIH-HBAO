classdef dlnetworkAssemblerStrategy < ...
        nnet.internal.cnn.assembler.FunctionalNetworkAssemblerStrategy & ...
        nnet.internal.cnn.assembler.InitializeMixin
    % dlnetworkAssemblerStrategy   Concrete dlnetwork assembler strategy.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods        
        function internalNetwork = createInternalNetwork(~, ...
                internalLayers, analyzedLayers)
            sortedLayerGraph = analyzedLayers.LayerGraph;            
            internalLayerGraph = iExternalToInternalLayerGraph(...
                sortedLayerGraph);
            internalLayerGraph.Layers = internalLayers;

            internalNetwork = iInternalDlnetwork(internalLayerGraph);
        end
        
        function internalNetwork = prepareNetworkForFunctional(~, ...
            internalNetwork)         
            internalNetwork = setupForFunctional(internalNetwork);
        end
    end
end

function internalLayerGraph = iExternalToInternalLayerGraph( lg )
internalLayerGraph = nnet.internal.cnn.assembler...
    .externalToInternalLayerGraph(lg);
end

function net = iInternalDlnetwork(varargin)
net = nnet.internal.cnn.dlnetwork(varargin{:});
end