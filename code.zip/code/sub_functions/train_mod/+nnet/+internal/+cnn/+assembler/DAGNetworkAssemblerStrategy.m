classdef DAGNetworkAssemblerStrategy <  ...
        nnet.internal.cnn.assembler.CommonNetworkAssemblerStrategy
    % DAGNetworkAssemblerStrategy   Concrete DAG network assembler
    % strategy.
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    methods        
        function internalNetwork = createInternalNetwork(~, ...
                internalLayers, analyzedLayers)
            sortedLayerGraph = analyzedLayers.LayerGraph;            
            internalLayerGraph = iExternalToInternalLayerGraph(...
                sortedLayerGraph);
            internalLayerGraph.Layers = internalLayers;
            topologicalOrder = extractTopologicalOrder( sortedLayerGraph );
            internalNetwork = nnet.internal.cnn.DAGNetwork(...
                internalLayerGraph, topologicalOrder);
        end
        
        function externalNetwork = convertToExternalNetwork(this, ...
                internalNetwork, analyzedLayers)
            % We assume by this stage you have called
            % this.prepareNetworkForHostPrediction            
            externalNetwork = DAGNetwork(internalNetwork, ...
                this.computeLayersMap(analyzedLayers.ExternalLayers));
        end
    end
end

function internalLayerGraph = iExternalToInternalLayerGraph( lg )
internalLayerGraph = nnet.internal.cnn.assembler...
    .externalToInternalLayerGraph(lg);
end
