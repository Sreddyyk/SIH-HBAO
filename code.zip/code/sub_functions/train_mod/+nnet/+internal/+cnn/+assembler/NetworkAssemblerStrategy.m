classdef (Abstract) NetworkAssemblerStrategy
    % NetworkAssemblerStrategy   Interface for network assembler strategy
    %   A network assembler strategy encapsulates the algorithms used
    %   to initialize, configure and assemble a network.
    
    %   Copyright 2018 The MathWorks, Inc.
    
    methods(Abstract)
        % fixIssues   Fix eventual issues in analyzedLayers by modifying the
        % internalLayers.
        internalLayers = fixIssues(this, internalLayers, analyzedLayers)
        
        % initializeLearnableParameters   Initialize learnable parameters
        % of the internal layers to the precision specified. precision is a
        % nnet.internal.cnn.util.Precision instance.
        internalLayers = initializeLearnableParameters(this, ...
            internalLayers, precision)
        
        % createInternalNetwork   Create the internal network using
        % information in the analyzedLayers.
        internalNetwork = createInternalNetwork(this, internalLayers, ...
            analyzedLayers)
        
        % prepareNetworkForHostPrediction   Prepare the internal network
        % for Host prediction.
        internalNetwork = prepareNetworkForHostPrediction(this, ...
            internalNetwork)
        
        % prepareNetworkForTraining   Convert learnable parameters to the
        % correct format.
        internalNetwork = prepareNetworkForTraining(this, ...
            internalNetwork, executionSettings)
        
        % convertToExternalNetwork   Convert to external network using
        % information in the analyzedLayers.
        externalNetwork = convertToExternalNetwork(this, internalNetwork, ...
            analyzedLayers)
        
        % resetState   Reset the RNN layers states to their initial values.
        externalNetwork = resetState(this, externalNetwork)
    end
end