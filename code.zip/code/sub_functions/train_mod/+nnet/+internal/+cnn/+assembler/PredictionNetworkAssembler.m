classdef PredictionNetworkAssembler < ...
        nnet.internal.cnn.assembler.NetworkAssembler
    % PredictionNetworkAssembler   Assembler for prediction networks
    %   A prediction network assembler is responsible for constructing a
    %   network ready for prediction.
    
    %   Copyright 2018 The MathWorks, Inc.
            
    properties (Access = private)
        Strategy
    end   
    
    methods
        function this = PredictionNetworkAssembler(assemblerStrategy)
            this.Strategy = assemblerStrategy;
        end
        
        function internalNetwork = assemble(this, analyzedLayers, ...
                executionSettings)
            % analyzedLayers is a nnet.internal.cnn.analyzer.NetworkAnalyzer
            assert(nargin > 2, ...
                "assemble called with the wrong number of inputs.")

            internalLayers = analyzedLayers.InternalLayers;
                        
            internalLayers = this.Strategy.fixIssues(internalLayers, ...
                analyzedLayers);
            internalLayers = this.Strategy.initializeLearnableParameters(...
                internalLayers, executionSettings.precision);
            
            internalNetwork = this.Strategy.createInternalNetwork(...
                internalLayers, analyzedLayers);
            internalNetwork = this.Strategy...
                .prepareNetworkForHostPrediction(internalNetwork);
        end
        
        function network = createExternalNetwork(this, internalNetwork, ...
                analyzedLayers)
            % analyzedLayers is a nnet.internal.cnn.analyzer.NetworkAnalyzer
            network = this.Strategy.convertToExternalNetwork(...
                internalNetwork, analyzedLayers);
            network = this.Strategy.resetState(network);
        end
    end
end