classdef FunctionalNetworkAssembler < ...
        nnet.internal.cnn.assembler.NetworkAssembler
    % FunctionalNetworkAssembler   Assembler for functional networks
    %   A functional network assembler is responsible for constructing a
    %   network ready for functional behavior. This is used to create the
    %   internal dlnetwork.
    
    %   Copyright 2019 The MathWorks, Inc.
            
    properties (Access = private)
        Strategy
    end   
    
    methods
        function this = FunctionalNetworkAssembler(assemblerStrategy)
            this.Strategy = assemblerStrategy;
        end
        
        function internalNetwork = assemble(this, analyzedLayers)
            % analyzedLayers isa nnet.internal.cnn.analyzer.NetworkAnalyzer
            internalLayers = analyzedLayers.InternalLayers;
            
            internalLayers = this.Strategy.initializeLearnableParameters(...
                internalLayers, iSinglePrecision);            
            internalNetwork = this.Strategy.createInternalNetwork(...
                internalLayers, analyzedLayers);
            internalNetwork = this.Strategy.prepareNetworkForFunctional(...
                internalNetwork);
        end
    end
end

function precision = iSinglePrecision
precision = nnet.internal.cnn.util.Precision('single');
end