classdef SimpleTrainingNetworkAssembler < ...
        nnet.internal.cnn.assembler.NetworkAssembler
    % SimpleTrainingNetworkAssembler   Simple assembler for training networks
    %   A training network assembler is responsible for constructing a
    %   network ready for training and converting it to an external network.
    %
    %   The assemble method of a simple training network assembler does
    %   not use training and validation data. Use instead
    %   TrainingNetworkAssembler to validate data and set response
    %   metadata.
    
    %   Copyright 2018 The MathWorks, Inc.
            
    properties (Access = private)
        Strategy
    end   
    
    methods
        function this = SimpleTrainingNetworkAssembler(assemblerStrategy)
            this.Strategy = assemblerStrategy;
        end
        
        function internalNetwork = assemble(this, analyzedLayers, ...
                executionSettings)
            % analyzedLayers is a nnet.internal.cnn.analyzer.NetworkAnalyzer
            assert(nargin > 2, ...
                "assemble called with the wrong number of inputs.")
            
            internalLayers = analyzedLayers.InternalLayers;
            internalLayers = this.Strategy.initializeLearnableParameters(...
                internalLayers, executionSettings.precision);
            
            internalNetwork = this.Strategy.createInternalNetwork(...
                internalLayers, analyzedLayers);
            
            internalNetwork = this.Strategy.prepareNetworkForTraining(...
                internalNetwork, executionSettings);
        end
        
        function network = createExternalNetwork(this, internalNetwork, ...
                analyzedLayers)
            % We assume by this stage you have called
            % internalNet.prepareNetworkForPrediction() and
            % internalNet.setupNetworkForHostPrediction().
            network = this.Strategy.convertToExternalNetwork(...
                internalNetwork, analyzedLayers);
            network = this.Strategy.resetState(network);
        end
    end
end