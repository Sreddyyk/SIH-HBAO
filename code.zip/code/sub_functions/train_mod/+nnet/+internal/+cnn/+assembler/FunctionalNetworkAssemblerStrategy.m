classdef(Abstract) FunctionalNetworkAssemblerStrategy 
    % FunctionalNetworkAssemblerStrategy   Interface for functional
    % assembler strategy.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods(Abstract)
        % initializeLearnableParameters   Initialize learnable parameters
        % of the internal layers to the precision specified. precision is a
        % nnet.internal.cnn.util.Precision instance.
        internalLayers = initializeLearnableParameters(this, ...
            internalLayers, precision)
        
        % createInternalNetwork   Create the internal network using
        % information in the analyzedLayers.
        internalNetwork = createInternalNetwork(this, internalLayers, ...
            analyzedLayers)
        
        % prepareNetworkForFunctional   Prepare the internal network for
        % functional
        internalNetwork = prepareNetworkForFunctional(this, ...
            internalNetwork)  
    end
end