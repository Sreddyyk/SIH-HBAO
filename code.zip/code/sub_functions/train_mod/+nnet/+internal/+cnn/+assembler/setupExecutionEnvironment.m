function executionSettings = setupExecutionEnvironment( opts, isRNN, X, ...
    precision)
% Detect CPU/GPU/multiGPU/parallel training, and set up environment
% appropriately.

%   Copyright 2018-2019 The MathWorks, Inc.

backgroundPrefetch = iUseBackgroundPrefetch(X) || opts.DispatchInBackground;
executionSettings = nnet.internal.cnn.assembler.createExecutionSettings;
executionSettings.backgroundPrefetch = backgroundPrefetch;
executionSettings.precision = precision;
isParallel = iIsParallelExecutionEnvironment( opts.ExecutionEnvironment );
if ( isParallel && isRNN )
    error(message('nnet_cnn:trainNetwork:InvalidRNNExecutionEnvironment'));
end
if isParallel
    [executionSettings.useParallel, executionSettings.workerLoad, executionSettings.backgroundPrefetch] = ...
        iSetupAndValidateParallel( opts.ExecutionEnvironment, opts.WorkerLoad, backgroundPrefetch);
end

GPUShouldBeUsed = nnet.internal.cnn.util.GPUShouldBeUsed( ...
    opts.ExecutionEnvironment, executionSettings.workerLoad );
if GPUShouldBeUsed
    executionSettings.executionEnvironment = 'gpu';
else
    matlabOnlineAvailable = matlab.internal.environment.context.isMATLABOnline && ...
                          ~isempty(getenv('USE_STATELESS_GPU')) && ...
                          getenv('USE_STATELESS_GPU') == '1';
    statelessAvailable = strcmp(opts.ExecutionEnvironment, 'auto') && ...
                         matlabOnlineAvailable;
    if statelessAvailable
        executionSettings.executionEnvironment = 'gpu';
        executionSettings.useStateless = true;
    end
end
end

function tf = iIsParallelExecutionEnvironment(executionEnvironment)
tf = ismember( executionEnvironment, {'multi-gpu', 'parallel'} );
end

function [useParallel, workerLoad, backgroundPrefetch] = iSetupAndValidateParallel( executionEnvironment, workerLoad, backgroundPrefetch )
% Pool and work-per-worker setup and validation
nnet.internal.cnn.util.validatePCTIsInstalled(executionEnvironment);
[useParallel, isMultiGpu, pool] = iValidateParallelPool( executionEnvironment, backgroundPrefetch );
if useParallel
    [workerLoad, backgroundPrefetch] = iValidateWorkerLoad( isMultiGpu, pool, workerLoad, backgroundPrefetch );
end
end

function [useParallel, isMultiGpu, pool] = iValidateParallelPool( executionEnvironment, backgroundPrefetch )
% Detect parallel training, open a pool if necessary, and validate that
% pool
useParallel = true;
pool = gcp('nocreate');

% Multi-GPU (local parallel pool)
% Expect a local pool to be open, or open one with one worker per GPU
isMultiGpu = false;
if string(executionEnvironment) == "multi-gpu"
    isMultiGpu = true;

    if ~isempty(pool)
        % Check that the open pool is local
        if ~isa( pool.Cluster, 'parallel.cluster.Local' )
            error(message('nnet_cnn:trainNetwork:ExpectedLocalPool'));
        end
    else
        
        % Attempt to use all available GPUs.  If gpuDeviceCount is zero,
        % default to using a single-gpu; this will ensure we fall through
        % to the GPU-checking code that will generate a useful error about
        % why the device count is zero.
        numGpus = max(1, gpuDeviceCount());
        
        % If no pool is open and there is only one supported GPU, we
        % should train as normal, on the client, without opening a
        % pool. User can force training to happen on a pool by opening
        % it themselves.
        if numGpus == 1
            isMultiGpu = false;
            useParallel = false;
            return;
        else
            % Check that the default cluster profile is local
            defaultProfileName = parallel.defaultClusterProfile();
            defaultProfileType = parallel.internal.settings.ProfileExpander.getClusterType( defaultProfileName );
            if defaultProfileType == parallel.internal.types.SchedulerType.Local
                % Open the default cluster with numGpus workers, or the
                % default number of workers if using background prefetch
                % Account for the possibility that user has changed the
                % default local profile to have fewer workers
                clust = parcluster( defaultProfileName );
                numWorkers = numGpus;
                if backgroundPrefetch || clust.NumWorkers < numGpus
                    numWorkers = clust.NumWorkers;
                end
                % Open pool. We need SPMD enabled and doing it when opening
                % the pool leads to faster communication.
                pool = parpool( clust, numWorkers, 'SpmdEnabled', true );
            else
                error(message('nnet_cnn:trainNetwork:MultiGpuRequiresDefaultLocal', defaultProfileName));
            end
        end
    end
    
    % General parallel pool
    % Expect a pool to be open, or open the default pool
else
    if isempty(pool)
        % Error if user has disabled auto-pool creation
        s = settings;
        if s.parallel.client.pool.AutoCreate.ActiveValue == 0
            error(message('nnet_cnn:trainNetwork:ParallelAutoOpenDisabled'));
        end
        % Open pool using default profile
        pool = parpool( 'SpmdEnabled', true );
    end
end

% Check that SPMD is enabled in the current pool
if ~pool.SpmdEnabled
    error(message('nnet_cnn:trainNetwork:SPMDDisabled'));
end
end

function [workerLoad, backgroundPrefetch] = iValidateWorkerLoad( isMultiGpu, pool, userWorkerLoad, backgroundPrefetch )
% Given a parallel pool, modify the workerLoad settings to disable any
% workers that cannot access GPUs - unless there are no GPUs, in which case
% assume training on all pool CPUs

% Initialize workerLoad, using input user settings if provided
numWorkers = pool.NumWorkers;
useDefaultWorkerLoad = false;
if ~isempty(userWorkerLoad)
    % Validate user input
    if ~isscalar(userWorkerLoad) && length(userWorkerLoad) ~= numWorkers
        error(message('nnet_cnn:trainNetwork:InvalidWorkerLoad'));
    end
else
    userWorkerLoad = ones( 1, numWorkers );
    useDefaultWorkerLoad = true;
end

% Collect machine and device info about each worker
spmd
    [hostname, deviceIndex] = iGetHostnameAndDeviceIndex();
end
deviceIndex = [ deviceIndex{:} ];
[~, order, hostIds] = unique({ hostname{:} }, 'sorted');
numNodes = numel( order );
numWorkersPerNode = accumarray(hostIds, 1);

% Deal with CPU-only clusters as if they all have unique GPUs, so no
% workers are eliminated
cpuCluster = all( deviceIndex == 0 );
if cpuCluster
    deviceIndex = 1:numWorkers;
end
% Default worker load for CPU-only clusters with background prefetch is
% for all but one on each node to be used for training computation
cpuBackgroundDefault = false;
if cpuCluster && useDefaultWorkerLoad && backgroundPrefetch
    cpuBackgroundDefault = true;
end

% For scalar worker load, determine the loads based on the environment on
% each host
if isscalar(userWorkerLoad) || cpuBackgroundDefault
    % Map from values grouped by host back to workers
    [~, I] = sort( hostIds );
    originalIndices = 1:numWorkers;
    originalIndices = originalIndices(I);
    
    % Calculate how many workers on each host should be doing training
    % computation
    if cpuBackgroundDefault
        computeWorkersPerNode = max( 1, numWorkersPerNode - 1 );
    elseif userWorkerLoad < 1
        computeWorkersPerNode = ceil( numWorkersPerNode * userWorkerLoad );
    else
        computeWorkersPerNode = min( numWorkersPerNode, floor( userWorkerLoad ) );
    end
    
    % Start with a load of 1 on every worker, then zero the ones that are
    % not compute workers. This can be vectorized but the code is complex
    % and slow.
    userWorkerLoad = ones( 1, numWorkers );
    assert( numNodes == numel( numWorkersPerNode ) );
    i = 1;
    for n = 1:numNodes
        userWorkerLoad((i+computeWorkersPerNode(n)):(i+numWorkersPerNode(n)-1)) = 0;
        i = i + numWorkersPerNode(n);
    end
    
    % Scatter the resulting loads out to the correct locations in the pool.
    % Typically this will do nothing because the hosts are grouped and
    % ordered.
    userWorkerLoad = userWorkerLoad(originalIndices);
end

% Create the final worker load by copying the user settings, then stripping
% out non-unique device/host combinations in the active workers
workerLoad = userWorkerLoad;
hostnameDevice = [ hostIds(:) deviceIndex(:) ];
% Eliminate workers that are disabled manually or have no GPU. CPU-only
% clusters will be treated as if all workers have a unique GPU.
maskDisabled = workerLoad == 0 | deviceIndex == 0;
hostnameDevice(maskDisabled,1) = 0;
hostnameDevice(maskDisabled,2) = 0;
% Now reduce to the remaining unique combinations
[~, uniqueIndices] = unique(hostnameDevice, 'rows', 'stable');
% Mask superfluous and no-GPU workers
mask = true( 1, numWorkers );
mask(uniqueIndices) = false;
mask(maskDisabled) = true;
% Apply mask to existing settings
workerLoad(mask) = 0;

% Special case: the result of the above is that all workers are idle, which
% can only happen in a hybrid pool where all the workers on GPU hosts have
% been explicitly disabled and only workers on CPU hosts are left. In this
% case training will happen on the CPUs of the remaining workers.
if all( workerLoad == 0 )
    workerLoad = userWorkerLoad;
    return;
end

% Save the warning state before emitting WorkerLoad warnings
warnState = warning('query', 'backtrace');
cleanupObj = onCleanup(@()warning(warnState));
warning off backtrace;

% Report a warning if there are idle workers as a consequence of GPU
% sharing
disabledLabsMask = (userWorkerLoad > 0) & (workerLoad == 0);
numNewIdleWorkers = sum( disabledLabsMask );
if numNewIdleWorkers > 0
    problemLabsStr = mat2str( find( disabledLabsMask ) );
    if ~backgroundPrefetch
        if isMultiGpu
            warning(message('nnet_cnn:trainNetwork:SomeWorkersIdleLocal', problemLabsStr));
        else
            warning(message('nnet_cnn:trainNetwork:SomeWorkersIdleCluster', problemLabsStr));
        end
    elseif ~useDefaultWorkerLoad
        if isMultiGpu
            warning(message('nnet_cnn:trainNetwork:SomeComputeWorkersDisabledLocal', problemLabsStr));
        else
            warning(message('nnet_cnn:trainNetwork:SomeComputeWorkersDisabledCluster', problemLabsStr));
        end
    end
end

% Validate background prefetch. If this is being used, there must be at
% least one prefetch worker, otherwise it will be disabled.
if backgroundPrefetch
    computeWorkers = double( workerLoad > 0 );
    computeWorkersPerNode = accumarray( hostIds, computeWorkers );
    nodesWithNoBackgroundWorkers = computeWorkersPerNode == numWorkersPerNode;
    if any(nodesWithNoBackgroundWorkers)
        if isMultiGpu
            warning(message('nnet_cnn:trainNetwork:BackgroundPrefetchDisabledLocal'));
            backgroundPrefetch = false;
        else
            whichNodes = find(nodesWithNoBackgroundWorkers);
            allLabs = 1:numWorkers;
            labsOnFirstProblemNode = allLabs(hostIds == whichNodes(1));
            workerLoadAfterDisablingNodes = workerLoad;
            workerLoadAfterDisablingNodes(hostIds == whichNodes) = 0;
            if all(workerLoadAfterDisablingNodes == 0)
                % Disable background because there are no background
                % workers on any hosts which have compute workers
                warning( message( 'nnet_cnn:trainNetwork:BackgroundPrefetchDisabledCluster' ) );
                backgroundPrefetch = false;
            else
                % Warn that hosts with no background workers will be
                % disabled
                warning( message( 'nnet_cnn:trainNetwork:SomeNodesDisabledCluster', ...
                    mat2str(labsOnFirstProblemNode) ) );
                % Set workerLoad to zero on all these labs.
                workerLoad = workerLoadAfterDisablingNodes;
            end
        end
    end
end

end

function [hostid, deviceIndex] = iGetHostnameAndDeviceIndex()
hostid = parallel.internal.general.HostNameUtils.getLocalHostAddress();
try
    if nnet.internal.cnn.util.isGPUCompatible()
        deviceIndex = parallel.internal.gpu.currentDeviceIndex();
    else
        deviceIndex = 0;
    end
catch
    deviceIndex = 0;
end
end

function tf = iUseBackgroundPrefetch(X)
tf = (isa(X, 'matlab.io.datastore.BackgroundDispatchable') && X.DispatchInBackground) || ...
    (isa(X, 'nnet.internal.cnn.BackgroundCapableDispatcher') && X.RunInBackground);
end