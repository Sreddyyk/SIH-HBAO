classdef (Abstract) NetworkAssembler
    % NetworkAssembler   Interface for network assembler
    %   A network assembler is the context where network assembler strategy
    %   algorithms are put together to assemble a network.
    
    %   Copyright 2018-2019 The MathWorks, Inc.
        
    methods (Abstract)
        % assemble   Assemble an internal network. Here analyzed layers is
        % a nnet.internal.cnn.analyzer.NetworkAnalyzer.
        internalNetwork = assemble(this, analyzedLayers, varargin)
    end
end
