classdef SeriesNetworkAssemblerStrategy < ...
        nnet.internal.cnn.assembler.CommonNetworkAssemblerStrategy
    % SeriesNetworkAssemblerStrategy   Concrete Series network assembler
    % strategy.
    
    %   Copyright 2018 The MathWorks, Inc.
    
    methods           
        function internalNetwork = createInternalNetwork(~, ...
                internalLayers, analyzedLayers)
            sortedLayerGraph = analyzedLayers.LayerGraph;            
            internalLayerGraph = iExternalToInternalLayerGraph(...
                sortedLayerGraph);
            internalLayerGraph.Layers = internalLayers;
            topologicalOrder = extractTopologicalOrder( sortedLayerGraph );
            internalNetwork = nnet.internal.cnn.DAGNetwork(...
                internalLayerGraph, topologicalOrder);
        end
            
        function externalNetwork = convertToExternalNetwork(this, ...
                internalNetwork, analyzedLayers)
            % We assume by this stage you have called
            % this.prepareNetworkForHostPrediction
            
            % SeriesNetwork has to be constructed from the internal layers
            % not to lose information about the internal custom layers
            externalNetwork = SeriesNetwork(internalNetwork.OriginalLayers, ...
                this.computeLayersMap(analyzedLayers.ExternalLayers));
        end
    end
end

function internalLayerGraph = iExternalToInternalLayerGraph( externalLayerGraph )
internalLayers = iGetInternalLayers( externalLayerGraph.Layers );
internalLayerGraph = nnet.internal.cnn.LayerGraph( internalLayers );
end

function internalLayers = iGetInternalLayers( layers )
internalLayers = nnet.internal.cnn.layer.util.ExternalInternalConverter.getInternalLayers( layers );
end