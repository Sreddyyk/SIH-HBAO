function internalLayerGraph = externalToInternalLayerGraph( externalLayerGraph )
% externalToInternalLayerGraph    Convert an internal layer graph to
% external

%   Copyright 2019 The MathWorks, Inc.

internalLayers = iGetInternalLayers( externalLayerGraph.Layers );
hiddenConnections = externalLayerGraph.HiddenConnections;
internalConnections = iHiddenToInternalConnections( hiddenConnections );
internalLayerGraph = nnet.internal.cnn.LayerGraph(internalLayers, internalConnections);
end

function internalLayers = iGetInternalLayers( layers )
internalLayers = nnet.internal.cnn.layer.util.ExternalInternalConverter.getInternalLayers( layers );
end

function internalConnections = iHiddenToInternalConnections( hiddenConnections )
internalConnections = nnet.internal.cnn.util.hiddenToInternalConnections( hiddenConnections );
end
