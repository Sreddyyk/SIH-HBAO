classdef InitializeMixin 
    % InitializeMixin   Mixin to initialize internal layers

    %   Copyright 2019 The MathWorks, Inc.
    
    methods(Sealed)
        function internalLayers = initializeLearnableParameters(~, ...
                internalLayers, precision)         
            for i = 1:numel(internalLayers)
                try                
                    internalLayers{i} = internalLayers{i}...
                        .initializeLearnableParameters(precision);
                    if isa(internalLayers{i}, ...
                            'nnet.internal.cnn.layer.Recurrent' )
                        internalLayers{i} = internalLayers{i}...
                            .initializeDynamicParameters(precision);
                    end
                catch exception
                    % Add layer number and custom message to the error
                    newMsg = iBold("Layer "+string(i)+":")+...
                        " Invalid initializer. "+string(...
                        exception.message);
                    exception = MException(exception.identifier, newMsg);
                    throw(exception)
                end
            end
        end  
                        
        function layersMap = computeLayersMap(~, layers)
            layersMap = iLayersMap(layers);
        end
    end
end

function str = iBold(str)
    % Add markup to make text bold
    if matlab.internal.display.isHot()
        str = "<strong>" + str + "</strong>";
    end
end

function layersMap = iLayersMap( layers )
layersMap = nnet.internal.cnn.layer.util.InternalExternalMap( layers );
end
