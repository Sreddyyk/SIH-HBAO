classdef NetworkAssemblerStrategyFactory
    % NetworkAssemblerStrategyFactory   Factory for making network
    % assembler strategies
    %
    %   strategy = NetworkAssemblerStrategyFactory.createStrategy(...
    %       isSeriesNetwork)
    %   isSeriesNetwork: whether we need a Series network strategy.
    
    %   Copyright 2018 The MathWorks, Inc.
    
    methods (Static)
        function strategy = createStrategy(isSeriesNetwork)
            if isSeriesNetwork
               strategy = nnet.internal.cnn.assembler...
                   .SeriesNetworkAssemblerStrategy();            
            else
               strategy = nnet.internal.cnn.assembler...
                   .DAGNetworkAssemblerStrategy();
            end
        end
    end
end
