classdef Seq2SeqLongestStrategy < nnet.internal.cnn.sequence.NextStrategy & nnet.internal.cnn.sequence.Utilities
    % Seq2OneLongestStrategy   Strategy for 'longest' sequence length mini-batches and seq2seq problems
    
    %   Copyright 2018-2019 The MathWorks, Inc.

    properties
        % PredictorSize   Row vector defining fixed predictor size
        PredictorSize
        
        % ResponseSize   Row vector defining fixed response size
        ResponseSize
        
        % PaddingValue   Scalar numeric value to be used for padding
        PaddingValue
        
        % PaddingDirection   String specifying 'left' or 'right' padding
        PaddingDirection
        
        % ReadStrategy   Function handle specifying to read raw predictors
        %                and responses 
        ReadStrategy
        
        % IndexingFcn   Function handle specifying sequence indices for
        %               mini-batch creation
        IndexingFcn
    end
    
    properties (Dependent)
        % ExternalSequenceDimension   Dimension of sequence data as defined
        %                             by predictors
        ExternalSequenceDimension
    end
    
    methods
        function this = Seq2SeqLongestStrategy(readStrategy, predictorSize, responseSize, paddingValue, paddingDirection)
            this.PredictorSize = predictorSize;
            this.ResponseSize = responseSize;
            this.PaddingValue = paddingValue;
            this.ReadStrategy = readStrategy;
            this.PaddingDirection = paddingDirection;
            switch this.PaddingDirection 
                case "left"
                    this.IndexingFcn = @(dataSeqLen, longestSeqLen) this.leftPad(dataSeqLen, longestSeqLen);
                case "right" 
                    this.IndexingFcn = @(dataSeqLen, longestSeqLen) this.rightPad(dataSeqLen, longestSeqLen);
            end
        end
        
        function sequenceDimension = get.ExternalSequenceDimension(this)
            % The external sequence dimension corresponds to the sequence
            % dimension of the data when it is passed in it's raw format to
            % trainNetwork or an inference method. The external sequence
            % dimension differs from the internal tensor sequence
            % dimension, as the internal tensor includes an observation
            % dimension.
            %
            % External format: d-dimensional sequences are stored as N x 1
            % cell arrays, and the contents of each cell array are
            %
            %   X = {x1 x2 ... xD T}
            %
            % Internal tensor format: d-dimensional sequences are held in
            % tensors of shape
            %
            %   X = [x1 x2 ... xD N T]
            
            sequenceDimension = numel( this.PredictorSize ) + 1;
        end
        
        function [miniBatchPredictors, miniBatchResponses, advanceSeq, rawDataIdx] = nextBatch(this, predictors, responses, indices, ~)
            % nextBatch   Create mini-batches and response where the
            % sequence length is padded to the length of the longest
            % sequence in the batch
            
            % advanceSeq is always false. Since we are truncating at
            % the longest sequence length, there is never a need to
            % advance in the sequence dimension
            advanceSeq = false;
            batchSize = numel(indices);
            
            % Get raw data/response at given indices
            rawData = this.ReadStrategy.readDataFcn( predictors, indices );
            
            % Get data sequence dimensions
            dataSeqLen = cellfun( @(x)size(x, this.ExternalSequenceDimension), rawData );
            longestSeq = max( dataSeqLen );
            
            % Initialize mini-batch
            miniBatchPredictors = this.initializeMiniBatch( this.PredictorSize, batchSize, longestSeq, this.PaddingValue );
            
            % Allocate mini-batch data and mini-batch response
            miniBatchResponses = this.initializeMiniBatch( this.ResponseSize, batchSize, longestSeq, this.PaddingValue );
            
            mbd = reshape( miniBatchPredictors, [], batchSize, longestSeq );
            mbr = reshape( miniBatchResponses, [], batchSize, longestSeq );
            rawDataIdx = cell(batchSize, 1);
            for ii = 1:batchSize
                % Get the data
                predictorII = rawData{ii};
                % Get raw data indices
                idx = this.IndexingFcn(dataSeqLen(ii), longestSeq);
                % Allocate data into mini-batch
                mbd(:, ii, idx) = reshape( predictorII, prod(this.PredictorSize), dataSeqLen(ii) );
                % Allocate response
                responseII = this.ReadStrategy.readResponseFcn( responses, indices(ii) );
                mbr(:, ii, idx) = reshape( responseII, prod(this.ResponseSize), dataSeqLen(ii) );
                % Gather indices for indexing into batch
                rawDataIdx{ii} = idx;
            end
            miniBatchPredictors = reshape( mbd, size(miniBatchPredictors) );
            miniBatchResponses = reshape( mbr, size(miniBatchResponses) );
        end
    end
end