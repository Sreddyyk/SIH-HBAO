classdef Seq2OneShortestStrategy < nnet.internal.cnn.sequence.NextStrategy & nnet.internal.cnn.sequence.Utilities
    % Seq2OneShortestStrategy   Strategy for 'shortest' sequence length mini-batches and seq2one problems
    
    %   Copyright 2018-2019 The MathWorks, Inc.

    properties
        % PredictorSize   Row vector defining fixed predictor size
        PredictorSize
        
        % ResponseSize   Row vector defining fixed response size
        ResponseSize
        
        % PaddingValue   Scalar numeric value to be used for padding
        PaddingValue
        
        % PaddingDirection   String specifying 'left' or 'right' padding
        PaddingDirection
        
        % ReadStrategy   Function handle specifying to read raw predictors
        %                and responses 
        ReadStrategy
        
        % IndexingFcn   Function handle specifying sequence indices for
        %               mini-batch creation
        IndexingFcn
    end
    
    properties (Dependent)
        % ExternalSequenceDimension   Dimension of sequence data as defined
        %                             by predictors
        ExternalSequenceDimension
    end
    
    methods
        function this = Seq2OneShortestStrategy(readStrategy, predictorSize, responseSize, paddingValue, paddingDirection)
            this.PredictorSize = predictorSize;
            this.ResponseSize = responseSize;
            this.PaddingValue = paddingValue;
            this.ReadStrategy = readStrategy;
            this.PaddingDirection = paddingDirection;
            switch this.PaddingDirection 
                case "left"
                    this.IndexingFcn = @(dataSeqLen, shortestSeqLen) this.leftTruncate(dataSeqLen, shortestSeqLen);
                case "right"
                    this.IndexingFcn = @(dataSeqLen, shortestSeqLen) this.rightTruncate(dataSeqLen, shortestSeqLen);
            end
        end
        
        function sequenceDimension = get.ExternalSequenceDimension(this)
            % The external sequence dimension corresponds to the sequence
            % dimension of the data when it is passed in it's raw format to
            % trainNetwork or an inference method. The external sequence
            % dimension differs from the internal tensor sequence
            % dimension, as the internal tensor includes an observation
            % dimension.
            %
            % External format: d-dimensional sequences are stored as N x 1
            % cell arrays, and the contents of each cell array are
            %
            %   X = {x1 x2 ... xD T}
            %
            % Internal tensor format: d-dimensional sequences are held in
            % tensors of shape
            %
            %   X = [x1 x2 ... xD N T]
            
            sequenceDimension = numel( this.PredictorSize ) + 1;
        end
        
        function [miniBatchPredictors, miniBatchResponses, advanceSeq, unpaddingIdx] = nextBatch(this, predictors, responses, indices, ~)
            % nextBatch   Create mini-batches and response where the
            % sequence length is truncated to the length of the shortest
            % sequence in the batch
            
            % advanceSeq is always false. Since we are truncating at
            % the longest sequence length, there is never a need to
            % advance in the sequence dimension
            advanceSeq = false;
            batchSize = numel(indices);
            
            % Get raw data/response at given indices
            rawData = this.ReadStrategy.readDataFcn( predictors, indices );
            
            % Get data sequence dimensions
            dataSeqLen = cellfun( @(x)size(x, this.ExternalSequenceDimension), rawData );
            shortestSeq = min( dataSeqLen );
            
            % Initialize mini-batch
            miniBatchPredictors = this.initializeMiniBatch( this.PredictorSize, batchSize, shortestSeq, this.PaddingValue );
            
            % Allocate mini-batch data
            mbd = reshape( miniBatchPredictors, [], batchSize, shortestSeq );
            unpaddingIdx = cell(batchSize, 1);
            for ii = 1:batchSize
                % Get the data
                predictorII = reshape( rawData{ii}, prod(this.PredictorSize), [] );
                % Get raw data indices
                idx = this.IndexingFcn(dataSeqLen(ii), shortestSeq);
                % Allocate data into mini-batch
                mbd(:, ii, :) = predictorII(:, idx);
                % Set unpadding indices
                unpaddingIdx{ii} = 1:numel(idx);
            end
            miniBatchPredictors = reshape( mbd, size(miniBatchPredictors) );
            
            % Allocate response
            miniBatchResponses = this.ReadStrategy.readResponseFcn( responses, indices );
        end
    end
end