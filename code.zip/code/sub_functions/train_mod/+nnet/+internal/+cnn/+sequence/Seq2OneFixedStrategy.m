classdef Seq2OneFixedStrategy < nnet.internal.cnn.sequence.NextStrategy & nnet.internal.cnn.sequence.Utilities
    % Seq2OneFixedStrategy   Strategy for fixed sequence length mini-batches and seq2one problems
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties
        % PredictorSize   Row vector defining fixed predictor size
        PredictorSize
        
        % ResponseSize   Row vector defining fixed response size
        ResponseSize
        
        % PaddingValue   Scalar numeric value to be used for padding
        PaddingValue
        
        % PaddingDirection   String specifying 'left' or 'right' padding
        PaddingDirection
        
        % ReadStrategy   Function handle specifying to read raw predictors
        %                and responses 
        ReadStrategy
        
        % IndexingFcn   Function handle specifying sequence indices for
        %               mini-batch creation
        IndexingFcn
    end
    
    properties (Dependent)
        % ExternalSequenceDimension   Dimension of sequence data as defined
        %                             by predictors
        ExternalSequenceDimension
    end
    
    methods
        function this = Seq2OneFixedStrategy(readStrategy, predictorSize, responseSize, paddingValue, paddingDirection)
            this.PredictorSize = predictorSize;
            this.ResponseSize = responseSize;
            this.PaddingValue = paddingValue;
            this.ReadStrategy = readStrategy;
            this.PaddingDirection = paddingDirection;
            switch this.PaddingDirection
                case "left"
                    this.IndexingFcn = @(dataSeqLen, seqIndices, maxOutputSeqLen) ...
                        this.leftPadForFixedSeqLen(dataSeqLen, seqIndices, maxOutputSeqLen);
                case "right"
                    this.IndexingFcn = @(dataSeqLen, seqIndices, maxOutputSeqLen) ...
                        this.rightPadForFixedSeqLen(dataSeqLen, seqIndices, maxOutputSeqLen);
            end
        end
        
        function sequenceDimension = get.ExternalSequenceDimension(this)
            % The external sequence dimension corresponds to the sequence
            % dimension of the data when it is passed in it's raw format to
            % trainNetwork or an inference method. The external sequence
            % dimension differs from the internal tensor sequence
            % dimension, as the internal tensor includes an observation
            % dimension.
            %
            % External format: d-dimensional sequences are stored as N x 1
            % cell arrays, and the contents of each cell array are
            %
            %   X = {x1 x2 ... xD T}
            %
            % Internal tensor format: d-dimensional sequences are held in
            % tensors of shape
            %
            %   X = [x1 x2 ... xD N T]
            
            sequenceDimension = numel( this.PredictorSize ) + 1;
        end
        
        function [miniBatchPredictors, miniBatchResponses, advanceSeq, unpaddingIdx] = nextBatch(this, predictors, responses, indices, seqIndices)
            % nextBatch   Create a mini-batch and response where the
            % sequence length is padded/truncated to a specified length
            
            % Get raw data/response at given indices
            rawData = this.ReadStrategy.readDataFcn( predictors, indices );
            
            % Initialize mini-batch data
            batchSize = numel( indices );
            sequenceLength = numel( seqIndices );
            miniBatchPredictors = this.initializeMiniBatch( this.PredictorSize, batchSize, sequenceLength, this.PaddingValue );
            
            % Get sequence dimensions
            dataSeqLen = cellfun( @(x)size(x, this.ExternalSequenceDimension), rawData );
            
            % Determine whether another pass along sequence dimension is
            % needed
            advanceSeq = max( dataSeqLen ) > max( seqIndices );
            
            % Allocate mini-batch data
            mbd = reshape( miniBatchPredictors, [], batchSize, sequenceLength );
            maxSeq = max( dataSeqLen );
            numBatches = ceil( maxSeq/sequenceLength );
            maxOutputSeqLen = numBatches*sequenceLength;
            unpaddingIdx = cell(batchSize, 1);
            for ii = 1:batchSize
                % Get the data
                predictorII = rawData{ii};
                [dataIdx, batchIdx] = this.IndexingFcn(dataSeqLen(ii), seqIndices, maxOutputSeqLen);
                % Write into the mini-batch
                predictorII = reshape( predictorII, prod(this.PredictorSize), [] );
                mbd(:, ii, batchIdx) = predictorII(:, dataIdx);
                % Set unpadding indices
                unpaddingIdx{ii} = batchIdx;
            end
            % Reshape to arbitrary dimensions
            miniBatchPredictors = reshape( mbd, size(miniBatchPredictors) );
            
            % Allocate response
            miniBatchResponses = this.ReadStrategy.readResponseFcn( responses, indices );
        end
    end
end