classdef Utilities
    % Utilities   Utilities for built-in sequence dispatchers
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    methods (Static)
        function miniBatchData = initializeMiniBatch(dataSize, batchSize, sequenceLength, paddingValue )
            % initializeMiniData   Create an array which will have the
            % mini-batch data assigned into it 
            miniBatchData = paddingValue.*ones( [dataSize batchSize sequenceLength] );
        end
        
        function idx = leftPad(dataSeqLen, paddedSeqLen)
            idx = (paddedSeqLen - dataSeqLen + 1):paddedSeqLen;
        end
        
        function idx = rightPad(dataSeqLen, ~)
            idx = 1:dataSeqLen;
        end
        
        function idx = leftTruncate(dataSeqLen, truncatedLen)
            idx = (dataSeqLen - truncatedLen + 1):dataSeqLen;
        end
        
        function idx = rightTruncate(~, truncatedLen)
            idx = 1:truncatedLen;
        end
        
        function [dataIdx, batchIdx] = rightPadForFixedSeqLen(dataSeqLen, seqIndices, ~)
            % Get indices for indexing into the data
            dataIdx = seqIndices(1):min(seqIndices(end), dataSeqLen);
            
            % Get indices for indexing into the mini-batch
            batchIdx = 1:numel(dataIdx);
        end
        
        function [dataIdx, batchIdx] = leftPadForFixedSeqLen(dataSeqLen, seqIndices, maxOutputSeqLen)
            % Get full padded sequence indices
            paddedIndsFull = [nan(1, maxOutputSeqLen - dataSeqLen) 1:dataSeqLen];
            paddedInds = paddedIndsFull( seqIndices );
            
            % Determine indices for mini-batch and for raw data
            batchIdx = 1:numel( seqIndices );
            batchIdx = batchIdx( ~isnan(paddedInds) );
            dataIdx = paddedInds( ~isnan(paddedInds) );
        end
    end
end