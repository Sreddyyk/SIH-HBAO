classdef (Abstract) NextStrategy
    % NextStrategy   Interface to be inherited by seq2one/seq2seq mini-batch strategy classes
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties (Abstract)
        % PredictorSize   Row vector defining fixed predictor size
        PredictorSize
        
        % ResponseSize   Row vector defining fixed response size
        ResponseSize
        
        % PaddingValue   Scalar numeric value to be used for padding
        PaddingValue
        
        % PaddingDirection   String specifying 'left' or 'right' padding
        PaddingDirection
        
        % ReadStrategy   Function handle specifying how to read raw
        %                predictors and responses 
        ReadStrategy
        
        % IndexingFcn   Function handle which returns sequence indices for
        %               mini-batch creation
        IndexingFcn
    end

    methods (Abstract)
        % nextBatch   Get the next mini-batch
        [miniBatchPredictors, miniBatchResponses, advanceSeq, unpaddingIdx] = nextBatch(this, predictors, responses, indices, seqIndices)
    end
end