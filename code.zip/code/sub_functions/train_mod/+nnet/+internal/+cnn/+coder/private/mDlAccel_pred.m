function out = mDlAccel_pred(in)

%   Copyright 2018 The MathWorks, Inc.

%#codegen
persistent mynet;

if isempty(mynet)   
    mynet = coder.loadDeepLearningNetwork(coder.const('dl_net.mat'));
end

out = mynet.predict(in);