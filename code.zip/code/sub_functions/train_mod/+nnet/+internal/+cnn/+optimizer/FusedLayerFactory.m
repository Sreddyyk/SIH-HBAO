classdef FusedLayerFactory
    % FusedLayerFactory  Builder for fused layers, constructing an
    % appropriate layer of the requested class.
    
    %   Copyright 2018 The MathWorks, Inc.
    
    % This class uses str2func and eval to extract concrete identifiers
    % from class names. This avoids needing to create a child factory class
    % for every fused layer type.
    
    properties( Access = private )
        ClassName
        BuildFunction
    end
    
    properties( Dependent, SetAccess = private )
        NameRoot
    end
    
    methods

        function obj = FusedLayerFactory( fusedLayerClassName )
            obj.ClassName = string(fusedLayerClassName);
            obj.BuildFunction = str2func( fusedLayerClassName );
        end
        
        function fusedLayer = build( this, name, originalLayerGraph )
            fusedLayer = this.BuildFunction( name, originalLayerGraph );
        end
        
        function nameRoot = get.NameRoot( this )
            nameRoot = eval( this.ClassName + ".DefaultName" );
        end

    end
    
end
