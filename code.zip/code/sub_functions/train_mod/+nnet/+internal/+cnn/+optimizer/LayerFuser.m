classdef LayerFuser < ...
        nnet.internal.cnn.optimizer.NetworkOptimizable
    % LayerFuser  Basic class for network optimizer that substitutes closed
    % sub-graphs with individual FusedLayer implementations
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties
        % Active  Defines whether this LayerFuser should be used
        Active = true
    end
    
    properties( SetAccess = protected )
        % LayerIndexMap  Table defining the location of each original layer
        % in the optimized layer graph
        LayerIndexMap
    end
    
    properties( Access = protected )
        % Factory  A FusedLayerFactory for building a particular FusedLayer
        % type
        Factory
    end
    
    methods

        function obj = LayerFuser( fusedLayerFactory, supportsTraining )
            % LayerFuser   Construct a LayerFuser for substituting as
            % appropriate the FusedLayer type built by the input
            % fusedLayerFactory
            obj.Factory = fusedLayerFactory;
            obj.SupportsTraining = nargin < 2 || supportsTraining;
        end
        
        function [layerIndex, layerOffset] = mapFromOriginal( this, layerIndex )
            layerOffset = ones(size(layerIndex));
            if ~isempty(this.LayerIndexMap) % Ensure optimization applied
                layerIndex = this.LayerIndexMap.Index(layerIndex);
                layerOffset = this.LayerIndexMap.Offset(layerIndex);
            end
        end
        
        function layerIndices = mapToOriginal( this, layerIndex )
            layerIndices = layerIndex;
            if ~isempty(this.LayerIndexMap) % Ensure optimization applied
                layerMask = this.LayerIndexMap.Index == layerIndex;
                layerIndices(this.LayerIndexMap.Offset(layerMask)) = find(layerMask);
            end
        end
        
        function layerGraph = optimize( this, layerGraph )
            % optimize  Substitutes any sub-graph as defined by the
            % findMatches method
            numLayers = numel(layerGraph.Layers);
            this.LayerIndexMap = table((1:numLayers)', ones(numLayers,1), 'VariableNames', {'Index', 'Offset'});
            
            % Find matching sub-graphs
            matches = findMatches( this, layerGraph );

            % Substitute
            numMatches = numel(matches);
            fusedLayers = cell(numMatches,1);
            for i = 1:numMatches
                indices = matches{i};
                subGraph = this.extractSubGraph( layerGraph, indices );
                name = sprintf('%s_%d', this.Factory.NameRoot, i);
                fusedLayers{i} = this.Factory.build( name, subGraph );
            end
            [layerGraph, layerMap] = this.substituteBlocks( layerGraph, matches, fusedLayers );
            this.LayerIndexMap = table(layerMap(:,1), layerMap(:,2), 'VariableNames', {'Index', 'Offset'});
        end

    end
    
    methods( Abstract, Access = protected )
       
        % Subclasses define findMatches to determine fusion behaviour.
        % Returns a cell array, each entry of which is a list of indices
        % that define a closed sub-graph within the layerGraph.
        matches = findMatches( this, layerGraph );
        
    end
   
    %% Internal helpers
    methods( Static, Hidden = true)

        function subGraph = extractSubGraph(layerGraph, indices)
        % Creates a layerGraph out of the given layers and their connections.
        % Assumes the indices match a closed sub-graph in topological order

            % Extract the layers and connections for the subGraph
            subLayers = layerGraph.Layers(indices);
            subConnections = layerGraph.Connections;
            internalConnectionsMask = ismember(subConnections(:,3), indices(2:end));
            subConnections = subConnections(internalConnectionsMask,:);

            % 'Rename' the nodes in the Connections matrix
            layerMap = 1:numel(layerGraph.Layers);
            layerMap(indices) = 1:numel(subLayers);
            subConnections(:,1) = layerMap(subConnections(:,1));
            subConnections(:,3) = layerMap(subConnections(:,3));

            subGraph = nnet.internal.cnn.LayerGraph(subLayers, subConnections);
        end

        function [layerGraph, layerMap] = substituteBlocks(layerGraph, matches, fusedLayers)
            % Assumes matches are layer indices in a topological order
            newLayers = layerGraph.Layers;
            connections = layerGraph.Connections;
            newConnections = connections;
            numLayers = numel(newLayers);
            numMatches = numel(matches);
            deleteLayers = false(numLayers, 1);
            deleteConnections = false(size(newConnections,1), 1);
            layerMap = [(1:numLayers)' ones(numLayers,1)];
            for i = 1:numMatches
                indices = matches{i};

                % Replace first layer in block, mark others for deletion
                newLayers(indices(1)) = fusedLayers(i);
                deleteLayers(indices(2:end)) = true;

                % Rewire outputs to last layer in block to first layer
                outputsFromLastLayerInBlockMask = connections(:,1) == indices(end);
                newConnections(outputsFromLastLayerInBlockMask,1) = indices(1);

                % Mark disconnected connections for deletion
                inputsToBlockInternalLayersMask = ismember(connections(:,3), indices(2:end));
                deleteConnections(inputsToBlockInternalLayersMask) = true;

                % Update layer index map
                layerMap(indices,1) = layerMap(indices(1));
                layerMap(indices,2) = 1:numel(indices);
            end

            % Re-number layers
            newLayers(deleteLayers) = [];
            newLayerNumbers = cumsum(~deleteLayers);
            newLayerNumbers(deleteLayers) = 0;
            newConnections(:,1) = newLayerNumbers(newConnections(:,1));
            newConnections(:,3) = newLayerNumbers(newConnections(:,3));
            newConnections(deleteConnections,:) = [];

            layerGraph = nnet.internal.cnn.LayerGraph(newLayers, newConnections);

            % Re-number layers in layer map
            trueLayers = layerMap(:,2) == 1;
            reverseMap = (1:numLayers)';
            reverseMap(trueLayers) = 1:sum(trueLayers);
            layerMap(:,1) = reverseMap(layerMap(:,1));
        end 
    end
    
end
