classdef CPUGenericLayerFuser < nnet.internal.cnn.optimizer.LayerFuser
    % CPUGenericLayerFuser  Basic layer fuser for fusing layers 
    % in an entire network.
    
    %   Copyright 2019 The MathWorks, Inc.
   
    properties (Access = private, Hidden = true)
       % Holds information about the inference to be done.
       InferenceInfo;
    end
    
    methods
        function obj = CPUGenericLayerFuser(fusedLayerFactory, inferenceInfo)
            supportsTraining = false;
            obj = obj@nnet.internal.cnn.optimizer.LayerFuser(...
                fusedLayerFactory, supportsTraining);
            obj.InferenceInfo = inferenceInfo;
        end
        
        function layerGraph = optimize( this, layerGraph )
            % optimize  Substitutes any sub-graph as defined by the
            % findMatches method
            numLayers = numel(layerGraph.Layers);
            this.LayerIndexMap = table((1:numLayers)', ...
                ones(numLayers,1), 'VariableNames', {'Index', 'Offset'});
            
            % Find matching sub-graphs, and return the precision and number
            % of data dimensions.
            matches = findMatches(this, layerGraph);

            % Substitute
            numMatches = numel(matches);
            fusedLayers = cell(numMatches,1);
            Precision = this.InferenceInfo.Precision.Type;
            NumDataDimensions = length(this.InferenceInfo.DataSize{1})-1;
            import nnet.internal.cnn.layer.CPUGenericFusedLayer;
            for i = 1:numMatches
                indices = matches{i};
                subGraph = this.extractSubGraph( layerGraph, indices );
                name = sprintf('%s_%d', this.Factory.NameRoot, i);
                fusedLayers{i} = CPUGenericFusedLayer(name, subGraph, Precision, NumDataDimensions);
            end
            [layerGraph, layerMap] = this.substituteBlocks( layerGraph, matches, fusedLayers );
            this.LayerIndexMap = table(layerMap(:,1), layerMap(:,2), 'VariableNames', {'Index', 'Offset'});
        end
    end
    
    methods( Access = protected )
        
        function matches = findMatches(this, layerGraph)
            % findMatches  Returns matches for the graph.
            import nnet.internal.cnn.optimizer.*
            matches = {};
            % We need to be dealing with a single-input, single-output network.
            numLayers = numel(layerGraph.Layers);
            % All layers after the first layer are a target of something.
            singleInput = all(ismember(2:numLayers, layerGraph.Connections(:,3)));
            % All layers until the last layer are a source for something
            % else.
            singleOutput = all(ismember(1:(numLayers-1), layerGraph.Connections(:,1)));
            if ~singleInput || ~singleOutput
                return;
            end
            % Check whether the individual layers are fusable.
            Precision = string(this.InferenceInfo.Precision.Type);
            NumDataDimensions = length(this.InferenceInfo.DataSize{1})-1;
            fuseableIdx = CPUGenericLayerFuser.checkLayersForFusability(layerGraph, Precision, NumDataDimensions);
            if ~all(fuseableIdx)
                % Find first non-fusable layer.
                lastFuseable = find(~fuseableIdx, 1, 'first');
                % If we didn't find any, or if the first non-fuseable layer
                % is either the first or second layer, no fusion.
                if isempty(lastFuseable) || (lastFuseable < 3)
                    return;
                end
                lastFuseable = lastFuseable-1;
                % We can still fuse as long as none of the remaining nodes
                % are connected to anything but the last fusable node.
                lastCnx = layerGraph.Connections(layerGraph.Connections(:,3) > lastFuseable, 1);
                if all(lastCnx >= lastFuseable)
                    matches = { 1:lastFuseable };
                end
            else
                matches = { 1:numLayers };
            end
        end
        
    end
    
    methods (Static, Access = protected, Hidden = true)
        function layerIsFusable = checkLayersForFusability(layerGraph, Precision, NumDataDimensions)
            % checkLayerSupport  Checks the support for individual layers.
            numLayers = numel(layerGraph.Layers);
            layerIsFusable = false(numLayers, 1);
            % Supported layer classes.
            for i = 1:numel(layerGraph.Layers)
                if isa(layerGraph.Layers{i}, "nnet.internal.cnn.layer.CustomLayer")
                    % Check for support package layers.
                    externalLayer = layerGraph.Layers{i}.ExternalCustomLayer;
                    if isa(externalLayer, "nnet.internal.cnn.layer.CPUFusableLayer")
                        layerIsFusable(i) = externalLayer.isFusable(Precision, NumDataDimensions);
                    end
                elseif isa(layerGraph.Layers{i}, "nnet.internal.cnn.layer.CPUFusableLayer")
                    layerIsFusable(i) = layerGraph.Layers{i}.isFusable(Precision, NumDataDimensions);
                end
            end
        end
   end
    
end
