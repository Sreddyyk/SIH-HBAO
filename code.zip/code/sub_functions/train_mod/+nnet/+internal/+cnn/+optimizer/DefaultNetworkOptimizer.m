classdef DefaultNetworkOptimizer < ...
        nnet.internal.cnn.optimizer.LayerFuserCollection
    % DefaultNetworkOptimizer  Optimizer that carries out all appropriate
    % optimizations that should happen by default on construction of a
    % DAGNetwork
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    methods
        function obj = DefaultNetworkOptimizer(inferenceInfo, gpuShouldBeUsed)
            % Construct default optimizer
            
            obj.Identifier = 'default';
            
            % Add default layer fusers
            if (nargin == 2) && ~gpuShouldBeUsed
                obj.Identifier = sprintf('default_%d', inferenceInfo.MiniBatchSize);
                LayerFuser = nnet.internal.cnn.optimizer.CPUGenericLayerFuser(...
                    nnet.internal.cnn.optimizer.FusedLayerFactory( ...
                      "nnet.internal.cnn.layer.CPUGenericFusedLayer" ),...
                      inferenceInfo);
                obj.addLayerFuser( LayerFuser );
            end
            obj.addLayerFuser( nnet.internal.cnn.layer.ConvolutionBatchNormActivation.LayerFuser );
            obj.addLayerFuser( nnet.internal.cnn.layer.ConvolutionReLU.LayerFuser );
            obj.addLayerFuser( nnet.internal.cnn.layer.GroupedConvolutionBatchNormActivation.LayerFuser );
            obj.addLayerFuser( nnet.internal.cnn.layer.GroupedConvolutionReLU.LayerFuser );
        end
    end
    
end
