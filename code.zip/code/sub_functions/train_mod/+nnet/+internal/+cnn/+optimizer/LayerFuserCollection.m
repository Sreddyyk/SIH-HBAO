classdef LayerFuserCollection < ...
        nnet.internal.cnn.optimizer.NetworkOptimizable
    % LayerFuserCollection  Manages an array of LayerFuser objects for
    % different FusedLayer types
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties( Access = private )
        LayerFusers
        LayerIndexMap
    end
    
    methods
        
        function layerGraph = optimize( this, layerGraph, mode )
            
            if nargin < 3
                mode = "unspecified";
            end
            
            n = numel(layerGraph.Layers);
            this.LayerIndexMap = table((1:n)', ones(n,1), 'VariableNames', {'Index', 'Offset'});
            
            % Fuse layers
            for f = 1:numel(this.LayerFusers)
                layerFuser = this.LayerFusers{f};
                if layerFuser.Active
                    layerGraph = iOptimize( layerFuser, layerGraph, mode );

                    % Update mappings
                    if ~isempty(layerFuser.LayerIndexMap)
                        index = layerFuser.LayerIndexMap.Index(this.LayerIndexMap.Index);
                        offset = layerFuser.LayerIndexMap.Offset(this.LayerIndexMap.Index) + ...
                            this.LayerIndexMap.Offset - 1;
                        this.LayerIndexMap.Index = index;
                        this.LayerIndexMap.Offset = offset;
                    end
                end
            end
            
        end
        
        function internalLayerGraph = optimizeForPrediction( this, internalLayerGraph )
            internalLayerGraph = optimize( this, internalLayerGraph, "prediction" );
        end
        
        function internalLayerGraph = optimizeForTraining( this, internalLayerGraph )
            internalLayerGraph = optimize( this, internalLayerGraph, "training" );
        end
        
        function [layerIndex, layerOffset] = mapFromOriginal( this, originalLayerIndex )
            if ~isempty(this.LayerIndexMap) % Ensure optimization applied
                layerIndex = this.LayerIndexMap.Index(originalLayerIndex);
                layerOffset = this.LayerIndexMap.Offset(originalLayerIndex);
            else
                layerIndex = originalLayerIndex;
                layerOffset = ones(size(originalLayerIndex));
            end
        end
        
        function layerIndices = mapToOriginal( this, layerIndex )
            layerIndices = layerIndex;
            if ~isempty(this.LayerIndexMap) % Ensure optimization applied
                layerMask = this.LayerIndexMap.Index == layerIndex;
                layerIndices(this.LayerIndexMap.Offset(layerMask)) = find(layerMask);
            end
        end
        
        function addLayerFuser( this, fuser )
            this.LayerFusers = [ this.LayerFusers; { fuser } ];
        end
        
    end
    
end

function layerGraph = iOptimize( layerFuser, layerGraph, mode )
switch mode
    case "unspecified"
        layerGraph = optimize( layerFuser, layerGraph );
    case "prediction"
        layerGraph = optimizeForPrediction( layerFuser, layerGraph );
    case "training"
        layerGraph = optimizeForTraining( layerFuser, layerGraph );
end
end
