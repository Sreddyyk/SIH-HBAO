classdef NetworkOptimizationFactory
    % NetworkOptimizationFactory  Builds a NetworkOptimizer appropriate for
    % the user input to the 'Acceleration' parameter
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties( Constant )
        ValidStrings = [
            "none"
            "auto"
            "mex"];
    end
    
    methods( Static )
        
        function optimizer = buildOptimizerFromParameters( params, network, inferenceInfo, gpuShouldBeUsed )
            % buildOptimizerFromParameters  Parses the user's input to the
            % 'Acceleration' parameter and the parameters of the current
            % inference method (if applicable) and returns an appropriate
            % NetworkOptimizer object.
            import nnet.internal.cnn.optimizer.*
            import nnet.internal.cnn.coder.*
            
            % Validate
            str = validatestring(params, NetworkOptimizationFactory.ValidStrings);
            
            % Construct appropriate optimizer
            import nnet.internal.cnn.optimizer.*
            switch( str )
                case "auto"
                    optimizer = DefaultNetworkOptimizer(inferenceInfo, gpuShouldBeUsed);
                case "none"
                    optimizer = NoOpNetworkOptimizer();
                case "mex"
                    optimizer = DLAccelWholeNetworkOptimizer(network, inferenceInfo, gpuShouldBeUsed);
            end
        end
        
    end
    
end
