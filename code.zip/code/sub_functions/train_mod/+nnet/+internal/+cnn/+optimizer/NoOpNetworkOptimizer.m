classdef NoOpNetworkOptimizer < ...
        nnet.internal.cnn.optimizer.NetworkOptimizable
    % NoOpNetworkOptimizer  Network Optimizer that does no optimization
    
    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function obj = NoOpNetworkOptimizer()
            obj.Identifier = 'noop';
        end
        
        function layerGraph = optimize( this, layerGraph )
            % Do nothing
        end
        
        function [layerIndex, layerOffset] = mapFromOriginal( this, layerIndex )
            layerOffset = ones(size(layerIndex));
        end

        function layerIndices = mapToOriginal( this, layerIndex )
            layerIndices = layerIndex;
        end

    end
    
end
