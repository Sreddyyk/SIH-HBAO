classdef NetworkOptimizable < handle
    % NetworkOptimizable  Interface for network optimizers
    
    %   Copyright 2018 The MathWorks, Inc.
    
    properties
        % Identifier  Users can label this optimizer in order to equate two
        % instances
        Identifier
    end
    
    properties( Access = protected )
        % SupportsTraining  For NetworkOptimizable objects using the
        % default behaviour, defines whether this optimizer supports
        % training optimization
        SupportsTraining = true
    end
    
    methods( Abstract )
        
        % optimize  Modify a layer graph definition by altering or
        % substituting layers to produce an optimized version
        internalLayerGraph = optimize( this, internalLayerGraph );
        
        % mapFromOriginal  For an original LayerGraph with N layers that
        % was optimized, provide a mapping for a layerIndex into the
        % original LayerGraph's array of layers. This allows DAGNetwork to
        % recover the original layer from the optimized LayerGraph. It
        % mostly maps to the behaviour of FusedLayer types, which
        % explicitly retain the layer sub-graph they fuse; however it can
        % be used flexibly to define more complicated mappings.
        %
        % Returns:
        %   layerIndex:   The index into the optimized LayerGraph's array
        %                 of layers where this layer (or its behaviour)
        %                 can be found.
        %   layerOffset:  If an original layer's behaviour has been
        %                 absorbed into another's, specifies an offset into
        %                 that layer to find the original.
        %
        % Argument layerIndex may be a vector of layerIndices, in which
        % case the outputs are vectors of indices and offsets for each
        % input index.
        [layerIndex, layerOffset] = mapFromOriginal( this, layerIndex );
        
        % mapToOriginal  For an original LayerGraph with N layers that was
        % optimized, provide a mapping for a layerIndex in the optimized
        % LayerGraph's array of layers to the layers in the original
        % LayerGraph that were fused, in their original order.
        layerIndices = mapToOriginal( this, layerIndex );
        
    end
    
    methods
        
        function internalLayerGraph = optimizeForPrediction( this, internalLayerGraph )
            % optimizeForPrediction  Overload this to provide different
            % behaviour for prediction optimization as for training
            
            internalLayerGraph = optimize( this, internalLayerGraph );
        end
        
        function internalLayerGraph = optimizeForTraining( this, internalLayerGraph )
            % optimizeForPrediction  Overload this to provide different
            % behaviour for training optimization as for prediction
            
            if this.SupportsTraining
                internalLayerGraph = optimize( this, internalLayerGraph );
            end
        end
    end
end