classdef SequenceLayerFuser < nnet.internal.cnn.optimizer.LayerFuser
    % SequenceLayerFuser  Basic layer fuser for fusing layers connected in
    % a sequence
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties( Access = private )
        % MatchLayers  The sequences of layers that map to the FusedLayer
        % type that this LayerFuser manages. As a string array or cell
        % array of string arrays.
        MatchLayers
    end
    
    methods
        
        function obj = SequenceLayerFuser( fusedLayerFactory, matchLayers, supportsTraining )
            obj = obj@nnet.internal.cnn.optimizer.LayerFuser( fusedLayerFactory, nargin < 3 || supportsTraining );
            obj.MatchLayers = matchLayers;
        end
        
        function internalLayerGraph = optimizeForPrediction( this, internalLayerGraph )
            % optimizeForPrediction  Overload this to provide different
            % behaviour for prediction optimization as for training
            
            internalLayerGraph = optimize( this, internalLayerGraph );
        end
        
        function internalLayerGraph = optimizeForTraining( this, internalLayerGraph )
            % optimizeForPrediction  Overload this to provide different
            % behaviour for training optimization as for prediction
            
            if this.SupportsTraining
                internalLayerGraph = optimize( this, internalLayerGraph );
            else
                % Clear the LayerIndexMap from any previous layer graphs
                this.LayerIndexMap = [];
            end
        end        
    end
    
    methods( Access = protected )
        
        function matches = findMatches( this, layerGraph )
            % findMatches  Matches to layer sequences as defined by the
            % FusedLayer type
            matchLayers = this.MatchLayers;
            if ~iscell( matchLayers )
                matchLayers = { matchLayers };
            end
            matches = {};
            for i = 1:numel(matchLayers)
                newMatches = iFindLayerSequence(layerGraph, matchLayers{i}, matches);
                matches = [matches; newMatches]; %#ok<AGROW>
            end
        end
        
    end
    
end


%% Internal helpers

function matches = iFindLayerSequence( layerGraph, layersToMatch, existingMatches )
% Find closed sub-graphs that match a given sequence. Only serial sequences
% are matched here.

layers = layerGraph.Layers;
numLayersToMatch = numel(layersToMatch);
graph = layerGraph.getAugmentedDigraph();
adjacencyMatrix = adjacency(graph);

% Get the classes of the layers, for matching.
if iscell( layers )
    layerClasses = cellfun(@(l)string(class(l)), layers);
else
    layerClasses = arrayfun(@(l)string(class(l)), layers);
end

% Replace layers already matched so that they cannot match again
layerClasses(cell2mat(existingMatches)) = "";

% Get candidate starting points
matches = {};
matchesToStart = find(layerClasses == layersToMatch(1));

% Check the successors of each candidate and make sure they match
for m = 1:numel(matchesToStart)
    % Depth-first search produces candidates for matching sequence
    startingMatch = matchesToStart(m);
    theseMatches = dfsearch(graph, startingMatch);
    theseMatches = theseMatches(1:min(numLayersToMatch,end));
    
    % Check subsequent layers all match the sequence, and internal layers
    % connect to only one other layer
    if ~isequal(layerClasses(theseMatches), layersToMatch) || ...
            any(sum(adjacencyMatrix(theseMatches(1:end-1),:), 2) ~= 1)
        theseMatches = [];
    end
    matches = [matches; theseMatches]; %#ok<AGROW>
end
end

