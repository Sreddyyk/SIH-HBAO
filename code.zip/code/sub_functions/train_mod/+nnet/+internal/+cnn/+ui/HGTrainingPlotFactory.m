classdef HGTrainingPlotFactory < nnet.internal.cnn.ui.TrainingPlotFactory
    % HGTrainingPlotFactory   Builder for the training plot used by the CLI.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function trainingPlotPresenter = createPresenter(~, plotConfig)
            if plotConfig.HasVariableNumItersPerEpoch
                epochDisplayer = nnet.internal.cnn.ui.axes.EpochDisplayHider();
                determinateProgress = nnet.internal.cnn.ui.progress.HGDeterminateProgressText();
                tableDataFactory = nnet.internal.cnn.ui.info.VariableEpochSizeTextTableDataFactory();
            else
                epochDisplayer = nnet.internal.cnn.ui.axes.EpochAxesDisplayer();
                determinateProgress = nnet.internal.cnn.ui.progress.HGDeterminateProgressBar();
                tableDataFactory = nnet.internal.cnn.ui.info.TextTableDataFactory();
            end

            % create the view
            legendLayout = nnet.internal.cnn.ui.layout.HGLegend();
            textLayout = nnet.internal.cnn.ui.layout.HGTextTable();
            dialogFactory = nnet.internal.cnn.ui.HGDialogFactory();
            trainingPlotView = nnet.internal.cnn.ui.HGTrainingPlotView(determinateProgress, legendLayout, textLayout, dialogFactory);

            % create the presenter
            if plotConfig.LossType == "classification"
                axesFactory = nnet.internal.cnn.ui.factory.HGClassificationAxesFactory();
                metricRowDataFactory = nnet.internal.cnn.ui.info.ClassificationMetricRowDataFactory();
            else
                axesFactory = nnet.internal.cnn.ui.factory.HGRegressionAxesFactory();
                metricRowDataFactory = nnet.internal.cnn.ui.info.RegressionMetricRowDataFactory();
            end
            executionInfo = iCreateExecutionInfo(plotConfig);
            validationInfo = iCreateValidationInfo(plotConfig);
            epochInfo = iCreateEpochInfo(plotConfig);
            
            watch = nnet.internal.cnn.ui.adapter.Stopwatch();
            stopReasonRowDataFactory = nnet.internal.cnn.ui.info.StopReasonRowDataFactory();
            
            preprocessingDisplayerFactory = nnet.internal.cnn.ui.preprocess.HGPreprocessingDisplayFactory();
            
            helpLauncher = nnet.internal.cnn.ui.info.TrainingPlotHelpLauncher();
            trainingPlotPresenter = nnet.internal.cnn.ui.TrainingPlotPresenterWithDialog(...
                trainingPlotView, tableDataFactory, metricRowDataFactory, stopReasonRowDataFactory, preprocessingDisplayerFactory, ...
                axesFactory, epochDisplayer, helpLauncher, watch, executionInfo, validationInfo, epochInfo);
        end
    end
end

function executionInfo = iCreateExecutionInfo(plotConfig)
executionInfo = nnet.internal.cnn.ui.ExecutionInfo(...
    plotConfig.ExecutionEnvironment, ...
    plotConfig.UseParallel, ...
    plotConfig.TrainingOptions.LearnRateScheduleSettings.Method, ...
    plotConfig.TrainingOptions.InitialLearnRate);
end

function validationInfo = iCreateValidationInfo(plotConfig)
validationInfo = nnet.internal.cnn.ui.ValidationInfo(...
    plotConfig.IsValidationSpecified, ...
    plotConfig.TrainingOptions.ValidationFrequency);
end

function epochInfo = iCreateEpochInfo(plotConfig)
epochInfo = nnet.internal.cnn.ui.EpochInfo(...
    plotConfig.TrainingOptions.MaxEpochs, ...
    plotConfig.NumObservations, ...
    plotConfig.TrainingOptions.MiniBatchSize);
end