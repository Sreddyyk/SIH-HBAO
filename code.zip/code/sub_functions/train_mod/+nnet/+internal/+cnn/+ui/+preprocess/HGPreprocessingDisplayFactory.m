classdef HGPreprocessingDisplayFactory < nnet.internal.cnn.ui.preprocess.PreprocessingDisplayFactory
    % HGPreprocessingDisplayFactory   Factory for creating PreprocessingDisplay
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function preprocessingDisplay = createPreprocessingDisplay(~, willInputsBeNormalized)
            if willInputsBeNormalized
                preprocessingDisplay = nnet.internal.cnn.ui.preprocess.HGMessagePreprocessingDisplay();
            else
                preprocessingDisplay = nnet.internal.cnn.ui.preprocess.HGEmptyPreprocessingDisplay();
            end
        end
    end
end

