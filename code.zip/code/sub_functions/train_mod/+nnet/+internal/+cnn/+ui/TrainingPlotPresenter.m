classdef(Abstract) TrainingPlotPresenter < handle
    % TrainingPlotPresenter   Interface for the presenter for the training plot
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    events
        % Event fired when user indicates that they want to stop training
        StopTrainingRequested 
    end
    
    methods(Abstract)
        showPreprocessingStage(this, willInputsBeNormalized)
        % showPreprocessingStage   Show preprocessing stage of plot.
        
        showTrainingStage(this, trainingStartTime)
        % showTrainingStage   Show training stage of plot.
        
        updatePlot(this, infoStruct)
        % updatePlot   Updates the plot using a struct of information
        
        updatePlotForLastIteration(this, infoStruct)
        % updatePlotForLastIteration   Updates the plot using a struct of
        % information for the last iteration only.
        
        showPostTrainingStage(this, trainingStartTime, infoStruct, trainingStopReason)
        % showPostTrainingStage   Show the post-training stage of the plot
        
        cleanUpDialogs(this)
        % cleanUpDialogs   Clean up dialogs
        
        displayTrainingErrorMessage(this)
        % displayTrainingErrorMessage   Displays message explaining that
        % error occurred during training.
        
        displayPlotErrorMessage(test)
        % displayPlotErrorMessage   Displays message explaining that error
        % occurred in plot.
    end  
end
