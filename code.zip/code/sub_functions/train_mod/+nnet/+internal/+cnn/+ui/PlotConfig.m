classdef(Abstract) PlotConfig < handle
    % PlotConfig   Configuration for neural network plots
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(Abstract, SetAccess = private)                                
        % HasVariableNumItersEpoch   (logical) Will training have a
        % variable number of iterations in each epoch? Variable number of
        % iterations per epochs occurs when either:
        %   - training RNN networks with numeric sequence lengths, or
        %   - the number of observations in the data is unknown (i.e. Inf)
        HasVariableNumItersPerEpoch
        
        % LossType   (string) What type of loss is it? One of
        % "classification" and "regression"
        LossType
        
        % ExecutionEnvironment   (string) One of "cpu" or "gpu".
        % Note that this is not the same as the ExecutionEnvironment found
        % in the TrainingOptions - this is computed *after* trainNetwork is
        % called.
        ExecutionEnvironment
        
        % UseParallel  (logical) Will use parallel?
        UseParallel
        
        % NumObservations   (integer) Number of observations in data. Can
        % be non-finite if number of observations is unknown.
        NumObservations
        
        % IsValidationSpecified   (logical) Has validation data been specified?
        IsValidationSpecified

        % TrainingOptions   (trainingOptions). The training options object
        % created by user of trainNetwork.
        TrainingOptions
    end
end

