classdef Metric < nnet.internal.cnn.ui.metric.UpdateableMetric
    % Metric   Class which reads information struct and updates its UpdateableSeries if necessary.
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    properties(Access = private)
        % UpdateableSeries   (nnet.internal.cnn.ui.axes.UpdateableSeries)
        % Series to update
        UpdateableSeries
        
        % DuringTrainingMetricName   (char) Name of struct field name to extract
        % during training
        DuringTrainingMetricName
        
        % FinalizedMetricName   (char) Name of struct field name to extract
        % during the finalization step. This can also be an empty string,
        % which implies that there is no finalized metric name.
        FinalizedMetricName
        
        % CanUpdateOnLastIteration   (bool) True if this Metric can have
        % its values updated on the last iteration of training.
        CanUpdateOnLastIteration        
        
        % CanUpdateAfterTraining  (bool) True if this Metric can have its
        % values updated after the training loop has been completed (i.e.
        % when reporting the finalized validation results).
        CanUpdateAfterTraining
    end
    
    methods
        function this = Metric(updateableSeries, duringTrainingMetricName, finalizedMetricName, canUpdateOnLastIteration)
            this.UpdateableSeries = updateableSeries;
            
            this.DuringTrainingMetricName = duringTrainingMetricName;
            this.FinalizedMetricName = finalizedMetricName;
            
            this.CanUpdateOnLastIteration = canUpdateOnLastIteration;
            this.CanUpdateAfterTraining = ~isempty(finalizedMetricName);
        end
        
        function update(this, infoStruct)
            % Updates the data in this metric during training.
            this.doUpdate(infoStruct, this.DuringTrainingMetricName);
        end
        
        function updateForLastIteration(this, infoStruct)
            % Updates the data in this metric on the last iteration of
            % training.
            if this.CanUpdateOnLastIteration
                this.doUpdate(infoStruct, this.DuringTrainingMetricName);
            end
        end
        
        function updatePostTraining(this, infoStruct)
            % Updates the data in this metric after training (e.g. the
            % post-batch-normalization calculation of validation).
            if this.CanUpdateAfterTraining
                this.doUpdate(infoStruct, this.FinalizedMetricName);
            end
        end
    end
    
    methods(Access = private)        
        function doUpdate(this, infoStruct, metricName)
            % Performs an update, adding the new metric values to the
            % UpdateableSeries.
            metricValue = infoStruct.(metricName);
            if iMetricIsNonEmpty(metricValue)
                xValue = infoStruct.Iteration;
                yValue = infoStruct.(metricName);
                this.UpdateableSeries.add(xValue, yValue);
            end
        end
    end
end

function tf = iMetricIsNonEmpty(metricValue)
tf = ~isempty(metricValue);
end
