classdef UIFigureLegend < nnet.internal.cnn.ui.layout.LegendLayout
    % UIFigureLegend   Shows a legend for uifigure-version of the training plot
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(Dependent)
        % Parent   (graphics handle) The parent component
        Parent 
    end
    
    properties(SetAccess = private)
        % MainPanel   (matlab.ui.container.Panel)
        % The main panel representing the entire legend.
        MainPanel
        
        % PreferredHeight   (integer) Preferred height of MainPanel in
        % pixels
        PreferredHeight
    end
    
    properties
        % PreferredWidth   (integer) Preferred width of MainPanel in pixels
        PreferredWidth 
    end
    
    properties(Access = private)                
        % GridLayout   (uigridlayout)
        % Layout for laying all the individual elements in the legend.
        GridLayout
        
        % SectionHeader Panels (cell of panels)
        SectionHeaderPanels
        
        % SubSectionPanels  (cell of panels)
        SubSectionPanels
        
        % Axes (cell of panels)
        Axes 
    end
    
    methods
        function this = UIFigureLegend()
            this.MainPanel = uipanel(...
                'Parent', [], ...
                'BorderType', 'line', ...
                'BackgroundColor', 'white', ...
                'Units', 'pixels', ...
                'HighlightColor', iBorderColor());
            
            this.PreferredWidth = iWidthInPixels(); 
            this.PreferredHeight = 100;
            
            this.MainPanel.Position(3) = this.PreferredWidth;
            
            this.SectionHeaderPanels = {};
            this.SubSectionPanels = {};
            this.Axes = {};
            
            this.createInnerGUIComponents();
        end
        
        function set.PreferredWidth(this, width)
            this.PreferredWidth = width;
            
            this.MainPanel.Position(3) = this.PreferredWidth; %#ok<MCSUP>
            
            axesWidthInPixels = this.PreferredWidth - iLeftPaddingInPixels();
            for i=1:numel(this.Axes) %#ok<MCSUP>
                this.Axes{i}.Position(3) = axesWidthInPixels; %#ok<MCSUP>
                this.Axes{i}.XLim = [0, axesWidthInPixels]; %#ok<MCSUP>
            end
        end
        
        function parent = get.Parent(this)
            parent = this.MainPanel.Parent; 
        end
        
        function set.Parent(this, parent)
            this.MainPanel.Parent = parent; 
        end
        
        function addSection(this, sectionName, sectionStructArr)

            % add vertical spacer if there is already a section
            if numel(this.SectionHeaderPanels) > 0
                this.addTinyVerticalSpacer();
            end
            
            % add panel for the section header.
            this.addSectionHeader(sectionName);
            
            % add successive panels for each subsection
            for lineIndex=1:numel(sectionStructArr)
                this.addSubSection(sectionStructArr(lineIndex), lineIndex);
            end
            
            this.updateSizeOfLegend();
        end
    end
    
    methods(Access = private)
        function addSectionHeader(this, sectionName)
            horizontalHeaderPanel = uigridlayout('Parent', this.GridLayout, 'RowHeight', {iTextHeightInPixels()}, 'ColumnWidth', {'1x'}, ...
                'Padding', [0,0,0,0], 'RowSpacing', 0, 'ColumnSpacing', 0);
            this.SectionHeaderPanels{end+1} = horizontalHeaderPanel;
            
            % add section
            sectionIndex = numel(this.SectionHeaderPanels);
            
            % add section title
            iAddSectionTitle(horizontalHeaderPanel, sectionIndex, sectionName);
        end
        
        function addSubSection(this, sectionStruct, lineIndex)
            % addSubSection   the subsection consists of a fixed space on the left, then an
            % axes object that fills the remaining horizontal space.
            
            subSectionHorizontalPanel = uigridlayout('Parent', this.GridLayout, 'RowHeight', {'1x'}, 'ColumnWidth', {'1x'}, ...
                'Padding', [iLeftPaddingInPixels(), 0,0,0]);
            
            axesPanel = uipanel('Parent', subSectionHorizontalPanel, 'BorderType', 'none', 'BackgroundColor', 'white');
            this.addAxes(axesPanel, sectionStruct, this.PreferredWidth - iLeftPaddingInPixels(), lineIndex);
            
            % add subSectionPanel to various things.
            this.SubSectionPanels{end+1} = subSectionHorizontalPanel;
            iSetUpPreferredHeightInGridParent(this.GridLayout, subSectionHorizontalPanel, iTextHeightInPixels());
        end
        
        function addAxes(this, parent, sectionStruct, axesWidthInPixels, lineIndex)
            
            sectionIndex = numel(this.SectionHeaderPanels);
            
            % the axes draws two things:
            %   1) a line with the correct properties
            %   2) a text label on the right of the axes
            axesTag = ['NNET_CNN_TRAININGPLOT_UIFIGURE_LEGEND_SECTION', num2str(sectionIndex), '_SUBSECTION', num2str(lineIndex)];
            ax = uiaxes('Parent', parent, ...
                'Units', 'pixels', ...
                'XTick', [], 'YTick', [], ...
                'XLim', [0,axesWidthInPixels], ...  % Make XLim in terms of pixels so that we can control the length of the line below.
                'YLim', [0,1], ...
                'Box', 'off', ...
                'Position', [0,0,axesWidthInPixels,iTextHeightInPixels()], ...
                'BackgroundColor', 'white', ...
                'Tag', axesTag);
            axis(ax, 'off');
            ax.Interactions = [];  % Stop mouse draggability.
            ax.Toolbar.Visible = false;  % Turn off floating palette.
            this.Axes{end+1} = ax;
            
            % draw line in the axes.
            lineWidth = 60;
            lineTag = ['NNET_CNN_TRAININGPLOT_UIFIGURE_LEGEND_SECTION', num2str(sectionIndex), '_LINE', num2str(lineIndex)];
            line(ax, 'XData', [0,0.5,1]*lineWidth, 'YData', [0.5,0.5,0.5], ...
                'LineStyle', sectionStruct.LineStyle, ...
                'LineWidth', sectionStruct.LineWidth, ...
                'Color', sectionStruct.LineColor, ...
                'Marker', sectionStruct.Marker, ...
                'MarkerIndices', 2, ...
                'MarkerFaceColor', sectionStruct.MarkerFaceColor, ...
                'MarkerEdgeColor', sectionStruct.MarkerEdgeColor, ...
                'Tag', lineTag);
            
            % add text label on the right of the axes.
            spaceBetweenAxesAndText = 6;
            textTag = ['NNET_CNN_TRAININGPLOT_UIFIGURE_LEGEND_SECTION', num2str(sectionIndex), '_TEXT', num2str(lineIndex)];
            text(...
                lineWidth+spaceBetweenAxesAndText, ...
                0.5, ...
                sectionStruct.Text, ...
                'Parent', ax, ...
                'FontSize', iFontSizeInPixels(), ... % uilabel only supports pixels for font units
                'Tag', textTag);
        end
        
        function addTinyVerticalSpacer(this)
            verticalSpacer = uipanel('Parent', this.GridLayout, 'BorderType', 'none', 'BackgroundColor', 'white');
            iSetUpPreferredHeightInGridParent(this.GridLayout, verticalSpacer, 0.5 * iTextHeightInPixels());
        end
        
        function updateSizeOfLegend(this)
            % compute the height that the section should have
            numElements = numel(this.SectionHeaderPanels) + numel(this.SubSectionPanels);
            numSpacers = numel(this.SectionHeaderPanels)-1;
            heightOfContents = iTextHeightInPixels() * (numElements + numSpacers*0.5);
            this.PreferredHeight = heightOfContents + 2*iMargin();
            % update the height of the legend
            this.MainPanel.Position(4) = this.PreferredHeight;
            % update the width of the legend
            this.MainPanel.Position(3) = this.PreferredWidth;
        end
    end
    
    methods(Access = private)
        function createInnerGUIComponents(this)            
            gridSize = [1,1];  % Cannot set any elements of GridSize to 0.
            this.GridLayout = uigridlayout(this.MainPanel, gridSize, 'RowSpacing', 0, 'ColumnSpacing', 0, 'Padding', repmat(iMargin(), 1,4));  
        end
    end
end

% helpers
function sectionTitle = iAddSectionTitle(parent, sectionIndex, sectionName)
tag = sprintf('NNET_CNN_TRAININGPLOT_UIFIGURE_LEGEND_SECTION_TITLE%d', sectionIndex);

sectionTitle = uilabel(...
    'Parent', parent, ...
    'Text', sectionName, ...
    'HorizontalAlignment', 'left', ...
    'VerticalAlignment', 'center', ...
    'BackgroundColor', 'white', ...
    'FontSize', iFontSizeInPixels(), ...  % uilabel only supports pixels for font units
    'FontWeight', 'bold', ...
    'Tag', tag);
end

function color = iBorderColor()
color = [0.8, 0.8, 0.8];
end

function margin = iMargin()
margin = 12;
end

function width = iLeftPaddingInPixels()
width = 25;
end

function height = iTextHeightInPixels()
height = 23;
end

function fontSize = iFontSizeInPixels()
fontSize = 12;
end

function iSetUpPreferredHeightInGridParent(gridParent, objectToChangeHeight, height)
rowIndex = iGetIndicesInGrid(gridParent, objectToChangeHeight);
gridParent.RowHeight{rowIndex} = height;
end

function [rowIndex, colIndex] = iGetIndicesInGrid(gridParent, object)
childIndex = find(gridParent.Children == object, 1);
rowIndex = gridParent.Children(childIndex).Layout.Row;     % could be array!
colIndex = gridParent.Children(childIndex).Layout.Column;  % could be array!
end

function width = iWidthInPixels()
width = 500;
end
