classdef CLITrainingPlotter < nnet.internal.cnn.ui.TrainingPlotter
    % CLITrainingPlotter   Training plotter for CLI training plot.
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    properties(Access = private)
        % TrainingPlotFactory   (nnet.internal.cnn.ui.TrainingPlotFactory)
        % Constructs a training plot presenter
        TrainingPlotFactory
        
        % StopTrainingRequestedListener   (listener) Listener on
        % StopTrainingRequested event fired from TrainingPlotPresenter
        StopTrainingRequestedListener
    end
    
    properties(SetAccess = private)
        % TrainingPlotPresenter
        % (nnet.internal.cnn.ui.TrainingPlotPresenter)
        % The presenter for the training progress plot.
        TrainingPlotPresenter = []
        
        % TrainingStartTime   (datetime) The time that start was called
        TrainingStartTime
        
        % LastInfoStruct   (struct) Store of the last infostruct computed
        % so that the presenter can be given it for the post-training stage
        LastInfoStruct = [];
        
        % HasFinishedTraining   (boolean) Has training finished? More
        % specifically, has trainNetwork *completely* finished?
        HasFinishedTraining = false
    end
    
    methods
        function this = CLITrainingPlotter(trainingPlotFactory)
            this.TrainingPlotFactory = trainingPlotFactory;
            this.HasFinishedTraining = false;
        end
        
        function configure(this, plotConfig)
            this.HasFinishedTraining = false;
            this.TrainingPlotPresenter = this.TrainingPlotFactory.createPresenter(plotConfig);
            
            this.StopTrainingRequestedListener = addlistener(...
                this.TrainingPlotPresenter, 'StopTrainingRequested',...
                @this.stopTrainingRequestedCallback);
        end
        
        function showPreprocessingStage(this, willInputsBeNormalized)
            this.TrainingPlotPresenter.showPreprocessingStage(willInputsBeNormalized);
        end

        function showTrainingStage(this, trainingStartDate)
            this.TrainingPlotPresenter.showTrainingStage(trainingStartDate);
        end
        
        function updatePlot(this, infoStruct)
            this.TrainingPlotPresenter.updatePlot(infoStruct);
        end
        
        function updatePlotForLastIteration(this, infoStruct)
            this.TrainingPlotPresenter.updatePlotForLastIteration(infoStruct);
        end
        
        function showPostTrainingStage(this, trainingStartDate, infoStruct, stopReason)
            this.TrainingPlotPresenter.showPostTrainingStage(trainingStartDate, infoStruct, stopReason);
        end
        
        function showPlotError(this, ~)
            this.TrainingPlotPresenter.cleanUpDialogs();
            this.TrainingPlotPresenter.displayPlotErrorMessage();
        end
        
        function finalizePlot(this, errorOccurred)
            if errorOccurred
                this.TrainingPlotPresenter.displayTrainingErrorMessage(); 
            end
            this.TrainingPlotPresenter.cleanUpDialogs();
            this.HasFinishedTraining = true;
        end
    end
    
    methods(Access = private)        
        % callbacks
        function stopTrainingRequestedCallback(this, ~, ~)
            stopReason = nnet.internal.cnn.util.TrainingStopReason.StopButton;
            evtData = nnet.internal.cnn.util.TrainingInterruptEventData( stopReason );
            
            this.notify('StopTrainingRequested', evtData);
        end
    end
end

