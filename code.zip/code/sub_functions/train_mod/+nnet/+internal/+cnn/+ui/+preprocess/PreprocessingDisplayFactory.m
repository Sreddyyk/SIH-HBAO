classdef(Abstract) PreprocessingDisplayFactory < handle
    % PreprocessingDisplayFactory   Interface for factories that create preprocessing displays
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods(Abstract)
        % createPreprocessingDisplay   Create preprocessing display
        % based on whether or not inputs will be normalized on training
        % setup.
        preprocessingDisplay = createPreprocessingDisplay(this, willInputsBeNormalized)
    end
end

