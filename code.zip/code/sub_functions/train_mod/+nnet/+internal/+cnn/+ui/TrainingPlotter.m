classdef(Abstract) TrainingPlotter < handle
    % TrainingPlotter   Interface for plotting information during deep learning training
    
    %   Copyright 2019 The MathWorks, Inc.
    
    events
        StopTrainingRequested 
    end
    
    methods(Abstract)
        % configure   Configure the plot with config
        configure(this, plotConfig)
        
        % showPreprocessingStage   Have the plot show that some preprocessing is occurring before training
        % 
        % willInputsBeNormalized: this field is a logical which indicates
        % whether or not input normalization will occur or not.
        showPreprocessingStage(this, willInputsBeNormalized)
        
        % showTrainingStage   Have plot show that training has now started
        %
        % The trainingStartDate is a datetime object.
        showTrainingStage(this, trainingStartDate)
        
        % updatePlot   Update the plot during training. 
        %
        % This method is called at the *end* of each training iteration.
        %
        % The infoStruct contains the following fields:
        %   - Epoch: The current epoch number
        %   - Iteration: The iteration number that has just finished
        %   - LearnRate: The current learn rate
        %   - ElapsedTime: The time elapsed since *training* started.
        %
        %   - Loss: The loss value
        %   - Accuracy: The accuracy value. Is NaN if not relevant.
        %   - RMSE: The RMSE value. Is NaN if not relevant.
        %   - ValidationLoss: The validation loss. Is NaN if validation didn't occur in this iteration.
        %   - ValidationAccuracy: The validation accuracy. Is NaN if not relevant, or validation didn't occur in this iteration.
        %   - ValidationRMSE: The validation RMSE. Is NAN if not relevant, or validation didn't occur in this iteration.
        updatePlot(this, infoStruct)
        
        % updatePlotForLastIteration   Update the plot on the last iteration of training.
        %
        % This method is called at the *end* of the last training
        % iteration. Note that both updatePlot() and
        % updatePlotForLastIteration() will be called at the end of the last
        % iteration. That is because at the point updatePlot() is called,
        % we don't know whether or not the iteration is the last iteration.
        % It is only at the point of updatePlotForLastIteration() do we
        % know. One way this differs from updatePlot() is that we always
        % receive validation information on the last iteration, whereas we
        % do not always for updatePlot().
        %
        % The infoStruct contains the same fields as for the updatePlot()
        % method.
        updatePlotForLastIteration(this, infoStruct)
        
        % showPostTrainingStage   Have plot show that training has now finished.
        %
        % This method is called *after* any finalization has occurred. The
        % infostruct contains the following fields:
        %   - Epoch: The current epoch number
        %   - Iteration: The iteration number that has just finished
        %   - LearnRate: The current learn rate
        %   - ElapsedTime: The time elapsed since *training* started.
        %
        %   - FinalValidationLoss: The *finalized* validation loss (after network finalization). Is NaN if validation didn't occur.
        %   - FinalValidationAccuracy: The *finalized* validation accuracy (after network finalization). Is NaN if not relevant, or validation didn't occur.
        %   - FinalValidationRMSE: The *finalized* validation RMSE (after network finalization). Is NAN if not relevant, or validation didn't occur.
        showPostTrainingStage(this, trainingStartDate, postTrainingInfoStruct, stopReason)
        
        % showPlotError   Display error thrown by plot during training and post-training.
        %
        % If exception is thrown due to the plot, we capture the error and
        % convert it to a warning. However, this class is passed the
        % exception that was thrown, so that it can be reported by the
        % plot.
        showPlotError(this, exception)
        
        % finalizePlot   Finalize the plot.
        %
        % This is called right at the end of the entire training and
        % post-training process. 
        finalizePlot(this, errorOccurred)
    end
end

