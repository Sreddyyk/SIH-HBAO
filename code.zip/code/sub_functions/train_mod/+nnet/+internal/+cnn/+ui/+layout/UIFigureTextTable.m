classdef UIFigureTextTable < nnet.internal.cnn.ui.layout.TextLayout
    % UIFigureTextTable   Panel for showing text in tabular form in the uifigure-version of the training plot
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(Dependent)
        % Parent   (graphics handle) The parent component
        Parent 
    end
    
    properties(SetAccess = private)        
        % MainPanel   (matlab.ui.container.Panel)
        % The main panel representing the entire legend.
        MainPanel
        
        % PreferredHeight   (integer) The preferred height of the MainPanel
        % in pixels
        PreferredHeight
    end
    
    properties(Access = private)
        % GridContainer   (matlab.ui.container.GridLayout)
        % The grid container that lays out all the text
        GridContainer
        
        % RowHeights   (vector of doubles) The pixel heights of
        % each row
        RowHeights
        
        % CurrentSectionIndex   (integer) Used to generate tags.
        CurrentSectionIndex
        
        % SectionNames   (cellstring) Cell of section names.
        SectionNames
        
        % SectionStructs   (cell of struct arrays) This stores the section
        % structs
        SectionStructs
        
        % TextControls   (cell of nx2 array of uilabels) Stores all the
        % uicontrols. Each cell element corresponds to a section and is of
        % size nx2 where n is the number of rows in that section. n varies
        % with the section in general.
        TextControls
    end
    
    methods
        function this = UIFigureTextTable()
            this.MainPanel = uipanel(...
                'Parent', [], ...
                'BorderType', 'none');
            
            this.reset();
        end
        
        function parent = get.Parent(this)
            parent = this.MainPanel.Parent; 
        end
        
        function set.Parent(this, parent)
            this.MainPanel.Parent = parent;
        end
        
        function reset(this)
            this.CurrentSectionIndex = 0;
            this.SectionNames = {};
            this.SectionStructs = {};
            this.TextControls = {};
            
            this.RowHeights = [];
            this.PreferredHeight = 0;
            
            delete(this.GridContainer);
            gridSize = [1,2];  % Cannot set any elements of GridSize to 0.
            this.GridContainer = uigridlayout(this.MainPanel, gridSize, 'RowSpacing', 0, 'ColumnSpacing', 0, 'Padding', [0,0,0,0]);  
        end
        
        function addSection(this, sectionName, sectionStructArr)
            numContentRows = numel(sectionStructArr);
            this.CurrentSectionIndex = this.CurrentSectionIndex + 1;
            this.SectionNames{end+1} = sectionName;
            this.SectionStructs{end+1} = sectionStructArr;
            this.TextControls{end+1} = matlab.ui.control.Label.empty(0,2);
            
            % add row for separation
            if this.CurrentSectionIndex > 1
                this.addSeparationRow();
            end
            
            % add title and contents
            this.addTitle(sectionName);
            for i=1:numContentRows
                 this.addRow(i, sectionStructArr);
            end
            
            % Update preferred height
            this.PreferredHeight = sum(this.RowHeights);
        end
        
        function update(this, rowID, newRightText)
            [sectionIndex, subSectionIndex] = this.findRow(rowID);
            if ~isempty(sectionIndex) && ~isempty(subSectionIndex)
                this.SectionStructs{sectionIndex}(subSectionIndex).RightText = newRightText;
                this.TextControls{sectionIndex}(subSectionIndex, 2).Text = newRightText;
            end
        end
    end
    
    methods(Access = private)
        function addSeparationRow(this)
            iAddSpacer(this.GridContainer);
            iAddSpacer(this.GridContainer);
            
            % Update row height and record it in RowHeights.
            rowHeight = 0.5 * iTextHeightInPixels();
            this.GridContainer.RowHeight{end} = rowHeight;
            this.RowHeights = [this.RowHeights, rowHeight];
        end
        
        function addTitle(this, titleName)
            uilabel(...
                'Parent', this.GridContainer, ...
                'Text', titleName, ...
                'FontWeight', 'bold', ...
                'FontSize', iFontSizeInPixels(), ...  % FontSize can only be pixels for uilabel.
                'HorizontalAlignment', 'left', ...
                'Tag', ['NNET_CNN_TRAININGPLOT_UIFIGURE_TEXTTABLE_TITLE', num2str(this.CurrentSectionIndex)]);
            
            iAddSpacer(this.GridContainer);
            
            % Update row height and record it in RowHeights.
            rowHeight = 1 * iTextHeightInPixels();
            this.GridContainer.RowHeight{end} = rowHeight;
            this.RowHeights = [this.RowHeights, rowHeight];
        end
        
        function addRow(this, rowIndex, sectionStructArr)
            leftControl = uilabel(...
                'Parent', this.GridContainer, ...
                'Text', sectionStructArr(rowIndex).LeftText, ...
                'FontSize', iFontSizeInPixels(), ...  % FontSize can only be pixels for uilabel.
                'HorizontalAlignment', 'left', ...
                'Tag', ['NNET_CNN_TRAININGPLOT_UIFIGURE_TEXTTABLE_LEFTTEXT_', sectionStructArr(rowIndex).RowID]);
            
            rightControl = uilabel(...
                'Parent', this.GridContainer, ...
                'Text', sectionStructArr(rowIndex).RightText, ...
                'FontSize', iFontSizeInPixels(), ... % FontSize can only be pixels for uilabel.
                'HorizontalAlignment', 'left', ...
                'Tag', ['NNET_CNN_TRAININGPLOT_UIFIGURE_TEXTTABLE_RIGHTTEXT_', sectionStructArr(rowIndex).RowID]);
            
            this.TextControls{this.CurrentSectionIndex}(end+1, :) = [leftControl, rightControl];
            
            % Update row height and record it in RowHeights.
            rowHeight = 1 * iTextHeightInPixels();
            this.GridContainer.RowHeight{end} = rowHeight;
            this.RowHeights = [this.RowHeights, rowHeight];
        end
        
        function [sectionIndex, subSectionIndex] = findRow(this, rowID)
            sectionIndex = [];
            subSectionIndex = [];
            for i=1:numel(this.SectionStructs)
                sectionStruct = this.SectionStructs{i};
                j = find( strcmp({sectionStruct.RowID}, rowID), 1);
                if ~isempty(j)
                    sectionIndex = i;
                    subSectionIndex = j;
                    break; 
                end
            end
        end
    end
    
end

% helpers
function iAddSpacer(parent)
uilabel('Parent', parent, 'Text', '');
end

function pixels = iFontSizeInPixels()
pixels = 12;
end

function height = iTextHeightInPixels()
height = 23;
end
