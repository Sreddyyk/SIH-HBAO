classdef HGDialogFactory < nnet.internal.cnn.ui.DialogFactory
    % HGDialogFactory   Factory for creating dialogs
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    methods        
        function h = createWarningDialog(~, parent, message, titleMessage, tag) %#ok<INUSL>
            h = msgbox(...
                message.getString(), ...
                titleMessage.getString(), ...
                'warn', 'modal');
            h.Tag = tag;
        end
    end
    
end

