classdef UIFigureDeterminateProgressText < nnet.internal.cnn.ui.progress.DeterminateProgress
    % UIFigureDeterminateProgressText   Shows progress as text for the uifigure-version of the training plot
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        % Parent   (graphics handle) The parent of MainPanel which holds
        % the progress bar.
        Parent = []

        % Value   (double) The current value. The minimum is 0.
        Value = 0
        
        % Maximum   (positive double) The maximum value.
        Maximum = 1
    end
    
    properties(SetAccess = private)
        % MainPanel   (uipanel) The main panel holding the progress bar
        MainPanel
        
        % PreferredHeight   (integer) The preferred height of MainPanel in
        % pixels
        PreferredHeight = 31
    end
    
    properties(Access = private)
        % ProgressText   (uilabel) The text control that indicates the
        % current progress
        ProgressText
        
        % StopButton   (uibutton) The button to stop training
        StopButton
    end
    
    properties(Constant, Access = private)
        % StopButtonWidth
        StopButtonWidth = 44 
    end
    
    methods
        function this = UIFigureDeterminateProgressText()
            this.Value = 0;
            this.Maximum = 1;
            this.Parent = [];
            this.createGUIComponents();
        end
        
        function set.Value(this, value)
            this.Value = value;
            this.updateText();
        end
        
        function set.Maximum(this, maxValue)
            this.Maximum = maxValue;
            this.updateText();
        end
        
        function set.Parent(this, parent)
            this.Parent = parent;
            this.MainPanel.Parent = parent; %#ok<MCSUP>
        end
    end
    
    methods(Access = private)
        function createGUIComponents(this)
            this.createMainPanel(this.Parent);
            
            horizontalFlow = uigridlayout(...
                'Parent', this.MainPanel, ...
                'RowHeight', { this.PreferredHeight }, ...
                'ColumnWidth', {'1x', this.StopButtonWidth }, ...
                'RowSpacing', 0, 'ColumnSpacing', 5, 'Padding', [0,0,0,0]);
            
            this.createProgressText(horizontalFlow);
            this.createStopButton(horizontalFlow);
            
            this.updateText();
        end
        
        function createMainPanel(this, parent)
            this.MainPanel = uipanel(...
                'Parent', parent, ...
                'BorderType', 'none', ...
                'Tag', 'NNET_CNN_TRAININGPLOT_UIFIGURE_DETERMINATEPROGTEXT_MAINPANEL');
        end
        
        function createProgressText(this, parent)
            this.ProgressText = uilabel(...
                'Parent', parent, ...
                'Text', '', ...
                'FontSize', iFontSizeInPixels(), ... % uilabel only supports pixels for font units
                'HorizontalAlignment', 'left', ...
                'VerticalAlignment', 'center', ...
                'Tag', 'NNET_CNN_TRAININGPLOT_UIFIGURE_DETERMINATEPROGTEXT_PROGRESSTEXT');
        end
        
        function createStopButton(this, parent)
            this.StopButton = iCreateStopButton(parent);
            this.StopButton.ButtonPushedFcn = @this.stopButtonClickedCallback;
        end
        
        function updateText(this)
            % The message displays something like "Training x".
            % However, currValue indicates the iteration has just
            % completed, not the iteration that we are going to train.
            % Therefore, we must +1 to currValue, unless we have already
            % reached the last iteration.
            currValueToShow = this.Value + 1;
            m = message('nnet_cnn:internal:cnn:ui:trainingplot:ProgressBarLabelWithoutMax', num2str(currValueToShow));
            this.ProgressText.Text = m.getString();
        end
        
        % callbacks
        function stopButtonClickedCallback(this, ~, ~)
            this.notify('StopButtonClicked'); 
        end
    end
end

% helpers
function stopButton = iCreateStopButton(parent)
stopButtonText = message('nnet_cnn:internal:cnn:ui:trainingplot:StopButton').getString();
stopButton = uibutton(parent, ...
    'Text', stopButtonText, ...
    'Tag', 'NNET_CNN_TRAININGPLOT_UIFIGURE_DETERMINATEPROGTEXT_STOPBUTTON');
end

function val = iFontSizeInPixels()
val = 12;
end


