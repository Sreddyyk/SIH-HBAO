classdef HGEmptyPreprocessingDisplay < nnet.internal.cnn.ui.preprocess.PreprocessingDisplay
    % HGEmptyPreprocessingDisplay   PreprocessingDisplay that shows nothing.
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    methods
        function panel = getPanel(~)
            panel = uipanel('Parent', [], 'BorderType', 'none'); 
        end
    end
    
end

