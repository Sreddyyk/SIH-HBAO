classdef UIFigureEmptyPreprocessingDisplay < nnet.internal.cnn.ui.preprocess.PreprocessingDisplay
    % UIFigureEmptyPreprocessingDisplay   PreprocessingDisplayer that shows nothing.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function panel = getPanel(~)
            panel = uipanel('Parent', [], 'BorderType', 'none'); 
        end
    end
    
end

