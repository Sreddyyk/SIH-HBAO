classdef(Abstract) DialogFactory < handle
    % DialogFactory   Interface for factories that create dialogs
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods(Abstract)     
        % createWarningDialog   Creates warning dialog
        h = createWarningDialog(~, parent, message, titleMessage, tag)
    end
    
end

