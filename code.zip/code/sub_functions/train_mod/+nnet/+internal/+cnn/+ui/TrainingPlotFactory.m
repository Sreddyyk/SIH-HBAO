classdef (Abstract) TrainingPlotFactory < handle
    % TrainingPlotFactory   Interface for factories that create training plots
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods (Abstract)
        trainingPlotPresenter = createPresenter(this, plotConfig);
    end
end