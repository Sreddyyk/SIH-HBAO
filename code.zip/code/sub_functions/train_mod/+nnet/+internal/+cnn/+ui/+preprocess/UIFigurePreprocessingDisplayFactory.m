classdef UIFigurePreprocessingDisplayFactory < nnet.internal.cnn.ui.preprocess.PreprocessingDisplayFactory
    % UIFigurePreprocessingDisplayFactory   Factory for creating uifigure-versions of PreprocessingDisplay
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function preprocessingDisplay = createPreprocessingDisplay(~, willInputsBeNormalized)
            if willInputsBeNormalized
                preprocessingDisplay = nnet.internal.cnn.ui.preprocess.UIFigureMessagePreprocessingDisplay();
            else
                preprocessingDisplay = nnet.internal.cnn.ui.preprocess.UIFigureEmptyPreprocessingDisplay();
            end
        end
    end
end

