function saveTrainingPlotFigureToFile(parentFigure, filePath, cliTrainingPlotter)
% saveTrainingPlotFigureToFile   Saves the training plot figure to file.
% 
% This function ensures that the saved figure does not contain any NNET
% objects. It's important that saving the training plot figure to file does
% not inadvertently save any internal objects. Saving any internal
% objects can cause save/load compatibility problems between releases if
% those internal objects change, and we do not want to have to support
% save/load of training plot internals for future releases.
% 
% You must ensure that the parentFigure is the figure that contains the
% training plot elements that were constructed using the given
% CLITrainingPlotter.

assert(isa(cliTrainingPlotter, 'nnet.internal.cnn.ui.CLITrainingPlotter'));

if ~cliTrainingPlotter.HasFinishedTraining
    error('nnet_cnn:internal:cnn:ui:trainingplot:InternalError', ...
        'You can only save the training plot once training has finished');
end

% Delete any stop button contained in the parentFigure. That's because the
% stop button can contain references to internal objects, and we do not
% want to save that in the figure.
stopButtons = [...
    findall(parentFigure, 'Tag', 'NNET_CNN_TRAININGPLOT_UIFIGURE_DETERMINATEPROGTEXT_STOPBUTTON'); ...
    findall(parentFigure, 'Tag', 'NNET_CNN_TRAININGPLOT_UIFIGURE_DETERMINATEPROGBARANDTEXT_STOPBUTTON') ...
    ];
delete(stopButtons);

% Finally save the figure.
savefig(parentFigure, filePath);

end