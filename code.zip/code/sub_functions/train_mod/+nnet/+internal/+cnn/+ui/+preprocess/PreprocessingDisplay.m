classdef(Abstract) PreprocessingDisplay < handle
    % PreprocessingDisplay   Interface for strategy for displaying preprocessing information
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    methods(Abstract)
        % getPanel   Get panel to display preprocessing information.
        panel = getPanel(this)
    end
    
end

