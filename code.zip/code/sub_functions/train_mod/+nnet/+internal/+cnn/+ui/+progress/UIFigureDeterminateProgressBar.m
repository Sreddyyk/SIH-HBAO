classdef UIFigureDeterminateProgressBar < nnet.internal.cnn.ui.progress.DeterminateProgress
    % UIFigureDeterminateProgressBar   A determinate progress bar implemented for the uifigure-version of the training plot
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties
        % Parent   (graphics handle) The parent of MainPanel which holds
        % the progress bar.
        Parent = []
    end
    
    properties
        % Value   (double) The value between Minimum and Maximum
        % (inclusive) indicating where the progress bar is.
        Value = 0
        
        % Maximum   (double) The maximum value of the progress bar
        Maximum = 1
    end
    
    properties(SetAccess = private)        
        % MainPanel   (uipanel) The main panel holding the progress bar
        MainPanel
    end
    
    properties(Dependent, SetAccess = private)
        % PreferredHeight   (integer) The preferred height of MainPanel in
        % pixels
        PreferredHeight
    end
    
    properties(Access = private)
        % Minimum   (double) The minimum value of the progress bar
        Minimum = 0
        
        % ProgressText   (uipanel) The text control that indicates the
        % current progress
        ProgressText
        
        % ProgressTextHeight   (integer) Height of ProgressText in pixels
        ProgressTextHeight = 31
        
        % Axes   (axes) The axes on which to draw the progress bar
        Axes
        
        % OuterBorder   (patch) The patch object that draws the border
        % around the axes
        OuterBorder
        
        % Bar   (patch) The patch object that draws the moving bar
        Bar
        
        % BarHeight   (integer) Height of progress bar
        BarHeight = 31
        
        % StopButton   (uibutton) The button to stop
        % training
        StopButton
        
        % StopButtonWidth
        StopButtonWidth = 44
    end
    
    methods
        function this = UIFigureDeterminateProgressBar()
            this.createGUIComponents();
        end
        
        function set.Value(this, value)
            this.Value = value;
            this.update();
        end
        
        function set.Maximum(this, maxValue)
            this.Maximum = maxValue;
            this.issueWarningIfBoundsInvalid();
            this.update();
        end
        
        function set.Parent(this, parent)
            this.Parent = parent;
            this.MainPanel.Parent = parent; %#ok<MCSUP>
        end
        
        function h = get.PreferredHeight(this)
            h = this.ProgressTextHeight + this.BarHeight; 
        end
    end
    
    methods(Access = private)
        function issueWarningIfBoundsInvalid(this)
            if this.areBoundsInvalid()
                this.Minimum = 0;
                this.Maximum = 1;
                warning(message('nnet_cnn:internal:cnn:ui:trainingplot:GenericWarning'));
            end
        end
        
        function tf = areBoundsInvalid(this)
            tf = ~isnumeric(this.Maximum) || ~isreal(this.Maximum) || ...
                isempty(this.Maximum) || iIsNotScalar(this.Maximum) || ...
                isnan(this.Maximum) || isinf(this.Maximum) || ...
                this.Maximum <= 0;
        end
        
        function update(this)
            this.updateBar(); 
            this.updateText();
        end
        
        function createGUIComponents(this)            
            this.MainPanel = uipanel('Parent', this.Parent, 'BorderType', 'none', ...
                'Tag', 'NNET_CNN_TRAININGPLOT_UIFIGURE_DETERMINATEPROGBARANDTEXT_MAINPANEL');
            verticalFlow = uigridlayout(...
                'Parent', this.MainPanel, ...
                'RowHeight', {this.ProgressTextHeight, this.BarHeight}, ...
                'ColumnWidth', {'1x'}, ...
                'RowSpacing', 0, 'ColumnSpacing', 0, 'Padding', [0,0,0,0]);
            
            % First row
            this.createProgressText(verticalFlow);
            
            % Second row
            horizontalFlow = uigridlayout(verticalFlow, ...
                'RowHeight', {'1x'}, 'ColumnWidth', {'1x', this.StopButtonWidth}, ...
                'RowSpacing', 0, 'ColumnSpacing', 0, 'Padding', [0,0,0,0]);
            % Prog bar
            this.createAxes(horizontalFlow);
            this.createOuterBorder();
            this.createBar();
            % Stop button
            this.createStopButton(horizontalFlow);
            
            this.update();
        end
        
        function createProgressText(this, parent)
             this.ProgressText = uilabel(...
                'Parent', parent, ...
                'Text', '', ...
                'FontSize', iFontSizeInPixels(), ...  % uilabel only supports pixels for font units
                'HorizontalAlignment', 'left', ...
                'Tag', 'NNET_CNN_TRAININGPLOT_UIFIGURE_DETERMINATEPROGBARANDTEXT_PROGRESSTEXT');
        end
        
        function createAxes(this, parent)            
            % createAxes   Creates axes with no border and no tick marks.
            % Limits are set to [0,1] for x and y.
            this.Axes = uiaxes(...
                'Parent', parent, ...
                'XGrid', 'off', 'YGrid', 'off', ...
                'XTick', [], 'YTick', [], ...
                'XLim', [0,1], 'YLim', [0,1], ...
                'Box', 'off');
            axis(this.Axes, 'off');
            this.Axes.Interactions = [];  % Stop mouse draggability.
            this.Axes.Toolbar.Visible = false;  % Turn off floating palette
        end
        
        function createOuterBorder(this)
            this.OuterBorder = patch(this.Axes, ...
                'XData', [0,0,1,1], ...
                'YData', [0,1,1,0], ...
                'FaceColor', iLightGray(), ...
                'EdgeColor', iGreyColor(), ...
                'LineWidth', 0.1, ...
                'Tag', 'NNET_CNN_TRAININGPLOT_UIFIGURE_DETERMINATEPROGBARANDTEXT_OUTERBORDER');
        end
        
        function createBar(this)
            initialProgress = 0;
            this.Bar = patch(this.Axes, ...
                [0,0,initialProgress,initialProgress], ...
                [0,1,1,0], ...
                iMATLABBlue(), ...
                'EdgeColor', 'none', ...
                'Tag', 'NNET_CNN_TRAININGPLOT_UIFIGURE_DETERMINATEPROGBARANDTEXT_BAR');
        end
        
        function createStopButton(this, parent)
             this.StopButton = iCreateStopButton(parent);
             this.StopButton.ButtonPushedFcn = @this.stopButtonClickedCallback;
        end
        
        function updateBar(this)
            value = iEnsureValueIsBetweenZeroAndMaximum(this.Value, this.Maximum);
            progressRatio = double(value) / double(this.Maximum);
            
            this.Bar.XData = [0,0,progressRatio,progressRatio];
        end
        
        function updateText(this)
            % The message displays something like "Training x of y".
            % However, currValue indicates the iteration has just
            % completed, not the iteration that we are going to train.
            % Therefore, we must +1 to currValue, unless we have already
            % reached the last iteration.
            currValue = iEnsureValueIsBetweenZeroAndMaximum(this.Value + 1, this.Maximum);
            m = message('nnet_cnn:internal:cnn:ui:trainingplot:ProgressBarLabel', num2str(currValue), num2str(this.Maximum));
            this.ProgressText.Text = m.getString();
        end
        
        % callbacks
        function stopButtonClickedCallback(this, ~, ~)
            this.notify('StopButtonClicked'); 
        end
    end
end

% helpers
function color = iGreyColor()
color = [188,188,188]/256;
end

function color = iMATLABBlue()
color = [0, 114, 189]/256;
end

function color = iLightGray()
color = [230,230,230]/256;
end

function val = iFontSizeInPixels()
val = 12;
end

function value = iEnsureValueIsBetweenZeroAndMaximum(value, maximum)
value = min( max(value, 0), maximum );
end

function tf = iIsNotScalar(value)
tf = numel(value) ~= 1;
end

function stopButton = iCreateStopButton(parent)
stopButtonText = message('nnet_cnn:internal:cnn:ui:trainingplot:StopButton').getString();
stopButton = uibutton(parent, ...
    'Text', stopButtonText, ...
    'Tag', 'NNET_CNN_TRAININGPLOT_UIFIGURE_DETERMINATEPROGBARANDTEXT_STOPBUTTON');
end

