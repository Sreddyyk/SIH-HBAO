classdef TrainingPlotConfig < nnet.internal.cnn.ui.PlotConfig
    % TrainingPlotConfig   Plot configuration for the training plot
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(SetAccess = private)
        % HasVariableNumItersEpoch   (logical) Will training have a
        % variable number of iterations in each epoch? Variable number of
        % iterations per epochs occurs when either:
        %   - training RNN networks with numeric sequence lengths, or
        %   - the number of observations in the data is unknown (i.e. Inf)
        HasVariableNumItersPerEpoch
        
        % LossType   (string) What type of loss is it? One of
        % "classification" and "regression"
        LossType
        
        % ExecutionEnvironment   (string) One of "cpu" or "gpu".
        % Note that this is not the same as the ExecutionEnvironment found
        % in the TrainingOptions - this is computed after trainNetwork is
        % called.
        ExecutionEnvironment
        
        % UseParallel  (logical) Will use parallel?
        UseParallel
        
        % NumObservations   (integer) Number of observations in data. Can
        % be non-finite if number of observations is unknown in advance of
        % training e.g. if datastore is used.
        NumObservations

        % TrainingOptions   (trainingOptions). The training options object
        % created by user of trainNetwork.
        TrainingOptions
    end
    
    properties(Dependent, SetAccess = private)
        % IsValidationSpecified   (logical) Has validation data been specified?
        IsValidationSpecified 
    end
    
    methods
        function this = TrainingPlotConfig(trainingOpts, networkInfo, trainingDispatcher, executionSettings)
             this.HasVariableNumItersPerEpoch = iHasVariableNumItersPerEpoch(trainingOpts, networkInfo, trainingDispatcher);
             this.LossType = iLossType(networkInfo);
             this.ExecutionEnvironment = string(executionSettings.executionEnvironment);
             this.UseParallel = executionSettings.useParallel;
             this.NumObservations = trainingDispatcher.NumObservations;
             this.TrainingOptions = trainingOpts;
        end
        
        function tf = get.IsValidationSpecified(this)
            tf = ~isempty(this.TrainingOptions.ValidationData); 
        end
    end
end

function tf = iHasVariableNumItersPerEpoch(trainingOpts, networkInfo, trainingDispatcher)
isRNNWithNumericSeqLen = networkInfo.IsRNN && isnumeric(trainingOpts.SequenceLength);
datastoreHasUnknownNumObs = ~isfinite(trainingDispatcher.NumObservations);

tf = isRNNWithNumericSeqLen || datastoreHasUnknownNumObs;
end

function type = iLossType(networkInfo)
if networkInfo.DoesClassification
    type = "classification";
else
    type = "regression";
end
end