classdef AccumulatorFactory
    % AccumulatorFactory   Class for creating statistics accumulators.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods(Static)
        function accumulators = create(inputSizes,outputType)
            % accumulators = create(inputSizes,outputType)
            % creates an Accumulator object for each input of the network. 
            % inputSizes is a cell array with the size of the data for one
            % observation at one time step. outputType specifies the 
            % precision of the statistics returned from the accumulators.

            % Select the observation and sequence dimension as reduction dimensions.
            vecdim = cellfun(@(sz)numel(sz)+[1,2],inputSizes,'UniformOutput',false);
            
            defaultstats = {'mean','std','min','max'};
            
            numInputs = numel(inputSizes);
            accumulators = cell(1,numInputs);
            for i = 1:numInputs
                accumulators{i} = iAccumulator(vecdim{i},defaultstats,outputType);
            end
        end
    end
end

function obj = iAccumulator(vecdim,stats,outtype)
obj = nnet.internal.cnn.statistics.Accumulator(vecdim,stats,outtype);
end