classdef Accumulator
    % Accumulator   Statistics accumulator class
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(SetAccess = private)
        % VecDim   Dimensions which should be reduced in each block of data
        VecDim(1,:) double
        
        % WhichStats   Collection of statistics that should be computed
        WhichStats(1,:) cell
        
        % OutputPrecision   Precision to which the resulting statistics
        % should be cast.
        OutputPrecision
    end
    properties(Access = private)
        % NanFlag   NaN condition ('omitnan' or 'includenan') to be used
        % during the map operation.
        NanFlag(1,:) char = 'omitnan'
        
        % MapFcns   Transform functions applied to each block of data. The
        % i-th cell contains the reduction function for the i-th requested
        % statistic captured in WhichStats.
        MapFcns(1,:) cell
        
        % ReduceFcns   Reduction functions applied to the results of the
        % MapFcns for multiple blocks. The i-th cell contains the reduction
        % function for the i-th requested statistic captured in WhichStats.
        ReduceFcns(1,:) cell
        
        % OutputFcns   Functions to retrieve the final statistics from
        % intermediate values. The i-th cell contains the output function
        % for the i-th requested statistic captured in WhichStats.
        OutputFcns(1,:) cell
        
        % Intermediates   Intermediate representation of the statistics
        % returned from the reduction functions. The i-th cell contains the 
        % intermediate results for the i-th requested statistic captured 
        % in WhichStats.
        Intermediates(1,:) cell
    end
    
    methods
        function this = Accumulator(reductionDims,whichstats,precision)
            this.VecDim = reductionDims;
            this.OutputPrecision = precision;
            
            whichstats = unique(whichstats);
            this.WhichStats = whichstats;
            [this.MapFcns, this.ReduceFcns, this.OutputFcns] = ...
                iFcnFactory(whichstats,reductionDims,this.NanFlag);
            
            this = reset(this);
        end
        
        function this = reset(this)
            this.Intermediates = cell(1,numel(this.WhichStats));
        end
        
        function this = accumulate(this,dataBlock)
            % Compute statistics from the data block (via the map function)
            % and merge the results with the running statistics (via the
            % reduce function)
            for i = 1:numel(this.WhichStats)
                blockStats = feval(this.MapFcns{i},dataBlock);
                intermediates = [ blockStats; this.Intermediates{i} ];
                this.Intermediates{i} = feval( this.ReduceFcns{i}, intermediates );
            end
        end
        
        function mergedAcc = merge(myAcc,theirAcc)
            assert( isequal(myAcc.VecDim, theirAcc.VecDim), ...
                "The accumulators being merged must have the same VecDim")
            assert( isequal(myAcc.WhichStats, theirAcc.WhichStats), ...
                "The accumulators being merged must have the same statistics")
            
            % Merge two accumulator objects by merging their running statistics
            mergedAcc = myAcc;
            for i = 1:numel(mergedAcc.WhichStats)
                if isempty(myAcc.Intermediates{i})
                    mergedAcc.Intermediates{i} = theirAcc.Intermediates{i};
                elseif isempty(theirAcc.Intermediates{i})
                    mergedAcc.Intermediates{i} = myAcc.Intermediates{i};
                else
                    intermediates = [ 
                        myAcc.Intermediates{i}
                        theirAcc.Intermediates{i} ];
                    mergedAcc.Intermediates{i} = feval( mergedAcc.ReduceFcns{i}, intermediates );
                end
            end
        end
        
        function this = gather(this)
            this.Intermediates = iRecursiveFcn(this.Intermediates,@gather);
        end
        
        function val = getStatistic(this,type)
            % Retrieve the requested statistic from the intermediate
            % representation.
            type = validatestring(type,this.WhichStats);
            idx = strcmp(this.WhichStats,type);
            if isempty(this.Intermediates{idx})
                val = [];
            else
                val = feval( this.OutputFcns{idx}, this.Intermediates{idx} );
            end
            val = this.OutputPrecision.cast(val);
        end
    end
    
end

function [mapFcns,reduceFcns,getFcn] = iFcnFactory(whichstats,dims,nanflag)
mapFcns = cell(1,numel(whichstats));
reduceFcns = cell(1,numel(whichstats));
getFcn = cell(1,numel(whichstats));
biasflag = 1;
reduceNanFlag = 'includenan';
computetype = 'double';
toComputeType = @(x)iRecursiveFcn(x,@double);
for i = 1:numel(whichstats)
    switch whichstats{i}
        case 'mean'
            mapFcns{i} = @(x)nnet.internal.cnn.statistics.mapMean(x,dims,nanflag,computetype);
            reduceFcns{i} = @(y)nnet.internal.cnn.statistics.reduceMean(y,dims,reduceNanFlag,computetype);
            getFcn{i} = @(y) y{1};
            
        case 'var'
            mapFcns{i} = @(x)nnet.internal.cnn.statistics.mapVar(toComputeType(x),biasflag,dims,nanflag);
            reduceFcns{i} = @(y)nnet.internal.cnn.statistics.reduceVar(y,dims,reduceNanFlag);
            getFcn{i} = @(y)iCorrectBias(biasflag,y{1},y{3});
            
        case 'std'
            mapFcns{i} = @(x)nnet.internal.cnn.statistics.mapVar(toComputeType(x),biasflag,dims,nanflag);
            reduceFcns{i} = @(y)nnet.internal.cnn.statistics.reduceVar(y,dims,reduceNanFlag);
            getFcn{i} = @(y)sqrt(iCorrectBias(biasflag,y{1},y{3}));
            
        case 'min'
            mapFcns{i} = @(x)nnet.internal.cnn.statistics.mapMin(x,dims,nanflag);
            reduceFcns{i} = @(x)nnet.internal.cnn.statistics.reduceMin(x);
            getFcn{i} = @(y) y{1};
            
        case 'max'
            mapFcns{i} = @(x)nnet.internal.cnn.statistics.mapMax(x,dims,nanflag);
            reduceFcns{i} = @(x)nnet.internal.cnn.statistics.reduceMax(x);
            getFcn{i} = @(y) y{1};
            
        otherwise
            % This should not be hit through external code
            error('Invalid statistics type')
    end
end
end

function val = iCorrectBias(biasFlag,variance,counter)
% Bias correct the result
if biasFlag == 0
    nm1 = max(counter - 1, 1);
    % Bias-correct the result
    val = variance .* (counter./nm1);
else
    val = variance;
end
end

function data = iRecursiveFcn(data,fcn)
if iscell(data)
    data = cellfun(@(x)iRecursiveFcn(x,fcn), data, 'UniformOutput', false);
else
    data = fcn(data);
end
end
