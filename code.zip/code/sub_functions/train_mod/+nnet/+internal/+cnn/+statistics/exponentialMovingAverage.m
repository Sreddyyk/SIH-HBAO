function runningStatistic = exponentialMovingAverage(newStatistic,runningStatistic, decay)
%EXPONENTIALMOVINGAVERAGE Computes the Exponentially Weighted Moving
%Average Filter using the specified decay

%   Copyright 2019 The MathWorks, Inc.

runningStatistic = decay.*newStatistic + (1-decay).*runningStatistic;
end

