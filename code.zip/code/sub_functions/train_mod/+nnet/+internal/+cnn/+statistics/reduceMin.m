function outCell = reduceMin(intermediates)
% Combine min statistics by computing the min between the
% intermediate statistics.

%   Copyright 2019 The MathWorks, Inc.

if isempty(intermediates)
    outCell = intermediates;
else
    isEmptyValue = cellfun(@isempty,intermediates);
    if all(isEmptyValue)
        outCell = {[]};
    else
        intermediates = intermediates(~isEmptyValue);
        reducedMin = intermediates{1};
        for i = 2:size(intermediates,1)
            reducedMin = min(reducedMin,intermediates{i},'includenan');
        end
        outCell = {reducedMin};
    end
end
end