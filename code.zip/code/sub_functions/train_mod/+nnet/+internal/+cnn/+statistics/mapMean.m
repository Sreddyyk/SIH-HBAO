function outCell = mapMean(dataBlock, dim, nanflag, computetype)
% mapMean   Compute statistics of a block of data (subset that fits into memory)
%
% Input arguments:
%    dataBlock - one or more blocks of data represented as numeric array or
%                a cell array of numeric arrays
%    dim       - dimension or vector of dimensions to operate over
%    nanflag   - whether to include or omit NaN values
%
% Output arguments:
%    outCell   - cell array with fields {mean, count, isempty}
%
% Example:
%     % Use an image datastore and tall to compute the mean image
%
%     ds = digitDatastore;
%     ds.ReadSize = 128;
%     T = tall(ds);
%
%     dim = 4; % compute the mean image over all observations
%     mapFcn = @(x)nnet.internal.cnn.statistics.mapMean(x,dim,'omitnan','double');
%     reduceFcn = @(stats)nnet.internal.cnn.statistics.reduceMean(stats,dim,'includenan','double');
%
%     meanStats = matlab.tall.reduce(  mapFcn, reduceFcn, T );
%     meanStats = gather(meanStats);
%     meanVal = meanStats{1};

%   Copyright 2019 The MathWorks, Inc.
if nargin<4
    computetype = 'default';
end
if nargin<3
    nanflag = 'includenan';
end
validateattributes( dim, {'numeric'}, {'vector','integer','positive'})
dim = reshape(dim,1,[]);

if isempty(dataBlock)
    outCell = {zeros(size(dataBlock)),zeros(size(dataBlock)),true};
else
    if ~iscell(dataBlock)
        dataBlock = {dataBlock};
    end
    outCell = cellfun( @(x)iMean(x,dim,nanflag,computetype), ...
        dataBlock, 'UniformOutput', false);
    outCell = cat(1,outCell{:});
end
end

function outCell = iMean(data, dim, nanflag, computetype)
% Compute mean of block
blockMean = mean(data, dim, nanflag, computetype);

blockIsEmpty = isempty(data);
if blockIsEmpty
    % Ensure that a possibly empty block does not corrupt the reduction
    % with NaN by setting to zero while preserving the size.
    blockMean(:) = 0;
end

% To combine multiple block means, store the number of elements
% that were reduced in this mapping operations
if strcmpi(nanflag, 'includenan')
    countPerElement = prod(size(data, dim));
    blockCount = repmat(countPerElement, size(blockMean));
else
    blockCount = sum(~isnan(data), dim, computetype);
end

outCell = { blockMean, blockCount, blockIsEmpty };
end