function outCell = reduceMax(intermediates)
% Combine max statistics by computing the max between the
% intermediate statistics.

%   Copyright 2019 The MathWorks, Inc.

if isempty(intermediates)
    outCell = intermediates;
else
    isEmptyValue = cellfun(@isempty,intermediates);
    if all(isEmptyValue)
        outCell = {[]};
    else
        intermediates = intermediates(~isEmptyValue);
        reducedMax = intermediates{1};
        for i = 2:size(intermediates,1)
            reducedMax = max(reducedMax,intermediates{i},'includenan');
        end
        outCell = {reducedMax};
    end
end
end