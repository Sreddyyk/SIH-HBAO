function out = mapMax(dataBlock,vecdim,nanflag)
% Extract the max value in the specified dimensions for each block
% of data (the dataBlock is a mini-batch worth of data)

%   Copyright 2019 The MathWorks, Inc.
    
if iscell(dataBlock)
    out = cellfun(@(x)max(x,[],vecdim,nanflag),dataBlock,'UniformOutput',false);
else
    out = {max(dataBlock,[],vecdim,nanflag)};
end
end