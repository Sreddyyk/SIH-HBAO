function outCell = mapVar(dataBlock, flag, dim, nanflag)
% Compute statistics of a block of data (subset that fits into memory)
% Input arguments:
%   flag    - weight flag (0 or 1)
%   dim     - dimension or vector of dimensino to operate over
%   nanflag - whether to include or omit NaN values
% Output arguments:
%   outCell - cell array with field {variance, mean, count, isempty}

%   Copyright 2019 The MathWorks, Inc.
if nargin<4
    nanflag = 'includenan';
end
validateattributes( dim, {'numeric'}, {'vector','integer','positive'})
dim = reshape(dim,1,[]);

if ~iscell(dataBlock)
    dataBlock = {dataBlock};
end
outCell = cellfun( @(x)iVar(x,flag,dim,nanflag), ...
    dataBlock, 'UniformOutput', false);
outCell = cat(1,outCell{:});
end

function outCell = iVar(data, flag, dim, nanflag)
% Compute variance of block
blockVar = var(data, flag, dim, nanflag);
blockMean = mean(data, dim, nanflag);

blockIsEmpty = isempty(data);
if blockIsEmpty
    % Ensure that a possibly empty chunk does not corrupt the reduction
    % with NaN by setting to zero while preserving the size.
    blockVar(:) = 0;
    blockMean(:) = 0;
end

% blockVar is scaled by blockCount
if strcmpi(nanflag, 'includenan')
    countPerElement = prod(size(data, dim));
    blockCount = repmat(countPerElement, size(blockVar));
else
    blockCount = sum(~isnan(data), dim);
end
outCell = {blockVar, blockMean, blockCount, blockIsEmpty};
end