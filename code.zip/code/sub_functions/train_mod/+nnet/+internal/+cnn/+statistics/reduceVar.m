function outCell = reduceVar(inCell, dim, nanflag)
% Combine intermediate statistics from multiple chunks
% Input arguments:
%   inCell  - intermediate results (from mapVar) stored in separate rows
%   dim     - dimension or vector of dimensino to operate over
%   nanflag - whether to include or omit NaN values
% Output arguments:
%   outCell - one row vector of merged statistics

%   Copyright 2019 The MathWorks, Inc.

if nargin<3
    nanflag = 'includenan';
end
validateattributes( dim, {'numeric'}, {'vector','integer','positive'})
dim = reshape(dim,1,[]);

if isempty(inCell) || size(inCell,1) == 1
    outCell = inCell;
else
    outCell = inCell(1,:);
    for i = 2:size(inCell,1)
        outCell = iReduceTwoIntermediates(outCell, inCell(i,:), dim, nanflag);
    end
end
end

function outCell = iReduceTwoIntermediates(A, B, dim, nanflag)
blockDim = max([dim,ndims(A{1})])+1;
vVar = cat(blockDim, A{1}, B{1});
vMean = cat(blockDim, A{2}, B{2});
vCount = cat(blockDim, A{3}, B{3});
vIsEmpty = cat(blockDim, A{4}, B{4});
locIsEmpty = all(vIsEmpty,blockDim);
if all(size(vVar,[dim,blockDim]) <= 1)
    % return itself if already fully reduced
    locVar = vVar;
    locMean = vMean;
    locCount = vCount;
else
    % Note that by this point any dimensions other than the tall
    % dimension have already been reduced. We just need to complete the
    % reduction of the tall dimension.
    locCount = sum(vCount, blockDim);
    if strcmpi(nanflag, 'omitnan')
        vMean(vCount == 0) = 0;
        vVar(vCount == 0) = 0;
    end
    locMean = sum(vCount .* vMean, blockDim) ./ locCount;
    locVar = sum(vCount .* vVar, blockDim) ./ locCount;
    % When one input is empty, avoid applying the variance adjustment
    % altogether. This is to avoid Inf * 0 calculations when the mean
    % of the other input is greater than sqrt(realmax).
    countProd = prod(vCount ./ locCount, blockDim) .* ones(size(locVar));
    locVarAdjust = abs(diff(vMean, 1, blockDim)) .^ 2 .* countProd;
    locVar(countProd ~= 0) = locVar(countProd ~= 0) + locVarAdjust(countProd ~= 0);
    
    if locIsEmpty
        % If we're combining empty chunks, then locMean and locVar will have become NaN,
        % we need to revert to 0.
        locVar(:) = 0;
        locMean(:) = 0;
    end
end
outCell = {locVar, locMean, locCount, locIsEmpty};
end