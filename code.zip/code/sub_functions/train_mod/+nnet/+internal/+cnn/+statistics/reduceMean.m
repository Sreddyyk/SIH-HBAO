function mergedCell = reduceMean(intermediatesCell, dim, nanflag, computetype)
% reduceMean   Reduction function used by tall.reduce or mapreduce to
% reduce intermediate results from multiple blocks.
%
% Input arguments:
%   inCell  - intermediate results (from mapMean) stored in separate rows
%             with values {mean, count, isempty}
%   dim     - dimension or vector of dimensions that the block-wise
%             reduction was performed on
%   nanflag - whether to include or omit NaN values ('includenan'|'omitnant')
%
% Output arguments:
%   outCell - one row vector of merged statistics
%
% Example:
%     % Use an image datastore and tall to compute the mean image
%
%     ds = digitDatastore;
%     ds.ReadSize = 128;
%     T = tall(ds);
%
%     dim = 4; % compute the mean image over all observations
%     mapFcn = @(x)nnet.internal.cnn.statistics.mapMean(x,dim,'omitnan','double');
%     reduceFcn = @(stats)nnet.internal.cnn.statistics.reduceMean(stats,dim,'includenan','double');
%
%     meanStats = matlab.tall.reduce(  mapFcn, reduceFcn, T );
%     meanStats = gather(meanStats);
%     meanVal = meanStats{1};

%   Copyright 2019 The MathWorks, Inc.
if nargin<4
    computetype = 'default';
end
if nargin<3
    nanflag = 'includenan';
end
validateattributes( dim, {'numeric'}, {'vector','integer','positive'})
dim = reshape(dim,1,[]);

if isempty(intermediatesCell) || size(intermediatesCell,1) == 1
    mergedCell = intermediatesCell;
else
    % Find a "free" dimension for concatenating intermediate results
    reductionDim = max([dim,ndims(intermediatesCell{1})])+1;
    vMean = cat(reductionDim, intermediatesCell{:,1});
    vCount = cat(reductionDim, intermediatesCell{:,2});
    vIsEmpty = cat(reductionDim, intermediatesCell{:,3});
    if all(size(vMean, [dim,reductionDim]) <= 1)
        % Return itself if already fully reduced
        mergedMean = vMean;
        mergedCount = vCount;
        mergedIsEmpty = vIsEmpty;
    else
        % Note that by this point each block is already reduced according to
        % dim. We just need to complete the reduction of the block dimension.
        mergedCount = sum(vCount, reductionDim, computetype);
        if strcmpi(nanflag, 'omitnan')
            vMean(vCount == 0) = 0;
        end
        mergedMean = sum(vCount .* vMean, reductionDim, computetype) ./ mergedCount;
        
        mergedIsEmpty = all(vIsEmpty);
        if mergedIsEmpty
            % If we're combining empty blocks, then mergedMean will have
            % become NaN, we need to revert to 0.
            mergedMean(:) = 0;
        end
    end
    mergedCell = {mergedMean, mergedCount, mergedIsEmpty};
end
end