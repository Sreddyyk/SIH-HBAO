function out = mapMin(dataBlock,vecdim,nanflag)
% Extract the min value in the specified dimensions for each block
% of data (the dataBlock is a mini-batch worth of data)

%   Copyright 2019 The MathWorks, Inc.

if iscell(dataBlock)
    out = cellfun(@(x)min(x,[],vecdim,nanflag),dataBlock,'UniformOutput',false);
else
    out = {min(dataBlock,[],vecdim,nanflag)};
end
end