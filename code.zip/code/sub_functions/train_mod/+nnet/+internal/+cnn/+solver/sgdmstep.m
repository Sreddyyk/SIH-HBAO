function [step, vel] = sgdmstep(g, vel, learnrate, momentum)
% sgdmstep   Calculate SGDM update step for a single parameter

%   Copyright 2019 The MathWorks, Inc.

vel = momentum.*vel - learnrate.*g;
step = vel;
