function [step, avg_gsq] = rmspropstep(g, avg_gsq, learnrate, rho, epsilon)
% rmspropstep   Calculate rmsprop update step for a single parameter

%   Copyright 2019 The MathWorks, Inc.

avg_gsq = rho.*avg_gsq + (1 - rho).*(g.^2);
step = -learnrate.*( g./(sqrt(avg_gsq) + epsilon) );
