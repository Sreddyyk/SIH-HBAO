function [step, avg_g, avg_gsq] = adamstep(g, avg_g, avg_gsq, learnrate, beta1, beta2, epsilon)
% adamstep   Calculate adam update step for a single parameter

%   Copyright 2019 The MathWorks, Inc.

avg_g = beta1.*avg_g + (1 - beta1).*g;
avg_gsq= beta2.*avg_gsq + (1 - beta2).*(g.^2);
step = -learnrate.*( avg_g./(sqrt(avg_gsq) + epsilon) );