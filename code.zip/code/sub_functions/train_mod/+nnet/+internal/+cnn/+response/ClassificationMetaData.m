classdef ClassificationMetaData < nnet.internal.cnn.response.ResponseMetaData
    % ClassificationMetaData   Meta data for a classification response
    % variable
    %
    %   This class is used in dispatchers to represent the meta data for a
    %   classification response variable. This meta data is used for
    %   setting the class names of a classification layer, and for
    %   validating that training and validation dispatchers have matching
    %   labels.
    
    %   Copyright 2018 The MathWorks, Inc.
    
    properties
        % Categories   A list of the categories
        %
        %   This property is categorical column vector containing instances
        %   of all the classes. For example, if our classes are cats and
        %   dogs, this property will be categorical(["cats"; "dogs"]). We
        %   can also deduce from this property if classes are ordinal.
        Categories
    end
    
    methods
        function this = ClassificationMetaData(categories)
            assert(iscategorical(categories));
            this.Categories = categories;
        end
    end
end

