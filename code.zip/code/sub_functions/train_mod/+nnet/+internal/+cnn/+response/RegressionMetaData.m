classdef RegressionMetaData < nnet.internal.cnn.response.ResponseMetaData
    % RegressionMetaData   Meta data for a regression response variable
    %
    %   This class is used in dispatchers to represent meta data for a
    %   regression response variable. This meta data is used for setting
    %   the response names of a regression layer.
    
    %   Copyright 2018 The MathWorks, Inc.
    
    properties
        % ResponseNames   A cell array of response names
        ResponseNames
    end
    
    methods
        function this = RegressionMetaData(responseNames)
            assert(iscellstr(responseNames)); %#ok<ISCLSTR>
            this.ResponseNames = responseNames;
        end
    end
end

