classdef(Abstract) ResponseMetaData < matlab.mixin.Heterogeneous
    % ResponseMetaData   Abstract base class for representing response
    % variable meta data
    
    %   Copyright 2018 The MathWorks, Inc.
end