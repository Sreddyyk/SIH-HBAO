classdef(Abstract) OptionsDefinition < nnet.internal.cnn.options.OptionsDefinitionInterface
    % OptionsDefinition Define default value, validation and canonicalization functions for an option
    % Each Property defines the default value, the validation function and
    % the canonicalization function for a given option in TrainingOptions.
    % It contains the definitions for the options shared by both training
    % and inference.

    %   Copyright 2019 The MathWorks, Inc.

    properties (Constant=true)
        MiniBatchSize=struct(...
            'DefaultValue',128,...
            'ValidationFcn',@nnet.internal.cnn.options.OptionsValidator.assertIsPositiveIntegerScalar,...
            'CanonicalizationFcn',@(x)x)

        SequencePaddingValue=struct(...
            'DefaultValue',0.0,...
            'ValidationFcn',@nnet.internal.cnn.options.OptionsValidator.assertValidSequencePaddingValue,...
            'CanonicalizationFcn',@double)

        SequencePaddingDirection=struct(...
            'DefaultValue','right',...
            'ValidationFcn',@nnet.internal.cnn.options.OptionsValidator.assertAndReturnValidSequencePaddingDirection,...
            'CanonicalizationFcn',@nnet.internal.cnn.options.OptionsValidator.assertAndReturnValidSequencePaddingDirection)
    end
    
    methods(Sealed=true)
        function dfltvalue = getDefaultValue(this,optname)
            dfltvalue = this.(optname).DefaultValue;
        end
        
        function validateValue(this,optvalue,optname)
            this.(optname).ValidationFcn(optvalue);
        end

        function canonicalizedvalue = canonicalizeValue(this,oldvalue,optname)
            canonicalizedvalue = this.(optname).CanonicalizationFcn(oldvalue);
        end
    end
end
