classdef OptionsValidator
    % OptionsValidator Contains validation functions for inference and
    % training options

    % Each method is used for validating an inference or training option.

    %   Copyright 2019 The MathWorks, Inc.
    
    methods(Static)
        function assertIsPositiveIntegerScalar(x)
            validateattributes(x,{'numeric'}, {'scalar','real','integer','positive'});
        end

        function assertValidLearnRateDropFactor(x)
            validateattributes(x,{'numeric'}, {'scalar','real','finite','>=',0,'<=',1});
        end

        function assertValidInitialLearnRate(x)
            validateattributes(x, {'numeric'}, {'scalar','real','finite','positive'});
        end

        function assertValidSequencePaddingValue( x )
            validateattributes(x, {'numeric'}, {'scalar','real'} )
        end

        function x = assertAndReturnValidCheckpointPath(x)
            % iAssertValidCheckpointPath Throws an error if the checkpoint path is not
            % valid. Valid checkpoint paths are empty strings and existing directories
            % with write access.
            x = convertStringsToChars(x);
            isEmptyPath = isempty(x);
            isWritableExistingDir = ischar(x) && isfolder(x) && iCanWriteToDir(x);
            isValidCheckpointPath = isEmptyPath || isWritableExistingDir;

            if ~isValidCheckpointPath
                iThrowCheckpointPathError()
            end
        end

        function assertValidValidationPatience(x)
            isValidPatience = isscalar(x) && (isinf(x) || isPositiveInteger(x));
            if ~isValidPatience
                error(message('nnet_cnn:TrainingOptionsSGDM:InvalidValidationPatience'))
            end
        end

        function assertValidL2Regularization(x)
            validateattributes(x,{'numeric'},{'scalar','real','finite','nonnegative'});
        end

        function assertValidGradientThreshold(x) 
            validateattributes(x,{'numeric'},{'scalar','real','nonnegative','nonempty','nonnan'});
        end

        function assertBinary(x) 
            validateattributes(x,{'logical','numeric'},{'scalar','binary'});
        end

        function assertValidWorkerLoad(w) 
            if isempty(w)
                % an empty worker load value is valid
                return
            end
            validateattributes(w,{'numeric'}, ...
                {'vector','finite','nonnegative'});
            if sum(w)<=0 || ( isscalar(w) && w > 1 && floor(w) ~= w )
                error(message('nnet_cnn:TrainingOptionsSGDM:InvalidWorkerLoad'));
            end
        end

        function assertValidDispatchInBackground(x) 
            validateattributes(x,{'numeric','logical'},{'scalar','nonempty','finite','nonsparse'});
        end
        
        function assertValidValidationData(validationData) 
            % assertValidValidationData   Return true if validationData is one of the
            % allowed data types for validation. This can be either a table, an
            % imageDatastore or a cell array containing two arrays. The consistency of
            % the data with respect to training data and network architecture will be
            % checked outside.
            if istable(validationData)
                % data type is accepted, no further validation
            elseif iIsAnImageDatastore(validationData)
                iAssertValidationDatastoreHasLabels(validationData);
            elseif iIsADatastore(validationData)
                iAssertValidationDatastoreHasValidData(validationData);
            elseif iscell(validationData)
                iAssertValidationCellDataHasTwoEntries(validationData);
            elseif isempty(validationData)
                % if ValidationData is empty, certify it is numeric or cell
                iAssertEmptyValidationData(validationData);
            else
                iThrowValidationDataError();
            end
        end
        
        function shuffleValue = assertAndReturnValidShuffleValue(x) 
            expectedShuffleValues = {'never', 'once', 'every-epoch'};
            shuffleValue = validatestring(x, expectedShuffleValues);
        end
        
        function method = assertandReturnValidGradientThresholdMethod(s) %
            method = validatestring(s, {'global-l2norm','l2norm','absolute-value'});
        end
        
        function validString = assertAndReturnValidExecutionEnvironment(inputString) %
            validExecutionEnvironments = {'auto', 'gpu', 'cpu', 'multi-gpu', 'parallel'};
            validString = validatestring(inputString,validExecutionEnvironments);
        end

        function validString = assertAndReturnValidSequencePaddingDirection(inputString) 
            validPaddingDirections = {'left', 'right'};
            validString = validatestring(inputString, validPaddingDirections);
        end
        
        function learnRateScheduleValue = assertAndReturnValidLearnRateSchedule(x) %
            expectedLearnRateScheduleValues = {'none', 'piecewise'};
            learnRateScheduleValue = validatestring(x, expectedLearnRateScheduleValues);
        end

        function assertValidPlots(plotsOption) 
            if ~isa(plotsOption, 'nnet.internal.cnn.ui.TrainingPlotter')
                validPlots = {'training-progress','none'};
                validatestring(plotsOption, validPlots);
            end
        end

        function validPlotsOption = assertAndReturnValidPlots(plotsOption) 
            if isa(plotsOption, 'nnet.internal.cnn.ui.TrainingPlotter')
                validPlotsOption = plotsOption;
            else
                validPlots = {'training-progress', 'none'};
                validPlotsOption = validatestring(plotsOption, validPlots);
                validPlotsOption = char(validPlotsOption);
            end
        end
        
        function y = assertAndReturnValidSequenceLength(x)
            try
                if ischar(x) || isstring(x)
                    y = validatestring(x, {'longest','shortest'});
                else
                    validateattributes(x, {'numeric'},{'scalar','real','integer','positive'});
                    y = x;
                end
            catch
                error(message('nnet_cnn:TrainingOptionsSGDM:InvalidSequenceLength'));
            end
        end
        
        function assertValidOutputFcn(f) 
            isValidFcn = isempty(f) || iIsFunctionWithInputs(f) || iIsCellOfValidFunctions(f);
            if ~isValidFcn
                error(message('nnet_cnn:TrainingOptionsSGDM:InvalidOutputFcn'));
            end
        end

        % Adam / RMSProp
        function assertIsScalarReal0StrictlyLower1(x)
            validateattributes(x,{'numeric'}, {'scalar','real','finite','>=',0,'<',1});
        end

        function assertValidEpsilon(x)
            validateattributes(x,{'numeric'}, {'scalar','real','finite','>',0});
        end
        
        % SGDM
        function assertValidMomentum(x)
            validateattributes(x,{'numeric'}, {'scalar','real','finite','>=',0,'<=',1});
        end

        % Inference
        function validString = assertAndReturnValidAcceleration(inputString)
            validString = validatestring(inputString,nnet.internal.cnn.optimizer.NetworkOptimizationFactory.ValidStrings);
        end

        function validString = assertAndReturnValidInferenceExecutionEnvironment(inputString) %
            validExecutionEnvironments = {'auto','gpu','cpu'};
            validString = validatestring(inputString,validExecutionEnvironments);
        end

        function validString = assertValidOutputAs(x) 
            validChoices = {'rows','columns','channels'};
            validString = validatestring(x,validChoices);
        end
        
        function y = assertAndReturnInferenceValidSequenceLength(x)
            try
                if ischar(x) || isstring(x)
                    y = validatestring(x, {'longest','shortest'});
                else
                    validateattributes(x, {'numeric'},{'scalar','real','integer','positive'});
                    y = x;
                end
            catch
                error(message('nnet_cnn:DAGNetwork:InvalidSequenceLength'));
            end
        end
    end
end

% Additional functions needed only by OptionsValidator for type
% checks

function tf = iIsAnImageDatastore(x)
tf = isa(x, 'matlab.io.datastore.ImageDatastore');
end

function tf = iIsADatastore(x)
tf = isa(x,'matlab.io.Datastore') || isa(x,'matlab.io.datastore.Datastore');
end

function iAssertValidationCellDataHasTwoEntries(dataCell)
if numel(dataCell)~=2
    error(message('nnet_cnn:TrainingOptionsSGDM:CellArrayNeedsTwoEntries'));
end
end

function iAssertEmptyValidationData(x)
validateattributes(x,{'numeric'},{'real','integer'})
end

function tf = iCanWriteToDir(proposedDir)
[~, status] = fileattrib(proposedDir);
tf = status.UserWrite;
end

function tf = iIsFunctionWithInputs( f )
tf = isa(f, 'function_handle') && nargin(f) ~= 0;
end

function tf = iIsCellOfValidFunctions(f)
tf = iscell(f) && all( cellfun(@iIsFunctionWithInputs,f(:)) );
end

function tf = isPositiveInteger(x)
isPositive = x>0;
isInteger = isreal(x) && isnumeric(x) && all(mod(x,1)==0);
tf = isPositive && isInteger;
end

function iAssertValidationDatastoreHasLabels(imds)
if isempty(imds.Labels)
    error(message('nnet_cnn:TrainingOptionsSGDM:ImageDatastoreHasNoLabels'));
end
end

function iAssertValidationDatastoreHasValidData(ds)
data = preview(ds);
hasEnoughResponses = size(data,2) >= 2;
validDataContainer = iscell(data) || istable(data);
if ~validDataContainer || ~hasEnoughResponses
    error(message('nnet_cnn:TrainingOptionsSGDM:DatastoreHasInvalidData'));
end
end

function iThrowValidationDataError()
error(message('nnet_cnn:TrainingOptionsSGDM:InvalidValidationDataType'));
end

function iThrowCheckpointPathError()
error(message('nnet_cnn:TrainingOptionsSGDM:InvalidCheckpointPath'));
end