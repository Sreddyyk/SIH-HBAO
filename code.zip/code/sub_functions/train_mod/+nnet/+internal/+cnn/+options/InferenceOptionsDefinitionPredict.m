classdef InferenceOptionsDefinitionPredict < nnet.internal.cnn.options.InferenceOptionsDefinition
    % InferenceOptionsDefinitionPredict Define default value, validation and
    % canonicalization functions for an option of predict

    % Each Property defines the default value, the validation function and
    % the canonicalization function for a given option in TrainingOptions.
    % It contains the definitions for the options for predict.

    %   Copyright 2019 The MathWorks, Inc.

    properties( Constant=true )
        ReturnCategorical=struct(...
            'DefaultValue',false,...
            'ValidationFcn',@nnet.internal.cnn.options.OptionsValidator.assertBinary,...
            'CanonicalizationFcn',@logical)
    end
end