classdef(Abstract) OptionsDefinitionInterface
    % OptionsDefinitionInterface Base OptionsDefinition objects

    %   Copyright 2019 The MathWorks, Inc.

    methods(Abstract=true)
        getDefaultValue(this,optname)
        validateValue(this,optvalue,optname)
        canonicalizeValue(this,oldvalue,optname)
    end    
end
