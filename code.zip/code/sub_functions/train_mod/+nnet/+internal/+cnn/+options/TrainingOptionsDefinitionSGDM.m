classdef TrainingOptionsDefinitionSGDM < nnet.internal.cnn.options.TrainingOptionsDefinition
    % TrainingOptionsDefinitionSGDM Define default value, validation and
    % canonicalization functions for a training option for SGDM

    % Each Property defines the default value, the validation function and
    % the canonicalization function for a given option in TrainingOptions.
    % It contains the definitions for the options used for training with
    % SGDM.

    %   Copyright 2019 The MathWorks, Inc.
    
    properties(Constant=true)
        Momentum=struct(...
            'DefaultValue',0.9,...
            'ValidationFcn',@nnet.internal.cnn.options.OptionsValidator.assertValidMomentum,...
            'CanonicalizationFcn',@(x)x)
        
        InitialLearnRate=struct(...
            'DefaultValue',0.01,...
            'ValidationFcn',@nnet.internal.cnn.options.OptionsValidator.assertValidInitialLearnRate,...
            'CanonicalizationFcn',@(x)x)
    end
end