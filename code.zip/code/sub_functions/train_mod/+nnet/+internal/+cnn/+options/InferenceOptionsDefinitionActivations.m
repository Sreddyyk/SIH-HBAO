classdef InferenceOptionsDefinitionActivations < nnet.internal.cnn.options.InferenceOptionsDefinition
    % InferenceOptionsDefinitionActivations Define default value, validation
    % and canonicalization functions for an option of activations

    % Each Property defines the default value, the validation function and
    % the canonicalization function for a given option in TrainingOptions.
    % It contains the definitions for the options for activations.

    %   Copyright 2019 The MathWorks, Inc.

    properties( Constant=true )
        OutputAs=struct(...
            'DefaultValue','channels',...
            'ValidationFcn',@(x)any(nnet.internal.cnn.options.OptionsValidator.assertValidOutputAs(x)),...
            'CanonicalizationFcn',@nnet.internal.cnn.options.OptionsValidator.assertValidOutputAs)

        MiniBatchesInCell=struct(...
            'DefaultValue',false,...
            'ValidationFcn',@nnet.internal.cnn.options.OptionsValidator.assertBinary,...
            'CanonicalizationFcn',@(x) x)
    end
end