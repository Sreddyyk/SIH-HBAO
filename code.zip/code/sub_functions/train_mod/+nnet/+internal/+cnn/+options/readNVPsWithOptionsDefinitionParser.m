function [inputArguments,unmatched]=readNVPsWithOptionsDefinitionParser(optionsDefinition,keepUnmatched,varargin) 
    % readNVPsWithOptionsDefinitionParser read NVPs with parser's parameter
    % defined by an OptionsDefinition object and canonicalize result

    % Each method is used for validating and canonicalizing an inference
    % or training option.

    %   Copyright 2019 The MathWorks, Inc.
    
    if ~isa(optionsDefinition, 'nnet.internal.cnn.options.OptionsDefinitionInterface')
        error(message('nnet_cnn:internal:cnn:options:readNVPsWithOptionsDefinitionParser:InvalidOptionsDefinition'))
    end
    p = inputParser;
    p.KeepUnmatched = keepUnmatched;
    fn = fieldnames(optionsDefinition);
    for ii = 1:numel(fn)
        p.addParameter(fn{ii}, optionsDefinition.getDefaultValue(fn{ii}), @(x)optionsDefinition.validateValue(x,fn{ii}));
    end
    p.parse(varargin{:});
    unmatched = p.Unmatched;
    inputArguments = p.Results;
    for ii = 1:numel(fn)
        inputArguments.(fn{ii}) = optionsDefinition.canonicalizeValue(inputArguments.(fn{ii}),fn{ii});
    end
end
