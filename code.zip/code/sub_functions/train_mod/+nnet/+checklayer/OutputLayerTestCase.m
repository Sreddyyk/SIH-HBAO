classdef(Abstract) OutputLayerTestCase < matlab.unittest.TestCase
    % OutputLayerTestCase   TestCase class to check validity of output
    % layers implementing the interface nnet.layer.RegressionLayer or
    % nnet.layer.ClassificationLayer.
    %
    %   To check the validity of an output layer, use checkLayer
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties (SetAccess = private)
        % Layer (nnet.layer.RegressionLayer|nnet.layer.ClassificationLayer)
        % Layer under test
        Layer
        
        % Predictions (containers.Map)   Map that stores data representing
        % Predictions made by the network. The map contains data for 'one'
        % and if applicatble, for 'multiple' observations.
        Predictions
        
        % Targets (containers.Map)   Map that stores data representing
        % targets. The map contains data for 'one' and if applicatble, for
        % 'multiple' observations.
        Targets
    end
    
    properties(TestParameter)
        Precision = {'single', 'double'};
        Observations = {'one', 'multiple'}
        Device = {'cpu','gpu'}
    end
    
    methods(Test,Abstract)
        forwardLossDoesNotError(test,Observations)
        forwardLossIsScalar(test,Observations)
        forwardLossIsConsistentInType(test,Precision,Device)
    end
    
    methods
        function test = OutputLayerTestCase()
            config = nnet.checklayer.util.UseConfiguration;
            test.Layer = config.Data.Layer;
            inputSize = config.Data.InputSize;
            obsDim = config.Data.ObservationDimension;
            isClassificationLayer = isa(test.Layer,'nnet.layer.ClassificationLayer');
            
            % Create a map container with random data for one observation
            % and multiple observations (if ObservationDimension is
            % specified). In case ObservationDimension is not specified,
            % the 'one' observation data will be exactly of size InputSize
            % as specified by the user.
            if isempty(obsDim)
                numObsMap = containers.Map({'one'},{1});
            else
                % The "one observation" case should contain one observation
                % and the "multi observation" case should contain two
                % observations.
                numObsMap = containers.Map({'one','multiple'},{1,2});
            end
            test.Predictions = iGeneratePredictionData( inputSize, ...
                isClassificationLayer, obsDim, numObsMap );
            test.Targets = iGenerateTargetData( inputSize,  ...
                isClassificationLayer, obsDim, numObsMap );
        end
    end
    
    methods(Access = protected)
        function loss = tryForwardLoss( test, Y, T )
            try
                loss = test.Layer.forwardLoss( Y, T );
            catch
                % 'forwardLoss' errored out, fail the test
                test.assumeFail( iGetTestCaseMessage('SkipTestMethodErrored','forwardLoss') );
            end
        end
        
        function castFcn = castDataFcn(~,precision,device)
            if device == "gpu"
                castFcn = @(x) gpuArray(cast(x,precision));
            else
                castFcn = @(x) cast(x,precision);
            end
        end
        
    end
end

function dataStruct = iGeneratePredictionData( inputSize, isClassification, obsDim, paramToNumObsMap )
% Generate predictions data for each entry in paramToNumObsMap.
% paramToNumObsMap maps a value of the test parameter 'Observations'
% to the number of observations that are generated for that parameter.
dataStruct = containers.Map();
for obs = keys(paramToNumObsMap)
    paramName = obs{1};
    numObs = paramToNumObsMap(paramName);
    dataSize = iSetDimension(inputSize,obsDim,numObs);
    % Generate data
    if isClassification
        % The input to a classification layer is always the output of a
        % softmax layer and is in the range [0,1].
        dataStruct(paramName) = (iGenerateSingleData(dataSize,1000) + 1)/2;
    else
        % The input to a regression layer can be in any value range. The range
        % [-1,1] is used to generate arbitrary data.
        dataStruct(paramName) = iGenerateSingleData(dataSize,1200);
    end
end
end

function dataStruct = iGenerateTargetData( inputSize, isClassification, obsDim, paramToNumObsMap )
% Generate targets data for each entry in paramToNumObsMap.
% paramToNumObsMap maps a value of the test parameter 'Observations'
% to the number of observations that are generated for that parameter.
dataStruct = containers.Map();
for obs = keys(paramToNumObsMap)
    paramName = obs{1};
    numObs = paramToNumObsMap(paramName);
    dataSize = iSetDimension(inputSize,obsDim,numObs);
    % Generate data
    if ~isClassification
        % The targets dispatched to a regression layer can be in any value
        % range. The range [-1,1] is used to generate arbitrary data.
        dataStruct(paramName) = iGenerateSingleData(dataSize,1500);
    elseif isempty(obsDim)
        % If ObservationDimension is not specified, one-hot encoded data
        % cannot be generated. Instead, the targets for the classification
        % layer are generated from arbitrary data in the range [0,1].
        dataStruct(paramName) = (iGenerateSingleData(dataSize,1800) + 1)/2;
    else
        % The targets dispatched to a classification layer are in one hot
        % encoding (only 0's and 1's) if ObservationDimension is specified.
        dataStruct(paramName) = iGenerateOneHotEncodedData(dataSize,obsDim);
    end
end
end

function data = iGenerateSingleData( sz, seed )
% iGenerateSingleData   Generate single data in the range [-1,1] using
% halton sequences.
data = nnet.checklayer.halton( sz, seed, 101 );
data = cast( data, 'single' );
end

function data = iGenerateOneHotEncodedData(inputSize,obsDim)
% iGenerateOneHotEncodedData   Generate single data containing only zeros
% and ones. There can only be one "1" along the class dimension.

% Generate random data and find maximum value along class dimension
classDim = obsDim-1;
s = rng(0);
restoreRng = onCleanup( @()rng(s) );
realData = rand(inputSize);
[~,idx] = max(realData,[],classDim);

% Convert indices to linear indices
subs = cell(1,numel(inputSize));
[subs{:}] = ind2sub(size(idx),1:numel(idx));
subs{classDim} = idx(:)';
linIdx = sub2ind(inputSize,subs{:});

% Create array of zeros and insert ones at the index locations
data = zeros(inputSize,'single');
data(linIdx) = 1;
end

function outputSize = iSetDimension(inputSize,dimension,value)
outputSize = inputSize;
numOutputDims = max( numel(inputSize), dimension );
outputSize(end+1:numOutputDims) = 1;
outputSize(dimension) = value;
end

function msgText = iGetTestCaseMessage(msgID,varargin)
msgText = getString(message( "nnet_cnn:nnet:checklayer:TestCase:"+msgID, varargin{:} ));
end
