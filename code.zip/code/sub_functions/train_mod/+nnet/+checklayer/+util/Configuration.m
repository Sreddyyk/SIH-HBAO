classdef Configuration < handle
    % Configuration   Handle class that holds information about the layer
    % to be tested and the environment that it is tested in. To check 
    % the validity of a layer, use checkLayer.
    
    %   Copyright 2018 The MathWorks, Inc.
    
    properties
        Layer
        InputSize
        ObservationDimension
        HasGPU
    end
    
end
