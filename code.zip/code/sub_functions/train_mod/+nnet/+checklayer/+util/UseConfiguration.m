classdef UseConfiguration
    % UseConfiguration   MATLAB constructs the Configuration object when 
    % loading the UseConfiguration class because Data is a constant 
    % property. All subsequently created instances of the UseConfiguration 
    % class refer to the same Configuration object. Access data in the
    % Configuration class via an instance of UseConfig.
    
    %   Copyright 2018 The MathWorks, Inc.
    
    properties (Constant)
        Data = nnet.checklayer.util.Configuration
    end

end