function dLdIn = numericDiff5Point(fcn, in, dLdOut)
% numericDiff5Point   Five-point numerical derivative function.
% The derivative of function 'fcn' is calculated with respect to the
% input argument 'in'.
%
% Inputs:
%   fcn    - Function handle that fulfills [out1,...,outM] = fcn(in1,...,inN).
%            If the derivative should be computed w.r.t. the data variable
%            'X' then fcn is typically @(X)layer.forward(X).
%            If the derivative should be computed w.r.t. a learnable
%            parameter 'W' then fcn needs to set the property 'W' before
%            forwarding data, e.g.
%            fcn = @(W) updateWeightsAndForward(layer,W,X);
%            function out = updateWeightsAndForward(layer,W,X)
%               layer.Weights = W;
%               out = layer.forward(X);
%            end
%   in     - Value at which the derivative should be computed. For
%            functions with multiple input arguments, in is a cell array.
%   dLdOut - The derivative of the network loss with respect to the
%            function outputs. dLdOut is a cell array if fcn has multiple
%            outputs. The chain rule, dLdIn = dOutdIn * dLdOut, is used to
%            compute the derivative of the loss with respect to the inputs.

%   Copyright 2017-2018 The MathWorks, Inc.

% The rng is reset multiple times during calculation of the numeric gradient.
% The initial rng state needs to be restored when exiting this function.
s = rng;
resetRng = onCleanup( @()rng(s) );

dLdOut = iToCell(dLdOut);
numOutputs = numel(dLdOut);

in = iToCell(in);
numInputs = numel(in);

% Compute the numerical gradient dLdIn using the following epsilon perturbation
epsilon = eps( class( iFlatten(dLdOut) ) )^(1/3);

% Deal with inputs that are all zeros
M = max( abs( iFlatten(in) ) );
if M > 0
    h = M * epsilon; % Step size should match data
else
    h = epsilon;
end

% Compute the numerical derivative with respect to each input variable
dLdIn = cellfun( @(x) zeros(size(x),'like',x), in, 'UniformOutput', false );
for jj = 1:numInputs
    % Compute the numerical derivative with respect to each element in the input
    for ii = 1:numel(in{jj})
        % Save original value
        x = in{jj}(ii);
        
        % Perturb x for finite differences
        xph = x + h;
        xmh = x - h;
        xp2h = x + (2*h);
        xm2h = x - (2*h);
        
        % Correct h (deltas between sample points) based on actual
        % difference. See
        % https://en.wikipedia.org/wiki/Numerical_differentiation#Practical_considerations_using_floating_point_arithmetic
        hp = xph - x;
        hm = x - xmh;
        h2p = xp2h - x;
        h2m = x - xm2h;
        h12 = 8*(hp + hm) - (h2p + h2m);
        
        % 5-point method for numerical derivative
        % x + 2h
        in{jj}(ii) = xp2h;
        outputOffset = iRunWithFixedRNG( fcn, in, numOutputs );
        dOutdInII = - outputOffset(:);
        
        % x + h
        in{jj}(ii) = xph;
        outputOffset = iRunWithFixedRNG( fcn, in, numOutputs );
        dOutdInII = dOutdInII + 8*outputOffset(:);
        
        % x - h
        in{jj}(ii) = xmh;
        outputOffset = iRunWithFixedRNG( fcn, in, numOutputs );
        dOutdInII = dOutdInII - 8*outputOffset(:);
        
        % x - 2h
        in{jj}(ii) = xm2h;
        outputOffset = iRunWithFixedRNG( fcn, in, numOutputs );
        dOutdInII = dOutdInII + outputOffset(:);
        
        % sum / 12h
        dOutdInII = dOutdInII ./ h12;
        
        % Reset
        in{jj}(ii) = x;
        
        % Apply chain rule: dLdIn(ii) = dLdOut * dOutdInII = sum(dOutdIn .* dLdOut(:))
        dLdIn{jj}(ii) = sum(dOutdInII .* iFlatten(dLdOut));
    end
end
dLdIn = iUnwrapCell(dLdIn);
end

function out = iRunWithFixedRNG( fcn, in, numOutputs )
% Set the seed of the random number generator in case the function fcn uses
% random numbers.
rng(0);
[out{1:numOutputs}] = fcn(in{:});
out = iFlatten(out);
end

function out = iFlatten(in)
if iscell(in)
    % Flatten each cell entry into a column vector
    in = cellfun( @(x)reshape(x,[],1), in, 'UniformOutput', false);
    % Flatten all cells into one long column vector
    out = cell2mat( in(:) );
else
    out = in(:);
end
end

function data = iToCell(data)
if ~iscell(data)
    data = {data};
end
end

function data = iUnwrapCell(data)
if iscell(data) && numel(data) == 1
    data = data{1};
end
end