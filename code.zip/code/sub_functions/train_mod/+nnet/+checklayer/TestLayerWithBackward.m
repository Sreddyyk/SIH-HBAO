classdef TestLayerWithBackward < nnet.checklayer.IntermediateLayerTestCase
    % TestLayerWithBackward   Test case class to check nnet.layer.Layer 
    % behaviour when the layer has a backward implementation
    %
    %   To check the validity of a layer, use checkLayer
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    methods(Test)
        function functionSyntaxesAreCorrect(test)
            test.verifyThat( test.Layer, iHasValidSignatures() );
        end
        
        function predictDoesNotError(test,Observations)
            % predictDoesNotError   Test that 'predict' can be used with no
            % errors
            
            inputData = test.InputData(Observations);
            layer = test.getLayerWithPrecision('single');
            
            fcn = @()layer.predict(inputData{:});
            numArgout = layer.NumOutputs;
            
            test.verifyThat(fcn, iDoesNotError('predict',numArgout))
        end
        
        function forwardDoesNotError(test,Observations)
            % forwardDoesNotError   Test that 'forward' can be used with no
            % errors
            
            % If 'forward' was not implemented in the layer then do not run
            % this test
            if ~test.LayerInformation.IsForwardDefined
                % Nothing to test, 'forward' was defined in the superclass
                % and not overridden
                return
            end
            
            inputData = test.InputData(Observations);
            layer = test.getLayerWithPrecision('single');
            
            fcn = @()layer.forward(inputData{:});
            numArgout = layer.NumOutputs+1;
            
            test.verifyThat(fcn, iDoesNotError('forward',numArgout))
        end
        
        function forwardPredictAreConsistentInSize(test,Observations)
            % forwardPredictAreConsistentInSize   Test that 'forward' and
            % 'predict' return outputs of the same size
            
            % If 'forward' was not implemented in the layer then do not run
            % this test
            if ~test.LayerInformation.IsForwardDefined
                % Nothing to test, 'forward' was defined in the superclass
                % and not overridden
                return
            end
            
            inputData = test.InputData(Observations);
            layer = test.getLayerWithPrecision('single');
            
            numLayerOutputs = layer.NumOutputs;
            [Zforward{1:numLayerOutputs}] = test.tryForward( layer, inputData{:} );
            [Zpredict{1:numLayerOutputs}] = test.tryPredict( layer, inputData{:} );
            
            test.verifyZforwardSameSizeAsZpredict( Zforward, Zpredict );
        end
        
        function backwardDoesNotError(test,Observations)
            % backwardDoesNotError   Test that 'backward' can be used with
            % no errors
            
            inputData = test.InputData(Observations);
            layer = test.getLayerWithPrecision('single');
            
            numLayerOutputs = layer.NumOutputs;
            [Z{1:numLayerOutputs}, memory] = test.tryForward( layer, inputData{:} );
            
            dLdZ = test.generateData( iAllSizes(Z), 'single' );
            
            fcn = @()layer.backward( inputData{:}, Z{:}, dLdZ{:}, memory );
            numBackwardOut = numel(test.LayerInformation.ParametersValues) + layer.NumInputs;
            
            test.verifyThat(fcn, iDoesNotError('backward',numBackwardOut))
        end
        
        function backwardIsConsistentInSize(test,Observations)
            % backwardIsConsistentInSize   Test that the output of
            % 'backward' is consistent in size. Namely, each dLdX should be 
            % the same size as X and each dLdW should be the same size as W
            
            inputData = test.InputData(Observations);
            layer = test.getLayerWithPrecision('single');
            
            numForwardOut = layer.NumOutputs;
            [Z{1:numForwardOut}, memory] = test.tryForward( layer, inputData{:} );
            
            dLdZ = test.generateData( iAllSizes(Z), 'single' );
            
            numLearnables = numel(test.LayerInformation.ParametersValues);
            numLayerInputs = layer.NumInputs;
            [dLdX{1:numLayerInputs}, dLdW{1:numLearnables}] = ...
                test.tryBackward( layer, inputData{:}, Z{:}, dLdZ{:}, memory );
            
            test.verifydLdXSameSizeAsX( dLdX, inputData );
            test.verifydLdWSameSizeAsWForEachLearnableParam( dLdW );
        end
        
        function predictIsConsistentInType(test,Precision,Device)
            % predictIsConsistentInType   Test that the output of
            % 'predict' is consistent in type. Namely, each Z should be the
            % same type as X.
            
            castFcn = test.castDataFcn(Precision,Device);
            inputData = castFcn(test.InputData('one'));
            layer = test.getLayerWithPrecision(castFcn);
            
            numLayerOutputs = layer.NumOutputs;
            [Z{1:numLayerOutputs}] = test.tryPredict( layer, inputData{:} );
            
            test.verifySameTypeForEachZ( Z, inputData{1}, 'predict' );
        end
        
        function forwardIsConsistentInType(test,Precision,Device)
            % forwardIsConsistentInType   Test that the output of
            % 'forward' is consistent in type. Namely, Z should be the
            % same type as X.
            
            % If 'forward' was not implemented in the layer then do not run
            % this test
            if ~test.LayerInformation.IsForwardDefined
                % Nothing to test, forward was defined in the superclass
                % and not overridden
                return
            end
            
            castFcn = test.castDataFcn(Precision,Device);
            inputData = castFcn(test.InputData('one'));
            layer = test.getLayerWithPrecision(castFcn);
            
            numLayerOutputs = layer.NumOutputs;
            [Z{1:numLayerOutputs}] = test.tryForward( layer, inputData{:} );
            
            test.verifySameTypeForEachZ( Z, inputData{1}, 'forward' );
        end
        
        function backwardIsConsistentInType(test,Precision,Device)
            % backwardIsConsistentInType   Test that the output of
            % 'backward' is consistent in type. Namely, each dLdX should be 
            % the same type as X and each dLdW should be the same type as W.
            
            castFcn = test.castDataFcn(Precision,Device);
            inputData = castFcn(test.InputData('one'));
            layer = test.getLayerWithPrecision(castFcn);
            
            numLayerOutputs = layer.NumOutputs;
            [Z{1:numLayerOutputs}, memory] = test.tryForward( layer, inputData{:} );
            
            dLdZ = castFcn( test.generateData( iAllSizes(Z), 'single' ) );
            
            numLearnables = numel(test.LayerInformation.ParametersValues);
            numLayerInputs = layer.NumInputs;
            [dLdX{1:numLayerInputs}, dLdW{1:numLearnables}] = ...
                test.tryBackward( layer, inputData{:}, Z{:}, dLdZ{:}, memory );
            
            test.verifySameTypeForEachdLdX( dLdX, inputData{1} );
            test.verifySameTypeForEachdLdW( dLdW, inputData{1} );
        end
        
        function gradientsAreNumericallyCorrect(test)
            % gradientsAreNumericallyCorrect   Test that the gradients
            % computed in 'backward' are numerically correct
            
            relTol = 1e-6;
            absTol = 1e-6;
            mixedTol = iRelativeTolerance(relTol) | iAbsoluteTolerance(absTol);
            numParameters = numel( test.LayerInformation.ParametersNames );
            
            castFcn = test.castDataFcn('double','cpu');
            layer = test.getLayerWithPrecision('double');
            
            obsType = obsTypeForGradientCheck(test);
            X0 = castFcn(test.InputData(obsType));
            numOutputs = layer.NumOutputs;
            [Z{1:numOutputs}, memory] = test.tryForward(layer,X0{:});
            
            % Perturb dLdZ so that it is not equal to X0
            dLdZ = test.generateData( iAllSizes(Z), 'double' );
            dLdZ = cellfun( @(dz) dz*0.9, dLdZ, 'UniformOutput', false);
            
            % Compute derivatives w.r.t. inputs and learnable parameters
            % via the layer's backward method
            numInputs = layer.NumInputs;
            [actual_dLdX{1:numInputs}, actual_dLdW{1:numParameters}] = ...
                test.tryBackward(layer, X0{:}, Z{:}, dLdZ{:}, memory);
            
            % Compute numerical derivative with respect to the inputs
            forwardWithNewX = @(varargin)forward(layer, varargin{:});
            expected_dLdX = iNumericGradient( forwardWithNewX, X0, dLdZ );
            if numInputs == 1
                msg = message('nnet_cnn:nnet:checklayer:TestCase:IncorrectGradient', 'dLdX', 'backward');
                test.verifyThat( actual_dLdX{1}, ...
                    iIsEqualTo(expected_dLdX, 'Within', mixedTol), ...
                    getString(msg) );
            else
                for i = 1:numInputs
                    msg = message('nnet_cnn:nnet:checklayer:TestCase:IncorrectGradientdLdX', layer.InputNames{i});
                    test.verifyThat( actual_dLdX{i}, ...
                        iIsEqualTo(expected_dLdX{i}, 'Within', mixedTol), ...
                        getString(msg) );
                end
            end
            
            % Compute numerical derivative with respect to the parameters
            for ii=1:numParameters
                paramName = test.LayerInformation.ParametersNames{ii};
                W0 = layer.(paramName);
                fcn = @(W)forwardWithWi( layer, paramName, W, X0 );
                expected_dLdW = iNumericGradient( fcn, W0, dLdZ );
                
                test.verifyThat( actual_dLdW{ii}, ...
                    iIsEqualTo(expected_dLdW, 'Within', mixedTol), ...
                    getString(message('nnet_cnn:nnet:checklayer:TestCase:IncorrectGradientdLdW',paramName)) );
            end
            
            function varargout = forwardWithWi( layer, param, newWi, X )
                layer.(param) = newWi;
                [varargout{1:nargout}] = forward( layer, X{:} );
            end
        end
    end
    
    methods(Access = private)
        function varargout = tryBackward( test, layer, varargin )
            try
                [varargout{1:nargout}] = layer.backward( varargin{:} );
            catch
                % 'backward' errored out, fail the test
                test.assumeFail( getString(message('nnet_cnn:nnet:checklayer:TestCase:SkipTestMethodErrored', 'backward')) )
            end
        end
        
        function verifydLdXSameSizeAsX( test, dLdX, X )
            if numel(X) == 1
                test.verifyThat( dLdX{1}, iIsOfSameSizeAs(X{1}), ...
                    getString(message('nnet_cnn:nnet:checklayer:TestCase:IncorrectSizedLdX')) );
            else
                for ii = 1:numel(X)
                    inputName = test.Layer.InputNames{ii};
                    test.verifyThat( dLdX{ii}, iIsOfSameSizeAs(X{ii}), ...
                        getString(message('nnet_cnn:nnet:checklayer:TestCase:IncorrectSizeMultidLdX',inputName)) );
                end
            end
        end
        
        function verifydLdWSameSizeAsWForEachLearnableParam( test, dLdW )
            for ii=1:numel(dLdW)
                test.verifydLdWSameSizeAsW( dLdW{ii}, test.LayerInformation.ParametersValues{ii}, test.LayerInformation.ParametersNames{ii} )
            end
        end
        
        function verifydLdWSameSizeAsW( test, dLdW, W, parameterName )
            test.verifyThat( dLdW, iIsOfSameSizeAs(W), ...
                getString(message('nnet_cnn:nnet:checklayer:TestCase:IncorrectSizedLdW',parameterName)) );
        end

        function verifySameTypeForEachdLdW( test, dLdW, X )
            for ii=1:numel(dLdW)
                parameterName = test.LayerInformation.ParametersNames{ii};
                test.verifyThat( dLdW{ii}, iIsOfSameTypeAs(X), ...
                    getString(message('nnet_cnn:nnet:checklayer:TestCase:IncorrectTypedLdW',parameterName)));
            end
        end
        
        function verifySameTypeForEachdLdX( test, dLdX, X )
            if numel(dLdX) == 1
                test.verifyThat( dLdX{1}, iIsOfSameTypeAs(X), ...
                    getString(message('nnet_cnn:nnet:checklayer:TestCase:IncorrectType','dLdX','backward')) );
            else
                for ii=1:numel(dLdX)
                    inputName = test.Layer.InputNames{ii};
                    test.verifyThat( dLdX{ii}, iIsOfSameTypeAs(X), ...
                        getString(message('nnet_cnn:nnet:checklayer:TestCase:IncorrectTypedLdX',inputName)));
                end
            end
        end
        
        function obsType = obsTypeForGradientCheck(test)
            if isKey(test.InputData,'multiple')
                obsType = 'multiple';
            else
                obsType = 'one';
            end
        end
    end
end

function constraint = iDoesNotError(varargin)
constraint = nnet.checklayer.constraints.DoesNotThrowErrors(varargin{:});
end

function constraint = iIsOfSameTypeAs(value)
constraint = nnet.checklayer.constraints.IsOfSameTypeAs(value);
end

function constraint = iIsOfSameSizeAs(value)
constraint = nnet.checklayer.constraints.IsOfSameSizeAs(value);
end

function constraint = iHasValidSignatures()
constraint = nnet.checklayer.constraints.HasValidSignatures();
end

function constraint = iIsEqualTo(varargin)
constraint = matlab.unittest.constraints.IsEqualTo(varargin{:});
end

function constraint = iRelativeTolerance(varargin)
constraint = matlab.unittest.constraints.RelativeTolerance(varargin{:});
end

function constraint = iAbsoluteTolerance(varargin)
constraint = matlab.unittest.constraints.AbsoluteTolerance(varargin{:});
end

function dLdIn = iNumericGradient(varargin)
dLdIn = nnet.checklayer.numericDiff5Point(varargin{:});
end

function sz = iAllSizes( sz )
if iscell(sz)
    sz = cellfun( @size, sz, 'UniformOutput', false);
else
    sz = size(sz);
end
end