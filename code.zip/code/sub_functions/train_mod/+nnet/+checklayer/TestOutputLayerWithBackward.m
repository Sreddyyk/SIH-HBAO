classdef TestOutputLayerWithBackward < nnet.checklayer.OutputLayerTestCase
    % TestOutputLayerWithBackward   TestCase class to check validity of
    % output layers with custom backwardLoss implementing the interface
    % nnet.layer.RegressionLayer or nnet.layer.ClassificationLayer.
    %
    %   To check the validity of a layer, use checkLayer
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods(Test)
        function forwardLossDoesNotError(test,Observations)
            % forwardLossDoesNotError   Check that 'forwardLoss' can be used
            % with no errors
            
            predictions = test.Predictions(Observations);
            targets =  test.Targets(Observations);
            
            fcn = @()test.Layer.forwardLoss(predictions,targets);
            
            test.verifyThat(fcn, iDoesNotError('forwardLoss',1));
        end
        
        function backwardLossDoesNotError(test,Observations)
            % backwardLossDoesNotError   Check that 'backwardLoss' can be
            % used with no errors
            
            predictions = test.Predictions(Observations);
            targets =  test.Targets(Observations);
            
            fcn = @()test.Layer.backwardLoss(predictions,targets);
            
            test.verifyThat(fcn, iDoesNotError('backwardLoss',1));
        end
        
        function forwardLossIsScalar(test,Observations)
            % forwardLossIsScalar   Check that the output of 'forwardLoss'
            % is a scalar
            
            predictions = test.Predictions(Observations);
            targets = test.Targets(Observations);
            
            loss = test.tryForwardLoss(predictions,targets);
            
            scalarSize = [1 1];
            test.verifySize( loss, scalarSize, ...
                iGetTestCaseMessage('IncorrectSizeForwardLoss') );
        end
        
        function backwardLossIsConsistentInSize(test,Observations)
            % backwardLossIsConsistentInSize   Check that the output of
            % 'backwardLoss' is consistent in size. Namely, dLdY should be
            % the same size as the predictions, Y.
            
            predictions = test.Predictions(Observations);
            targets = test.Targets(Observations);
            
            expectedSize = size(predictions);
            dLdY = test.tryBackwardLoss(predictions,targets);
            
            test.verifySize( dLdY, expectedSize, ...
                iGetTestCaseMessage('IncorrectSizeBackwardLoss') );
        end
        
        function forwardLossIsConsistentInType(test,Precision,Device)
            % forwardLossIsConsistentInType   Test that the output of
            % 'forwardLoss' is consistent in type. Namely, 'loss' should be
            % the same type as the predictions, Y.
            
            % cast predictions and targets to type specified by test
            % parameter "Precision" and "Device"
            castFcn = test.castDataFcn(Precision,Device);
            predictions = castFcn( test.Predictions('one') );
            targets = castFcn( test.Targets('one') );
            
            loss = test.tryForwardLoss(predictions,targets);
            
            test.verifyThat( loss, iIsOfSameTypeAs(predictions), ...
                iGetTestCaseMessage('IncorrectType','loss','forwardLoss') );
        end
        
        function backwardLossIsConsistentInType(test,Precision,Device)
            % backwardLossIsConsistentInType   Test that the output of
            % 'backwardLoss' is consistent in type. Namely, 'dLdY' should
            % be the same type as the predictions, Y.
            
            % cast predictions and targets to type specified by test
            % parameter "Precision" and "Device"
            castFcn = test.castDataFcn(Precision,Device);
            predictions = castFcn( test.Predictions('one') );
            targets = castFcn( test.Targets('one') );
            
            loss = test.tryBackwardLoss(predictions,targets);
            
            test.verifyThat( loss, iIsOfSameTypeAs(predictions), ...
                iGetTestCaseMessage('IncorrectTypeBackwardLoss') );
        end
        
        function gradientsAreNumericallyCorrect(test)
            % gradientsAreNumericallyCorrect   Test that the gradients
            % computed in 'backwardLoss' are numerically correct
            
            relTol = 1e-6;
            absTol = 1e-6;
            mixedTol = iRelativeTolerance(relTol) | iAbsoluteTolerance(absTol);
            
            obsType = obsTypeForGradientCheck(test);
            Y0 = double( test.Predictions(obsType) );
            T = double( test.Targets(obsType) );
            
            actual_dLdY = test.tryBackwardLoss(Y0,T);
            
            forwardLossGivenY = @(Y)test.tryForwardLoss(Y,T);
            expected_dLdY = iNumericGradient(forwardLossGivenY, Y0);
            
            test.verifyThat( actual_dLdY, ...
                iIsEqualTo(expected_dLdY, 'Within', mixedTol), ...
                iGetTestCaseMessage('IncorrectGradient','dLdY','backwardLoss') );
        end
    end
    
    methods(Access = private)
        function dLdY = tryBackwardLoss( test, Y, T )
            try
                dLdY = test.Layer.backwardLoss( Y, T );
            catch
                % 'backwardLoss' errored out, fail the test
                test.assumeFail( iGetTestCaseMessage('SkipTestMethodErrored','backwardLoss') )
            end
        end
        
        function obsType = obsTypeForGradientCheck(test)
            if isKey(test.Predictions,'multiple')
                obsType = 'multiple';
            else
                obsType = 'one';
            end
        end
    end
end

%% Constraints

function constraint = iRelativeTolerance(varargin)
constraint = matlab.unittest.constraints.RelativeTolerance(varargin{:});
end

function constraint = iAbsoluteTolerance(varargin)
constraint = matlab.unittest.constraints.AbsoluteTolerance(varargin{:});
end

function constraint = iIsEqualTo(varargin)
constraint = matlab.unittest.constraints.IsEqualTo(varargin{:});
end

function constraint = iDoesNotError(varargin)
constraint = nnet.checklayer.constraints.DoesNotThrowErrors(varargin{:});
end

function constraint = iIsOfSameTypeAs(value)
constraint = nnet.checklayer.constraints.IsOfSameTypeAs(value);
end

%% Helpers

function dLdIn = iNumericGradient(fcn,input)
dLdIn = nnet.checklayer.numericDiff5Point(fcn,input,ones(1,'like',input));
end

function msgText = iGetTestCaseMessage(msgID,varargin)
msgText = getString(message( "nnet_cnn:nnet:checklayer:TestCase:"+msgID, varargin{:} ));
end
