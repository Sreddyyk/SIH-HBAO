classdef TestLayerWithoutBackward < nnet.checklayer.IntermediateLayerTestCase
    % TestLayerWithoutBackward   Test case class to check nnet.layer.Layer
    % behaviour when the layer does not have a backward implementation
    %
    %   To check the validity of a layer, use checkLayer
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods(Test)
        function functionSyntaxesAreCorrect(test)
            test.verifyThat( test.Layer, iHasValidSignatures() );
        end
        
        function predictDoesNotError(test,Observations)
            % predictDoesNotError   Test that 'predict' can be used with no
            % errors
            
            inputData = test.convertToDlarray( test.InputData(Observations) );
            layer = test.getLayerWithPrecision( 'single' );
            layer = test.convertToDlarray(layer);
            
            fcn = @()layer.predict(inputData{:});
            numArgout = layer.NumOutputs;
            
            test.verifyThat(fcn, iDoesNotError('predict',numArgout))
        end
        
        function forwardDoesNotError(test,Observations)
            % forwardDoesNotError   Test that 'forward' can be used with no
            % errors
            
            % If 'forward' was not implemented in the layer then do not run
            % this test
            if ~test.LayerInformation.IsForwardDefined
                % Nothing to test, 'forward' was defined in the superclass
                % and not overridden
                return
            end
            
            inputData = test.convertToDlarray( test.InputData(Observations) );
            layer = test.getLayerWithPrecision( 'single' );
            layer = test.convertToDlarray(layer);
            
            fcn = @()layer.forward(inputData{:});
            numArgout = layer.NumOutputs;
            
            test.verifyThat(fcn, iDoesNotError('forward',numArgout))
        end
        
        function forwardPredictAreConsistentInSize(test,Observations)
            % forwardPredictAreConsistentInSize   Test that 'forward' and
            % 'predict' return outputs of the same size
            
            % If 'forward' was not implemented in the layer then do not run
            % this test
            if ~test.LayerInformation.IsForwardDefined
                % Nothing to test, 'forward' was defined in the superclass
                % and not overridden
                return
            end
            
            inputData = test.convertToDlarray( test.InputData(Observations) );
            layer = test.getLayerWithPrecision( 'single' );
            layer = test.convertToDlarray(layer);
            
            numLayerOutputs = layer.NumOutputs;
            [Zforward{1:numLayerOutputs}] = test.tryForward( layer, inputData{:} );
            [Zpredict{1:numLayerOutputs}] = test.tryPredict( layer, inputData{:} );
            
            test.verifyZforwardSameSizeAsZpredict( Zforward, Zpredict );
        end
        
        function predictIsConsistentInType(test,Precision,Device)
            % predictIsConsistentInType   Test that the output of
            % 'predict' is consistent in type. Namely, each Z should be the
            % same type as X.
            
            castFcn = test.castDataFcn(Precision,Device);
            inputData = castFcn(test.InputData('one'));
            dlarrayInput = test.convertToDlarray(inputData);
            
            layer = test.getLayerWithPrecision( castFcn );
            layer = test.convertToDlarray(layer);
            
            numLayerOutputs = layer.NumOutputs;
            [Z{1:numLayerOutputs}] = test.tryPredict( layer, dlarrayInput{:} );
            
            test.verifyUnlabeledDlarrayForEachZ( Z, 'predict' );
            test.verifySameTypeForEachZ( iExtractAllData(Z), inputData{1}, 'predict' );
        end       
        
        function forwardIsConsistentInType(test,Precision,Device)
            % forwardIsConsistentInType   Test that the output of
            % 'forward' is consistent in type. Namely, Z should be the
            % same type as X.
            
            % If 'forward' was not implemented in the layer then do not run
            % this test
            if ~test.LayerInformation.IsForwardDefined
                % Nothing to test, forward was defined in the superclass
                % and not overridden
                return
            end
            
            castFcn = test.castDataFcn(Precision,Device);
            inputData = castFcn(test.InputData('one'));
            dlarrayInput = test.convertToDlarray(inputData);
            
            layer = test.getLayerWithPrecision( castFcn );
            layer = test.convertToDlarray(layer);
            
            numLayerOutputs = layer.NumOutputs;
            [Z{1:numLayerOutputs}] = test.tryForward( layer, dlarrayInput{:} );
            
            test.verifyUnlabeledDlarrayForEachZ( Z, 'forward' );
            test.verifySameTypeForEachZ( iExtractAllData(Z), inputData{1}, 'forward' );
        end
        
        function backwardPropagationDoesNotError(test,Observations)
            % backwardPropagationDoesNotError   Test that derivates can be
            % computed using automatic differentiation
            testData = test.InputData(Observations);
            
            % Assert that forward doesn't error before computing gradients
            XForForward = test.convertToDlarray( testData );
            layerForForward = test.getLayerWithPrecision( 'single' );
            layerForForward = test.convertToDlarray(layerForForward);
            test.tryForward( layerForForward, XForForward{:} );
            
            % Verify that gradients can be computed using autodiff
            function [Zs,learnables] = forwardAndGradients()
                restore = iSetupCleanupFunction(); %#ok<NASGU>
                Xs = test.convertToRecordingDlarray( testData );
                layer = test.getLayerWithPrecision( 'single' );
                [layer, learnables] = test.convertToRecordingDlarray(layer);
                [Zs{1:layer.NumOutputs}] = forward( layer, Xs{:} );
                dLdZ = test.generateData( iAllSizes(Zs), 'single' );
                dLdZ = test.convertToDlarray(dLdZ);
                dLdX = deep.internal.propagateAdjoint( dLdZ, Zs, [Xs, learnables]); %#ok<NASGU>
            end

            if test.LayerInformation.IsForwardDefined
                inferenceMethod = 'forward';
            else
                inferenceMethod = 'predict';
            end
            test.verifyThat( @forwardAndGradients, iDoesNotError(), ...
                iGetTestCaseMessage('AutodiffFailedBackward',inferenceMethod) );
        end
    end
    
    methods(Access = private)
        function obj = convertToDlarray( test, obj )
            if isa(obj,'nnet.layer.Layer')
                % Convert learnable parameters to dlarrays
                paramNames = test.LayerInformation.ParametersNames;
                for ii=1:numel(paramNames)
                    obj.(paramNames{ii}) = dlarray( obj.(paramNames{ii}) );
                end
            elseif iscell(obj)
                % Convert each element in the cell to a dlarray
                obj = cellfun( @dlarray, obj, 'UniformOutput', false);
            else
                % Convert numeric data to dlarray
                obj = dlarray(obj);
            end
        end
        
        function [obj, varargout] = convertToRecordingDlarray( test, obj )
            if isa(obj,'nnet.layer.Layer')
                % Convert learnable parameters to recording dlarrays
                paramNames = test.LayerInformation.ParametersNames;
                Ws = cell(1,numel(paramNames));
                for ii=1:numel(paramNames)
                    obj.(paramNames{ii}) = iRecordingDlarray( obj.(paramNames{ii}) );
                    Ws{ii} = obj.(paramNames{ii});
                end
                varargout = {Ws};
            elseif iscell(obj)
                % Convert each element in the cell to a recording dlarray
                obj = cellfun( @iRecordingDlarray, obj, 'UniformOutput', false);
            else
                % Convert numeric data to a recording dlarray
                obj = iRecordingDlarray(obj);
            end
        end
        
        function verifyUnlabeledDlarrayForEachZ( test, Z, methodName )
            if numel(Z) == 1
                test.verifyThat( Z{1}, iIsUnlabeledDlarray(), ...
                    getString(message('nnet_cnn:nnet:checklayer:TestCase:IncorrectType','Z',methodName)) );
            else
                for ii=1:numel(Z)
                    outputName = test.Layer.OutputNames{ii};
                    test.verifyThat( Z{ii}, iIsUnlabeledDlarray(), ...
                        getString(message('nnet_cnn:nnet:checklayer:TestCase:IncorrectTypeMultiOut',outputName,methodName)));
                end
            end
        end
    end
end

%% Constraints

function out = iExtractAllData(in)
if iscell(in)
    out = cellfun( @iExtractAllData, in, 'UniformOutput', false );
elseif isa(in,'dlarray')
    out = extractdata(in);
else
    out = in;
end
end

function constraint = iDoesNotError(varargin)
constraint = nnet.checklayer.constraints.DoesNotThrowErrors(varargin{:});
end

function constraint = iIsUnlabeledDlarray()
constraint = nnet.checklayer.constraints.IsUnlabeledDlarray();
end

function constraint = iHasValidSignatures()
constraint = nnet.checklayer.constraints.HasValidSignatures();
end

%% Helpers

function sz = iAllSizes( sz )
if iscell(sz)
    sz = cellfun( @size, sz, 'UniformOutput', false);
else
    sz = size(sz);
end
end

function out = iRecordingDlarray(in)
out = dlarray(in);
out = deep.internal.recording.recordContainer(out);
end

function restore = iSetupCleanupFunction()
persistent tm;
if isempty(tm)
    tm = deep.internal.recording.TapeManager();
end
restore = [];
tracingCount = getTracingCount(tm);
if (tracingCount == 0)
    restore = deep.internal.startTracingAndSetupCleanup(tm);
end
end 

function msgText = iGetTestCaseMessage(msgID,varargin)
msgText = getString(message( "nnet_cnn:nnet:checklayer:TestCase:"+msgID, varargin{:} ));
end
