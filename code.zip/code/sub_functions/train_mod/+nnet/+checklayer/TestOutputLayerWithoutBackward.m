classdef TestOutputLayerWithoutBackward < nnet.checklayer.OutputLayerTestCase
    % TestOutputLayerWithoutBackward   TestCase class to check validity of
    % output layers without custom backwardLoss implementing the interface
    % nnet.layer.RegressionLayer or nnet.layer.ClassificationLayer.
    %
    %   To check the validity of a layer, use checkLayer
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods(Test)
        function forwardLossDoesNotError(test,Observations)
            % forwardLossDoesNotError   Check that 'forwardLoss' can be used
            % with no errors
            
            predictions = dlarray( test.Predictions(Observations) );
            targets =  test.Targets(Observations);
            
            fcn = @()test.Layer.forwardLoss(predictions,targets);
            
            test.verifyThat(fcn, iDoesNotError('forwardLoss',1));
        end
        
        function forwardLossIsScalar(test,Observations)
            % forwardLossIsScalar   Check that the output of 'forwardLoss'
            % is a scalar
            
            predictions = dlarray(test.Predictions(Observations));
            targets = test.Targets(Observations);
            
            loss = test.tryForwardLoss(predictions,targets);
            
            scalarSize = [1 1];
            test.verifySize( loss, scalarSize, ...
                iGetTestCaseMessage('IncorrectSizeForwardLoss') );
        end
        
        function forwardLossIsConsistentInType(test,Precision,Device)
            % forwardLossIsConsistentInType   Test that the output of
            % 'forwardLoss' is consistent in type. Namely, 'loss' should be
            % the same type as the predictions, Y.
            
            % cast predictions and targets to type specified by test
            % parameter "Precision" and "Device"
            castFcn = test.castDataFcn(Precision,Device);
            predictions = castFcn( test.Predictions('one') );
            targets = castFcn( test.Targets('one') );
            
            loss = test.tryForwardLoss(dlarray(predictions),targets);
            
            test.verifyThat( loss, iIsUnlabeledDlarray(), ...
                iGetTestCaseMessage('IncorrectType','loss','forwardLoss') );
            test.verifyThat( iExtractdata(loss), iIsOfSameTypeAs(predictions), ...
                iGetTestCaseMessage('IncorrectType','loss','forwardLoss') );
        end
        
        function backwardPropagationDoesNotError(test,Observations)
            % backwardPropagationDoesNotError   Check that gradients can be
            % computed using automatic differentiation (dlgradient)
            
            predictions = dlarray(test.Predictions(Observations));
            targets =  test.Targets(Observations);
            
            function grad = objectiveAndGradient(y)
                loss = test.tryForwardLoss( y, targets );
                grad = dlgradient(loss,y);
            end
            
            fcn = @()dlfeval(@objectiveAndGradient,predictions);
            test.verifyThat( fcn, iDoesNotError(), ...
                iGetTestCaseMessage('AutodiffFailedBackwardLoss') );
        end
        
    end
end

%% Constraints

function constraint = iDoesNotError(varargin)
constraint = nnet.checklayer.constraints.DoesNotThrowErrors(varargin{:});
end

function constraint = iIsOfSameTypeAs(value)
constraint = nnet.checklayer.constraints.IsOfSameTypeAs(value);
end

function constraint = iIsUnlabeledDlarray()
constraint = nnet.checklayer.constraints.IsUnlabeledDlarray();
end

%% Helpers

function msgText = iGetTestCaseMessage(msgID,varargin)
msgText = getString(message( "nnet_cnn:nnet:checklayer:TestCase:"+msgID, varargin{:} ));
end

function out = iExtractdata(in)
if isa(in,'dlarray')
    out = extractdata(in);
else
    out = in;
end
end