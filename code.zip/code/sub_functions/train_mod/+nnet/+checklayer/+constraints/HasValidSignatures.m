classdef HasValidSignatures < matlab.unittest.constraints.Constraint
    % HasValidSignatures   Constraint to verify that a custom layer has
    % valid method signatures
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    methods
        
        function [bool,errorMsg] = satisfiedBy(~, layer)
            errorMsg = iValidateMethodSignatures(layer);
            bool = isempty(errorMsg);
        end
        
        function diag = getDiagnosticFor(constraint, layer)
            import matlab.unittest.diagnostics.StringDiagnostic
            
            [~,errorMsg] = constraint.satisfiedBy(layer);
            diag = StringDiagnostic( errorMsg );
        end
    end
end

function diagnostics = iValidateMethodSignatures(layer)
msgs = nnet.internal.cnn.layer.util.CustomLayerVerifier.validateMethodSignatures(layer);
diagnostics = strjoin(msgs,newline);
end