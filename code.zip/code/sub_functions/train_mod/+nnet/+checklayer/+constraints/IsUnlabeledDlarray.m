classdef IsUnlabeledDlarray < matlab.unittest.constraints.Constraint
    % IsUnlabeledDlarray   Constraint to verify that a variable is a
    % dlarray without dimension labels
    
    %   Copyright 2019 The MathWorks, Inc.

    methods
        function bool = satisfiedBy(~, actual)
            bool = iIsdlarray(actual) && isempty(dims(actual));
        end
        
        function diag = getDiagnosticFor(constraint, actual)
            import matlab.unittest.diagnostics.StringDiagnostic
            
            bool = constraint.satisfiedBy(actual);
            if bool
                diag = '';
            elseif ~iIsdlarray(actual)
                % The value's class is incorrect. It should be a dlarray.
                diag = StringDiagnostic( ...
                    getString( message( 'nnet_cnn:nnet:checklayer:constraints:IsUnlabeledDlarray:DifferentTypes', ...
                    class( actual ), 'dlarray' ) ) );
            else
                % The value is a dlarray with dimension labels. It should
                % be unlabeled.
                diag = StringDiagnostic( ...
                    getString( message( 'nnet_cnn:nnet:checklayer:constraints:IsUnlabeledDlarray:HasDimensionLabels', ...
                    dims(actual) ) ) );
            end
        end
    end
end

function tf = iIsdlarray(var)
tf = isa(var,'dlarray');
end