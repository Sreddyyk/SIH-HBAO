classdef IsOfSameSizeAs < matlab.unittest.constraints.Constraint
    % IsOfSameSizeAs   Constraint to verify that two variables have the
    % same size
    
    %   Copyright 2018 The MathWorks, Inc.
    
    properties(SetAccess=immutable)
        ExpectedSize
    end
    
    methods
        function constraint = IsOfSameSizeAs(value)
            constraint.ExpectedSize = size(value);
        end
        
        function bool = satisfiedBy(constraint, actual)
            bool = isequal( constraint.ExpectedSize, size(actual) );
        end
        
        function diag = getDiagnosticFor(constraint, actual)
            import matlab.unittest.diagnostics.StringDiagnostic
            
            bool = constraint.satisfiedBy(actual);
            if bool
                diag = '';
            else
                diag = StringDiagnostic( ...
                    getString( message( 'nnet_cnn:nnet:checklayer:constraints:IsOfSameSizeAs:DifferentSizes', ...
                    iSizeToString( size(actual) ), ...
                    iSizeToString( constraint.ExpectedSize ) ) ) );
            end
        end
    end
end

function str = iSizeToString(sz)
str = "[" + strjoin(string(sz)," ") + "]";
end