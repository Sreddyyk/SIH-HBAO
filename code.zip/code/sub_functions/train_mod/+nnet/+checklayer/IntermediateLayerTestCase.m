classdef (Abstract) IntermediateLayerTestCase < matlab.unittest.TestCase
    % IntermediateLayerTestCase   Abstract test case class for common test
    % cases and test utilities to test intermediate custom layers.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties (SetAccess = private)
        % Layer (nnet.layer.Layer)   Layer under test
        Layer
        
        % LayerInformation (nnet.checklayer.MetaLayer) Information about
        % layer
        LayerInformation nnet.checklayer.MetaLayer
        
        % InputData (containers.Map)   Map that stores the input data to
        % test the layer for 'one' and 'multiple' observations
        InputData
    end
    
    properties(TestParameter)
        Precision = {'single', 'double'};
        Device = {'cpu','gpu'}
        Observations = {'one', 'multiple'}
    end
    
    methods(Test,Abstract)
        functionSyntaxesAreCorrect(test)
        
        predictDoesNotError(test,Observations)
        predictIsConsistentInType(test,Precision,Device)
        
        forwardDoesNotError(test,Observations)
        forwardIsConsistentInType(test,Precision,Device)
        forwardPredictAreConsistentInSize(test,Observations)
    end
    
    methods
        function test = IntermediateLayerTestCase()
            config = nnet.checklayer.util.UseConfiguration;
            test.Layer = config.Data.Layer;
            test.LayerInformation = nnet.checklayer.MetaLayer( config.Data.Layer );
            
            % Create a map container with random data for one observation
            % and multiple observations (if ObservationDimension is
            % specified). In case ObservationDimension is not specified,
            % the 'one' observation data will be exactly of size InputSize
            % as specified by the user.
            obsDim = config.Data.ObservationDimension;
            if isempty(obsDim)
                numObsMap = containers.Map({'one'},{1});
            else
                numObsMap = containers.Map({'one','multiple'},{1,2});
            end
            inputSize = config.Data.InputSize;
            test.InputData = test.generateInputData( inputSize, obsDim, numObsMap );
        end
    end
    
    methods(Access = protected)
        function layer = getLayerWithPrecision(test,precision)
            % setLayerPrecision   Cast all learnable parameters of the
            % layer to the given precision.
            if isa(precision,'function_handle')
                castFcn = precision;
            else
                castFcn = @(x) cast(x,precision);
            end
            layer = test.Layer;
            numParameters = numel( test.LayerInformation.ParametersNames );
            for ii=1:numParameters
                paramName = test.LayerInformation.ParametersNames{ii};
                layer.(paramName) = iUnWrapCell(castFcn(layer.(paramName)));
            end
        end
        
        function varargout = tryForward( test, layer, varargin )
            prevRng = rng(0);
            resetRng = onCleanup( @()rng(prevRng) );
            try
                [varargout{1:nargout}] = layer.forward( varargin{:} );
            catch
                % 'forward' errored out, fail the test
                if test.LayerInformation.IsForwardDefined
                    methodThatErrored = 'forward';
                else
                    methodThatErrored = 'predict';
                end
                test.assumeFail( getString(message('nnet_cnn:nnet:checklayer:TestCase:SkipTestMethodErrored', methodThatErrored)) )
            end
        end
        
        function varargout = tryPredict( test, layer, varargin )
            try
                [varargout{1:nargout}] = layer.predict( varargin{:} );
            catch
                % 'predict' errored out, fail the test
                test.assumeFail( getString(message('nnet_cnn:nnet:checklayer:TestCase:SkipTestMethodErrored', 'predict')) )
            end
        end
        
        function verifyZforwardSameSizeAsZpredict( test, Zforward, Zpredict )
            if numel(Zpredict) == 1
                test.verifyThat( Zforward{1}, iIsOfSameSizeAs(Zpredict{1}), ...
                    getString(message('nnet_cnn:nnet:checklayer:TestCase:InconsistentSizeZ')) );
            else
                for ii = 1:numel(Zpredict)
                    outputName = test.Layer.OutputNames{ii};
                    test.verifyThat( Zforward{ii}, iIsOfSameSizeAs(Zpredict{ii}), ...
                        getString(message('nnet_cnn:nnet:checklayer:TestCase:InconsistentSizeMultiZ',outputName)) );
                end
            end
        end
        
        function verifySameTypeForEachZ( test, Z, X, methodName )
            if numel(Z) == 1
                test.verifyThat( Z{1}, iIsOfSameTypeAs(X), ...
                    getString(message('nnet_cnn:nnet:checklayer:TestCase:IncorrectType','Z',methodName)) );
            else
                for ii=1:numel(Z)
                    outputName = test.Layer.OutputNames{ii};
                    test.verifyThat( Z{ii}, iIsOfSameTypeAs(X), ...
                        getString(message('nnet_cnn:nnet:checklayer:TestCase:IncorrectTypeMultiOut',outputName,methodName)));
                end
            end
        end
        
        function dataStruct = generateInputData( test, inputSize, obsDim, paramToNumObsMap )
            % Generate data for each entry in paramToNumObsMap. paramToNumObsMap maps a
            % value of the test parameter 'Observations' to the number of observations
            % that are generated for that parameter.
            dataStruct = containers.Map();
            for obs = keys(paramToNumObsMap)
                paramName = obs{1};
                numObs = paramToNumObsMap(paramName);
                % Generate data
                inputSize = iWrapInCell(inputSize);
                dataSize = cellfun( @(sz)iSetDimension(sz,obsDim,numObs), inputSize, 'UniformOutput', false);
                data = test.generateData(dataSize,'single');
                % Store data in a Map container
                dataStruct(paramName) = data;
            end
        end
        
        function datacell = generateData( ~, sz, precision )
            % iGenerateSingleData   Generate single data using halton sequences
            sz = iWrapInCell(sz);
            datacell = cell(1,numel(sz));
            for i = 1:numel(sz)
                seed = 1000+i;
                data = nnet.checklayer.halton( sz{i}, seed, 101 );
                datacell{i} = cast( data, precision );
            end
        end
        
        function castFcn = castDataFcn(~,precision,device)
            if strcmp(device,'gpu')
                castFcn = @(data) cellfun( ...
                    @(x) gpuArray(cast(x,precision)), ...
                    iWrapInCell(data), 'UniformOutput', false );
            else
                castFcn = @(xcell) cellfun( ...
                    @(x) cast(x,precision), ...
                    iWrapInCell(xcell), 'UniformOutput', false );
            end
        end
    end
    
end

function data = iWrapInCell(data)
if ~iscell(data)
    data = {data};
end
end

function data = iUnWrapCell(data)
if iscell(data) && isscalar(data)
    data = data{1};
end
end

function outputSize = iSetDimension(inputSize,dimension,value)
outputSize = inputSize;
numOutputDims = max( numel(inputSize), dimension );
outputSize(end+1:numOutputDims) = 1;
outputSize(dimension) = value;
end

function constraint = iIsOfSameTypeAs(value)
constraint = nnet.checklayer.constraints.IsOfSameTypeAs(value);
end

function constraint = iIsOfSameSizeAs(value)
constraint = nnet.checklayer.constraints.IsOfSameSizeAs(value);
end