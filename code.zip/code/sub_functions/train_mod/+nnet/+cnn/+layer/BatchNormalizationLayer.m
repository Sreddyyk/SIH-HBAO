classdef BatchNormalizationLayer < nnet.cnn.layer.Layer & nnet.internal.cnn.layer.Externalizable
    % BatchNormalizationLayer  Batch Normalization layer
    %
    % To create a batch normalization layer, use batchNormalizationLayer.
    %
    % A layer which normalizes each channel across a mini-batch. This can
    % be useful in reducing sensitivity to model hyperparameters and
    % improving training time.
    %
    % BatchNormalizationLayer properties:
    %     Name                      - A name for the layer.
    %     NumChannels               - The number of channels in the layer
    %                                 input.
    %     Epsilon                   - Offset for the divisor to prevent 
    %                                 divide-by-zero errors. Must be at 
    %                                 least 1e-5.
    %     NumInputs                 - The number of inputs for the layer.
    %     InputNames                - The names of the inputs of the layer.
    %     NumOutputs                - The number of outputs of the layer.
    %     OutputNames               - The names of the outputs of the layer.
    %
    % Properties for learnable parameters:
    %     Offset                    - Offset per channel.
    %     OffsetInitializer         - The function to initialiaze the offset.
    %     OffsetLearnRateFactor     - Multiplier for the learning rate for 
    %                                 Offset.
    %     OffsetL2Factor            - Multiplier for the L2 weight 
    %                                 regulariser for Offset.
    %
    %     Scale                     - Scale per channel.
    %     ScaleInitializer          - The function to initialiaze the scale.
    %     ScaleLearnRateFactor      - Multiplier for the learning rate for 
    %                                 Scale.
    %     ScaleL2Factor             - Multiplier for the L2 weight 
    %                                 regulariser for Scale.
    %
    % Properties determined during training:
    %     TrainedMean               - Per-channel mean of the layer input 
    %                                 data.
    %     TrainedVariance           - Per-channel variance of the layer input 
    %                                 data.
    %
    % Example:
    %     Create a batch normalization layer.
    %
    %     layer = batchNormalizationLayer()
    %
    % See also batchNormalizationLayer
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    properties(Dependent)
        % Name   A name for the layer
        %   The name for the layer. If this is set to '', then a name will
        %   be automatically set at training time.
        Name
        
        % TrainedMean  Per-channel mean of the layer input data, determined
        % during training or specified by the user.
        TrainedMean
        % TrainedVariance  Per-channel variance of the layer input data,
        % determined during training or specified by the user.
        TrainedVariance
    end
    
    properties(SetAccess = private, Dependent)
        % NumChannels   The number of channels in the input. This can be
        % set to 'auto', in which case the correct value will be determined
        % at training time.
        NumChannels
    end
    
    properties(Dependent)
        %Epsilon  Offset for the divisor to prevent divide-by-zero errors
        Epsilon
        
        %Offset  Bias per channel
        Offset
        %OffsetInitializer    Offset initializer
        OffsetInitializer
        %OffsetLearnRateFactor  Multiplier for the learning rate for Offset
        OffsetLearnRateFactor
        %OffsetL2Factor  Multiplier for the L2 weight regulariser for Offset
        OffsetL2Factor
        
        %Scale  Scale per channel
        Scale
        %ScaleInitializer    Scale initializer
        ScaleInitializer
        %ScaleLearnRateFactor  Multiplier for the learning rate for Scale
        ScaleLearnRateFactor
        %ScaleL2Factor  Multiplier for the L2 weight regulariser for Scale
        ScaleL2Factor
    end
    
    methods
        function this = BatchNormalizationLayer(privateLayer)
            this.PrivateLayer = privateLayer;
        end
        
        function val = get.Name(this)
            val = this.PrivateLayer.Name;
        end
        
        function this = set.Name(this, val)
            iAssertValidLayerName(val);
            this.PrivateLayer.Name = char(val);
        end
        
        function val = get.NumChannels(this)
            val = this.PrivateLayer.NumChannels;
            if isempty(val)
                val = 'auto';
            end
        end
        
        function val = get.TrainedMean(this)
            val = this.PrivateLayer.TrainedMean;
        end
        function this = set.TrainedMean(this, val)
            expectedNumChannels = iExpectedNumChannels(this.NumChannels);
            validSize = iInferValidSizeFromData(val, ...
                this.PrivateLayer.ChannelDim, expectedNumChannels);            
            val = iGatherAndValidateParameter(val, 'default', validSize);
            
            if ~isempty(val)
                this = this.inferSizeFromData(val);
            end
            % Store as single on the host
            this.PrivateLayer.TrainedMean = single(val);
        end
        
        function val = get.TrainedVariance(this)
            val = this.PrivateLayer.TrainedVariance;
        end
        function this = set.TrainedVariance(this, val)
            expectedNumChannels = iExpectedNumChannels(this.NumChannels);
            validSize = iInferValidSizeFromData(val, ...
                this.PrivateLayer.ChannelDim, expectedNumChannels);            
            val = iGatherAndValidateParameter(val, ...
                {'size', validSize, 'positive'});
            
            if ~isempty(val)
                this = this.inferSizeFromData(val);
            end
            % Store as single on the host
            this.PrivateLayer.TrainedVariance = single(val);
        end
        
        function val = get.Epsilon(this)
            val = this.PrivateLayer.Epsilon;
        end
        function this = set.Epsilon(this, val)
            minEpsilon = 1e-5; % Defined by cuDNN            
            val = gather(val);
            this.PrivateLayer.Epsilon = iValidateAndConvertEpsilon(val, minEpsilon);
        end
        
        function val = get.Offset(this)
            val = this.PrivateLayer.Offset.Value;
            if isa(val, 'dlarray')
                val = extractdata(val);
            end
        end
        function this = set.Offset(this, val)
            expectedNumChannels = iExpectedNumChannels(this.NumChannels);
            validSize = iInferValidSizeFromData(val, ...
                this.PrivateLayer.ChannelDim, expectedNumChannels);            
            val = iGatherAndValidateParameter(val, 'default', validSize);
            
            if ~isempty(val)
                this = this.inferSizeFromData(val);
            end
            this.PrivateLayer.Offset.Value = val;
        end
        
        function val = get.OffsetInitializer(this)
            if iIsCustomInitializer(this.PrivateLayer.Offset.Initializer)
                val = this.PrivateLayer.Offset.Initializer.Fcn;
            else
                val = this.PrivateLayer.Offset.Initializer.Name;
            end
        end
        
        function this = set.OffsetInitializer(this, value)
            value = iAssertValidOffsetInitializer(value);
            % Offset initializers do not require to pass arguments
            this.PrivateLayer.Offset.Initializer = iInitializerFactory(value);
        end
        
        function val = get.OffsetLearnRateFactor(this)
            val = this.PrivateLayer.Offset.LearnRateFactor;
        end
        function this = set.OffsetLearnRateFactor(this, val)
            val = gather(val);
            iAssertValidFactor(val,'OffsetLearnRateFactor');
            this.PrivateLayer.Offset.LearnRateFactor = val;
        end
        
        function val = get.OffsetL2Factor(this)
            val = this.PrivateLayer.Offset.L2Factor;
        end
        function this = set.OffsetL2Factor(this, val)
            val = gather(val);
            iAssertValidFactor(val,'OffsetL2RateFactor');
            this.PrivateLayer.Offset.L2Factor = val;
        end
        
        function val = get.Scale(this)
            val = this.PrivateLayer.Scale.Value;
            if isa(val, 'dlarray')
                val = extractdata(val);
            end
        end
        function this = set.Scale(this, val)
            expectedNumChannels = iExpectedNumChannels(this.NumChannels);
            validSize = iInferValidSizeFromData(val, ...
                this.PrivateLayer.ChannelDim, expectedNumChannels);            
            val = iGatherAndValidateParameter(val, 'default', validSize);
            
            if ~isempty(val)
                this = this.inferSizeFromData(val);
            end
            this.PrivateLayer.Scale.Value = val;
        end
        
        function val = get.ScaleInitializer(this)
            if iIsCustomInitializer(this.PrivateLayer.Scale.Initializer)
                val = this.PrivateLayer.Scale.Initializer.Fcn;
            else
                val = this.PrivateLayer.Scale.Initializer.Name;
            end
        end
        
        function this = set.ScaleInitializer(this, value)
            value = iAssertValidScaleInitializer(value);
            % Scale initializers do not require to pass arguments
            this.PrivateLayer.Scale.Initializer = iInitializerFactory(value);
        end
        
        function val = get.ScaleLearnRateFactor(this)
            val = this.PrivateLayer.Scale.LearnRateFactor;
        end
        function this = set.ScaleLearnRateFactor(this, val)
            val = gather(val);
            iAssertValidFactor(val,'ScaleLearnRateFactor');
            this.PrivateLayer.Scale.LearnRateFactor = val;
        end
        
        function val = get.ScaleL2Factor(this)
            val = this.PrivateLayer.Scale.L2Factor;
        end
        function this = set.ScaleL2Factor(this, val)
            val = gather(val);
            iAssertValidFactor(val,'ScaleL2RateFactor');
            this.PrivateLayer.Scale.L2Factor = val;
        end
        
        function out = saveobj(this)
            privateLayer = this.PrivateLayer;
            out.Version = 2.0;
            out.Name = privateLayer.Name;
            out.Epsilon = privateLayer.Epsilon;
            out.NumChannels = privateLayer.NumChannels;
            out.ChannelDim = privateLayer.ChannelDim;
            out.TrainedMean = privateLayer.TrainedMean;
            out.TrainedVariance = privateLayer.TrainedVariance;
            out.NumTrainingSamples = privateLayer.NumTrainingSamples;
            out.Offset = toStruct(privateLayer.Offset);
            out.Scale = toStruct(privateLayer.Scale);
        end
        
    end
    
    methods(Static)
        function this = loadobj(in)            
            if in.Version <= 1
                in = iUpgradeVersionOneToVersionTwo(in);
            end
            this = iLoadBatchNormalizationLayerFromCurrentVersion(in);
        end
    end
    
    methods(Hidden, Access = protected)
        function [description, type] = getOneLineDisplay(obj)
            if ~isempty(obj.PrivateLayer.NumChannels)
                description = iGetMessageString( ...
                    'nnet_cnn:layer:BatchNormalizationLayer:oneLineDisplay', ...
                    num2str(obj.NumChannels));
            else
                description = iGetMessageString( ...
                    'nnet_cnn:layer:BatchNormalizationLayer:oneLineDisplayNoChannels' );
            end
            
            type = iGetMessageString( 'nnet_cnn:layer:BatchNormalizationLayer:Type' );
        end
        
        function groups = getPropertyGroups( this )
            groups = [
                this.propertyGroupGeneral( {'Name', 'NumChannels', 'TrainedMean', 'TrainedVariance'} )
                this.propertyGroupHyperparameters( {'Epsilon'} )
                this.propertyGroupLearnableParameters( {'Offset', 'Scale'} )
                ];
        end
        
        function footer = getFooter( this )
            variableName = inputname(1);
            footer = this.createShowAllPropertiesFooter( variableName );
        end
        
    end
    
    methods(Access = private)
        function this = inferSizeFromData(this, val)
            channelDim = ndims(val);
            inputChannels = size(val,channelDim);
            inputSize = [NaN(1,channelDim-1) inputChannels];
            if ~isscalar(val)
                % Call inferSize() to determine the size of the layer. Sets
                % both number of channels and channel dimension.
                this.PrivateLayer = this.PrivateLayer.inferSize( inputSize );
            else
                % Call inferNumChannels() to set number of channels and
                % leave channel dimension unset until inferSize() gets
                % called. Channel dimension cannot be inferred from val
                % when it is scalar because it is of ambiguous size (1x1x1
                % or 1x1x1x1).
                this.PrivateLayer = this.PrivateLayer.inferNumChannels( inputSize );
            end
        end
    end
end

function messageString = iGetMessageString( varargin )
messageString = getString( message( varargin{:} ) );
end

function expectedNumChannels = iExpectedNumChannels(NumChannels)
expectedNumChannels = NumChannels;
if isequal(expectedNumChannels, 'auto')
    expectedNumChannels = NaN;
end
end

function epsilon = iValidateAndConvertEpsilon(value, minValue)
try 
    epsilon = nnet.internal.cnn.layer.paramvalidation...
        .validateAndConvertEpsilon(value, minValue);
catch e
    throwAsCaller(e);
end
end

function iAssertValidFactor(value,factorName)
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateLearnFactor(value,factorName));
end

function iAssertValidLayerName(name)
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateLayerName(name));
end

function value = iAssertValidOffsetInitializer(value)
validateattributes(value, {'function_handle','char','string'}, {});
if(ischar(value) || isstring(value))
    value = validatestring(value, {'narrow-normal', 'zeros', 'ones'});
end
end

function value = iAssertValidScaleInitializer(value)
validateattributes(value, {'function_handle','char','string'}, {});
if(ischar(value) || isstring(value))
    value = validatestring(value, {'narrow-normal', 'ones'});
end
end

function initializer = iInitializerFactory(varargin)
initializer = nnet.internal.cnn.layer.learnable.initializer...
    .initializerFactory(varargin{:});
end

function tf = iIsCustomInitializer(init)
tf = isa(init, 'nnet.internal.cnn.layer.learnable.initializer.Custom');
end

function S = iUpgradeVersionOneToVersionTwo(S)
% iUpgradeVersionOneToVersionTwo   Upgrade a v1 saved struct to a v2 saved
% struct. This means adding a "ChannelDim" property and offset and scale
% initializers.

S.Version = 2;

% In releases prior to 19a, only 4-D data was supported.
S.ChannelDim = 3;

% Add offset and scale initializers set to 'zeros', 'ones'.
S.Offset = iAddBasicInitializerToLearnable(S.Offset, "Zeros");
S.Scale = iAddBasicInitializerToLearnable(S.Scale, "Ones");

end

function s = iAddBasicInitializerToLearnable(s, name)
s.Initializer = struct('Class', ...
    "nnet.internal.cnn.layer.learnable.initializer."+name, ...
    'ConstructorArguments', []);
end

function iEvalAndThrow(func)
% Omit the stack containing internal functions by throwing as caller
try
    func();
catch exception
    throwAsCaller(exception)
end
end

function validSize = iInferValidSizeFromData(val, channelDim, expectedNumChannels)

if ~isscalar(val) && isempty(channelDim)
    channelDim = ndims(val);
end

if ~isempty(channelDim)
    validSize = [ones(1,channelDim-1) expectedNumChannels];
else
    validSize = [1 1];
end

end

%--------------------------------------------------------------------------
function layer = iLoadBatchNormalizationLayerFromCurrentVersion(in)

internalLayer = nnet.internal.cnn.layer.BatchNormalization(in.Name, in.NumChannels, in.Epsilon);
internalLayer.ChannelDim = in.ChannelDim;
internalLayer.Offset = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.fromStruct(in.Offset);
internalLayer.Scale = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.fromStruct(in.Scale);
internalLayer.TrainedMean = in.TrainedMean;
internalLayer.TrainedVariance = in.TrainedVariance;
internalLayer.NumTrainingSamples = in.NumTrainingSamples;
layer = nnet.cnn.layer.BatchNormalizationLayer(internalLayer);

end

function value = iGatherAndValidateParameter(varargin)
try
    value = nnet.internal.cnn.layer.paramvalidation...
        .gatherAndValidateNumericParameter(varargin{:});
catch exception
    throwAsCaller(exception)
end
end
