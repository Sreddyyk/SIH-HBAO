classdef GlobalAveragePooling2DLayer < nnet.cnn.layer.Layer & ...
        nnet.internal.cnn.layer.Externalizable
    % GlobalAveragePooling2DLayer   Global average pooling layer
    %
    %   The global average pooling layer computes the mean over the height
    %   and width dimension of the input.
    %
    %   GlobalAveragePooling2DLayer properties:
    %       Name                   - A name for the layer.
    %       NumInputs              - The number of inputs of the layer.
    %       InputNames             - The names of the inputs of the layer.
    %       NumOutputs             - The number of outputs of the layer.
    %       OutputNames            - The names of the outputs of the layer.
    %
    %   Example:
    %       Create a global average pooling 2d layer.
    %
    %       layer = globalAveragePooling2dLayer;
    %
    %   See also globalAveragePooling2DLayer, averagePooling2dLayer,
    %   maxPooling2dLayer, globalAveragePooling3DLayer.
    %
    %   <a href="matlab:helpview('deeplearning','list_of_layers')">List of Deep Learning Layers</a>
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(Dependent)
        % Name   A name for the layer
        %   The name for the layer. If this is set to '', then a name will
        %   be automatically set at training time.
        Name
    end    
    
    methods
        function layer = GlobalAveragePooling2DLayer(privateLayer)
            layer.PrivateLayer = privateLayer;
        end
        
        function this = set.Name(this, val)
            iAssertValidLayerName(val);
            this.PrivateLayer.Name = char(val);
        end
        
        function val = get.Name(this)
            val = this.PrivateLayer.Name;
        end
    end
       
    methods
        function out = saveobj(this)
            out.Version = 1.0;
            out.Name = this.Name;
        end
    end 
    
    methods(Hidden, Static)
        function this = loadobj(in)
            this = nnet.cnn.layer.GlobalAveragePooling2DLayer(...
                nnet.internal.cnn.layer.GlobalAveragePooling2D(in.Name));
        end
    end
    
    methods(Hidden, Access = protected)
        function [description, type] = getOneLineDisplay(~)
            description = iMessage("oneLineDisplay");
            type = iMessage("Type");            
        end
        
        function groups = getPropertyGroups( this )
           groups = this.propertyGroupGeneral( {'Name'} );
        end
    end
end

function msg = iMessage(entryName)
msg = getString(message("nnet_cnn:layer:GlobalAveragePooling2DLayer:"+...
    entryName));
end

function iAssertValidLayerName(name)
% Omit the stack containing internal functions by throwing as caller
try
    nnet.internal.cnn.layer.paramvalidation.validateLayerName(name);
catch exception
    throwAsCaller(exception)
end
end