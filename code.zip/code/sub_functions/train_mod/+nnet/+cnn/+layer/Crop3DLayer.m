classdef Crop3DLayer < nnet.cnn.layer.Layer & nnet.internal.cnn.layer.Externalizable
    % Crop3DLayer 3D crop layer
    %
    %   A 3D cropping layer. This layer crops an input feature map along
    %   the first three dimensions. To create a 3D crop layer, use
    %   crop3dLayer.
    %
    %   Crop3DLayer properties:
    %       Name         - A name for the layer.
    %       CropLocation - Location of the cropping window.
    %       NumInputs    - The number of inputs of the layer.
    %       InputNames   - The names of the inputs of the layer.
    %       NumOutputs   - The number of outputs of the layer.
    %       OutputNames  - The names of the outputs of the layer.
    %
    % Example:
    %    Create a 3D crop layer and connect both of its inputs using a
    %    layerGraph object.
    %
    %    layers = [
    %        image3dInputLayer([32 32 32 3], 'Name', 'image')
    %        crop3dLayer('centercrop', 'Name', 'crop')
    %        ]
    %
    %    % Create a layerGraph. The first input of crop3dLayer is automatically
    %    % connected to the first output of the image input layer.
    %    lgraph = layerGraph(layers)
    %
    %    % Connect the image layer output as a reference for crop Layer.
    %    lgraph = connectLayers(lgraph, 'image', 'crop/ref')
    %
    %   See also crop3dLayer.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    properties(Dependent)
        % Name   A name for the layer
        %   The name for the layer. If this is set to '', then a name will
        %   be automatically set at training time.
        Name        
    end
    
    properties(SetAccess = private, Dependent)
        
        % CropLocation The location of the cropping window
        %   The CropLocation is either 'centercrop' or [X Y Z] vector that
        %   defines the upper-left-front corner of the cropping window.
        %   When 'centercrop', the cropping window is automatically
        %   positioned in the center of the input feature map. 
        %   When CropLocation is an [X Y Z] vector, X is the location in the
        %   horizontal direction, Y is the location in the vertical
        %   direction and Z is the location in the planar direction. 
        CropLocation
    end
    
    methods(Hidden, Static)
        function this = loadobj(in)
            internalLayer = nnet.internal.cnn.layer.Crop3D(...
                in.Name, in.CropLocation);
            
            this = nnet.cnn.layer.Crop3DLayer(internalLayer);
        end
    end
    
    methods
        function this = Crop3DLayer(internalLayer)
            this.PrivateLayer = internalLayer;
        end
        
        function out = saveobj(this)
            privateLayer = this.PrivateLayer;
            out.Version  = 1.0;
            out.Name     = privateLayer.Name;
            out.CropLocation = privateLayer.CropLocation;
        end
        
        function val = get.Name(this)
            val = this.PrivateLayer.Name;
        end
        
        function this = set.Name(this, val)
            iEvalAndThrow(@()...
            nnet.internal.cnn.layer.paramvalidation.validateLayerName(val));
            this.PrivateLayer.Name = char(val);
        end
        
        function v = get.CropLocation(this)
            v = this.PrivateLayer.CropLocation;
        end
        
    end
    
    methods(Hidden, Access = protected)
        function [description, type] = getOneLineDisplay(this)
            
            if strcmp(this.CropLocation, 'centercrop')
                description = getString(message(...
                    'nnet_cnn:layer:Crop3DLayer:crop3dCenterCropDescription'));
            else
                description = getString(message(...
                    'nnet_cnn:layer:Crop3DLayer:crop3dDescription', mat2str(this.CropLocation)));
            end
            
            type = getString(message('nnet_cnn:layer:Crop3DLayer:crop3dType'));
        end
        
        function groups = getPropertyGroups( this )
            groups = this.propertyGroupGeneral( {'Name','CropLocation','NumInputs','InputNames'} );
        end
    end
    
end

function iEvalAndThrow(func)
% Omit the stack containing internal functions by throwing as caller
try
    func();
catch exception
    throwAsCaller(exception)
end
end