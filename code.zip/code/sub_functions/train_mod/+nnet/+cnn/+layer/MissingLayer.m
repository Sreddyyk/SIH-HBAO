classdef MissingLayer < nnet.layer.Layer
    % MissingLayer   The default object for a deep learning layer.
    %
    %   A MissingLayer can be an indication of an issue that occurred
    %   when loading a layer array, layer graph, SeriesNetwork, or
    %   DAGNetwork from MAT-file. The class files of all necessary layers
    %   need to be on the MATLAB path before loading a MAT-file.
    %
    %   MissingLayer properties:
    %       Name                   - A name for the missing layer.
    %       NumInputs              - The number of inputs of the layer.
    %       InputNames             - The names of the inputs of the layer.
    %       NumOutputs             - The number of outputs of the layer.
    %       OutputNames            - The names of the outputs of the layer.
    
    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function this = MissingLayer(name,inputNames,outputNames)
            this.Name = name;
            this.Description = iGetMessageString('nnet_cnn:layer:MissingLayer:oneLineDisplay');
            this.Type = iGetMessageString('nnet_cnn:layer:MissingLayer:Type');
            if nargin > 1
                this.InputNames = inputNames;
                this.OutputNames = outputNames;
            end
        end
        
        function varargout = predict( ~, varargin ) %#ok<STOUT>
            throwAsCaller(MException(message('nnet_cnn:layer:MissingLayer:CannotUseLayer')));
        end
        
        function varargout = forward( ~, varargin ) %#ok<STOUT>
            throwAsCaller(MException(message('nnet_cnn:layer:MissingLayer:CannotUseLayer')));
        end
        
        function varargout = backward( ~, varargin ) %#ok<STOUT>
            throwAsCaller(MException(message('nnet_cnn:layer:MissingLayer:CannotUseLayer')));
        end
    end
end

function messageString = iGetMessageString( varargin )
messageString = getString( message( varargin{:} ) );
end
