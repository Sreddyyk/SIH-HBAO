classdef LSTMLayer < nnet.cnn.layer.Layer & nnet.internal.cnn.layer.Externalizable
    % LSTMLayer  Long Short-Term Memory (LSTM) layer
    %
    % To create an LSTM layer, use lstmLayer.
    %
    % LSTMLayer properties:
    %     Name                                - Name of the layer
    %     InputSize                           - Input size of the layer
    %     NumHiddenUnits                      - Number of hidden units in the layer
    %     OutputMode                          - Output as sequence or last
    %     StateActivationFunction             - Activation function to
    %                                           update the cell and hidden
    %                                           state
    %     GateActivationFunction              - Activation function to
    %                                           apply to the gates
    %     NumInputs                           - The number of inputs for
    %                                           the layer.
    %     InputNames                          - The names of the inputs of  
    %                                           the layer.
    %     NumOutputs                          - The number of outputs of  
    %                                           the layer.
    %     OutputNames                         - The names of the outputs of  
    %                                           the layer.
    %
    % Properties for learnable parameters:
    %     InputWeights                        - Input weights
    %     InputWeightsInitializer             - The function for
    %                                           initializing the input 
    %                                           weights.    
    %     InputWeightsLearnRateFactor         - Learning rate multiplier
    %                                           for the input weights
    %     InputWeightsL2Factor                - L2 multiplier for the
    %                                           input weights
    %
    %     RecurrentWeights                    - Recurrent weights
    %     RecurrentWeightsInitializer         - The function for
    %                                           initializing the recurrent
    %                                           weights.    
    %     RecurrentWeightsLearnRateFactor     - Learning rate multiplier
    %                                           for the recurrent weights
    %     RecurrentWeightsL2Factor            - L2 multiplier for the
    %                                           recurrent weights
    %
    %     Bias                                - Bias vector
    %     BiasInitializer                     - The function for
    %                                           initializing the bias.
    %     BiasLearnRateFactor                 - Learning rate multiplier
    %                                           for the bias
    %     BiasL2Factor                        - L2 multiplier for the bias
    %                                       
    % State parameters:
    %     HiddenState                         - Hidden state vector
    %     CellState                           - Cell state vector
    %
    %   Example:
    %       Create a Long Short-Term Memory layer.
    %
    %       layer = lstmLayer(10)
    %
    %   See also lstmLayer
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    properties(Dependent)
        % Name   A name for the layer
        %   The name for the layer. If this is set to '', then a name will
        %   be automatically set at training time.
        Name         
    end
    
    properties(SetAccess = private, Dependent)
        % InputSize   The input size for the layer. If this is set to
        % 'auto', then the input size will be automatically set during
        % training
        InputSize
        
        % NumHiddenUnits   The number of hidden units in the layer
        NumHiddenUnits
        
        % OutputMode   The output format of the layer. If 'sequence',
        % output is a sequence. If 'last', the output is the last element
        % in a sequence
        OutputMode
        
        % StateActivationFunction   The activation function to update the
        % cell and hidden state. Valid options are 'tanh' or 'softsign'.
        % The default is 'tanh'.
        StateActivationFunction
        
        % GateActivationFunction   The activation function to apply to the
        % gates. Valid options are 'sigmoid' or 'hard-sigmoid'. The default
        % is 'sigmoid'.
        GateActivationFunction
    end
    
    properties(Dependent)
        % InputWeights   The input weights for the layer
        %   The input weight matrix for the LSTM layer. The input weight
        %   matrix is a vertical concatenation of the four "gate" input
        %   weight matrices in the forward pass of an LSTM. Those
        %   individual matrices are concatenated in the following order:
        %   input gate, forget gate, layer input, output gate. This matrix
        %   will have size 4*NumHiddenUnits-by-InputSize.
        InputWeights
        
        % InputWeightsInitializer    The function for initializing the
        % input weights.
        InputWeightsInitializer
        
        % InputWeightsLearnRateFactor   The learning rate factor for the
        % input weights
        %   The learning rate factor for the input weights. This factor is
        %   multiplied with the global learning rate to determine the
        %   learning rate for the input weights in this layer. For example,
        %   if it is set to 2, then the learning rate for the input weights
        %   in this layer will be twice the current global learning rate.
        %   To control the value of the learn rate for the four individual
        %   matrices in the InputWeights, a 1-by-4 vector can be assigned.
        InputWeightsLearnRateFactor (1,:) {mustBeNumeric, iCheckFactorDimensions}
        
        % InputWeightsL2Factor   The L2 regularization factor for the input
        % weights
        %   The L2 regularization factor for the input weights. This factor
        %   is multiplied with the global L2 regularization setting to
        %   determine the L2 regularization setting for the input weights
        %   in this layer. For example, if it is set to 2, then the L2
        %   regularization for the input weights in this layer will be
        %   twice the global L2 regularization setting. To control the
        %   value of the L2 factor for the four individual matrices in the
        %   InputWeights, a 1-by-4 vector can be assigned.
        InputWeightsL2Factor (1,:) {mustBeNumeric, iCheckFactorDimensions}
        
        % RecurrentWeights   The recurrent weights for the layer
        %   The recurrent weight matrix for the LSTM layer. The recurrent
        %   weight matrix is a vertical concatenation of the four "gate"
        %   recurrent weight matrices in the forward pass of an LSTM. Those
        %   individual matrices are concatenated in the following order:
        %   input gate, forget gate, layer input, output gate. This matrix
        %   will have size 4*NumHiddenUnits-by-NumHiddenUnits.
        RecurrentWeights
        
        % RecurrentWeightsInitializer    The function for initializing the
        % recurrent weights.
        RecurrentWeightsInitializer

        % RecurrentWeightsLearnRateFactor   The learning rate factor for
        % the recurrent weights
        %   The learning rate factor for the recurrent weights. This factor
        %   is multiplied with the global learning rate to determine the
        %   learning rate for the recurrent weights in this layer. For
        %   example, if it is set to 2, then the learning rate for the
        %   recurrent weights in this layer will be twice the current
        %   global learning rate. To control the value of the learn rate
        %   for the four individual matrices in the RecurrentWeights, a
        %   1-by-4 vector can be assigned.
        RecurrentWeightsLearnRateFactor (1,:) {mustBeNumeric, iCheckFactorDimensions}
        
        % RecurrentWeightsL2Factor   The L2 regularization factor for the
        % recurrent weights
        %   The L2 regularization factor for the recurrent weights. This
        %   factor is multiplied with the global L2 regularization setting
        %   to determine the L2 regularization setting for the recurrent
        %   weights in this layer. For example, if it is set to 2, then the
        %   L2 regularization for the recurrent weights in this layer will
        %   be twice the global L2 regularization setting. To control the
        %   value of the L2 factor for the four individual matrices in the
        %   RecurrentWeights, a 1-by-4 vector can be assigned.
        RecurrentWeightsL2Factor (1,:) {mustBeNumeric, iCheckFactorDimensions}
        
        % Bias   The biases for the layer
        %   The bias vector for the LSTM layer. The bias vector is a
        %   concatenation of the four "gate" bias vectors in the forward
        %   pass of an LSTM. Those individual vectors are concatenated in
        %   the following order: input gate, forget gate, layer input,
        %   output gate. This vector will have size 4*NumHiddenUnits-by-1.
        Bias
        
        % BiasInitializer    The function for initializing the bias 
        BiasInitializer
        
        % BiasLearnRateFactor   The learning rate factor for the biases
        %   The learning rate factor for the bias. This factor is
        %   multiplied with the global learning rate to determine the
        %   learning rate for the bias in this layer. For example, if it is
        %   set to 2, then the learning rate for the bias in this layer
        %   will be twice the current global learning rate. To control the
        %   value of the learn rate for the four individual vectors in the
        %   Bias, a 1-by-4 vector can be assigned.
        BiasLearnRateFactor (1,:) {mustBeNumeric, iCheckFactorDimensions}
        
        % BiasL2Factor   The L2 regularization factor for the biases
        %   The L2 regularization factor for the biases. This factor is
        %   multiplied with the global L2 regularization setting to
        %   determine the L2 regularization setting for the biases in this
        %   layer. For example, if it is set to 2, then the L2
        %   regularization for the biases in this layer will be twice the
        %   global L2 regularization setting. To control the value of the
        %   L2 factor for the four individual vectors in the Bias, a
        %   1-by-4 vector can be assigned.
        BiasL2Factor (1,:) {mustBeNumeric, iCheckFactorDimensions}
    end
    
    properties(Dependent)
        % HiddenState    The initial value of the hidden state.
        %   The initial value of the hidden state. This vector will have
        %   size NumHiddenUnits-by-1. Setting this value sets the default
        %   value to which the hidden state is reset to when calling the
        %   resetState method of SeriesNetwork.
        HiddenState
        
        % CellState   The initial value of the cell state
        %   The initial value of the cell state. This vector will have size
        %   NumHiddenUnits-by-1. Setting this value sets the default value
        %   to which the cell state is reset to when calling the resetState
        %   method of SeriesNetwork.
        CellState
    end
    
    properties(SetAccess = private, Hidden, Dependent)
        % OutputSize   The number of hidden units in the layer. See
        % NumHiddenUnits.
        OutputSize
        
        % OutputState   The hidden state of the layer. See HiddenState.
        OutputState
    end
    
    methods
        function this = LSTMLayer(privateLayer)
            this.PrivateLayer = privateLayer;
        end
        
        function val = get.Name(this)
            val = this.PrivateLayer.Name;
        end
        
        function this = set.Name(this, val)
            iAssertValidLayerName(val);
            this.PrivateLayer.Name = char(val);
        end
        
        function val = get.InputSize(this)
            val = this.PrivateLayer.InputSize;
            if isempty(val)
                val = 'auto';
            end
        end
        
        function val = get.NumHiddenUnits(this)
            val = this.PrivateLayer.HiddenSize;
        end
        
        function val = get.OutputMode(this)
            val = iGetOutputMode( this.PrivateLayer.ReturnSequence );
        end
        
        function val = get.StateActivationFunction(this)
            val = this.PrivateLayer.Activation;
        end
        
        function val = get.GateActivationFunction(this)
            val = this.PrivateLayer.RecurrentActivation;
        end
        
        function val = get.InputWeights(this)
            val = this.PrivateLayer.InputWeights.HostValue;
            if isa(val, 'dlarray')
                val = extractdata(val);
            end            
        end
        
        function this = set.InputWeights(this, value)
            if isequal(this.InputSize, 'auto')
                expectedInputSize = NaN;
            else
                expectedInputSize = this.InputSize;
            end
            attributes = {'size', [4*this.NumHiddenUnits expectedInputSize],...
                'real', 'nonsparse'};
            value = iGatherAndValidateParameter(value, attributes);
            
            if ~isempty(value)
                this.PrivateLayer = this.PrivateLayer.inferSize( size(value, 2) );
            end
            this.PrivateLayer.InputWeights.Value = value;
        end
        
        function val = get.InputWeightsInitializer(this)
            if iIsCustomInitializer(this.PrivateLayer.InputWeights.Initializer)
                val = this.PrivateLayer.InputWeights.Initializer.Fcn;
            else
                val = this.PrivateLayer.InputWeights.Initializer.Name;
            end
        end
        
        function this = set.InputWeightsInitializer(this, value)
            value = iAssertValidWeightsInitializer(value, 'InputWeightsInitializer');        
            % Create the initializer with in and out indices of the weights
            % size: 4*NumHiddenUnits-by-InputSize
            this.PrivateLayer.InputWeights.Initializer = ...
                iInitializerFactory(value, 2, 1);
        end
        
        function val = get.RecurrentWeights(this)
            val = this.PrivateLayer.RecurrentWeights.HostValue;
            if isa(val, 'dlarray')
                val = extractdata(val);
            end            
        end
        
        function this = set.RecurrentWeights(this, value)
            attributes = {'size', [4*this.NumHiddenUnits this.NumHiddenUnits],...
                'real', 'nonsparse'};
            value = iGatherAndValidateParameter(value, attributes);
            this.PrivateLayer.RecurrentWeights.Value = value;
        end
        
        function val = get.RecurrentWeightsInitializer(this)
            if iIsCustomInitializer(this.PrivateLayer.RecurrentWeights.Initializer)
                val = this.PrivateLayer.RecurrentWeights.Initializer.Fcn;
            else
                val = this.PrivateLayer.RecurrentWeights.Initializer.Name;
            end
        end
        
        function this = set.RecurrentWeightsInitializer(this, value)
            value = iAssertValidWeightsInitializer(value, 'RecurrentWeightsInitializer');        
            % Create the initializer with in and out indices of the weights
            % size: 4*NumHiddenUnits-by-NumHiddenUnits
            this.PrivateLayer.RecurrentWeights.Initializer = ...
                iInitializerFactory(value, 2, 1);
        end
        
        function val = get.Bias(this)
            val = this.PrivateLayer.Bias.HostValue;
            if isa(val, 'dlarray')
                val = extractdata(val);
            end            
        end
        
        function this = set.Bias(this, value)
            attributes = {'column', 'real', 'nonsparse', 'nrows', ...
                4*this.NumHiddenUnits};
            value = iGatherAndValidateParameter(value, attributes);
            this.PrivateLayer.Bias.Value = value;
        end
        
        function val = get.BiasInitializer(this)
            if iIsCustomInitializer(this.PrivateLayer.Bias.Initializer)
                val = this.PrivateLayer.Bias.Initializer.Fcn;
            else
                val = this.PrivateLayer.Bias.Initializer.Name;
            end
        end
        
        function this = set.BiasInitializer(this, value)
            value = iAssertValidBiasInitializer(value);
            % The Bias initializer needs to know which recurrent type
            this.PrivateLayer.Bias.Initializer = iInitializerFactory(value,...
                'LSTM');
        end
        
        function val = get.CellState(this)
            val = gather(this.PrivateLayer.CellState.Value);
        end

        function this = set.CellState(this, value)
            value = iGatherAndValidateParameter(value, 'default', [this.NumHiddenUnits 1]);
            
            this.PrivateLayer.InitialCellState = value;
            this.PrivateLayer.CellState.Value = value;
        end
        
        function val = get.HiddenState(this)
            val = gather(this.PrivateLayer.HiddenState.Value);
        end

        function this = set.HiddenState(this, value)
            value = iGatherAndValidateParameter(value, 'default', [this.NumHiddenUnits 1]);
            
            this.PrivateLayer.InitialHiddenState = value;
            this.PrivateLayer.HiddenState.Value = value;
        end
          
        function val = get.InputWeightsLearnRateFactor(this)
            val = this.getFactor(this.PrivateLayer.InputWeights.LearnRateFactor);
        end
        function this = set.InputWeightsLearnRateFactor(this, val)
            val = gather(val);
            iAssertValidFactor(val)
            this.PrivateLayer.InputWeights.LearnRateFactor = this.setFactor(val);
        end
        
        function val = get.InputWeightsL2Factor(this)
            val = this.getFactor(this.PrivateLayer.InputWeights.L2Factor);
        end
        function this = set.InputWeightsL2Factor(this, val)
            val = gather(val);
            iAssertValidFactor(val)
            this.PrivateLayer.InputWeights.L2Factor = this.setFactor(val);
        end
        
        function val = get.RecurrentWeightsLearnRateFactor(this)
            val = this.getFactor(this.PrivateLayer.RecurrentWeights.LearnRateFactor);
        end
        function this = set.RecurrentWeightsLearnRateFactor(this, val)
            val = gather(val);
            iAssertValidFactor(val)
            this.PrivateLayer.RecurrentWeights.LearnRateFactor = this.setFactor(val);
        end
        
        function val = get.RecurrentWeightsL2Factor(this)
            val = this.getFactor(this.PrivateLayer.RecurrentWeights.L2Factor);
        end
        function this = set.RecurrentWeightsL2Factor(this, val)
            val = gather(val);
            iAssertValidFactor(val)
            this.PrivateLayer.RecurrentWeights.L2Factor = this.setFactor(val);
        end
        
        function val = get.BiasLearnRateFactor(this)
            val = this.getFactor(this.PrivateLayer.Bias.LearnRateFactor);
        end
        function this = set.BiasLearnRateFactor(this, val)
            val = gather(val);
            iAssertValidFactor(val)
            this.PrivateLayer.Bias.LearnRateFactor = this.setFactor(val);
        end
        
        function val = get.BiasL2Factor(this)
            val = this.getFactor(this.PrivateLayer.Bias.L2Factor);
        end
        function this = set.BiasL2Factor(this, val)
            val = gather(val);
            iAssertValidFactor(val)
            this.PrivateLayer.Bias.L2Factor = this.setFactor(val);
        end
        
        function val = get.OutputSize(this)
            val = this.NumHiddenUnits;
        end
        
        function val = get.OutputState(this)
            val = this.HiddenState;
        end
        
        function out = saveobj(this)
            privateLayer = this.PrivateLayer;
            out.Version = 4.0;
            out.Name = privateLayer.Name;
            out.InputSize = privateLayer.InputSize;
            out.NumHiddenUnits = privateLayer.HiddenSize;
            out.ReturnSequence = privateLayer.ReturnSequence;
            out.StateActivationFunction = privateLayer.Activation;
            out.GateActivationFunction = privateLayer.RecurrentActivation;
            out.InputWeights = toStruct(privateLayer.InputWeights);
            out.RecurrentWeights = toStruct(privateLayer.RecurrentWeights);
            out.Bias = toStruct(privateLayer.Bias);
            out.CellState = toStruct(privateLayer.CellState);
            out.HiddenState = toStruct(privateLayer.HiddenState);
            out.InitialCellState = gather(privateLayer.InitialCellState);
            out.InitialHiddenState = gather(privateLayer.InitialHiddenState);
        end
    end
   
    methods(Static)
        function inputArguments = parseInputArguments(varargin)
            parser = iCreateParser();
            parser.parse(varargin{:});
            inputArguments = iConvertToCanonicalForm(parser);
            inputArguments.InputSize = [];
        end
        
        function this = loadobj(in)
            if in.Version <= 1.0
                in = iUpgradeVersionOneToVersionTwo(in);
            end
            if in.Version <= 2.0
                in = iUpgradeVersionTwoToVersionThree(in);
            end
            if in.Version <= 3.0
                in = iUpgradeVersionThreeToVersionFour(in);
            end
            internalLayer = nnet.internal.cnn.layer.LSTM( in.Name, ...
                in.InputSize, ...
                in.NumHiddenUnits, ...
                true, ...
                true, ...
                in.ReturnSequence, ...
                in.StateActivationFunction, ...
                in.GateActivationFunction );
            internalLayer.InputWeights = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.fromStruct(in.InputWeights);
            internalLayer.RecurrentWeights = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.fromStruct(in.RecurrentWeights);
            internalLayer.Bias = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.fromStruct(in.Bias);
            internalLayer.CellState = nnet.internal.cnn.layer.dynamic.TrainingDynamicParameter.fromStruct(in.CellState);
            internalLayer.HiddenState = nnet.internal.cnn.layer.dynamic.TrainingDynamicParameter.fromStruct(in.HiddenState);
            internalLayer.InitialHiddenState = in.InitialHiddenState;
            internalLayer.InitialCellState = in.InitialCellState;

            this = nnet.cnn.layer.LSTMLayer(internalLayer);
        end
    end
    
    methods(Hidden, Access = protected)
        function [description, type] = getOneLineDisplay(obj)
            description = iGetMessageString( ...
                'nnet_cnn:layer:LSTMLayer:oneLineDisplay', ...
                num2str(obj.NumHiddenUnits));
            
            type = iGetMessageString( 'nnet_cnn:layer:LSTMLayer:Type' );
        end
        
        function groups = getPropertyGroups( this )
            generalParameters = { 'Name' };
            hyperParameters = { 'InputSize', ...
                'NumHiddenUnits', ...
                'OutputMode', ...
                'StateActivationFunction', ...
                'GateActivationFunction' };
            learnableParameters = { 'InputWeights', ...
                'RecurrentWeights', ...
                'Bias' };
            stateParameters = { 'HiddenState', 'CellState' };
            groups = [
                this.propertyGroupGeneral( generalParameters )
                this.propertyGroupHyperparameters( hyperParameters )
                this.propertyGroupLearnableParameters( learnableParameters )
                this.propertyGroupDynamicParameters( stateParameters )
                ];
        end
                
        function footer = getFooter( this )
            variableName = inputname(1);
            footer = this.createShowAllPropertiesFooter( variableName );
        end
        
        function val = getFactor(this, val)
            if isscalar(val)
                % No operation needed
            elseif numel(val) == (4*this.NumHiddenUnits)
                val = val(1:this.NumHiddenUnits:end);
                val = val(:)';
            else
                % Error - the factor has incorrect size
            end
        end
        
        function val = setFactor(this, val)
            if isscalar(val)
                % No operation needed
            elseif numel(val) == 4
                % Expand a four-element vector into a 4*NumHiddenUnits-by-1
                % column vector
                expandedValues = repelem( val, this.NumHiddenUnits );
                val = expandedValues(:);
            else
                % Error - the factor has incorrect size
            end
        end
    end
end

function messageString = iGetMessageString( varargin )
messageString = getString( message( varargin{:} ) );
end

function p = iCreateParser()
p = inputParser;

defaultName = '';
defaultOutputMode = 'sequence';
defaultStateActivationFunction = 'tanh';
defaultGateActivationFunction = 'sigmoid';
defaultWeightLearnRateFactor = 1;
defaultBiasLearnRateFactor = 1;
defaultWeightL2Factor = 1;
defaultBiasL2Factor = 0;
defaultInputWeightsInitializer = 'glorot';
defaultRecurrentWeightsInitializer = 'orthogonal';
defaultBiasInitializer = 'unit-forget-gate';
defaultLearnable = [];
defaultState = [];

p.addRequired('NumHiddenUnits', @(x)validateattributes(x, {'numeric'}, {'scalar', 'positive', 'integer'}));
p.addParameter('Name', defaultName, @nnet.internal.cnn.layer.paramvalidation.validateLayerName);
p.addParameter('OutputMode', defaultOutputMode, @(x)any(iAssertAndReturnValidOutputMode(x)));
p.addParameter('StateActivationFunction', defaultStateActivationFunction, @(x)any(iAssertAndReturnValidStateActivation(x)));
p.addParameter('GateActivationFunction', defaultGateActivationFunction, @(x)any(iAssertAndReturnValidGateActivation(x)));
p.addParameter('InputWeightsLearnRateFactor', defaultWeightLearnRateFactor, @(x)iAssertValidFactor(x));
p.addParameter('RecurrentWeightsLearnRateFactor', defaultWeightLearnRateFactor,@(x)iAssertValidFactor(x));
p.addParameter('BiasLearnRateFactor', defaultBiasLearnRateFactor,@(x)iAssertValidFactor(x));
p.addParameter('InputWeightsL2Factor', defaultWeightL2Factor, @(x)iAssertValidFactor(x));
p.addParameter('RecurrentWeightsL2Factor', defaultWeightL2Factor, @(x)iAssertValidFactor(x));
p.addParameter('BiasL2Factor', defaultBiasL2Factor, @(x)iAssertValidFactor(x));
p.addParameter('InputWeightsInitializer', defaultInputWeightsInitializer);
p.addParameter('RecurrentWeightsInitializer', defaultRecurrentWeightsInitializer);
p.addParameter('BiasInitializer', defaultBiasInitializer);
p.addParameter('InputWeights', defaultLearnable);
p.addParameter('RecurrentWeights', defaultLearnable);
p.addParameter('Bias', defaultLearnable);
p.addParameter('HiddenState', defaultState);
p.addParameter('CellState', defaultState);
end

function inputArguments = iConvertToCanonicalForm(parser)
results = parser.Results;
inputArguments = struct;
inputArguments.NumHiddenUnits = double( results.NumHiddenUnits );
inputArguments.Name = convertStringsToChars(results.Name);
inputArguments.OutputMode = iAssertAndReturnValidOutputMode(results.OutputMode);
inputArguments.StateActivationFunction = iAssertAndReturnValidStateActivation(convertStringsToChars(results.StateActivationFunction));
inputArguments.GateActivationFunction = iAssertAndReturnValidGateActivation(convertStringsToChars(results.GateActivationFunction));
inputArguments.InputWeightsLearnRateFactor = results.InputWeightsLearnRateFactor;
inputArguments.RecurrentWeightsLearnRateFactor = results.RecurrentWeightsLearnRateFactor;
inputArguments.BiasLearnRateFactor = results.BiasLearnRateFactor;
inputArguments.InputWeightsL2Factor = results.InputWeightsL2Factor;
inputArguments.RecurrentWeightsL2Factor = results.RecurrentWeightsL2Factor;
inputArguments.BiasL2Factor = results.BiasL2Factor;
inputArguments.InputWeightsInitializer = results.InputWeightsInitializer;
inputArguments.RecurrentWeightsInitializer = results.RecurrentWeightsInitializer;
inputArguments.BiasInitializer = results.BiasInitializer;
inputArguments.InputWeights = results.InputWeights;
inputArguments.RecurrentWeights = results.RecurrentWeights;
inputArguments.Bias = results.Bias;
inputArguments.HiddenState = results.HiddenState;
inputArguments.CellState = results.CellState;
end

function mode = iGetOutputMode( tf )
if tf
    mode = 'sequence';
else
    mode = 'last';
end
end

function iCheckFactorDimensions( value )
dim = numel( value );
if ~(dim == 1 || dim == 4)
    exception = MException(message('nnet_cnn:layer:LSTMLayer:InvalidFactor'));
    throwAsCaller(exception);
end
end

function validString = iAssertAndReturnValidOutputMode(value)
validString = validatestring(value, {'sequence', 'last'});
end

function validString = iAssertAndReturnValidStateActivation(value)
validString = validatestring(value, {'tanh', 'softsign'});
end

function validString = iAssertAndReturnValidGateActivation(value)
validString = validatestring(value, {'sigmoid', 'hard-sigmoid'});
end

function iAssertValidFactor(value)
validateattributes(value, {'numeric'},  {'vector', 'real', 'nonnegative', 'finite'});
end

function value = iAssertValidWeightsInitializer(value, name)
validateattributes(value, {'function_handle','char','string'}, {});
if(ischar(value) || isstring(value))
    value = validatestring(value, {'narrow-normal', ...
                           'glorot', ...
                           'he', ...
                           'orthogonal', ...
                           'zeros', ...
                           'ones'}, '', name);
end
end

function value = iAssertValidBiasInitializer(value)
validateattributes(value, {'function_handle','char','string'}, {});
if(ischar(value) || isstring(value))
    value = validatestring(value, {'unit-forget-gate', ...
                           'narrow-normal', ...
                           'ones'});
end
end

function initializer = iInitializerFactory(varargin)
initializer = nnet.internal.cnn.layer.learnable.initializer...
    .initializerFactory(varargin{:});
end

function tf = iIsCustomInitializer(init)
tf = isa(init, 'nnet.internal.cnn.layer.learnable.initializer.Custom');
end

function iAssertValidLayerName(name)
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateLayerName(name));
end

function S = iUpgradeVersionOneToVersionTwo(S)
% iUpgradeVersionOneToVersionTwo   Upgrade a v1 (R2017b) saved struct to a
% v2 saved struct. This means transforming the cell state and hidden state
% dynamic parameters into struct() format. Additionally, OutputState and
% OutputSize are re-named to HiddenState and NumHiddenUnits.
S.Version = 2;
S.CellState = toStruct(S.CellState);
S.HiddenState = toStruct(S.OutputState);
S.NumHiddenUnits = S.OutputSize;
end

function S = iUpgradeVersionTwoToVersionThree(S)
% iUpgradeVersionTwoToVersionThree   Upgrade a v2 (R2018a) saved struct to
% a v3 saved struct. This means adding the state activation and gate
% activation properties to the layer.
S.Version = 3;
S.StateActivationFunction = 'tanh';
S.GateActivationFunction = 'sigmoid';
end

function S = iUpgradeVersionThreeToVersionFour(S)
% Upgrade a v3 (R2018b) saved struct to a v3 saved struct. This means
% adding input weights, recurrent weights and bias initializers set to 
% 'narrow-normal', 'narrow-normal', and 'unit-forget-gate'.
S.Version = 4;
S.InputWeights = iAddInitializerToLearnable(S.InputWeights, "Normal", []);
S.RecurrentWeights = iAddInitializerToLearnable(S.RecurrentWeights, "Normal", []);
S.Bias = iAddInitializerToLearnable(S.Bias, "UnitForgetGate", {{'LSTM'}});
end

function s = iAddInitializerToLearnable(s, name, arguments)
s.Initializer = struct('Class', ...
    "nnet.internal.cnn.layer.learnable.initializer."+name, ...
    'ConstructorArguments', arguments);
end

function iEvalAndThrow(func)
% Omit the stack containing internal functions by throwing as caller
try
    func();
catch exception
    throwAsCaller(exception)
end
end

function value = iGatherAndValidateParameter(varargin)
try
    value = nnet.internal.cnn.layer.paramvalidation...
        .gatherAndValidateNumericParameter(varargin{:});
catch exception
    throwAsCaller(exception)
end
end
