classdef FlattenLayer < nnet.cnn.layer.Layer & nnet.internal.cnn.layer.Externalizable
    % FlattenLayer   flatten the spatial dimensions of a tensor into the channel dimension
    %
    % The flatten layer flattens the spatial dimensions of the input into a
    % single channel. The layer preserves the observation dimension (N) and
    % the sequence dimension (S) after flattening. For example:
    %
    %   Description         | Size                        | Flattened size
    %   ----------------------------------------------------------------------
    %   Vector sequences    | C x N x S                   | C x N x S
    %   Image sequences     | H x W x C x N x S           | (H*W*C) x N x S
    %   3-D image sequences | H x W x D x C x N x S       | (H*W*D*C) x N x S
    %
    %   FlattenLayer properties:
    %       Name                   - A name for the layer.
    %       NumInputs              - The number of inputs of the layer.
    %       InputNames             - The names of the inputs of the layer.
    %       NumOutputs             - The number of outputs of the layer.
    %       OutputNames            - The names of the outputs of the layer.
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties(Dependent)
        % Name   A name for the layer
        %   The name for the layer. If this is set to '', then a name will
        %   be automatically set at training time.
        Name         
    end
    
    methods
        function this = FlattenLayer(privateLayer)
            this.PrivateLayer = privateLayer;
        end      
        
        function val = get.Name(this)
            val = this.PrivateLayer.Name;
        end
        
        function this = set.Name(this, val)
            iAssertValidLayerName(val);
            this.PrivateLayer.Name = char(val);
        end
        
        function out = saveobj(this)
            out.Version = 1.0;
            out.Name = this.PrivateLayer.Name;
            out.NumFlattenDimensions = this.PrivateLayer.NumFlattenDimensions;
        end
    end
    
    methods(Static)
        function this = loadobj(in)
            internalLayer = nnet.internal.cnn.layer.Flatten(in.Name, in.NumFlattenDimensions);
            this = nnet.cnn.layer.FlattenLayer(internalLayer);
        end
    end

    methods(Access = protected)
        function [description, type] = getOneLineDisplay(~)
            description = iGetMessageString('nnet_cnn:layer:FlattenLayer:oneLineDisplay');
            
            type = iGetMessageString( 'nnet_cnn:layer:FlattenLayer:Type' );
        end
        
        function groups = getPropertyGroups( this )
            groups = this.propertyGroupGeneral( {'Name'} );
        end
    end
end

function messageString = iGetMessageString( varargin )
messageString = getString( message( varargin{:} ) );
end

function iAssertValidLayerName(name)
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateLayerName(name));
end

function iEvalAndThrow(func)
% Omit the stack containing internal functions by throwing as caller
try
    func();
catch exception
    throwAsCaller(exception)
end
end
