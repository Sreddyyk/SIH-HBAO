classdef AveragePooling3DLayer < nnet.cnn.layer.Layer & nnet.internal.cnn.layer.Externalizable
    % AveragePooling3DLayer   3-D Average pooling layer
    %
    %   To create a 3-D average pooling layer, use averagePooling3dLayer
    %
    %   A 3-D average pooling layer. This layer performs downsampling.
    %
    %   AveragePooling3DLayer properties:
    %       Name                    - A name for the layer.
    %       PoolSize                - The height, width and depth of
    %                                 pooling regions.
    %       Stride                  - The vertical, horizontal and depth 
    %                                 stride.
    %       PaddingMode             - The mode used to determine the
    %                                 padding.
    %       PaddingSize             - The padding applied to the input 
    %                                 along the edges.
    %       NumInputs               - The number of inputs for the layer.
    %       InputNames              - The names of the inputs of the layer.
    %       NumOutputs              - The number of outputs of the layer.
    %       OutputNames             - The names of the outputs of the layer.
    %
    %   Example:
    %      % Create a 3-D average pooling layer with non-overlapping pooling
    %      % regions, which down-samples by a factor of 2:
    %
    %       layer = averagePooling3dLayer(2, 'Stride', 2);
    %
    %   See also averagePooling2dLayer, averagePooling3dLayer
    
    %   Copyright 2018 The MathWorks, Inc.
    
    properties(Dependent)
        % Name   A name for the layer
        %   The name for the layer. If this is set to '', then a name will
        %   be automatically set at training time.
        Name
    end 
        
    properties(SetAccess = private, Dependent)
        % PoolSize   The height, width and depth of a pooling region
        %   The size the pooling regions. This is a vector [h w d] where h
        %   is the height of a pooling region, w is the width of a pooling
        %   region and d is the depth of the pooling region.
        PoolSize
    end
    
    properties(Dependent)                        
       % Stride   The vertical, horizontal and depth stride
        %   The step size for traversing the input vertically, horizontally
        %   and in the depth direction. This is a vector [u v w] where u is
        %   the vertical stride, v is the horizontal stride and w is the
        %   depth stride.
        Stride
    end

    properties(SetAccess = private, Dependent)
        % PaddingMode   The mode used to determine the padding
        %   The mode used to calculate the PaddingSize property. This can
        %   be:
        %       'manual'    - PaddingSize is specified manually. 
        %       'same'      - PaddingSize is calculated so that the output
        %                     is the same size as the input when the stride
        %                     is 1. More generally, the output size will be
        %                     ceil(inputSize/stride), where inputSize is
        %                     the height, width and depth of the input.
        PaddingMode
    end

    properties(Dependent)
        % PaddingSize   The padding applied to the input along the edges
        %   The padding that is applied along the edges. This is a 2-by-3
        %   matrix [t l f; b r k] where t is the padding to the top, l is
        %   the padding applied to the left, f is the padding applied to
        %   the front, b is the padding applied to the bottom,  r is the
        %   padding applied to the right,  and k is the padding applied to
        %   the back.
        PaddingSize
    end

    
    methods
        function this = AveragePooling3DLayer(privateLayer)
            this.PrivateLayer = privateLayer;
        end
        
        function out = saveobj(this)
            privateLayer = this.PrivateLayer;            
            out.Version = 2.0;
            out.Name = privateLayer.Name;
            out.PoolSize = privateLayer.PoolSize;
            out.Stride = privateLayer.Stride;
            out.PaddingMode = privateLayer.PaddingMode;
            out.PaddingSize = privateLayer.PaddingSize;
        end
        
        function this = set.Name(this, val)
            iAssertValidLayerName(val);
            this.PrivateLayer.Name = char(val);
        end        
        
        function val = get.PoolSize(this)
            val = this.PrivateLayer.PoolSize;
        end
               
        function this = set.Stride(this, value)
            value = gather(value);
            iAssertValidStride(value);
            % Convert to canonical form
            this.PrivateLayer.Stride = double(iMakeIntoRowVectorOfThree(value));
        end
        
        function val = get.Stride(this)
            val = this.PrivateLayer.Stride;
        end              
        
        function val = get.PaddingMode(this)
            val = this.PrivateLayer.PaddingMode;
        end
        
        function this = set.PaddingSize(this, value)
            value = gather(value);
            if isequal(this.PaddingMode,'same')
                error(message('nnet_cnn:layer:Layer:PaddingSizeCanOnlyBeSetInManualMode'))
            end
            iAssertValidPaddingSize(value);
            
            padValue = iCalculatePaddingSize(value);
            iAssertPoolSizeIsGreaterThanPaddingSize(this.PoolSize, padValue);
            % Convert to canonical form
            this.PrivateLayer.PaddingSize = double(padValue);
        end
        
        function val = get.PaddingSize(this)
            val = iExtractPaddingSize(this.PrivateLayer.PaddingSize);
        end
        
        function val = get.Name(this)
            val = this.PrivateLayer.Name;
        end
    end
    
    methods

    end
    
    methods(Hidden, Static)
        function this = loadobj(in)
            this = iLoadAveragePooling3DLayerFromCurrentVersion(in);
        end
    end
    
    methods(Hidden, Access = protected)
        function [description, type] = getOneLineDisplay(this)
            poolSizeString = i3DSizeToString( this.PoolSize );
            strideString = "["+int2str( this.Stride )+"]";
            
            if this.PaddingMode ~= "manual"
                paddingSizeString = "'"+this.PaddingMode+"'";
            else
                paddingSizeString = "["+int2str( this.PaddingSize(1,:)) + "; " +int2str( this.PaddingSize(2,:)) +"]";
            end
            
            description = iGetMessageString(  ...
                'nnet_cnn:layer:AveragePooling3DLayer:oneLineDisplay', ...
                poolSizeString, ...
                strideString, ...
                paddingSizeString );
            
            type = iGetMessageString( 'nnet_cnn:layer:AveragePooling3DLayer:Type' );
        end
        
        function groups = getPropertyGroups( this )
            hyperparameters = {
                'PoolSize'
                'Stride'
                'PaddingMode'
                'PaddingSize'
                };
            
            groups = [
                this.propertyGroupGeneral( {'Name'} )
                this.propertyGroupHyperparameters( hyperparameters )
                ];
        end
    end
end


function messageString = iGetMessageString( varargin )
messageString = getString( message( varargin{:} ) );
end

function sizeString = i3DSizeToString( sizeVector )
% i3DSizeToString   Convert a 3-D size stored in a vector of 3 elements
% into a string separated by 'x'.
sizeString = [ ...
    int2str( sizeVector(1) ) ...
    'x' ...
    int2str( sizeVector(2) ) ...
    'x' ...
    int2str( sizeVector(3) )];
end

function iAssertValidLayerName(name)
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateLayerName(name));
end

function iAssertValidStride(value)
dims = 3;
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateSizeParameter(value, 'Stride',dims));
end

function rowVectorOfThree = iMakeIntoRowVectorOfThree(scalarOrRowVectorOfThree)
rowVectorOfThree = ...
    nnet.internal.cnn.layer.paramvalidation.makeIntoRowVectorOfThree(scalarOrRowVectorOfThree);
end

function iAssertValidPaddingSize(value)
dims = 3;
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validatePaddingSize(value,dims));
end

function obj = iLoadAveragePooling3DLayerFromCurrentVersion(in)
internalLayer = nnet.internal.cnn.layer.AveragePooling3D( ...
    in.Name, ...
    in.PoolSize, ...
    in.Stride, ...
    in.PaddingMode, ...
    in.PaddingSize);
obj = nnet.cnn.layer.AveragePooling3DLayer(internalLayer);
end

function paddingSize = iCalculatePaddingSize(padding)
dims = 3;
paddingSize = nnet.internal.cnn.layer.padding.calculatePaddingSize(padding,dims);
end

function iEvalAndThrow(func)
% Omit the stack containing internal functions by throwing as caller
try
    func();
catch exception
    throwAsCaller(exception)
end
end

function iAssertPoolSizeIsGreaterThanPaddingSize(poolSize, padValue)
if(~iPoolSizeIsGreaterThanPaddingSize(poolSize, padValue))
    exception = MException(message('nnet_cnn:layer:AveragePooling3DLayer:PaddingSizeLargerThanOrEqualToPoolSize'));
    throwAsCaller(exception);
end
end

function tf = iPoolSizeIsGreaterThanPaddingSize(poolSize, paddingSize)
tf = nnet.internal.cnn.layer.padding.poolOrFilterSizeIsGreaterThanPaddingSize(poolSize, paddingSize);
end

function out=iExtractPaddingSize(in)
if ~isempty(in)
    out = reshape(in,2,3);
else 
    out = in;
end
end