classdef RegressionOutputLayer < nnet.cnn.layer.Layer & nnet.internal.cnn.layer.Externalizable
    % RegressionOutputLayer   Regression output layer
    %
    %   To create a regression output layer, use regressionLayer.
    %
    %   A regression output layer. This layer is used as the output for
    %   a network that performs regression.
    %
    %   RegressionOutputLayer properties:
    %       Name                        - A name for the layer.
    %       ResponseNames               - The names of the responses.
    %       LossFunction                - The loss function that is used
    %                                     for training.
    %       NumInputs                   - The number of inputs for the 
    %                                     layer.
    %       InputNames                  - The names of the inputs of the 
    %                                     layer.
    %
    %   Example:
    %       Create a regression output layer.
    %
    %       layer = regressionLayer();
    %
    %   See also regressionLayer
    
    %   Copyright 2016-2018 The MathWorks, Inc.
    
    properties(Dependent)
        % Name   A name for the layer
        %   The name for the layer. If this is set to '', then a name will
        %   be automatically set at training time.
        Name         
    end
    
    properties(Dependent)
        % ResponseNames   The names of the responses
        %   A cell array containing the names of the responses. Set by
        %   passing unique names as strings vector or cell array of
        %   character vectors. Missing values will be skipped. During
        %   training, this property will be automatically set according to
        %   training data.
        ResponseNames
    end
    
    properties(SetAccess = private)
        % LossFunction   The loss function for training
        %   The loss function that will be used during training. Possible
        %   values are:
        %       'mean-squared-error'    - Mean squared error
        LossFunction = 'mean-squared-error';
    end
    
    methods
        function this = RegressionOutputLayer(privateLayer)
            this.PrivateLayer = privateLayer;
        end
        
        function out = saveobj(this)
            privateLayer = this.PrivateLayer;
            out.Version = 2.0;
            out.Name = privateLayer.Name;
            out.ResponseNames = privateLayer.ResponseNames;
            out.ObservationDim = privateLayer.ObservationDim;
        end
        
        function val = get.Name(this)
            val = this.PrivateLayer.Name;
        end
        
        function this = set.Name(this, val)
            iAssertValidLayerName(val);
            this.PrivateLayer.Name = char(val);
        end
        
        function val = get.ResponseNames(this)
            val = this.PrivateLayer.ResponseNames;
        end
        
        function this = set.ResponseNames(this, val)
            iAssertValidResponseNames(val);
            val = iConvertResponseNamesToCanonicalForm(val);
            this.PrivateLayer.ResponseNames = val;
        end
    end
    
    methods(Hidden, Static)
        function this = loadobj(in)
            if in.Version <= 1
                in = iUpgradeFromVersionOneToVersionTwo(in);
            end
            internalLayer = nnet.internal.cnn.layer.MeanSquaredError.constructWithObservationDim( ...
                in.Name, in.ResponseNames, in.ObservationDim );
            this = nnet.cnn.layer.RegressionOutputLayer(internalLayer);
        end
    end
    
    methods(Hidden, Access = protected)
        function [description, type] = getOneLineDisplay(this)
            lossFunction = this.LossFunction;
            
            numResponses = numel(this.ResponseNames);
            
            if numResponses==0
                description = iGetMessageString( ...
                    'nnet_cnn:layer:RegressionOutputLayer:oneLineDisplayNoResponses', ....
                    lossFunction );
            elseif numResponses==1
                description = iGetMessageString( ...
                    'nnet_cnn:layer:RegressionOutputLayer:oneLineDisplayOneResponse', ....
                    lossFunction, ...
                    this.ResponseNames{1} );
            elseif numResponses==2
                description = iGetMessageString( ...
                    'nnet_cnn:layer:RegressionOutputLayer:oneLineDisplayTwoResponses', ....
                    lossFunction, ...
                    this.ResponseNames{1}, ...
                    this.ResponseNames{2} );
            elseif numResponses>=3
                description = iGetMessageString( ...
                    'nnet_cnn:layer:RegressionOutputLayer:oneLineDisplayNResponses', ....
                    lossFunction, ...
                    this.ResponseNames{1}, ...
                    this.ResponseNames{2}, ...
                    int2str( numResponses-2 ) );
            end
            
            type = iGetMessageString( 'nnet_cnn:layer:RegressionOutputLayer:Type' );
        end
        
        function groups = getPropertyGroups( this )
            generalParameters = {
                'Name'
                'ResponseNames'
                };
            
            groups = [
                this.propertyGroupGeneral( generalParameters )
                this.propertyGroupHyperparameters( {'LossFunction'} )
                ];
        end
    end
end

function messageString = iGetMessageString( varargin )
messageString = getString( message( varargin{:} ) );
end

function iAssertValidLayerName(name)
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateLayerName(name));
end

function iAssertValidResponseNames(names)
iEvalAndThrow(@()...
     nnet.internal.cnn.layer.paramvalidation.validateResponseNames(names));
end

function names = iConvertResponseNamesToCanonicalForm(names)
names = nnet.internal.cnn.layer.paramvalidation...
    .convertResponseNamesToCanonicalForm(names);
end

function S = iUpgradeFromVersionOneToVersionTwo( S )
% iUpgradeFromVersionOneToVersionTwo   Add the observation dimension
% property to v1 layers. All v1 layers, created from R2017b and before,
% have observation dimension equal to 4, corresponding to the image data
% format.
S.Version = 2.0;
S.ObservationDim = 4;
end

function iEvalAndThrow(func)
% Omit the stack containing internal functions by throwing as caller
try
    func();
catch exception
    throwAsCaller(exception)
end
end
