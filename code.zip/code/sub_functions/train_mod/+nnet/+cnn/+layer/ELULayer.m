classdef ELULayer < nnet.layer.Layer
    % ELULayer   Exponential Linear Unit layer
    %
    %   To create an Exponential Linear Unit layer, use eluLayer.
    %   An ELU layer maps its input x to f(x) given by
    %   f(x) = alpha*(exp(x) - 1);   for x <= 0;
    %   f(x) = x;                   for x > 0;
    %   alpha is a positive constant, whose default value is 1.
    %
    %   The ELU hyperparameter controls the value to which
    %   an ELU saturates for negative net inputs. More info on:
    %   https://arxiv.org/abs/1511.07289v5 ,p.5.
    %
    %   ELULayer properties:
    %       Name                   - A name for the layer.
    %       Alpha                  - Scalar multiplier for negative values 
    %                                (default 1) 
    %       NumInputs              - The number of inputs of the layer.
    %       InputNames             - The names of the inputs of the layer.
    %       NumOutputs             - The number of outputs of the layer.
    %       OutputNames            - The names of the outputs of the layer.
    %
    %   Example:
    %     Create a exponential linear unit layer.
    %
    %     layer = eluLayer(2,'Name','elu_1');
    
    %   Copyright 2018 The MathWorks, Inc.
    
    properties
        Alpha
    end
    
    methods
        function layer = ELULayer(alpha,name)
            layer.Name = name;
            layer.Alpha = alpha;
            layer.Description = iGetMessageString('nnet_cnn:layer:ELULayer:oneLineDisplay',...
                num2str(layer.Alpha));
            layer.Type = iGetMessageString('nnet_cnn:layer:ELULayer:Type');
        end
        
        function this = set.Alpha(this, val)
            this.Alpha = gather(val);
        end
        
        function Z = predict(layer, X)
            % predict   Forward input data through the layer and output the result
            Z = max(0, X) + layer.Alpha*(exp(min(0, X)) -1);
        end
        
        function [dLdX] = backward(layer, X, Z, dLdZ, ~)
            % backward    Back propagate the derivative of the loss function
            % through the layer
            dLdX = (layer.Alpha  +Z) .* dLdZ;
            dLdX(X>0) = dLdZ(X>0);
        end
    end
end

function messageString = iGetMessageString( varargin )
messageString = getString( message( varargin{:} ) );
end
