classdef TransposedConvolution3DLayer < nnet.cnn.layer.Layer & nnet.internal.cnn.layer.Externalizable
    % TransposedConvolution3DLayer   3-D transposed convolution layer
    %
    %   To create a transposed convolution layer, use transposedConv3dLayer.
    %
    %   TransposedConvolution3DLayer properties:
    %       Name                        - A name for the layer.
    %       FilterSize                  - The height, width and depth of the
    %                                     filters.
    %       NumChannels                 - The number of channels for each
    %                                     filter.
    %       NumFilters                  - The number of filters.
    %       Stride                      - The step size for traversing the
    %                                     input vertically, horizontally 
    %                                     and along the depth.
    %       CroppingMode                - The mode used to determine the
    %                                     cropping.
    %       CroppingSize                - The amount to trim the edges
    %                                     of the full transposed
    %                                     convolution.
    %       Weights                     - Weights of the layer.
    %       Bias                        - Biases of the layer.
    %       WeightsInitializer          - The function for initializing the 
    %                                     weights.
    %       BiasInitializer             - The function for initializing the
    %                                     bias.    
    %       WeightLearnRateFactor       - A number that specifies
    %                                     multiplier for the learning rate
    %                                     of the weights.
    %       BiasLearnRateFactor         - A number that specifies a
    %                                     multiplier for the learning rate
    %                                     for the biases.
    %       WeightL2Factor              - A number that specifies a
    %                                     multiplier for the L2 weight
    %                                     regulariser for the weights.
    %       BiasL2Factor                - A number that specifies a
    %                                     multiplier for the L2 weight
    %                                     regulariser for the biases.
    %       NumInputs                   - The number of inputs for the 
    %                                     layer.
    %       InputNames                  - The names of the inputs of the 
    %                                     layer.
    %       NumOutputs                  - The number of outputs of the 
    %                                     layer.
    %       OutputNames                 - The names of the outputs of the 
    %                                     layer.
    %
    %   Example:
    %       Create a transposed convolution layer with 5 filters of size 
    %       10-by-10-by-10.
    %
    %       layer = transposedConv3dLayer(10, 5);
    %
    %   See also transposedConv3dLayer, convolution3dLayer.
    
    %   Copyright 2018-2019 The MathWorks, Inc.
    
    properties(Dependent)
        % Name   A name for the layer
        %   The name for the layer. If this is set to '', then a name will
        %   be automatically set at training time.
        Name         
    end
        
    properties(SetAccess = private, Dependent)
        % FilterSize   The height, width and depth of the filters
        %   The height, width and depth of the filters. This is a row 
        %   vector [h w d] specifying the height, width and depth of the
        %   filter.
        FilterSize
        
        % NumChannels   The number of channels in the input
        %   The number of channels in the input. This can be set to 'auto',
        %   in which case the correct value will be determined at training
        %   time.
        NumChannels
        
        % NumFilters   The number of filters
        %   The number of filters for this layer. This also determines how
        %   many maps there will be in the output.
        NumFilters
        
        % Stride   The vertical, horizontal and depth stride.
        %   The step size for traversing the input vertically,
        %   horizontally and along the depth. This is a row vector [u v w] 
        %   specifying the vertical, horizontal and depth stride.
        Stride
        
        % CroppingMode   The mode used to determine the cropping
        %   The mode used to calculate the CroppingSize property. This can
        %   be:
        %       'manual'    - CroppingSize is specified manually. 
        %       'same'      - CroppingSize is calculated so that the output
        %                     size will be inputSize * stride, where
        %                     inputSize is the height and width of the
        %                     input.
        CroppingMode
        
        % CroppingSize   Output layer size reduction
        %    A 2x3 matrix [t l f; b r bk], where t is the cropping applied to the
        %    top, b is the cropping applied to the bottom, l is the
        %    cropping applied to the left, r is the cropping applied to
        %    the right, f is the cropping applied to the front and bk to 
        %    the back.
        CroppingSize
    end
    
    properties(Dependent)
        % Weights   The weights for the layer
        %   The filters for the convolutional layer. An array with size
        %   FilterSize(1)-by-FilterSize(2)-by-FilterSize(3)-by-NumFilters-by-NumChannels.
        Weights
        
        % Bias   The bias vector for the layer
        %   The bias for the convolutional layer. The size will be
        %   1-by-1-by-1-by-NumFilters.
        Bias
        
        % WeightsInitializer   The function to initialize the weights.
        WeightsInitializer        
        
        % WeightLearnRateFactor   The learning rate factor for the weights
        %   The learning rate factor for the weights. This factor is
        %   multiplied with the global learning rate to determine the
        %   learning rate for the weights in this layer. For example, if it
        %   is set to 2, then the learning rate for the weights in this
        %   layer will be twice the current global learning rate.
        WeightLearnRateFactor
        
        % WeightL2Factor   The L2 regularization factor for the weights
        %   The L2 regularization factor for the weights. This factor is
        %   multiplied with the global L2 regularization setting to
        %   determine the L2 regularization setting for the weights in this
        %   layer. For example, if it is set to 2, then the L2
        %   regularization for the weights in this layer will be twice the
        %   global L2 regularization setting.
        WeightL2Factor
        
        % BiasInitializer   The function to initialize the bias.
        BiasInitializer        
        
        % BiasLearnRateFactor   The learning rate factor for the biases
        %   The learning rate factor for the bias. This factor is
        %   multiplied with the global learning rate to determine the
        %   learning rate for the bias in this layer. For example, if it
        %   is set to 2, then the learning rate for the bias in this layer
        %   will be twice the current global learning rate.
        BiasLearnRateFactor
        
        % BiasL2Factor   The L2 regularization factor for the biases
        %   The L2 regularization factor for the biases. This factor is
        %   multiplied with the global L2 regularization setting to
        %   determine the L2 regularization setting for the biases in this
        %   layer. For example, if it is set to 2, then the L2
        %   regularization for the biases in this layer will be twice the
        %   global L2 regularization setting.
        BiasL2Factor
    end
    
    methods
        function this = TransposedConvolution3DLayer(privateLayer)
            this.PrivateLayer = privateLayer;
        end
        
        function out = saveobj(this)
            privateLayer = this.PrivateLayer;
            out.Name = privateLayer.Name;
            out.Version = 1.0;
            out.FilterSize = privateLayer.FilterSize;
            out.NumChannels = privateLayer.NumChannels;
            out.NumFilters = privateLayer.NumFilters;
            out.Stride = privateLayer.Stride;
            out.CroppingMode = privateLayer.CroppingMode;
            out.CroppingSize = privateLayer.CroppingSize;
            out.Weights = toStruct(privateLayer.Weights);
            out.Bias = toStruct(privateLayer.Bias);
            out.OutputSizeOffset = privateLayer.OutputSizeOffset;
        end

        function val = get.Name(this)
            val = this.PrivateLayer.Name;
        end
        
        function this = set.Name(this, val)
            iAssertValidLayerName(val);
            this.PrivateLayer.Name = char(val);
        end
        
        function val = get.Weights(this)
            val = this.PrivateLayer.Weights.HostValue;
            if isa(val, 'dlarray')
                val = extractdata(val);
            end
        end
        
        function this = set.Weights(this, value)
            expectedSize = this.PrivateLayer.ExtWeightsSize;
            value = iGatherAndValidateParameter(value, expectedSize);
            
            if ~isempty(value)
                % Call inferSize to determine the size of the layer. In
                % transposed convolution weights, 5 dim stores numChannels.
                inputChannels = size(value,5);
                this.PrivateLayer = this.PrivateLayer.inferNumChannels( [NaN NaN NaN inputChannels] );
            end
            this.PrivateLayer.Weights.Value = value;
        end
        
        function val = get.Bias(this)
            val = this.PrivateLayer.Bias.HostValue;
            if isa(val, 'dlarray')
                val = extractdata(val);
            end
        end
        
        function this = set.Bias(this, value)            
            expectedSize = this.PrivateLayer.ExtBiasSize;
            value = iGatherAndValidateParameter(value, expectedSize);            
            this.PrivateLayer.Bias.Value = value;
        end
        
        function val = get.FilterSize(this)
            val = this.PrivateLayer.FilterSize;
        end
        
        function val = get.NumChannels(this)
            val = this.PrivateLayer.NumChannels;
            if isempty(val)
                val = 'auto';
            end
        end
        
        function val = get.NumFilters(this)
            val = this.PrivateLayer.NumFilters;
        end
        
        function val = get.Stride(this)
            val = this.PrivateLayer.Stride;
        end
        
        function val = get.CroppingMode(this)
            val = this.PrivateLayer.CroppingMode;
        end

        function val = get.CroppingSize(this)
            val = iExtractCroppingSize(this.PrivateLayer.CroppingSize);
        end
        
        function val = get.WeightsInitializer(this)
            if iIsCustomInitializer(this.PrivateLayer.Weights.Initializer)
                val = this.PrivateLayer.Weights.Initializer.Fcn;
            else
                val = this.PrivateLayer.Weights.Initializer.Name;
            end
        end
        
        function this = set.WeightsInitializer(this, value)
            value = iAssertValidWeightsInitializer(value);        
            % Create the initializer with in and out indices of the weights
            % size:
            % FilterSize(1)-by-FilterSize(2)-by-FilterSize(3)-by-
            % NumFilters-by-NumChannels
            this.PrivateLayer.Weights.Initializer = ...
                iInitializerFactory(value, [1 2 3 5], [1 2 3 4]);
        end
        
        function val = get.BiasInitializer(this)
            if iIsCustomInitializer(this.PrivateLayer.Bias.Initializer)
                val = this.PrivateLayer.Bias.Initializer.Fcn;
            else
                val = this.PrivateLayer.Bias.Initializer.Name;
            end
        end
        
        function this = set.BiasInitializer(this, value)
            value = iAssertValidBiasInitializer(value);
            % Bias initializers do not require to pass in and out indices
            this.PrivateLayer.Bias.Initializer = iInitializerFactory(value);
        end
        
        function val = get.WeightLearnRateFactor(this)
            val = this.PrivateLayer.Weights.LearnRateFactor;
        end
        
        function this = set.WeightLearnRateFactor(this, value)
            value = gather(value);
            iAssertValidFactor(value,'WeightLearnRateFactor');
            this.PrivateLayer.Weights.LearnRateFactor = value;
        end
        
        function val = get.BiasLearnRateFactor(this)
            val = this.PrivateLayer.Bias.LearnRateFactor;
        end
        
        function this = set.BiasLearnRateFactor(this, value)
            value = gather(value);
            iAssertValidFactor(value,'BiasLearnRateFactor');
            this.PrivateLayer.Bias.LearnRateFactor = value;
        end
        
        function val = get.WeightL2Factor(this)
            val = this.PrivateLayer.Weights.L2Factor;
        end
        
        function this = set.WeightL2Factor(this, value)
            value = gather(value);
            iAssertValidFactor(value,'WeightL2Factor');
            this.PrivateLayer.Weights.L2Factor = value;
        end
        
        function val = get.BiasL2Factor(this)
            val = this.PrivateLayer.Bias.L2Factor;
        end
        
        function this = set.BiasL2Factor(this, value)
            value = gather(value);
            iAssertValidFactor(value,'BiasL2Factor');
            this.PrivateLayer.Bias.L2Factor = value;
        end
    end
    
    methods(Static)
        function this = loadobj(in)
            this = iLoadLayerFromCurrentVersion(in);
        end
    end
    
    methods(Hidden, Access = protected)
        function [description, type] = getOneLineDisplay(this)
            numFiltersString = int2str( this.NumFilters );
            filterSizeString = i3DSizeToString( this.FilterSize );
            if ~isequal(this.NumChannels, 'auto')
                numChannelsString = ['x' int2str( this.NumChannels )];
            else
                numChannelsString = '';
            end
            strideString = int2str( this.Stride );
            
            if this.CroppingMode ~= "manual"
                croppingString = "'"+this.CroppingMode+"'";
            else
                croppingString = "["+int2str( this.CroppingSize(1,:)) + "; "...
                                    +int2str( this.CroppingSize(2,:)) +"]";
            end
            
            description = iGetMessageString( ...
                'nnet_cnn:layer:TransposedConvolution3DLayer:oneLineDisplay', ...
                numFiltersString, ...
                filterSizeString, ...
                numChannelsString, ...
                strideString, ...
                croppingString );
            
            type = iGetMessageString( 'nnet_cnn:layer:TransposedConvolution3DLayer:Type' );
        end
        
        function groups = getPropertyGroups( this )
            hyperparameters = {
                'FilterSize'
                'NumChannels'
                'NumFilters'
                'Stride'
                'CroppingMode'
                'CroppingSize'
                };
            
            learnableParameters = {'Weights', 'Bias'};
            
            groups = [
                this.propertyGroupGeneral( {'Name'} )
                this.propertyGroupHyperparameters( hyperparameters )
                this.propertyGroupLearnableParameters( learnableParameters )
                ];
        end
        
        function footer = getFooter( this )
            variableName = inputname(1);
            footer = this.createShowAllPropertiesFooter( variableName );
        end
        
    end
end

function messageString = iGetMessageString( varargin )
messageString = getString( message( varargin{:} ) );
end

function sizeString = i3DSizeToString( sizeVector )
% i3DSizeToString   Convert a 3-D size stored in a vector of 3 elements
% into a string separated by 'x'.
sizeString = [ ...
    int2str( sizeVector(1) ) ...
    'x' ...
    int2str( sizeVector(2) )... 
    'x' ...
    int2str( sizeVector(3) )];
end

function obj = iLoadLayerFromCurrentVersion(in)
internalLayer = nnet.internal.cnn.layer.TransposedConvolution3D(in);
internalLayer.Weights = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.fromStruct(in.Weights);
internalLayer.Bias = nnet.internal.cnn.layer.learnable.PredictionLearnableParameter.fromStruct(in.Bias);
            
obj = nnet.cnn.layer.TransposedConvolution3DLayer(internalLayer);
end

function iAssertValidFactor(value,factorName)
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateLearnFactor(value,factorName));
end

function iAssertValidLayerName(name)
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateLayerName(name));
end

function out=iExtractCroppingSize(in)
if(isempty(in))
    out = in;
else
    out = reshape(in,2,3);
end
end

function value = iAssertValidWeightsInitializer(value)
validateattributes(value, {'function_handle','char','string'}, {});
if(ischar(value) || isstring(value))
    value = validatestring(value, {'narrow-normal', ...
                           'glorot', ...
                           'he', ...
                           'zeros', ...
                           'ones'});
end
end

function value = iAssertValidBiasInitializer(value)
validateattributes(value, {'function_handle','char','string'}, {});
if(ischar(value) || isstring(value))
    value = validatestring(value, {'narrow-normal', ...
                           'zeros', ...
                           'ones'});
end
end

function initializer = iInitializerFactory(varargin)
initializer = nnet.internal.cnn.layer.learnable.initializer...
    .initializerFactory(varargin{:});
end

function tf = iIsCustomInitializer(init)
tf = isa(init, 'nnet.internal.cnn.layer.learnable.initializer.Custom');
end

function iEvalAndThrow(func)
% Omit the stack containing internal functions by throwing as caller
try
    func();
catch exception
    throwAsCaller(exception)
end
end

function value = iGatherAndValidateParameter(value, expectedSize)
try
    value = nnet.internal.cnn.layer.paramvalidation...
        .gatherAndValidateNumericParameter(value,'default',expectedSize);
catch exception
    throwAsCaller(exception)
end
end
