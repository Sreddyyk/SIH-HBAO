classdef ConcatenationLayer < nnet.cnn.layer.Layer & nnet.internal.cnn.layer.Externalizable
    % ConcatenationLayer   Concatenation layer
    %
    %   To create a concatenation layer, use concatenationLayer.
    %
    %   This layer concatenates the inputs along a specified dimension.
    %   Each input must have matching sizes in all dimensions except the
    %   concatenation dimension.
    %
    %   ConcatenationLayer properties:
    %       Name                        - A name for the layer.
    %       Dim                         - The concatenation axis dimesnion.  
    %       NumInputs                   - The number of inputs for the 
    %                                     layer.
    %       InputNames                  - The names of the inputs of the 
    %                                     layer.
    %       NumOutputs                  - The number of outputs of the 
    %                                     layer.
    %       OutputNames                 - The names of the outputs of the 
    %                                     layer.
    %
    %   Example:
    %       Create a concatenation layer with two inputs and concatenate
    %       along 4th dimension.
    %
    %       layer = concatenationLayer(4,2);
    %
    %   See also concatenationLayer
    
    %   Copyright 2018 The MathWorks, Inc.
    
    properties(Dependent)
        % Name   A name for the layer
        Name
    end
    
    properties (SetAccess=private, Dependent)
        % Dim   concatenation axis dimension
        Dim
    end
    
    methods
        function val = get.Name(this)
            val = this.PrivateLayer.Name;
        end
        
        function this = set.Name(this, val)
            iAssertValidLayerName(val);
            this.PrivateLayer.Name = char(val);
        end
        
        function val = get.Dim(this)
            val = this.PrivateLayer.ConcatenationAxis;
        end
        
        function out = saveobj(this)
            out.Version = 1.0;
            out.Name = this.PrivateLayer.Name;
            out.Dim = this.PrivateLayer.ConcatenationAxis; 
            out.NumInputs = this.PrivateLayer.NumInputs;
        end
    end
    
    methods(Static)
        function this = loadobj(in)
            internalLayer = nnet.internal.cnn.layer.Concatenation(in.Name, in.Dim, in.NumInputs);
            this = nnet.cnn.layer.ConcatenationLayer(internalLayer);
        end
    end
    
    methods(Access = public)
        function this = ConcatenationLayer(privateLayer)
            this.PrivateLayer = privateLayer;
        end
    end
    
    methods(Access = protected)
        function [description, type] = getOneLineDisplay(this)           
            description = iGetMessageString('nnet_cnn:layer:ConcatenationLayer:oneLineDisplay', this.NumInputs,this.Dim);          
            type = iGetMessageString( 'nnet_cnn:layer:ConcatenationLayer:Type' );
        end
        
        function groups = getPropertyGroups( this )
            groups = this.propertyGroupGeneral( ...
                { 'Name', 'Dim', 'NumInputs', 'InputNames' } );
        end
    end
end

function messageString = iGetMessageString( varargin )
messageString = getString( message( varargin{:} ) );
end

function iAssertValidLayerName(name)
nnet.internal.cnn.layer.paramvalidation.validateLayerName(name);
end