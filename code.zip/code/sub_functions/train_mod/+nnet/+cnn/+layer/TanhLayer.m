classdef TanhLayer < nnet.layer.Layer
    % TanhLayer   Hyperbolic tangent (tanh) layer
    %
    %   To create a hyperbolic tangent layer, use tanhLayer.
    %
    %   A hyperbolic tangent layer. This type of layer performs a simple
    %   tanh operation.
    %
    %   TanhLayer properties:
    %       Name                   - A name for the layer.
    %       NumInputs              - The number of inputs of the layer.
    %       InputNames             - The names of the inputs of the layer.
    %       NumOutputs             - The number of outputs of the layer.
    %       OutputNames            - The names of the outputs of the layer.
    %
    %   Example:
    %       Create a tanh layer.
    %
    %       layer = tanhLayer()
    %
    %   See also tanhLayer
    
    %   Copyright 2018 The MathWorks, Inc.
    
    methods
        function layer = TanhLayer(name)
            layer.Name = name;
            layer.Description = iGetMessageString( 'nnet_cnn:layer:TanhLayer:OneLineDisplay' );
            layer.Type = iGetMessageString( 'nnet_cnn:layer:TanhLayer:Type' );
        end
        
        function Z = predict(layer, X)
            % Forward input data through the layer at prediction time and
            % output the result
            Z = tanh(X);
        end
        

        function dLdX = backward(layer, ~, Z, dLdZ, ~)
            % Backward propagate the derivative of the loss function through 
            % the layer
            dLdX = (1 - Z.^2) .* dLdZ;
        end
    end
end

function messageString = iGetMessageString( messageID )
messageString = getString( message( messageID ) );
end