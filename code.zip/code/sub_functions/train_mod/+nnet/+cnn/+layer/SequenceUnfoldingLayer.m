classdef SequenceUnfoldingLayer < nnet.cnn.layer.Layer & nnet.internal.cnn.layer.Externalizable
    % SequenceUnfoldingLayer   Sequence unfolding layer
    %
    % A sequence unfolding layer restores the observation dimension (N) and
    % the sequence dimension (S) of the input. The layer does not affect
    % inputs with no sequence dimension or sequence dimension 1. For
    % example:
    %
    %   Description         | Size                        | Unfolded size
    %   ----------------------------------------------------------------------
    %   Numeric sequences   | C x (N*S)                   | C x N x S
    %   Image sequences     | H x W x C x (N*S)           | H x W x C x N x S
    %   Images              | H x W x C x N               | H x W x C x N       (No effect)
    %   3-D images          | H x W x D x C x N           | H x W x D x C x N   (No effect)
    %
    %   SequenceUnfoldingLayer properties:
    %       Name                   - A name for the layer.
    %       NumInputs              - The number of inputs of the layer.
    %       InputNames             - The names of the inputs of the layer.
    %       NumOutputs             - The number of outputs of the layer.
    %       OutputNames            - The names of the outputs of the layer.
    
    %   Copyright 2018 The MathWorks, Inc.
    
    properties(Dependent)
        % Name   A name for the layer
        %   The name for the layer. If this is set to '', then a name will
        %   be automatically set at training time.
        Name
    end
    
    methods
        function this = SequenceUnfoldingLayer(privateLayer)
            this.PrivateLayer = privateLayer;
        end
        
        function out = saveobj(this)
            privateLayer = this.PrivateLayer;
            out.Version = 1.0;
            out.Name = privateLayer.Name;
            out.NumInputDimensions = privateLayer.NumInputDimensions;
        end
        
        function val = get.Name(this)
            val = this.PrivateLayer.Name;
        end
        
        function this = set.Name(this, val)
            iAssertValidLayerName(val);
            this.PrivateLayer.Name = char(val);
        end
    end
    
    methods(Hidden, Static)
        function this = loadobj(in)
            internalLayer = nnet.internal.cnn.layer.SequenceUnfolding(in.Name, in.NumInputDimensions);
            this = nnet.cnn.layer.SequenceUnfoldingLayer(internalLayer);
        end
    end
    
    methods(Hidden, Access = protected)
        function [description, type] = getOneLineDisplay(~)          
            description = iGetMessageString(...
                'nnet_cnn:layer:SequenceUnfoldingLayer:oneLineDisplay');
            
            type = iGetMessageString(...
                'nnet_cnn:layer:SequenceUnfoldingLayer:Type');
        end
        
        function groups = getPropertyGroups( this )                       
            groups = this.propertyGroupGeneral( {'Name','NumInputs','InputNames'} );                
        end
    end
end

function messageString = iGetMessageString( varargin )
messageString = getString( message( varargin{:} ) );
end

function iAssertValidLayerName(name)
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateLayerName(name));
end

function iEvalAndThrow(func)
% Omit the stack containing internal functions by throwing as caller
try
    func();
catch exception
    throwAsCaller(exception)
end
end