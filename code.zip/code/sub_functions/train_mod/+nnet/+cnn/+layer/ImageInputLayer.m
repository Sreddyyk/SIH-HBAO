classdef ImageInputLayer < nnet.cnn.layer.Layer & nnet.internal.cnn.layer.Externalizable
    % ImageInputLayer   Image input layer
    %
    %   To create an image input layer, use imageInputLayer
    %
    %   ImageInputLayer properties:
    %       Name                        - A name for the layer.
    %       InputSize                   - The size of the input.
    %       DataAugmentation            - The use of the DataAugmentation
    %                                     property is not recommended. Use
    %                                     augmentedImageDatastore instead.
    %       Normalization               - Normalization applied to image
    %                                     data every time data is forward
    %                                     propagated through the input
    %                                     layer. Valid options are 
    %                                     'zerocenter', 'zscore', 
    %                                     'rescale-symmetric', 
    %                                     'rescale-zero-one', 'none', or a
    %                                     function handle.
    %       NormalizationDimension      - Dimension over which the same
    %                                     normalization is applied. Valid
    %                                     values are 'auto', 'channel',
    %                                     'element', 'all'.
    %       Mean                        - The mean image used for zero
    %                                     center and z-score normalization.
    %       StandardDeviation           - The standard deviation image used 
    %                                     for z-score normalization.
    %       Min                         - The minimum image used for the
    %                                     rescaling normalizations.
    %       Max                         - The maximum image used for the
    %                                     rescaling normalizations.
    %       NumOutputs                  - The number of outputs of the
    %                                     layer.
    %       OutputNames                 - The names of the outputs of the
    %                                     layer.
    %
    %   Example 1:
    %       Create an image input layer for 28-by-28 color images.
    %
    %       layer = imageInputLayer([28 28 3]);
    %
    %   Example 2:
    %       Create an image input layer for 28-by-28 grayscale images. Set
    %       the mean image for zero-center normalization to matrix ones.
    %
    %       layer = imageInputLayer([28 28], 'Mean', ones([28 28]));
    %
    %       % Reset the mean image to empty
    %
    %       layer.Mean = [];
    %
    %   See also imageInputLayer
    
    %   Copyright 2015-2019 The MathWorks, Inc.
    
    properties(Dependent)
        % Name   A name for the layer
        %   The name for the layer. If this is set to '', then a name will
        %   be automatically set at training time.
        Name
        
        % Mean   The mean image over the training data, used for
        %        'zerocenter' and 'zscore' normalization.
        Mean
        
        % StandardDeviation    The standard deviation over the training 
        %                      data, used for 'zscore' normalization.
        StandardDeviation
        
        % Min    The minimum over the training data, used for 
        %        'rescale-symmetric' and 'rescale-zero-one' normalization.
        Min
        
        % Max    The maximum over the training data, used for 
        %        'rescale-symmetric' and 'rescale-zero-one' normalization.
        Max
        
        % NormalizationDimension   Dimension over which the same 
        %                          normalization is applied. Valid values
        %                          are 'auto', 'channel', 'element', 'all'.
        NormalizationDimension
    end
    
    properties(SetAccess = private, Dependent)
        % InputSize Size of the input image as [height, width, channels].
        InputSize
        
        % DataAugmentation    DataAugmentation is not recommended. Use
        %                     augmentedImageDatastore instead.
        DataAugmentation
        
        % Normalization  A string that specifies the normalization applied
        %                to the input data every time it is forward
        %                propagated through the input layer. Valid values
        %                are 'zerocenter', 'zscore', 'rescale-symmetric'
        %                'rescale-zero-one', or 'none'. This property is
        %                read-only.
        Normalization
    end
    
    properties(Dependent, Hidden)
        % AverageImage   The mean image over the training data, used for
        %                'zerocenter' normalization.
        AverageImage
    end
   
    methods
        function this = ImageInputLayer(privateLayer)
            this.PrivateLayer = privateLayer;
        end
        
        function out = saveobj(this)
            out.Version = 4.0;
            out.Name = this.PrivateLayer.Name;
            out.InputSize = this.PrivateLayer.InputSize;
            out.Normalization = iSaveTransforms(this.PrivateLayer.Transforms);
            out.Augmentations = iSaveTransforms(this.PrivateLayer.TrainTransforms);
            out.NormalizationDimension = this.PrivateLayer.NormalizationDimension;
        end
        
        function val = get.Name(this)
            val = this.PrivateLayer.Name;
        end
        
        function this = set.Name(this, val)
            iAssertValidLayerName(val);
            this.PrivateLayer.Name = char(val);
        end
        
        function val = get.InputSize(this)
            val = this.PrivateLayer.InputSize;
        end
        
        function val = get.Normalization(this)
            transformObj = this.PrivateLayer.Transforms;
            if isempty(transformObj)
                val = 'none';
            elseif transformObj.Type == "rescale"
                if isequal( [transformObj.TargetMin, transformObj.TargetMax], [0 1] )
                    val = 'rescale-zero-one';
                elseif isequal( [transformObj.TargetMin, transformObj.TargetMax], [-1 1] )
                    val = 'rescale-symmetric';
                end
            elseif transformObj.Type == "custom"
                val = transformObj.Function;
            else
                val = transformObj.Type;
            end
        end
        
        function val = get.NormalizationDimension(this)
            val = this.PrivateLayer.NormalizationDimension;
        end
        
        function this = set.NormalizationDimension(this, val)
            iAssertValidNormalizationDimension(val,this.Normalization);
            % The shape of statistics must be consistent with the
            % normalization dimension parameter
            statistics = getNormalizationHyperParams(this);
            for i = 1:numel(statistics)
                iAssertValidStatistics(this.(statistics{i}), statistics{i}, ...
                    this.Normalization, val, this.InputSize);
            end
            this.PrivateLayer.NormalizationDimension = convertStringsToChars(val);
        end
        
        function val = get.DataAugmentation(this)
            n = numel(this.PrivateLayer.TrainTransforms);
            if n == 1
                val = this.PrivateLayer.TrainTransforms.Type;
            elseif n > 1
                val = {this.PrivateLayer.TrainTransforms(:).Type};
            else
                val = 'none';
            end
        end
        
        function val = get.AverageImage(this)
            val = this.Mean;
        end
        
        function this = set.AverageImage(this, val)
            this.Mean = val;
        end
        
        function val = get.Mean(this)
            val = this.PrivateLayer.Mean;
        end
        
        function this = set.Mean(this, val)
            val = gather(val);
            iAssertValidStatistics(val, 'Mean', this.Normalization, ...
                this.NormalizationDimension, this.InputSize);
            % Store as single
            this.PrivateLayer.Mean = single(val);
        end
        
        function val = get.StandardDeviation(this)
            val = this.PrivateLayer.Std;
        end
        
        function this = set.StandardDeviation(this, val)
            val = gather(val);
            iAssertValidStatistics(val, 'StandardDeviation', this.Normalization, ...
                this.NormalizationDimension, this.InputSize);
            % Store as single
            this.PrivateLayer.Std = single(val);
        end
        
        function val = get.Min(this)
            val = this.PrivateLayer.Min;
        end
        
        function this = set.Min(this, val)
            val = gather(val);
            iAssertValidStatistics(val, 'Min', this.Normalization, ...
                this.NormalizationDimension, this.InputSize);
            % Store as single
            this.PrivateLayer.Min = single(val);
        end
        
        function val = get.Max(this)
            val = this.PrivateLayer.Max;
        end
        
        function this = set.Max(this, val)
            val = gather(val);
            iAssertValidStatistics(val, 'Max', this.Normalization, ...
                this.NormalizationDimension, this.InputSize);
            % Store as single
            this.PrivateLayer.Max = single(val);
        end
    end
    
    methods(Static)
        function this = loadobj(in)
            if in.Version <= 1
                in = iUpgradeFromVersionOneToVersionTwo(in);
            end
            if in.Version <= 2
                in = iUpgradeFromVersionTwoToVersionThree(in);
            end
            if in.Version <= 3
                in = iUpgradeFromVersionThreeToVersionFour(in);
            end
            internalLayer = nnet.internal.cnn.layer.ImageInput( ...
                in.Name, in.InputSize, ...
                iLoadTransforms( in.Normalization ), ...
                iLoadTransforms( in.Augmentations ) );
            internalLayer.NormalizationDimension = in.NormalizationDimension;
            this = nnet.cnn.layer.ImageInputLayer(internalLayer);
        end
    end
    
    methods(Hidden, Access = protected)
        function [description, type] = getOneLineDisplay(this)
            imageSizeString = i3DSizeToString( this.InputSize );
            
            if isa(this.Normalization,'function_handle')
                normalizationString = 'custom';
            else
                normalizationString = [ '''' this.Normalization '''' ];
            end
            augmentationsString = iAugmentationsString( this.DataAugmentation );
            
            if strcmp(this.Normalization, 'none') && all(strcmp(this.DataAugmentation, 'none'))
                % No transformations
                description = iGetMessageString( ...
                    'nnet_cnn:layer:ImageInputLayer:oneLineDisplayNoTransforms', ....
                    imageSizeString );
            elseif strcmp(this.Normalization, 'none')
                % Only augmentations
                description = iGetMessageString( ...
                    'nnet_cnn:layer:ImageInputLayer:oneLineDisplayAugmentations', ....
                    imageSizeString, ...
                    augmentationsString );
            elseif all(strcmp(this.DataAugmentation, 'none'))
                % Only normalization
                description = iGetMessageString( ...
                    'nnet_cnn:layer:ImageInputLayer:oneLineDisplayNormalization', ....
                    imageSizeString, ...
                    normalizationString );
            else
                % Both filled
                description = iGetMessageString( ...
                    'nnet_cnn:layer:ImageInputLayer:oneLineDisplay', ....
                    imageSizeString, ...
                    normalizationString, ...
                    augmentationsString );
            end
            
            type = iGetMessageString( 'nnet_cnn:layer:ImageInputLayer:Type' );
        end
        
        function groups = getPropertyGroups( this )
            generalParameters = {
                'Name'
                'InputSize'
                };
            
            hyperParameters = [
                {'DataAugmentation'
                'Normalization'
                'NormalizationDimension'}
                getNormalizationHyperParams(this) 
                ];
            
            groups = [
                this.propertyGroupGeneral( generalParameters )
                this.propertyGroupHyperparameters( hyperParameters )
                ];
        end
    end
    
    methods(Access=private)
        function proplist = getNormalizationHyperParams(this)
            layerProperties = nnet.internal.cnn.layer.util.getPublicVisibleProperties(this);
            if isempty(this.PrivateLayer.Transforms)
                internalNormParams = {};
            else
                internalNormParams = this.PrivateLayer.Transforms.Hyperparams;
            end
            proplist = intersect(layerProperties,internalNormParams);
            proplist = proplist(:);
        end
    end   
end

function messageString = iGetMessageString( varargin )
messageString = getString( message( varargin{:} ) );
end

function sizeString = i3DSizeToString( sizeVector )
% i3DSizeToString   Convert a 3-D size stored in a vector of 3 elements
% into a string separated by 'x'.
sizeString = [ ...
    int2str( sizeVector(1) ) ...
    'x' ...
    int2str( sizeVector(2) ) ...
    'x' ...
    int2str( sizeVector(3) ) ];
end

function string = iAugmentationsString( augmentations )
% iAugmentationsString   Convert a cell array of augmentation types into a
% single string. Each augmentation type will be wrapped in '' and separated
% by a coma.
% If augmentations is only one string it will simply return it wrapped in ''.
if iscell( augmentations )
    string = ['''' strjoin( augmentations, ''', ''' ) ''''];
else
    string = ['''' augmentations ''''];
end
end

function S = iSaveTransforms(transforms)
% iSaveTransforms   Save a vector of transformations in the form of an
% array of structures
S = arrayfun( @serialize, transforms );
end

function transforms = iLoadTransforms( S )
% iLoadTransforms   Load a vector of transformations from an array of
% structures S
transforms = nnet.internal.cnn.layer.InputTransform.empty();
for i=1:numel(S)
    transforms = horzcat(transforms, iLoadTransform( S(i) )); %#ok<AGROW>
end
end

function transform = iLoadTransform(S)
% iLoadTransform   Load a transformation from a structure S
transform = nnet.internal.cnn.layer.InputTransformFactory.deserialize( S );
end

function iAssertValidLayerName(name)
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateLayerName(name));
end

function iAssertValidNormalizationDimension(val,normalization)
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateNormalizationDimension(val,normalization) );
end

function iAssertValidStatistics(value, valueName, normalization, normalizationDim, inputSize)
iEvalAndThrow(@()...
    nnet.internal.cnn.layer.paramvalidation.validateNormalizationStatistics(...
    value, valueName, normalization, normalizationDim, inputSize));
end

function iEvalAndThrow(func)
% Omit the stack containing internal functions by throwing as caller
try
    func();
catch exception
    throwAsCaller(exception)
end
end

function S = iUpgradeFromVersionOneToVersionTwo( S )
% iUpgradeFromVersionOneToVersionTwo   Update version and add the
% IsAverageImageMeanPerChannel property with default value = false.
S.Version = 2.0;
S.IsAverageImageMeanPerChannel = false;
end

function S = iUpgradeFromVersionTwoToVersionThree( S )
% IsAverageImageMeanPerChannel   Update version and convert the saved
% average image to a per-channel mean if the property
% IsAverageImageMeanPerChannel was set to true.
S.Version = 3.0;
normObj = S.Normalization;
isZeroCenterNorm = ~isempty(normObj) && normObj.Type == "zerocenter";
if isZeroCenterNorm
    if S.IsAverageImageMeanPerChannel
        % In versions 2.0, the average image was stored in full size even if it
        % was defined as mean per channel. Recompute the mean per channel and
        % store it as average image for version 3.0.
        compactAvg = iComputeMeanPerChannel(normObj.AverageImage);
        S.Normalization.AverageImage = compactAvg;
    end
end
end

function S = iUpgradeFromVersionThreeToVersionFour(S)
% iUpgradeFromVersionThreeToVersionFour   Upgrade a v3 (2019a) saved struct to
% a v4 saved struct. This means adding the NormalizationDimension parameter.
S.Version = 4.0;
S.NormalizationDimension = 'auto';
end

function out = iComputeMeanPerChannel(dataAvg)
spatialDims = [1 2];
out = nnet.internal.cnn.layer.util.computeMeanOfMeans(dataAvg,spatialDims);
end