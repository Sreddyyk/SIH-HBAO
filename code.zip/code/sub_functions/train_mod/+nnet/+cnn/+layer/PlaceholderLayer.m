classdef PlaceholderLayer < nnet.layer.Layer
    % PlaceholderLayer   Placeholder deep learning layer.
    %
    %   A PlaceholderLayer can be an indication of an issue that occurred
    %   when creating a layer array, layer graph, SeriesNetwork, or
    %   DAGNetwork.
    %
    %   PlaceholderLayer properties:
    %       Name                   - A name for the placeholder layer.
    %       NumInputs              - The number of inputs of the layer.
    %       InputNames             - The names of the inputs of the layer.
    %       NumOutputs             - The number of outputs of the layer.
    %       OutputNames            - The names of the outputs of the layer.
    
    %   Copyright 2019 The MathWorks, Inc.
    
    methods
        function this = PlaceholderLayer(name,inputNames,outputNames)
            this.Name = name;
            this.Description = iGetMessageString('nnet_cnn:layer:PlaceholderLayer:oneLineDisplay');
            this.Type = iGetMessageString('nnet_cnn:layer:PlaceholderLayer:Type');
            if nargin > 1
                this.InputNames = inputNames;
                this.OutputNames = outputNames;
            end
        end
        
        function varargout = predict( ~, varargin ) %#ok<STOUT>
            throwAsCaller(MException(message('nnet_cnn:layer:PlaceholderLayer:CannotUseLayer')));
        end
        
        function varargout = forward( ~, varargin ) %#ok<STOUT>
            throwAsCaller(MException(message('nnet_cnn:layer:PlaceholderLayer:CannotUseLayer')));
        end
        
        function varargout = backward( ~, varargin ) %#ok<STOUT>
            throwAsCaller(MException(message('nnet_cnn:layer:PlaceholderLayer:CannotUseLayer')));
        end
    end
end

function messageString = iGetMessageString( varargin )
messageString = getString( message( varargin{:} ) );
end
