classdef TrainingOptionsRMSProp < nnet.cnn.TrainingOptions
    % TrainingOptionsRMSProp   Training options for root mean square propagation (RMSProp)
    %
    %   This class holds the training options for root mean square
    %   propagation (RMSProp)
    %
    %   TrainingOptionsRMSProp properties:
    %       SquaredGradientDecayFactor  - Decay factor for moving average
    %                                     of squared gradients.
    %       Epsilon                     - Offset for the denominator in the
    %                                     RMSProp update.
    %       InitialLearnRate            - Initial learning rate.
    %       LearnRateSchedule           - Method for lowering the global 
    %                                     learning rate during training.
    %       LearnRateDropFactor         - A multiplicative factor applied 
    %                                     to the learning rate every time a
    %                                     certain number of epochs passed 
    %                                     if 'LearnRateSchedule' is set to 
    %                                     'piecewise'.
    %       LearnRateDropPeriod         - The learning rate drop factor is 
    %                                     applied to the global learning 
    %                                     rate every time this number of 
    %                                     epochs is passed if  
    %                                     'LearnRateSchedule' is set to 
    %                                     'piecewise'.
    %       L2Regularization            - Factor for L2 regularization.
    %       GradientThresholdMethod     - Method for gradient thresholding.
    %       GradientThreshold           - Gradient threshold.
    %       MaxEpochs                   - Maximum number of epochs.
    %       MiniBatchSize               - The size of a mini-batch for
    %                                     training.
    %       Verbose                     - Flag for printing information to
    %                                     the command window.
    %       VerboseFrequency            - This only has an effect if
    %                                     'Verbose' is set to true. It
    %                                     specifies the number of
    %                                     iterations between printing to
    %                                     the command window.
    %       ValidationData              - Data to use for validation during
    %                                     training.
    %       ValidationFrequency         - Number of iterations between
    %                                     evaluations of validation
    %                                     metrics.
    %       ValidationPatience          - The number of times that the
    %                                     validation loss is allowed to be
    %                                     larger than or equal to the
    %                                     previously smallest loss before
    %                                     training is stopped.
    %       Shuffle                     - This controls if the training
    %                                     data is shuffled.
    %       CheckpointPath              - Path where checkpoint networks
    %                                     will be saved.
    %       ExecutionEnvironment        - What hardware to use for training
    %                                     the network.
    %       WorkerLoad                  - Specify compute and prefetch
    %                                     workers and their relative load
    %                                     in a parallel pool.
    %       OutputFcn                   - User callback to be executed at
    %                                     each iteration.
    %       Plots                       - Plots to display during training
    %       SequenceLength              - Sequence length of a mini-batch
    %                                     during training.
    %       SequencePaddingValue        - Value to pad mini-batches along
    %                                     the sequence dimension.
    %       SequencePaddingDirection    - Direction of padding or
    %                                     truncation.
    %       DispatchInBackground        - Whether to use pre-fetch queueing
    %                                     is used when reading data. 
    %
    %   Example:
    %       Create a set of training options for training with RMSProp. The
    %       learning rate will be reduced by a factor of 0.2 every 5
    %       epochs. The training will last for 20 epochs, and each
    %       iteration will use a mini-batch with 300 observations.
    %
    %       opts = trainingOptions('rmsprop', ...
    %           'Plots', 'training-progress', ...
    %           'LearnRateSchedule', 'piecewise', ...
    %           'LearnRateDropFactor', 0.2, ...
    %           'LearnRateDropPeriod', 5, ...
    %           'MaxEpochs', 20, ...
    %           'MiniBatchSize', 300);
    %
    %   See also trainingOptions, trainNetwork.
    
    % Copyright 2017-2019 The MathWorks, Inc.

    properties(Constant=true,Access=protected)

        SolverName = 'rmsprop'
        
        % Version   Number to identify the current version of this object
        %   This is used to ensure that objects from older versions are
        %   loaded correctly.
        Version = 3
    end
    
    properties
        % SquaredGradientDecayFactor   Decay factor for moving average of squared gradients
        %   A real scalar in [0,1) specifying the exponential decay rate
        %   for the squared gradient moving average.
        SquaredGradientDecayFactor {iValidatePropertyValue(SquaredGradientDecayFactor, 'SquaredGradientDecayFactor')} = iGetDefaultValue('SquaredGradientDecayFactor')
        
        % Epsilon   Offset for the denominator in the RMSProp update
        %   A positive real scalar specifying the offset to use in the
        %   denominator for the RMSProp update to prevent divide-by-zero
        %   problems.
        Epsilon {iValidatePropertyValue(Epsilon, 'Epsilon')} = iGetDefaultValue('Epsilon')
        
        % InitialLearnRate   Initial learning rate
        %   The initial learning rate that is used for training. If the
        %   learning rate is too low, training will take a long time, but
        %   if it is too high, the training is likely to get stuck at a
        %   suboptimal result.
        InitialLearnRate
    end
    
    methods
        function this = TrainingOptionsRMSProp(varargin)
            this = this@nnet.cnn.TrainingOptions(nnet.internal.cnn.options.TrainingOptionsDefinitionRMSProp,varargin{:});
        end
        
        function out = saveobj(this)
            out = saveobj@nnet.cnn.TrainingOptions(this);
            out.SquaredGradientDecayFactor = this.SquaredGradientDecayFactor;
            out.Epsilon = this.Epsilon;
        end
        
        function this=set.InitialLearnRate(this,newValue)
            iValidatePropertyValue(newValue,'InitialLearnRate');
            this.InitialLearnRate=newValue;
        end
    end
    
    methods(Static)
        function this = loadobj(in)
            if iTrainingOptionsAreFrom2018a(in)
                versionNumber19b = 2;
                in = iUpgradeTrainingOptionsFrom2018aTo2019b(in, versionNumber19b);
            end
            if iTrainingOptionsAreFrom2019b(in)
                versionNumber20a = 3;
                in = iUpgradeTrainingOptionsFrom2019bTo2020a(in, versionNumber20a);
            end
            % remove the Version field to prevent the parser from throwing
            % an error for an unmatched option.
            in = rmfield(in,'Version');
            this = nnet.cnn.TrainingOptionsRMSProp(in);
        end
    end
end

function tf = iTrainingOptionsAreFrom2018a(in)
% For training options from 2018a, Version will be 1
tf = in.Version == 1;
end

function tf = iTrainingOptionsAreFrom2019b(in)
% For training options from 2019b, Version will be 2
tf = in.Version == 2;
end

function inStruct = iUpgradeTrainingOptionsFrom2018aTo2019b(inStruct, version)
inStruct = nnet.internal.cnn.util.upgradeTrainingOptionsFrom2018aTo2019b(inStruct, version);
end

function inStruct = iUpgradeTrainingOptionsFrom2019bTo2020a(inStruct, version)
inStruct = nnet.internal.cnn.util.upgradeTrainingOptionsFrom2019bTo2020a(inStruct, version);
end

function val = iGetDefaultValue(optname)
persistent optionsDefinition;
if isempty(optionsDefinition)
    optionsDefinition=nnet.internal.cnn.options.TrainingOptionsDefinitionRMSProp;
end
val = optionsDefinition.getDefaultValue(optname);
end

function iValidatePropertyValue(x,optname)
persistent optionsDefinition;
if isempty(optionsDefinition)
    optionsDefinition=nnet.internal.cnn.options.TrainingOptionsDefinitionRMSProp;
end
optionsDefinition.validateValue(x,optname);
end