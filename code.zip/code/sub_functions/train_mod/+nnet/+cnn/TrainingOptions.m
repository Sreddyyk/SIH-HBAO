classdef(Abstract) TrainingOptions
    % TrainingOptions   Base training options for stochastic solvers.
    %
    %   This class holds the training options common to stochastic solvers.
    %
    %   TrainingOptions properties:
    %       LearnRateSchedule           - Method for lowering the global 
    %                                     learning rate during training.
    %       LearnRateDropFactor         - A multiplicative factor applied 
    %                                     to the learning rate every time a
    %                                     certain number of epochs passed 
    %                                     if 'LearnRateSchedule' is set to 
    %                                     'piecewise'.
    %       LearnRateDropPeriod         - The learning rate drop factor is 
    %                                     applied to the global learning 
    %                                     rate every time this number of 
    %                                     epochs is passed if  
    %                                     'LearnRateSchedule' is set to 
    %                                     'piecewise'.
    %       L2Regularization            - Factor for L2 regularization.
    %       GradientThresholdMethod     - Method for gradient thresholding.
    %       GradientThreshold           - Gradient threshold.
    %       MaxEpochs                   - Maximum number of epochs.
    %       MiniBatchSize               - The size of a mini-batch for
    %                                     training.
    %       Verbose                     - Flag for printing information to
    %                                     the command window.
    %       VerboseFrequency            - This only has an effect if
    %                                     'Verbose' is set to true. It
    %                                     specifies the number of
    %                                     iterations between printing to
    %                                     the command window.
    %       ValidationData              - Data to use for validation during
    %                                     training.
    %       ValidationFrequency         - Number of iterations between
    %                                     evaluations of validation
    %                                     metrics.
    %       ValidationPatience          - The number of times that the
    %                                     validation loss is allowed to be
    %                                     larger than or equal to the
    %                                     previously smallest loss before
    %                                     training is stopped.
    %       Shuffle                     - This controls if the training
    %                                     data is shuffled.
    %       CheckpointPath              - Path where checkpoint networks
    %                                     will be saved.
    %       ExecutionEnvironment        - What hardware to use for training
    %                                     the network.
    %       WorkerLoad                  - Specify compute and prefetch
    %                                     workers and their relative load
    %                                     in a parallel pool.
    %       OutputFcn                   - User callback to be executed at
    %                                     each iteration.
    %       Plots                       - Plots to display during training
    %       SequenceLength              - Sequence length of a mini-batch
    %                                     during training.
    %       SequencePaddingValue        - Value to pad mini-batches along
    %                                     the sequence dimension.
    %       SequencePaddingDirection    - Direction of padding or
    %                                     truncation.
    %       DispatchInBackground        - Flag to use prefetch queueing 
    %                                     when reading data.
    %       ResetInputNormalization     - Flag to reset input normalization.
    
    % Copyright 2017-2019 The MathWorks, Inc.
    
    properties(Abstract,Constant=true,Access=protected)
        % Version   Number to identify the current version of this object
        %   This is used to ensure that objects from older versions are
        %   loaded correctly.
        Version

        % SolverName TBD for every class derived from
        % TrainingOptions, e.g. TrainingOptionsADAM.SolverName =
        % 'adam'.
        SolverName
    end
    
    properties
        
        % LearnRateSchedule 
        LearnRateSchedule {iValidatePropertyValue(LearnRateSchedule,'LearnRateSchedule')} = iGetDefaultValue('LearnRateSchedule')
        
        % LearnRateDropFactor
        LearnRateDropFactor {iValidatePropertyValue(LearnRateDropFactor,'LearnRateDropFactor')} = iGetDefaultValue('LearnRateDropFactor')
        
        % LearnRateDropPeriod        
        LearnRateDropPeriod {iValidatePropertyValue(LearnRateDropPeriod,'LearnRateDropPeriod')} = iGetDefaultValue('LearnRateDropPeriod')        

        % L2Regularization   Factor for L2 regularization
        %   The factor for the L2 regularizer. It should be noted that each
        %   set of parameters in a layer can specify a multiplier for this
        %   L2 regularizer.
        L2Regularization {iValidatePropertyValue(L2Regularization,'L2Regularization')} = iGetDefaultValue('L2Regularization')

        % GradientThresholdMethod   Method used for gradient thresholding
        %   Method used for thresholding the gradient. Options are
        %   'global-l2norm','l2norm' (default) and 'absolute-value'.
        GradientThresholdMethod {iValidatePropertyValue(GradientThresholdMethod,'GradientThresholdMethod')} = iGetDefaultValue('GradientThresholdMethod')
    
        % GradientThreshold   Threshold used for gradients
        %   The threshold used to scale the gradients by the method
        %   specified in GradientThresholdMethod.
        GradientThreshold {iValidatePropertyValue(GradientThreshold,'GradientThreshold')} = iGetDefaultValue('GradientThreshold')

        % MaxEpochs   Maximum number of epochs
        %   The maximum number of epochs that will be used for training.
        %   Training will stop once this number of epochs has passed.
        MaxEpochs {iValidatePropertyValue(MaxEpochs,'MaxEpochs')} = iGetDefaultValue('MaxEpochs')

        % MiniBatchSize   The size of a mini-batch for training
        %   The size of the mini-batch used for each training iteration.
        MiniBatchSize {iValidatePropertyValue(MiniBatchSize,'MiniBatchSize')} = iGetDefaultValue('MiniBatchSize')
                                                            
        % Verbose   Flag for printing information to the command window
        %   If this is set to true, information on training progress will
        %   be printed to the command window. The default is true.
        Verbose logical {iValidatePropertyValue(Verbose,'Verbose')} = iGetDefaultValue('Verbose')

        % VerboseFrequency   Frequency for printing information
        %   This only has an effect if 'Verbose' is true. It specifies the
        %   number of iterations between printing to the command window.
        VerboseFrequency {iValidatePropertyValue(VerboseFrequency,'VerboseFrequency')} = iGetDefaultValue('VerboseFrequency')
 
        % ValidationData   Data to be used for validation purposes
        ValidationData {iValidatePropertyValue(ValidationData,'ValidationData')} = iGetDefaultValue('ValidationData')
        
        % ValidationFrequency   Frequency for computing validation metrics
        ValidationFrequency {iValidatePropertyValue(ValidationFrequency,'ValidationFrequency')} = iGetDefaultValue('ValidationFrequency')
        
        % ValidationPatience   Patience used to stop training
        ValidationPatience {iValidatePropertyValue(ValidationPatience,'ValidationPatience')} = iGetDefaultValue('ValidationPatience')
        
        % Shuffle   This controls when the training data is shuffled. It
        % can either be 'once' to shuffle data once before training,
        % 'every-epoch' to shuffle before every training epoch, or 'never'
        % in order not to shuffle the data.
        Shuffle {iValidatePropertyValue(Shuffle,'Shuffle')} = iGetDefaultValue('Shuffle')
        
        % CheckpointPath   This is the path where the checkpoint networks
        % will be saved. If empty, no checkpoint will be saved.
        CheckpointPath {iValidatePropertyValue(CheckpointPath,'CheckpointPath')} = iGetDefaultValue('CheckpointPath')
        
        % ExecutionEnvironment   Determines what hardware to use for
        % training the network.
        ExecutionEnvironment {iValidatePropertyValue(ExecutionEnvironment,'ExecutionEnvironment')} = iGetDefaultValue('ExecutionEnvironment')
        
        % WorkerLoad   Relative division of load between parallel workers
        % on different hardware
        WorkerLoad {iValidatePropertyValue(WorkerLoad,'WorkerLoad')} = iGetDefaultValue('WorkerLoad')
        
        % OutputFcn   Functions to call after each iteration, passing
        % training info from the current iteration, and returning true to
        % terminate training early
        OutputFcn {iValidatePropertyValue(OutputFcn,'OutputFcn')} = iGetDefaultValue('OutputFcn')
        
        % Plots   Plots to show during training
        Plots {iValidatePropertyValue(Plots,'Plots')} = iGetDefaultValue('Plots')
        
        % SequenceLength   Determines the strategy used to create
        % mini-batches of sequence data
        SequenceLength {iValidatePropertyValue(SequenceLength,'SequenceLength')} = iGetDefaultValue('SequenceLength')
        
        % SequencePaddingValue   Scalar value used to pad mini-batches in
        % the along the sequence dimension
        SequencePaddingValue double {iValidatePropertyValue(SequencePaddingValue,'SequencePaddingValue')} = iGetDefaultValue('SequencePaddingValue')
        
        % SequencePaddingDirection   Specify direction of sequence padding
        % or truncation
        SequencePaddingDirection {iValidatePropertyValue(SequencePaddingDirection,'SequencePaddingDirection')} = iGetDefaultValue('SequencePaddingDirection')
        
        % DispatchInBackground  Accelerate reading, augmentation, and
        % queuing of data.
        DispatchInBackground logical {iValidatePropertyValue(DispatchInBackground,'DispatchInBackground')} = iGetDefaultValue('DispatchInBackground')
        
        % ResetInputNormalization  Flag for clearing statistics in input
        % layers. Empty statistics are derived during training.
        ResetInputNormalization logical {iValidatePropertyValue(ResetInputNormalization,'ResetInputNormalization')} = iGetDefaultValue('ResetInputNormalization')
    end

    properties(Abstract)
        InitialLearnRate
    end
    
    properties(Hidden=true,Dependent,SetAccess=private)
        % LearnRateScheduleSettings   Settings for the learning rate schedule
        %   The learning rate schedule settings. This summarizes the
        %   options for the chosen learning rate schedule. The field Method
        %   gives the name of the method for adjusting the learning rate.
        %   This can either be 'none', in which case the learning rate is
        %   not altered, or 'piecewise', in which case there will be two
        %   additional fields. These fields are DropFactor, which is a
        %   multiplicative factor for dropping the learning rate, and
        %   DropPeriod, which determines how many epochs should pass
        %   before dropping the learning rate.
        LearnRateScheduleSettings
    end

    methods(Access = public)
        function this = TrainingOptions(defaultOptions,varargin)
            try
                keepUnmatched = true;
                [inputArguments, unmatched] = nnet.internal.cnn.options.readNVPsWithOptionsDefinitionParser(defaultOptions,keepUnmatched,varargin{:});
                this.errorForInvalidOptions(unmatched,this.SolverName);
                this = this.assignTrainingOptions(inputArguments);
            catch e
                % Reduce the stack trace of the error message by throwing as caller
                throwAsCaller(e)
            end
        end
        
        function out = saveobj(this)
            out.Version = this.Version;
            out.LearnRateSchedule     = this.LearnRateSchedule;
            out.LearnRateDropFactor   = this.LearnRateDropFactor;
            out.LearnRateDropPeriod   = this.LearnRateDropPeriod;
            out.L2Regularization = this.L2Regularization;
            out.GradientThresholdMethod = this.GradientThresholdMethod;
            out.GradientThreshold = this.GradientThreshold;
            out.MaxEpochs = this.MaxEpochs;
            out.MiniBatchSize = this.MiniBatchSize;
            out.Verbose = this.Verbose;
            out.VerboseFrequency = this.VerboseFrequency;
            out.ValidationData = this.ValidationData;
            out.ValidationFrequency = this.ValidationFrequency;
            out.ValidationPatience = this.ValidationPatience;
            out.Shuffle = this.Shuffle;
            out.CheckpointPath = this.CheckpointPath;
            out.ExecutionEnvironment = this.ExecutionEnvironment;
            out.WorkerLoad = this.WorkerLoad;
            out.OutputFcn = this.OutputFcn;
            out.Plots = this.Plots;
            out.SequenceLength = this.SequenceLength;
            out.SequencePaddingValue = this.SequencePaddingValue;
            out.SequencePaddingDirection = this.SequencePaddingDirection;
            out.DispatchInBackground = this.DispatchInBackground;
            out.ResetInputNormalization = this.ResetInputNormalization;
            out.InitialLearnRate = this.InitialLearnRate;

            if isa(out.Plots,'nnet.internal.cnn.ui.TrainingPlotter')
                out.Plots = 'training-progress';
            end
        end
    end

    % set methods for properties requiring nontrivial canonicalization
    methods
        function obj = set.GradientThresholdMethod(obj,newValue)
            obj.GradientThresholdMethod = iCanonicalizePropertyValue(newValue,'GradientThresholdMethod');
        end
        
        function obj = set.Shuffle(obj,newValue)
            obj.Shuffle = iCanonicalizePropertyValue(newValue,'Shuffle');
        end

        function obj = set.CheckpointPath(obj,newValue)
            obj.CheckpointPath = iCanonicalizePropertyValue(newValue,'CheckpointPath');
        end

        function obj = set.ExecutionEnvironment(obj,newValue)
            obj.ExecutionEnvironment = iCanonicalizePropertyValue(newValue,'ExecutionEnvironment');
        end
        
        function obj = set.Plots(obj,newValue)
            obj.Plots = iCanonicalizePropertyValue(newValue,'Plots');
        end
        
        function obj = set.SequenceLength(obj,newValue)
            obj.SequenceLength = iCanonicalizePropertyValue(newValue,'SequenceLength');
        end
        
        function obj = set.SequencePaddingDirection(obj,newValue)
            obj.SequencePaddingDirection = iCanonicalizePropertyValue(newValue,'SequencePaddingDirection');
        end
        
        function obj = set.LearnRateSchedule(obj,newValue)
            obj.LearnRateSchedule = iCanonicalizePropertyValue(newValue,'LearnRateSchedule');
        end

        % this set method is only used when loading from releases 2016a ||
        % 2016b, which would throw an error if they don't find it
        function obj = set.LearnRateScheduleSettings(obj,newValue)
            % the Method field is the only one which has different name
            % for NVP and how it is stored in LRS struct
            obj.LearnRateSchedule = newValue.Method;
            fn = fieldnames(newValue);
            for ii=1:numel(fn)
               if ~strcmp(fn{ii},'Method')
                   obj.(fn{ii}) = newValue.(fn{ii});
               end
            end
        end
        
        % get method for Dependent variable LearnRateScheduleSettings
        function LRScheduleSettings = get.LearnRateScheduleSettings(this)
            LRScheduleSettings = this.createLearnRateScheduleSettings( ...
                this.LearnRateSchedule, ...
                this.LearnRateDropFactor, ...
                this.LearnRateDropPeriod);
        end
    end

    methods(Access=private,Hidden=true)
        function this = assignTrainingOptions(this,inputArguments)
            fn = fieldnames(this);
            for ii = 1:numel(fn)
                this.(fn{ii}) = inputArguments.(fn{ii});
            end
            this.DispatchInBackground = iManageDispatchInBackground(inputArguments);
        end

        function errorForInvalidOptions(~,s,solverName)
            fieldNames = fieldnames(s);
            numFields = numel(fieldNames);
            if ( numFields > 0 )
                firstInvalidFieldName = fieldNames{1};
                error(message('nnet_cnn:TrainingOptionsSGDM:InvalidTrainingOptionForSolver',firstInvalidFieldName,solverName));
            end
        end
        
        function scheduleSettings = createLearnRateScheduleSettings(~, ...
                learnRateSchedule, learnRateDropFactor, learnRateDropPeriod)

            % method used to build the LearnRateScheduleSettings struct

            scheduleSettings = struct;
            switch learnRateSchedule
                case 'none'
                    scheduleSettings.Method = 'none';
                case 'piecewise'
                    scheduleSettings.Method = 'piecewise';
                    scheduleSettings.DropRateFactor = learnRateDropFactor;
                    scheduleSettings.DropPeriod = learnRateDropPeriod;
                otherwise
                    error(message('nnet_cnn:TrainingOptionsSGDM:InvalidLearningRateScheduleMethod'));
            end
        end
    end
    
    methods(Static,Hidden=true)
        function out = flattenLearnRateScheduleSettings(out, learnRateScheduleSettings)
            learnRateScedule = learnRateScheduleSettings.Method;
            out.LearnRateSchedule = learnRateScedule;
            switch learnRateScedule
                case 'none'
                    out.LearnRateDropFactor = [];
                    out.LearnRateDropPeriod = [];
                case 'piecewise'
                    out.LearnRateDropFactor = learnRateScheduleSettings.DropRateFactor;
                    out.LearnRateDropPeriod = learnRateScheduleSettings.DropPeriod;
                otherwise
                    error(message('nnet_cnn:TrainingOptionsSGDM:InvalidLearningRateScheduleMethod'));
            end
        end
    end
end

function tf = iManageDispatchInBackground(inputArguments)
if isfield(inputArguments,'DispatchInBackground')
    % DispatchInBackground was added to trainingOptions in
    % R2019a
    tf = inputArguments.DispatchInBackground;
else
    % For serialized prior versions, just assign
    % default value when deserializing.
    tf = false;
end
end

function val = iGetDefaultValue(optname)
persistent optionsDefinition;
if isempty(optionsDefinition)
    optionsDefinition=nnet.internal.cnn.options.TrainingOptionsDefinition;
end
val = optionsDefinition.getDefaultValue(optname);
end

function iValidatePropertyValue(x,optname)
persistent optionsDefinition;
if isempty(optionsDefinition)
    optionsDefinition=nnet.internal.cnn.options.TrainingOptionsDefinition;
end
optionsDefinition.validateValue(x,optname);
end

function canonicalizedval = iCanonicalizePropertyValue(x,optname)
persistent optionsDefinition;
if isempty(optionsDefinition)
    optionsDefinition=nnet.internal.cnn.options.TrainingOptionsDefinition;
end
canonicalizedval = optionsDefinition.canonicalizeValue(x,optname);
end