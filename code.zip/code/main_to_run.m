clc;
clear;
close all;
dbstop if error
warning off
 addpath(genpath(pwd));
addpath('sub_functions')
main_feat_extract;


